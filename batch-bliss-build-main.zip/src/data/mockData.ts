export interface Product {
  id: string;
  code: string;
  name: string;
  category: string;
  purchasePrice: number;
  salePrice: number;
  weightGrams: number;
  margin: number;
  stock: number;
  minStock: number;
  description?: string;
  supplierIds?: string[];
  /** Optional commercial reference. Older records fall back to code. */
  reference?: string;
  /** Physical grams currently available. Older records are derived from stock and weight. */
  availableGrams?: number;
  /** Weighted average acquisition cost per unit, or per gram for weight-based products. */
  averagePurchasePrice?: number;
  /** Date of the latest inventory entry that updated acquisition cost. */
  lastPurchaseDate?: string;
}


export type FinancialAccountKind = 'cash' | 'bank' | 'wallet';
export type FinancialMovementType =
  | 'sale_income' | 'expense' | 'inventory_purchase' | 'supplier_payment'
  | 'transfer' | 'transfer_out' | 'transfer_in' | 'opening_balance' | 'adjustment';

/** Normalized business meaning of a financial ledger entry. */
export type FinancialMovementCode =
  | 'SALE_PAYMENT' | 'SALE_CANCEL'
  | 'LAYAWAY_PAYMENT' | 'LAYAWAY_COMPLETED' | 'LAYAWAY_REFUND' | 'CUSTOMER_CREDIT' | 'CUSTOMER_CREDIT_USED'
  | 'CASH_IN' | 'CASH_OUT'
  | 'BANK_IN' | 'BANK_OUT' | 'BANK_TRANSFER'
  | 'EXPENSE' | 'PURCHASE_PAYMENT' | 'SUPPLIER_PAYMENT'
  | 'ADJUSTMENT' | 'OPENING_BALANCE' | 'REVERSAL';

export type FinancialReferenceType =
  | 'SALE' | 'LAYAWAY' | 'QUOTATION' | 'EXPENSE' | 'PURCHASE'
  | 'SUPPLIER_INVOICE' | 'FINANCIAL_ACCOUNT' | 'TRANSFER' | 'CUSTOMER' | 'MANUAL';

export type FinancialMovementStatus = 'POSTED' | 'COMPLETED' | 'REVERSED' | 'CANCELLED';

export interface FinancialAccount {
  id: string;
  name: string;
  kind: FinancialAccountKind;
  active: boolean;
  balance: number;
  createdAt: string;
  updatedAt: string;
}

export interface FinancialMovement {
  id: string;
  type: FinancialMovementType;
  amount: number;
  originAccountId?: string;
  destinationAccountId?: string;
  originBalanceBefore: number;
  originBalanceAfter: number;
  destinationBalanceBefore: number;
  destinationBalanceAfter: number;
  reference: string;
  documentType: string;
  documentId: string;
  observation: string;
  userId: string;
  userName: string;
  date: string;
  createdAt: string;
  /** Semantic ledger metadata. Optional for records created before V2.3. */
  movementCode?: FinancialMovementCode;
  relatedMovementId?: string;
  referenceType?: FinancialReferenceType;
  referenceId?: string;
  status?: FinancialMovementStatus;
  updatedAt?: string;
  notes?: string;
  /** Customer owning a credit movement. Optional for historical rows. */
  customerId?: string;
}

export interface PaymentAllocation {
  accountId: string;
  amount: number;
  paymentMethod?: string;
}

export interface FinancialSummary {
  cash: number; banks: number; totalFunds: number; accountsPayable: number;
  sales: number; costOfSales: number; grossProfit: number; expenses: number;
  netProfit: number; availableProfit: number; incomeToday: number; expensesToday: number;
}

export interface Contact {
  id: string;
  type: 'client' | 'supplier';
  name: string;
  document: string;
  phone: string;
  email: string;
  address: string;
  notes?: string;
}

export type InventoryAdjustmentType = 'increase' | 'decrease';

export interface InventoryCostValues {
  quantity: number;
  grams: number;
  totalCost: number;
  unitCost: number;
  valuePerGram: number;
  purchasePrice: number;
}

export type InventoryCostField = keyof InventoryCostValues;

export interface InventoryAdjustmentInput extends InventoryCostValues {
  operation?: 'create' | 'update' | 'delete';
  adjustmentId?: string;
  productId: string;
  type: InventoryAdjustmentType;
  notes: string;
  date: string;
  supplierId?: string;
  supplierName?: string;
  paymentStatus?: 'paid' | 'pending';
  accountId?: string;
  dueDate?: string;
}

export interface InventoryAdjustment {
  id: string;
  productId: string;
  productCode: string;
  productName: string;
  type: InventoryAdjustmentType;
  quantity: number;
  grams: number;
  totalCost: number;
  unitCost: number;
  valuePerGram: number;
  purchasePrice: number;
  averagePriceBefore: number;
  averagePriceAfter: number;
  stockBefore: number;
  stockAfter: number;
  gramsBefore: number;
  gramsAfter: number;
  notes: string;
  date: string;
  supplierId?: string;
  supplierName?: string;
  createdAt: string;
}

export interface InventoryAdjustmentProjection {
  stockBefore: number;
  stockAfter: number;
  gramsBefore: number;
  gramsAfter: number;
  purchasePriceAfter: number;
  averagePriceBefore: number;
  averagePriceAfter: number;
  marginAfter: number;
  weightGramsAfter: number;
}

const finiteNonNegative = (value: number): number =>
  Number.isFinite(value) && value >= 0 ? value : 0;

export function getProductAvailableGrams(product: Product): number {
  if (typeof product.availableGrams === 'number' && Number.isFinite(product.availableGrams)) return Math.max(0, product.availableGrams);
  return isSoldByWeight(product)
    ? Math.max(0, product.stock)
    : Math.max(0, product.weightGrams * product.stock);
}

export function getProductAveragePurchasePrice(product: Product): number {
  return typeof product.averagePurchasePrice === 'number' && Number.isFinite(product.averagePurchasePrice)
    ? Math.max(0, product.averagePurchasePrice)
    : Math.max(0, product.purchasePrice);
}

/**
 * Recalculates the complete cost tuple from the field the user edited.
 * Unit cost and purchase price intentionally remain synchronized so there is
 * one unambiguous current acquisition price.
 */
export function recalculateInventoryCosts(
  current: InventoryCostValues,
  field: InventoryCostField,
  nextValue: number,
): InventoryCostValues {
  const next: InventoryCostValues = {
    quantity: finiteNonNegative(current.quantity),
    grams: finiteNonNegative(current.grams),
    totalCost: finiteNonNegative(current.totalCost),
    unitCost: finiteNonNegative(current.unitCost),
    valuePerGram: finiteNonNegative(current.valuePerGram),
    purchasePrice: finiteNonNegative(current.purchasePrice),
  };

  next[field] = finiteNonNegative(nextValue);

  const syncFromTotal = () => {
    next.unitCost = next.quantity > 0 ? next.totalCost / next.quantity : 0;
    next.purchasePrice = next.unitCost;
    next.valuePerGram = next.grams > 0 ? next.totalCost / next.grams : 0;
  };

  if (field === 'totalCost') {
    syncFromTotal();
  } else if (field === 'unitCost' || field === 'purchasePrice') {
    const price = field === 'unitCost' ? next.unitCost : next.purchasePrice;
    next.unitCost = price;
    next.purchasePrice = price;
    next.totalCost = price * next.quantity;
    next.valuePerGram = next.grams > 0 ? next.totalCost / next.grams : 0;
  } else if (field === 'valuePerGram') {
    next.totalCost = next.valuePerGram * next.grams;
    next.unitCost = next.quantity > 0 ? next.totalCost / next.quantity : 0;
    next.purchasePrice = next.unitCost;
  } else if (field === 'quantity') {
    const price = next.purchasePrice || next.unitCost;
    if (price > 0) {
      next.unitCost = price;
      next.purchasePrice = price;
      next.totalCost = price * next.quantity;
      next.valuePerGram = next.grams > 0 ? next.totalCost / next.grams : 0;
    } else if (next.totalCost > 0) {
      syncFromTotal();
    }
  } else if (field === 'grams') {
    if (next.totalCost > 0) {
      next.valuePerGram = next.grams > 0 ? next.totalCost / next.grams : 0;
    } else if (next.valuePerGram > 0) {
      next.totalCost = next.valuePerGram * next.grams;
      next.unitCost = next.quantity > 0 ? next.totalCost / next.quantity : 0;
      next.purchasePrice = next.unitCost;
    }
  }

  return next;
}

export function calculateInventoryProjection(
  product: Product,
  input: InventoryAdjustmentInput,
): InventoryAdjustmentProjection {
  const increase = input.type === 'increase';
  const byWeight = isSoldByWeight(product);
  const stockBefore = finiteNonNegative(product.stock);
  const gramsBefore = getProductAvailableGrams(product);
  const stockDelta = byWeight ? input.grams : input.quantity;
  const stockAfter = increase ? stockBefore + stockDelta : stockBefore - stockDelta;
  const gramsAfter = increase ? gramsBefore + input.grams : gramsBefore - input.grams;
  const averagePriceBefore = getProductAveragePurchasePrice(product);

  let averagePriceAfter = averagePriceBefore;
  let purchasePriceAfter = product.purchasePrice;

  if (increase) {
    const basisBefore = byWeight ? gramsBefore : stockBefore;
    const basisIncoming = byWeight ? input.grams : input.quantity;
    const basisAfter = basisBefore + basisIncoming;
    averagePriceAfter = basisAfter > 0
      ? ((averagePriceBefore * basisBefore) + input.totalCost) / basisAfter
      : (byWeight ? input.valuePerGram : input.unitCost);
    purchasePriceAfter = byWeight ? input.valuePerGram : input.purchasePrice;
  }

  const weightGramsAfter = !byWeight && stockAfter > 0
    ? gramsAfter / stockAfter
    : product.weightGrams;
  const marginAfter = averagePriceAfter > 0
    ? ((product.salePrice - averagePriceAfter) / averagePriceAfter) * 100
    : 0;

  return {
    stockBefore,
    stockAfter,
    gramsBefore,
    gramsAfter,
    purchasePriceAfter,
    averagePriceBefore,
    averagePriceAfter,
    marginAfter,
    weightGramsAfter,
  };
}

export interface InvoiceItem {
  productId: string;
  code: string;
  name: string;

  quantity: number;

  weightGrams: number;

  unitPrice: number;

  subtotal: number;

  // NUEVOS CAMPOS
  isByWeight?: boolean;
  totalGramsSold?: number;

  priceModified?: boolean;
  originalPrice?: number;
  costPrice?: number;
}


export interface Invoice {
  id: string;
  number: string;
  clientId: string;
  clientName: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  date: string;
  status: 'paid' | 'pending' | 'cancelled';
  paymentMethod?: string;
  clientNotes?: string;
  internalNotes?: string;
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  tipoDocumento?: 'factura' | 'cotizacion';
  paymentAllocations?: PaymentAllocation[];
}

export interface PurchaseInvoice {
  id: string;
  number: string;
  supplierId: string;
  supplierName: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  date: string;
  status: 'paid' | 'pending' | 'cancelled';
  description?: string;
  paymentMethod?: string;
}

export interface ExpenseInvoice {
  id: string;
  number: string;
  supplierId: string;
  supplierName: string;
  total: number;
  description: string;
  date: string;
  paymentMethod: string;
  status: 'paid' | 'pending';
  accountId?: string;
}

export interface Quotation {
  id: string;
  number: string;
  clientId: string;
  clientName: string;
  items: InvoiceItem[];
  subtotal: number;
  discount: number;
  tax: number;
  total: number;
  date: string;
  validUntil: string;
  status: 'active' | 'accepted' | 'expired' | 'cancelled';
  notes?: string;
}

export const SOLD_BY_WEIGHT_CATEGORY = 'Venta por gramos';

export const categories = [
  'Anillos', 'Cadenas', 'Pulseras', 'Aretes', 'Dijes', 'Collares', 'Relojes', SOLD_BY_WEIGHT_CATEGORY, 'Otros'
];

export function isSoldByWeight(product: Product): boolean {
  return product.category === SOLD_BY_WEIGHT_CATEGORY;
}

export const paymentMethods = [
  'Efectivo', 'Transferencia', 'Tarjeta débito', 'Tarjeta crédito', 'Nequi', 'Daviplata', 'Otro'
];

// Static UUIDs for mock data referential integrity
const MOCK_IDS = {
  prod1: '00000000-0000-4000-a000-000000000001',
  prod2: '00000000-0000-4000-a000-000000000002',
  prod3: '00000000-0000-4000-a000-000000000003',
  prod4: '00000000-0000-4000-a000-000000000004',
  prod5: '00000000-0000-4000-a000-000000000005',
  prod6: '00000000-0000-4000-a000-000000000006',
  prod7: '00000000-0000-4000-a000-000000000007',
  prod8: '00000000-0000-4000-a000-000000000008',
  client1: '00000000-0000-4000-b000-000000000001',
  client2: '00000000-0000-4000-b000-000000000002',
  client5: '00000000-0000-4000-b000-000000000005',
  supplier3: '00000000-0000-4000-b000-000000000003',
  supplier4: '00000000-0000-4000-b000-000000000004',
};

export const mockProducts: Product[] = [
  { id: MOCK_IDS.prod1, code: 'AN-001', name: 'Anillo Solitario Oro 18K', category: 'Anillos', purchasePrice: 450000, salePrice: 680000, weightGrams: 3.5, margin: 51.1, stock: 8, minStock: 3, supplierIds: [MOCK_IDS.supplier3] },
  { id: MOCK_IDS.prod2, code: 'AN-002', name: 'Anillo Matrimonio Oro 14K', category: 'Anillos', purchasePrice: 320000, salePrice: 520000, weightGrams: 4.2, margin: 62.5, stock: 12, minStock: 5, supplierIds: [MOCK_IDS.supplier3, MOCK_IDS.supplier4] },
  { id: MOCK_IDS.prod3, code: 'CA-001', name: 'Cadena Eslabón Oro 18K', category: 'Cadenas', purchasePrice: 1200000, salePrice: 1850000, weightGrams: 15.0, margin: 54.2, stock: 4, minStock: 2, supplierIds: [MOCK_IDS.supplier3] },
  { id: MOCK_IDS.prod4, code: 'PU-001', name: 'Pulsera Tejido Oro 14K', category: 'Pulseras', purchasePrice: 580000, salePrice: 890000, weightGrams: 8.5, margin: 53.4, stock: 6, minStock: 3, supplierIds: [MOCK_IDS.supplier4] },
  { id: MOCK_IDS.prod5, code: 'AR-001', name: 'Aretes Perla Oro 18K', category: 'Aretes', purchasePrice: 280000, salePrice: 450000, weightGrams: 2.8, margin: 60.7, stock: 15, minStock: 5, supplierIds: [MOCK_IDS.supplier3] },
  { id: MOCK_IDS.prod6, code: 'DI-001', name: 'Dije Corazón Oro 18K', category: 'Dijes', purchasePrice: 180000, salePrice: 320000, weightGrams: 1.8, margin: 77.8, stock: 2, minStock: 3, description: 'Dije con incrustación de circón', supplierIds: [MOCK_IDS.supplier3, MOCK_IDS.supplier4] },
  { id: MOCK_IDS.prod7, code: 'CO-001', name: 'Collar Gargantilla Oro 14K', category: 'Collares', purchasePrice: 950000, salePrice: 1400000, weightGrams: 12.0, margin: 47.4, stock: 3, minStock: 2, supplierIds: [MOCK_IDS.supplier4] },
  { id: MOCK_IDS.prod8, code: 'CA-002', name: 'Cadena Cartier Oro 18K', category: 'Cadenas', purchasePrice: 2100000, salePrice: 3200000, weightGrams: 22.0, margin: 52.4, stock: 1, minStock: 2, supplierIds: [MOCK_IDS.supplier3] },
];

export const mockContacts: Contact[] = [
  { id: MOCK_IDS.client1, type: 'client', name: 'María García López', document: '1023456789', phone: '3001234567', email: 'maria@email.com', address: 'Cra 15 #45-20, Bogotá' },
  { id: MOCK_IDS.client2, type: 'client', name: 'Carlos Rodríguez', document: '80123456', phone: '3109876543', email: 'carlos@email.com', address: 'Calle 80 #12-34, Medellín' },
  { id: MOCK_IDS.supplier3, type: 'supplier', name: 'Oro Fino S.A.S', document: '900123456-1', phone: '6012345678', email: 'ventas@orofino.com', address: 'Zona Industrial, Bogotá', notes: 'Proveedor principal de oro 18K' },
  { id: MOCK_IDS.supplier4, type: 'supplier', name: 'Joyería Mayorista del Valle', document: '900654321-2', phone: '6027654321', email: 'info@jmvalle.com', address: 'Cali, Valle del Cauca' },
  { id: MOCK_IDS.client5, type: 'client', name: 'Ana Martínez Ruiz', document: '52987654', phone: '3205551234', email: 'ana.martinez@email.com', address: 'Av 68 #23-15, Bogotá' },
];



export const mockInvoices: Invoice[] = [
  {
    id: '00000000-0000-4000-d000-000000000001', number: 'FAC-0001', clientId: MOCK_IDS.client1, clientName: 'María García López',
    items: [
      { productId: MOCK_IDS.prod1, code: 'AN-001', name: 'Anillo Solitario Oro 18K', quantity: 1, weightGrams: 3.5, unitPrice: 680000, subtotal: 680000 },
      { productId: MOCK_IDS.prod5, code: 'AR-001', name: 'Aretes Perla Oro 18K', quantity: 1, weightGrams: 2.8, unitPrice: 450000, subtotal: 450000 },
    ],
    subtotal: 1130000, discount: 0, tax: 0, total: 1130000, date: '2026-02-24', status: 'paid', paymentMethod: 'Efectivo'
  },
  {
    id: '00000000-0000-4000-d000-000000000002', number: 'FAC-0002', clientId: MOCK_IDS.client2, clientName: 'Carlos Rodríguez',
    items: [
      { productId: MOCK_IDS.prod3, code: 'CA-001', name: 'Cadena Eslabón Oro 18K', quantity: 1, weightGrams: 15.0, unitPrice: 1850000, subtotal: 1850000 },
    ],
    subtotal: 1850000, discount: 50000, tax: 0, total: 1800000, date: '2026-02-24', status: 'paid', paymentMethod: 'Transferencia'
  },
  {
    id: '00000000-0000-4000-d000-000000000003', number: 'FAC-0003', clientId: MOCK_IDS.client5, clientName: 'Ana Martínez Ruiz',
    items: [
      { productId: MOCK_IDS.prod4, code: 'PU-001', name: 'Pulsera Tejido Oro 14K', quantity: 1, weightGrams: 8.5, unitPrice: 890000, subtotal: 890000 },
    ],
    subtotal: 890000, discount: 0, tax: 0, total: 890000, date: '2026-02-23', status: 'pending', paymentMethod: 'Nequi'
  },
];

export const mockExpenses: ExpenseInvoice[] = [
  { id: '00000000-0000-4000-f000-000000000001', number: 'GAS-0001', supplierId: MOCK_IDS.supplier3, supplierName: 'Oro Fino S.A.S', total: 150000, description: 'Servicio de pulido y acabado', date: '2026-02-22', paymentMethod: 'Efectivo', status: 'paid' },
];

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(value);
}
