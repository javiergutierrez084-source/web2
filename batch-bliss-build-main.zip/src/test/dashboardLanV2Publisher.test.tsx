// @vitest-environment jsdom
import { act, render } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  state: {
    products: [],
    categories: ['Anillos'],
    contacts: [],
    invoices: [],
    purchaseInvoices: [],
    expenses: [],
    layaways: [],
    cashSessions: [],
    financialAccounts: [],
    financialMovements: [],
    financialSummary: null,
    isLoading: false,
  } as Record<string, unknown>,
  notify: vi.fn(async () => null),
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => mocks.state,
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ mode: 'lan', role: 'server' }),
}));

import LanRepositoryChangePublisher from '@/components/LanRepositoryChangePublisher';

beforeEach(() => {
  Object.assign(mocks.state, {
    products: [],
    categories: ['Anillos'],
    contacts: [],
    invoices: [],
    purchaseInvoices: [],
    expenses: [],
    layaways: [],
    cashSessions: [],
    financialAccounts: [],
    financialMovements: [],
    financialSummary: null,
    isLoading: false,
  });
  mocks.notify.mockClear();
  window.joyaControlLan = { notifyRepositoryChanged: mocks.notify } as typeof window.joyaControlLan;
});

describe('Dashboard LAN V2 automatic refresh publisher', () => {
  it.each([
    ['sale', 'invoices', [{ id: 'i1', number: 'F-1', clientId: 'c1', clientName: 'Ana', date: '2026-07-20', status: 'paid', total: 100, items: [] }]],
    ['purchase', 'purchaseInvoices', [{ id: 'p1', date: '2026-07-20', status: 'paid', total: 80 }]],
    ['customer', 'contacts', [{ id: 'c1', type: 'client', name: 'Ana', document: '1' }]],
    ['layaway', 'layaways', [{ id: 'l1', completed: false, invoiceId: 'i1', invoice: { status: 'pending', clientId: 'c1', total: 200 }, payments: [] }]],
    ['cash', 'cashSessions', [{ id: 'cs1', date: '2026-07-20', openedAt: '08:00', openedBy: 'Admin' }]],
    ['financial account', 'financialAccounts', [{ id: 'account-caja-separados', name: 'Caja Separados', kind: 'cash', active: true, balance: 100 }]],
    ['financial movement', 'financialMovements', [{ id: 'fm1', type: 'transfer', amount: 100, originAccountId: 'account-caja-separados', destinationAccountId: 'account-caja-principal', date: '2026-07-20' }]],
  ])('reuses the established Repository event channel after a %s change', async (_label, field, value) => {
    const view = render(<LanRepositoryChangePublisher />);

    mocks.state[field] = value;
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    expect(mocks.notify).toHaveBeenCalledTimes(1);
    expect(mocks.notify).toHaveBeenCalledWith('PRODUCTS_UPDATED');
  });
});
