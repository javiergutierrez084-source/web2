// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  buildOwnerFinanceExportFilename,
  buildOwnerFinanceExportSummary,
  buildOwnerFinanceReportRows,
} from '@/lib/OwnerFinanceExports';
import {
  cancelOwnerWithdrawalLocal,
  createOwnerWithdrawalLocal,
  fetchOwnerFinanceWorkspaceLocal,
  saveOwnerFinanceSettingsLocal,
} from '@/lib/OwnerFinanceLocalDataService';

const user = {
  id: 'owner-user-v2',
  username: 'owner-v2',
  display_name: 'Propietario V2',
  password_hash: '',
  role: 'master' as const,
  active: true,
  created_at: '2026-07-01T10:00:00.000Z',
  last_login: null,
};

const account = {
  id: 'account-owner-v2',
  name: 'Caja Principal',
  kind: 'cash' as const,
  active: true,
  balance: 50_000,
  created_at: '2026-07-01T10:00:00.000Z',
  updated_at: '2026-07-01T10:00:00.000Z',
};

async function addInvoice(id: string, date: string, total: number, cost: number) {
  await localDb.invoices.add({
    id,
    number: id,
    client_id: '',
    client_name: 'Cliente',
    subtotal: total,
    discount: 0,
    tax: 0,
    total,
    date,
    status: 'paid',
    payment_method: 'EFECTIVO',
    client_notes: '',
    internal_notes: '',
    cancellation_reason: '',
    cancelled_at: '',
    cancelled_by: '',
    tipo_documento: 'FACTURA',
    created_at: date,
  });
  await localDb.invoice_items.add({
    invoice_id: id,
    product_id: `product-${id}`,
    code: id,
    name: `Producto ${id}`,
    quantity: 1,
    weight_grams: 0,
    unit_price: total,
    subtotal: total,
    price_modified: false,
    original_price: total,
    cost_price: cost,
  });
}

async function addExpense(id: string, date: string, total: number) {
  await localDb.expenses.add({
    id,
    number: id,
    supplier_id: '',
    supplier_name: '',
    total,
    description: 'Gasto del período',
    date,
    payment_method: 'EFECTIVO',
    status: 'paid',
    created_at: date,
    account_id: account.id,
  });
}

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.financial_accounts.put(account);
  setSession({
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    role: user.role,
  });
});

describe('Finanzas del Propietario V2 - períodos mensuales', () => {
  it('cambia de período y carga utilidad, configuración e historial exclusivamente del mes seleccionado', async () => {
    await addInvoice('FV-JUN', '2026-06-15T10:00:00.000Z', 1_000, 200);
    await addExpense('EG-JUN', '2026-06-20T10:00:00.000Z', 100);
    await addInvoice('FV-JUL', '2026-07-10T10:00:00.000Z', 800, 300);

    await saveOwnerFinanceSettingsLocal({
      periodKey: '2026-06',
      periodStatus: 'OPEN',
      projectedWithdrawalPercentage: 50,
      monthlyProfitGoal: 1_000,
      financialPeriod: 'MONTHLY',
    });
    await saveOwnerFinanceSettingsLocal({
      periodKey: '2026-07',
      periodStatus: 'OPEN',
      projectedWithdrawalPercentage: 30,
      monthlyProfitGoal: 2_000,
      financialPeriod: 'MONTHLY',
    });

    const initialJune = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    const concept = initialJune.concepts.find(item => item.active)!;
    await createOwnerWithdrawalLocal({
      withdrawalDate: '2026-06-25T15:30:00.000Z',
      conceptId: concept.id,
      amount: 200,
      observations: 'Retiro de junio',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    });

    const june = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    expect(june.selectedPeriod).toBe('2026-06');
    expect(june.settings).toMatchObject({
      periodKey: '2026-06',
      periodStatus: 'OPEN',
      projectedWithdrawalPercentage: 50,
      monthlyProfitGoal: 1_000,
    });
    expect(june.dashboard).toMatchObject({
      profitMonth: 500,
      availableProfit: 500,
      withdrawnProfit: 200,
      availableBalance: 500,
      suggestedWithdrawalValue: 250,
      monthlyGoalProgressPercentage: 50,
    });
    expect(june.withdrawals).toHaveLength(1);
    expect(june.withdrawals[0]).toMatchObject({ periodKey: '2026-06', amount: 200 });

    const july = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-07' });
    expect(july.selectedPeriod).toBe('2026-07');
    expect(july.dashboard).toMatchObject({
      profitMonth: 500,
      availableProfit: 500,
      withdrawnProfit: 0,
      availableBalance: 500,
      suggestedWithdrawalValue: 150,
    });
    expect(july.withdrawals).toHaveLength(0);
    expect(july.periods.map(period => period.key).slice(0, 2)).toEqual(['2026-07', '2026-06']);
  });

  it('asocia el retiro al mes seleccionado y nunca lo mueve automáticamente al mes actual', async () => {
    const june = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    const concept = june.concepts.find(item => item.active)!;
    const selectedPeriodWithdrawal = {
      withdrawalDate: '2026-06-30T23:50',
      periodKey: '2026-06',
      conceptId: concept.id,
      amount: 350,
      observations: 'Liquidación histórica',
      accountId: account.id,
      paymentMethod: 'TRANSFERENCIA',
    };
    const withdrawal = await createOwnerWithdrawalLocal(selectedPeriodWithdrawal);

    expect(withdrawal.periodKey).toBe('2026-06');
    expect((await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' })).withdrawals)
      .toContainEqual(expect.objectContaining({ id: withdrawal.id, periodKey: '2026-06' }));
    expect((await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-07' })).withdrawals)
      .not.toContainEqual(expect.objectContaining({ id: withdrawal.id }));

    const movement = await localDb.financial_movements.get(withdrawal.financialMovementId);
    expect(JSON.parse(movement!.notes || '{}')).toMatchObject({ periodKey: '2026-06' });

    await expect(createOwnerWithdrawalLocal({
      ...selectedPeriodWithdrawal,
      withdrawalDate: '2026-07-01T00:10',
    })).rejects.toThrow('OWNER_WITHDRAWAL_PERIOD_MISMATCH');
  });

  it('cierra y reabre el período sin generar movimientos ni modificar valores financieros', async () => {
    await addInvoice('FV-CLOSE', '2026-06-10T10:00:00.000Z', 1_000, 400);
    const june = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    const concept = june.concepts.find(item => item.active)!;
    const withdrawal = await createOwnerWithdrawalLocal({
      withdrawalDate: '2026-06-15T12:00:00.000Z',
      conceptId: concept.id,
      amount: 100,
      observations: 'Retiro previo al cierre',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    });
    const movementsBeforeClose = await localDb.financial_movements.count();
    const balanceBeforeClose = (await localDb.financial_accounts.get(account.id))!.balance;

    await saveOwnerFinanceSettingsLocal({
      ...june.settings,
      periodKey: '2026-06',
      periodStatus: 'CLOSED',
    });

    const closed = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    expect(closed.settings.periodStatus).toBe('CLOSED');
    expect(closed.periods.find(period => period.key === '2026-06')?.status).toBe('CLOSED');
    expect(await localDb.financial_movements.count()).toBe(movementsBeforeClose);
    expect((await localDb.financial_accounts.get(account.id))!.balance).toBe(balanceBeforeClose);

    await expect(createOwnerWithdrawalLocal({
      withdrawalDate: '2026-06-20T12:00:00.000Z',
      conceptId: concept.id,
      amount: 50,
      observations: '',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    })).rejects.toThrow('OWNER_FINANCE_PERIOD_CLOSED');
    await expect(cancelOwnerWithdrawalLocal(withdrawal.id, 'No permitido durante cierre'))
      .rejects.toThrow('OWNER_FINANCE_PERIOD_CLOSED');

    await saveOwnerFinanceSettingsLocal({
      ...closed.settings,
      periodKey: '2026-06',
      periodStatus: 'OPEN',
    });
    const reopened = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    expect(reopened.settings.periodStatus).toBe('OPEN');
    expect(reopened.dashboard).toMatchObject(closed.dashboard);
    expect(await localDb.financial_movements.count()).toBe(movementsBeforeClose);

    const cancelled = await cancelOwnerWithdrawalLocal(withdrawal.id, 'Retiro duplicado');
    expect(cancelled.status).toBe('ANULADO');
    const afterCancellation = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    expect(afterCancellation.dashboard).toMatchObject({
      profitMonth: 600,
      withdrawnProfit: 0,
      availableBalance: 600,
    });
    expect(afterCancellation.withdrawals).toContainEqual(expect.objectContaining({
      id: withdrawal.id,
      status: 'ANULADO',
    }));
  });

  it('actualiza el resumen de reportes con datos exclusivos del período seleccionado', async () => {
    await addInvoice('FV-REPORT-JUN', '2026-06-12T10:00:00.000Z', 1_200, 400);
    await addInvoice('FV-REPORT-JUL', '2026-07-12T10:00:00.000Z', 9_000, 1_000);
    await saveOwnerFinanceSettingsLocal({
      periodKey: '2026-06',
      periodStatus: 'OPEN',
      projectedWithdrawalPercentage: 25,
      monthlyProfitGoal: 1_000,
      financialPeriod: 'MONTHLY',
    });

    const june = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    const period = june.periods.find(item => item.key === '2026-06')!;
    const summary = buildOwnerFinanceExportSummary(june.dashboard, period);

    expect(summary).toMatchObject({
      periodKey: '2026-06',
      generatedProfit: 800,
      monthlyProfitGoal: 1_000,
      compliancePercentage: 80,
      withdrawnProfit: 0,
      availableBalance: 800,
    });
    expect(summary.generatedProfit).not.toBe(8_000);
  });

  it('bloquea el cierre de períodos futuros en la capa de servicio', async () => {
    const futurePeriod = '2999-01';
    const workspace = await fetchOwnerFinanceWorkspaceLocal({ periodKey: futurePeriod });

    await expect(saveOwnerFinanceSettingsLocal({
      ...workspace.settings,
      periodKey: futurePeriod,
      periodStatus: 'CLOSED',
    })).rejects.toThrow('OWNER_FINANCE_FUTURE_PERIOD_CLOSE_NOT_ALLOWED');

    const afterAttempt = await fetchOwnerFinanceWorkspaceLocal({ periodKey: futurePeriod });
    expect(afterAttempt.settings.periodStatus).toBe('OPEN');
    expect(afterAttempt.settings.closedAt).toBeNull();
  });

  it('conserva usuario, fecha y hora del cierre y de la reapertura', async () => {
    const periodKey = '2026-06';
    const initial = await fetchOwnerFinanceWorkspaceLocal({ periodKey });

    await saveOwnerFinanceSettingsLocal({
      ...initial.settings,
      periodKey,
      periodStatus: 'CLOSED',
    });
    const closed = await fetchOwnerFinanceWorkspaceLocal({ periodKey });
    expect(closed.settings).toMatchObject({
      periodStatus: 'CLOSED',
      closedBy: user.display_name,
    });
    expect(new Date(closed.settings.closedAt || '').toString()).not.toBe('Invalid Date');

    await saveOwnerFinanceSettingsLocal({
      ...closed.settings,
      periodKey,
      periodStatus: 'OPEN',
    });
    const reopened = await fetchOwnerFinanceWorkspaceLocal({ periodKey });
    expect(reopened.settings).toMatchObject({
      periodStatus: 'OPEN',
      closedBy: user.display_name,
      reopenedBy: user.display_name,
    });
    expect(new Date(reopened.settings.reopenedAt || '').toString()).not.toBe('Invalid Date');
    expect(reopened.settings.closedAt).toBe(closed.settings.closedAt);
  });

  it('normaliza transparentemente configuraciones antiguas con campos faltantes o nulos', async () => {
    await localDb.system_settings.put({
      id: 'owner-finance',
      backup_enabled: false,
      backup_interval: 'daily',
      backup_hour: 0,
      backup_folder: '',
      max_backups: 0,
      delete_old_backups: false,
      verify_checksum: false,
      backup_before_restore: false,
      backup_on_startup: false,
      backup_on_exit: false,
      backup_on_import: false,
      compression_enabled: false,
      default_destination: 'local',
      owner_projected_withdrawal_percentage: undefined,
      owner_monthly_profit_goal: undefined,
      owner_financial_period: undefined,
      owner_withdrawal_concepts: null,
      owner_finance_periods: [
        { period_key: '2025-05' },
        null,
        { period_key: 'fecha-invalida', status: null },
      ],
    } as never);

    const legacy = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2025-05' });
    expect(legacy.settings).toMatchObject({
      periodKey: '2025-05',
      periodStatus: 'OPEN',
      projectedWithdrawalPercentage: 30,
      monthlyProfitGoal: 0,
      financialPeriod: 'MONTHLY',
      closedAt: null,
      closedBy: null,
      reopenedAt: null,
      reopenedBy: null,
    });
    expect(legacy.concepts).toHaveLength(6);

    const persisted = await localDb.system_settings.get('owner-finance') as unknown as {
      owner_finance_periods: Array<Record<string, unknown>>;
    };
    expect(persisted.owner_finance_periods.find(item => item.period_key === '2025-05')).toMatchObject({
      projected_withdrawal_percentage: 30,
      monthly_profit_goal: 0,
      financial_period: 'MONTHLY',
      status: 'OPEN',
    });
  });

  it('genera resumen y nombres de reportes con período, estado, fecha y usuario', async () => {
    await addInvoice('FV-EXPORT', '2026-06-12T10:00:00.000Z', 1_200, 400);
    const workspace = await fetchOwnerFinanceWorkspaceLocal({ periodKey: '2026-06' });
    const period = { ...workspace.periods.find(item => item.key === '2026-06')!, status: 'CLOSED' as const };
    const summary = buildOwnerFinanceExportSummary(workspace.dashboard, period, {
      generatedAt: '2026-07-26T14:30:00.000Z',
      generatedBy: 'Propietario V2',
    });
    const reportRows = buildOwnerFinanceReportRows(summary);

    expect(summary).toMatchObject({
      periodKey: '2026-06',
      periodStatus: 'Cerrado',
      generatedAt: '2026-07-26T14:30:00.000Z',
      generatedBy: 'Propietario V2',
      generatedProfit: 800,
    });
    expect(reportRows).toEqual(expect.arrayContaining([
      { Indicador: 'Período', Valor: period.label },
      { Indicador: 'Estado del período', Valor: 'Cerrado' },
      { Indicador: 'Usuario que generó el reporte', Valor: 'Propietario V2' },
      { Indicador: 'Utilidad generada', Valor: 800 },
    ]));
    expect(buildOwnerFinanceExportFilename('2026-07', 'pdf')).toBe('Finanzas_2026-07.pdf');
    expect(buildOwnerFinanceExportFilename('2026-07', 'xlsx')).toBe('Finanzas_2026-07.xlsx');
    expect(buildOwnerFinanceExportFilename('2026-07', 'csv')).toBe('Finanzas_2026-07.csv');
  });

});
