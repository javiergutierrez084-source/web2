// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { buildBackupEnvelope, importAllData } from '@/lib/backup';

const originalProduct = {
  id: 'backup-product-1',
  code: 'BK-001',
  name: 'Producto respaldo',
  category: 'Prueba',
  purchase_price: 100_000,
  sale_price: 150_000,
  weight_grams: 5,
  margin: 50,
  stock: 2,
  min_stock: 1,
  description: 'Registro de validación',
  supplier_ids: [],
  created_at: '2026-07-16T12:00:00.000Z',
};

describe('Backup V6 round-trip', () => {
  beforeEach(async () => {
    await localDb.delete();
    await localDb.open();
  });

  it('restaura la información respaldada de forma idéntica', async () => {
    await localDb.products.put(originalProduct);
    const backup = await buildBackupEnvelope({ createdBy: 'qa-final', deviceId: 'qa-device' });

    await localDb.products.update(originalProduct.id, { name: 'Producto alterado', stock: 99 });
    await importAllData(backup);

    const restored = await localDb.products.get(originalProduct.id);
    expect(restored).toEqual(originalProduct);
    expect(backup.metadata.recordCount).toBeGreaterThanOrEqual(1);
    expect(backup.checksum).toBeTruthy();
  });
});
