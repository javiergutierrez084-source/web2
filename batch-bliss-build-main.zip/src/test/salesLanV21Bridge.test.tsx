// @vitest-environment jsdom
import { act, render } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  repositoryHandler: null as null | ((request: { method: string; args?: Record<string, unknown> }) => Promise<unknown>),
  reload: vi.fn(async () => undefined),
  workspace: { company: {}, contacts: [], invoices: [], layaways: [], quotations: [], financialAccounts: [], financialMovements: [], financialSummary: null },
  getSalesWorkspace: vi.fn(),
  querySales: vi.fn(),
  getSaleById: vi.fn(),
  createSale: vi.fn(),
  cancelSale: vi.fn(),
  addLayawayPayment: vi.fn(),
  deleteLayaway: vi.fn(),
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    products: [], contacts: [], invoices: [], purchaseInvoices: [], expenses: [], layaways: [],
    cashSessions: [], financialAccounts: [], financialMovements: [], financialSummary: null,
    reloadFromDatabase: mocks.reload,
  }),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => ({ loginUser: vi.fn() }),
}));

vi.mock('@/lib/DashboardRepositoryService', () => ({
  DashboardRepositoryService: { buildServerMetrics: vi.fn() },
}));

vi.mock('@/lib/SalesRepositoryService', () => ({
  SalesRepositoryService: {
    getSalesWorkspace: mocks.getSalesWorkspace,
    querySales: mocks.querySales,
    getSaleById: mocks.getSaleById,
    createSale: mocks.createSale,
    updateSaleStatus: vi.fn(),
    cancelSale: mocks.cancelSale,
    applyContactChanges: vi.fn(),
    createQuotation: vi.fn(),
    updateQuotationStatus: vi.fn(),
    createLayaway: vi.fn(),
    updateLayaway: vi.fn(),
    deleteLayaway: mocks.deleteLayaway,
    addLayawayPayment: mocks.addLayawayPayment,
    completeLayaway: vi.fn(),
  },
}));

import LanAuthenticationBridge from '@/components/LanAuthenticationBridge';

beforeEach(() => {
  mocks.repositoryHandler = null;
  mocks.reload.mockClear();
  mocks.getSalesWorkspace.mockReset().mockResolvedValue(mocks.workspace);
  mocks.querySales.mockReset().mockResolvedValue([]);
  mocks.getSaleById.mockReset().mockResolvedValue(null);
  mocks.createSale.mockReset().mockResolvedValue([]);
  mocks.cancelSale.mockReset().mockResolvedValue({
    invoiceId: 'i1', cancelledAt: '2026-07-20', cancelledBy: 'Master', restoredProducts: [],
  });
  mocks.deleteLayaway.mockReset().mockResolvedValue({ invoiceId: 'i1', restoredProducts: [], resolution: 'credit', creditAmount: 20 });
  mocks.addLayawayPayment.mockReset().mockResolvedValue({
    payment: { id: 'p1', amount: 20, date: '2026-07-20', method: 'Efectivo' },
    invoiceId: 'i1', completed: false,
  });

  window.joyaControlLan = {
    onAuthRequest: () => () => undefined,
    onRepositoryRequest: handler => {
      mocks.repositoryHandler = request => handler({
        ...request,
        args: {
          ...(request.args || {}),
          __joyaControlAuthorizedLanSession: {
            id: 'server-authorized-user',
            username: 'master',
            displayName: 'Master',
            role: 'master',
            permissions: ['manage_contacts', 'create_sales', 'edit_sales', 'cancel_invoices', 'manage_layaways'],
          },
        },
      });
      return () => { mocks.repositoryHandler = null; };
    },
  } as typeof window.joyaControlLan;
});

describe('Sales LAN V2.1 server dispatcher', () => {
  it('dispatches Sales reads and refreshes Repository-backed React state after writes', async () => {
    const view = render(<LanAuthenticationBridge />);
    expect(mocks.repositoryHandler).not.toBeNull();

    await expect(mocks.repositoryHandler?.({ method: 'getSalesWorkspace', args: {} })).resolves.toEqual(mocks.workspace);
    await expect(mocks.repositoryHandler?.({ method: 'querySales', args: { query: { text: 'FAC' } } })).resolves.toEqual([]);
    await expect(mocks.repositoryHandler?.({ method: 'getSaleById', args: { id: 'i1' } })).resolves.toBeNull();

    await act(async () => {
      await mocks.repositoryHandler?.({
        method: 'createSale',
        args: { invoice: { id: 'i1' }, allocations: [], options: {} },
      });
      await mocks.repositoryHandler?.({
        method: 'cancelSale',
        args: { id: 'i1', reason: 'Prueba' },
      });
      await mocks.repositoryHandler?.({
        method: 'deleteSalesLayaway',
        args: { layawayId: 'l1', resolution: 'credit' },
      });
      await mocks.repositoryHandler?.({
        method: 'addSalesLayawayPayment',
        args: { layawayId: 'l1', payment: { amount: 20, date: '2026-07-20', method: 'Efectivo' } },
      });
    });

    expect(mocks.createSale).toHaveBeenCalledTimes(1);
    expect(mocks.cancelSale).toHaveBeenCalledWith('i1', 'Prueba');
    expect(mocks.deleteLayaway).toHaveBeenCalledWith('l1', 'credit');
    expect(mocks.addLayawayPayment).toHaveBeenCalledTimes(1);
    expect(mocks.reload).toHaveBeenCalledTimes(4);

    view.unmount();
    expect(mocks.repositoryHandler).toBeNull();
  });
});
