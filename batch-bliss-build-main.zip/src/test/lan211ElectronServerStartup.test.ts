import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function getFreePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') {
        socket.close();
        reject(new Error('FREE_PORT_NOT_AVAILABLE'));
        return;
      }
      const port = address.port;
      socket.close(error => error ? reject(error) : resolve(port));
    });
  });
}

afterEach(async () => {
  await stopLanServer();
});

describe('QA LAN 2.1.1 - Infraestructura Electron LAN', () => {
  it('mantiene alineados los canales IPC de main y preload, incluyendo alias compatibles', () => {
    const main = fs.readFileSync(path.resolve('electron/main.js'), 'utf8');
    const preload = fs.readFileSync(path.resolve('electron/preload.cjs'), 'utf8');

    for (const channel of [
      'lan-server-start',
      'lan-server-stop',
      'lan-server-status',
      'lan-server-activity-events',
      'lan-network-discover',
      'lan-system-identity',
    ]) {
      expect(main).toContain(channel);
      expect(preload).toContain(channel);
    }
    expect(main).toContain('registerLanIpcHandlers();');
    expect(main).toContain('from "./lanServer.js"');
  });

  it('abre un puerto HTTP real y responde /health con HTTP 200', async () => {
    const port = await getFreePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan211-'));
    const state = await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor QA LAN 2.1.1',
      userDataPath,
      version: '2.1',
    });

    expect(state.running).toBe(true);
    expect(state.port).toBe(port);

    const response = await fetch(`http://127.0.0.1:${port}/health`);
    expect(response.status).toBe(200);
    const payload = await response.json() as { status: string; version: string; serverName: string };
    expect(payload).toMatchObject({
      status: 'online',
      version: '2.1',
      serverName: 'Servidor QA LAN 2.1.1',
    });

    const stopped = await stopLanServer();
    expect(stopped.running).toBe(false);
  });
});
