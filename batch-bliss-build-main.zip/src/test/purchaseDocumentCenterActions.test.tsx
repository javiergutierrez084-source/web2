// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';
import PurchaseDocumentCenter from '@/components/PurchaseDocumentCenter';
import type { PurchaseDocumentRow } from '@/lib/PurchaseDocumentsService';

vi.mock('@/components/PdfDocumentActions', () => ({ default: ({ title }: { title?: string }) => <button type="button" aria-label={title}>PDF</button> }));
vi.mock('@/components/ExcelExportButton', () => ({ default: () => <button type="button">Exportar Excel</button> }));

const company = { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' };
const normal: PurchaseDocumentRow = {
  id: 'expense-1', source: 'supplier_invoice', type: 'expense', number: 'GAS-001', supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno', concept: 'Arriendo', date: '2026-07-01', dueDate: '2026-07-31',
  total: 500_000, paid: 0, balance: 500_000, status: 'pending',
};
const inherited: PurchaseDocumentRow = {
  ...normal, id: 'legacy-1', source: 'legacy_expense', number: 'LEG-001', legacyExpense: {
    id: 'legacy-1', number: 'LEG-001', supplierId: 'supplier-1', supplierName: 'Proveedor Uno',
    description: 'Gasto heredado', total: 300_000, date: '2026-06-01', status: 'pending', paymentMethod: 'Efectivo',
  },
};

describe('auditoría funcional - acciones del Centro de Documentos', () => {
  afterEach(() => cleanup());

  it('ejecuta editar, duplicar y eliminar para documentos operables', () => {
    const onEdit = vi.fn(); const onDuplicate = vi.fn(); const onDelete = vi.fn();
    render(<PurchaseDocumentCenter company={company} documents={[normal]} onEdit={onEdit} onDuplicate={onDuplicate} onDelete={onDelete} />);

    fireEvent.click(screen.getByRole('button', { name: 'Editar GAS-001' }));
    fireEvent.click(screen.getByRole('button', { name: 'Duplicar GAS-001' }));
    fireEvent.click(screen.getByRole('button', { name: 'Eliminar GAS-001' }));

    expect(onEdit).toHaveBeenCalledWith(normal);
    expect(onDuplicate).toHaveBeenCalledWith(normal);
    expect(onDelete).toHaveBeenCalledWith(normal);
    expect(screen.getByRole('button', { name: 'Imprimir o exportar PDF GAS-001' })).not.toBeNull();
  });

  it('no ofrece editar o eliminar gastos heredados que son de solo lectura', () => {
    const onEdit = vi.fn(); const onDuplicate = vi.fn(); const onDelete = vi.fn();
    render(<PurchaseDocumentCenter company={company} documents={[inherited]} onEdit={onEdit} onDuplicate={onDuplicate} onDelete={onDelete} />);

    const edit = screen.getByRole('button', { name: 'Editar LEG-001' }) as HTMLButtonElement;
    const remove = screen.getByRole('button', { name: 'Eliminar LEG-001' }) as HTMLButtonElement;
    expect(edit.disabled).toBe(true);
    expect(remove.disabled).toBe(true);
    expect(edit.title).toBe('Los gastos heredados son de solo lectura');
    expect(remove.title).toBe('Los gastos heredados se conservan por compatibilidad');
    expect(onEdit).not.toHaveBeenCalled();
    expect(onDelete).not.toHaveBeenCalled();
  });
});
