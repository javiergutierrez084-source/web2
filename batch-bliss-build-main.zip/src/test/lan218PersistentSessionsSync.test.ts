import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function post(url: string, body: Record<string, unknown>) {
  return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { cache: 'no-store' });
  expect(response.status).toBe(200);
  return response.json() as Promise<T>;
}

describe('LAN 2.1.8 - sesiones persistentes y sincronización servidor/cliente', () => {
  afterEach(async () => { await stopLanServer(); });

  it('reconecta 10 veces con la misma identidad, restaura usuario y no duplica equipos', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan218-'));
    const port = 49000 + Math.floor(Math.random() * 1000);
    const base = `http://127.0.0.1:${port}`;
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1',
      sessionPolicy: { inactiveMs: 20, timeoutMs: 40, retentionMs: 60_000 },
      authenticateUser: async (username: string, password: string) => username === 'master' && password === 'ok'
        ? { success: true, userId: 'u1', username, displayName: 'Maestro', role: 'master', permissions: ['*'] }
        : { success: false },
    });

    const deviceInstanceId = 'physical-device-a';
    const registration = await (await post(`${base}/client/register`, {
      deviceInstanceId, name: 'PC Oficina', hostname: 'pc-oficina', ip: '192.168.1.20', version: '2.1', localTime: new Date().toISOString(),
    })).json() as { clientId: string; sessionToken: string };

    const login = await post(`${base}/login`, { username: 'master', password: 'ok', ...registration });
    expect(login.status).toBe(200);

    for (let cycle = 0; cycle < 10; cycle += 1) {
      await new Promise(resolve => setTimeout(resolve, 50));
      const reconnect = await post(`${base}/client/reconnect`, {
        ...registration, deviceInstanceId, ip: `192.168.1.${30 + cycle}`,
      });
      expect(reconnect.status).toBe(200);
      const restored = await reconnect.json() as { clientId: string; sessionToken: string; restoredUsers: number };
      expect(restored.clientId).toBe(registration.clientId);
      expect(restored.sessionToken).toBe(registration.sessionToken);
      expect(restored.restoredUsers).toBeGreaterThanOrEqual(0);

      const ping = await post(`${base}/client/ping`, { ...registration, deviceInstanceId, timestamp: new Date().toISOString() });
      expect(ping.status).toBe(200);

      const clients = await getJson<{ clients: Array<{ clientId: string; activityCount: number; status: string }> }>(`${base}/clients`);
      const users = await getJson<{ users: Array<{ clientId: string; status: string }> }>(`${base}/users`);
      expect(clients.clients).toHaveLength(1);
      expect(clients.clients[0].clientId).toBe(registration.clientId);
      expect(clients.clients[0].status).toBe('connected');
      expect(clients.clients[0].activityCount).toBe(cycle + 1);
      expect(users.users).toHaveLength(1);
      expect(users.users[0]).toMatchObject({ clientId: registration.clientId, status: 'connected' });
    }

    expect(getLanServerState()).toMatchObject({ activeClients: 1, connectedUsers: 1, heartbeatsReceived: 10 });
  });

  it('deduplica registros persistidos antiguos por deviceInstanceId', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan218-dedupe-'));
    fs.writeFileSync(path.join(userDataPath, 'lan-clients.json'), JSON.stringify([
      { clientId: 'old', sessionToken: 'old-token', deviceInstanceId: 'same-device', name: 'PC', hostname: 'pc', ip: '1.1.1.1', version: '2.1', connectedAt: '2026-01-01T00:00:00.000Z', lastActivity: '2026-01-01T00:00:00.000Z', lastHeartbeat: '2026-01-01T00:00:00.000Z', status: 'expired', heartbeatCount: 1, activityCount: 1, totalLatencyMs: 0 },
      { clientId: 'new', sessionToken: 'new-token', deviceInstanceId: 'same-device', name: 'PC', hostname: 'pc', ip: '1.1.1.2', version: '2.1', connectedAt: '2026-01-02T00:00:00.000Z', lastActivity: '2026-01-02T00:00:00.000Z', lastHeartbeat: '2026-01-02T00:00:00.000Z', status: 'expired', heartbeatCount: 2, activityCount: 2, totalLatencyMs: 0 },
    ]));
    const port = 50000 + Math.floor(Math.random() * 1000);
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1' });
    const payload = await getJson<{ clients: Array<{ clientId: string }> }>(`http://127.0.0.1:${port}/clients`);
    expect(payload.clients).toHaveLength(1);
    expect(payload.clients[0]).toMatchObject({ clientId: 'new' });
  });
});
