import { describe, expect, it, vi } from 'vitest';
import {
  ONLINE_PRODUCTS_CACHE_TTL_MS,
  OnlineProductsRepository,
} from '@/lib/OnlineProductsRepository';

const CONNECTION = {
  url: 'https://midominio.com',
  port: 443,
  sessionId: 'a'.repeat(43),
  serverId: '11111111-1111-4111-8111-111111111111',
  version: '3.0.0',
};

const PRODUCTS = [
  {
    id: 'product-1',
    code: 'ANI-001',
    name: 'Anillo Oro',
    category: 'Anillos',
    reference: 'REF-001',
    description: '',
    weightGrams: 4.5,
    availableGrams: 13.5,
    salePrice: 950000,
    stock: 3,
    minStock: 1,
    status: 'available' as const,
  },
  {
    id: 'product-2',
    code: 'CAD-002',
    name: 'Cadena Plata',
    category: 'Cadenas',
    reference: 'REF-002',
    description: '',
    weightGrams: 8,
    availableGrams: 0,
    salePrice: 250000,
    stock: 0,
    minStock: 2,
    status: 'out_of_stock' as const,
  },
];

const INVENTORY = [
  {
    id: 'product-1',
    code: 'ANI-001',
    name: 'Anillo Oro',
    category: 'Anillos',
    stock: 3,
    availableGrams: 13.5,
    weightGrams: 4.5,
    minStock: 1,
    location: 'Vitrina A',
    lastMovement: { date: '2026-07-28T19:00:00.000Z', type: 'increase' as const },
    status: 'available' as const,
  },
  {
    id: 'product-2',
    code: 'CAD-002',
    name: 'Cadena Plata',
    category: 'Cadenas',
    stock: 0,
    availableGrams: 0,
    weightGrams: 8,
    minStock: 2,
    location: '',
    lastMovement: null,
    status: 'out_of_stock' as const,
  },
];

describe('OnlineProductsRepository', () => {
  it('consulta productos, detalle, búsqueda, inventario y referencia individual', async () => {
    const transport = vi.fn(async ({ resource, args }) => {
      const data = resource === 'products'
        ? PRODUCTS
        : resource === 'product'
          ? PRODUCTS.find(product => product.id === args?.id)
          : resource === 'productsSearch'
            ? PRODUCTS.filter(product => product.name.toLowerCase().includes(String(args?.query).toLowerCase()))
            : resource === 'inventory'
              ? INVENTORY
              : INVENTORY.find(item => item.id === args?.id);
      return {
        ok: true as const,
        resource,
        data,
        latencyMs: 12,
        communicatedAt: '2026-07-28T20:00:00.000Z',
      };
    });
    const repository = new OnlineProductsRepository(CONNECTION, { transport: transport as never });

    const products = await repository.getProducts();
    const product = await repository.getProduct('product-1');
    const search = await repository.searchProducts('plata');
    const inventory = await repository.getInventory();
    const inventoryItem = await repository.getInventoryItem('product-1');

    expect(products.totalProducts).toBe(2);
    expect(product.id).toBe('product-1');
    expect(search.map(item => item.id)).toEqual(['product-2']);
    expect(inventory.totalReferences).toBe(2);
    expect(inventory.totalExistences).toBe(3);
    expect(inventory.totalAvailableGrams).toBe(13.5);
    expect(inventoryItem.location).toBe('Vitrina A');
    expect(transport.mock.calls.map(([options]) => options.resource)).toEqual([
      'products',
      'product',
      'productsSearch',
      'inventory',
      'inventoryItem',
    ]);
  });

  it('mantiene cache en memoria por 60 segundos y renueva productos e inventario al vencer', async () => {
    let now = Date.parse('2026-07-28T20:00:00.000Z');
    const transport = vi.fn(async ({ resource }) => ({
      ok: true as const,
      resource,
      data: resource === 'products' ? PRODUCTS : INVENTORY,
      latencyMs: 10,
      communicatedAt: new Date(now).toISOString(),
    }));
    const repository = new OnlineProductsRepository(CONNECTION, {
      transport: transport as never,
      now: () => now,
    });

    const firstProducts = await repository.getProducts();
    const firstInventory = await repository.getInventory();
    now += ONLINE_PRODUCTS_CACHE_TTL_MS - 1;
    const cachedProducts = await repository.getProducts();
    const cachedInventory = await repository.getInventory();
    now += 2;
    const renewedProducts = await repository.getProducts();
    const renewedInventory = await repository.getInventory();

    expect(firstProducts.fromCache).toBe(false);
    expect(firstInventory.fromCache).toBe(false);
    expect(cachedProducts.fromCache).toBe(true);
    expect(cachedInventory.fromCache).toBe(true);
    expect(renewedProducts.fromCache).toBe(false);
    expect(renewedInventory.fromCache).toBe(false);
    expect(transport).toHaveBeenCalledTimes(4);
  });

  it('no guarda productos o inventario y no expone operaciones de escritura', async () => {
    const setItem = vi.spyOn(Storage.prototype, 'setItem');
    const repository = new OnlineProductsRepository(CONNECTION, {
      transport: (async ({ resource }) => ({
        ok: true,
        resource,
        data: resource === 'products' ? PRODUCTS : INVENTORY,
        latencyMs: 1,
        communicatedAt: '2026-07-28T20:00:00.000Z',
      })) as never,
    });

    await repository.getProducts();
    await repository.getInventory();
    expect(setItem).not.toHaveBeenCalled();
    const methods = Object.getOwnPropertyNames(OnlineProductsRepository.prototype);
    expect(methods).toEqual(expect.arrayContaining([
      'getProducts',
      'getProduct',
      'searchProducts',
      'getInventory',
      'getInventoryItem',
      'clearCache',
    ]));
    expect(methods).not.toEqual(expect.arrayContaining([
      'create', 'update', 'delete', 'post', 'put', 'patch', 'sync',
    ]));
    setItem.mockRestore();
  });

  it('propaga token inválido, expirado, timeout, servidor apagado y errores TLS', async () => {
    for (const code of [
      'HTTPS_SESSION_INVALID',
      'HTTPS_SESSION_EXPIRED',
      'HTTPS_TIMEOUT',
      'HTTPS_SERVER_NOT_FOUND',
      'HTTPS_TLS_INVALID',
      'HTTPS_CERTIFICATE_INVALID',
      'HTTPS_VERSION_INCOMPATIBLE',
    ]) {
      const repository = new OnlineProductsRepository(CONNECTION, {
        transport: (async () => ({ ok: false, errorCode: code, errorMessage: code })) as never,
      });
      await expect(repository.getProducts()).rejects.toMatchObject({ code });
    }
  });
});
