import { describe, expect, it, vi } from 'vitest';
import type { Contact, Product } from '@/data/mockData';
import {
  applyProductMassUpdatePlan,
  buildProductMassUpdatePlan,
  buildProductUpdateTemplateRows,
  type ProductMassUpdateField,
} from '@/lib/productMassUpdate';

const supplier = (id: string, name: string): Contact => ({
  id,
  type: 'supplier',
  name,
  document: '',
  phone: '',
  email: '',
  address: '',
});

const product = (overrides: Partial<Product> = {}): Product => ({
  id: 'product-1',
  code: 'P-001',
  reference: '770000001',
  name: 'Anillo Omega',
  category: 'Anillos',
  purchasePrice: 120000,
  salePrice: 160000,
  weightGrams: 8.4,
  margin: 33.333,
  stock: 4,
  minStock: 1,
  description: 'Observación original',
  supplierIds: ['supplier-omega'],
  ...overrides,
});

const selected = (...fields: ProductMassUpdateField[]) => new Set<ProductMassUpdateField>(fields);
const contacts = [supplier('supplier-omega', 'OMEGA'), supplier('supplier-abc', 'IMPORTADORA ABC')];
const categories = ['Anillos', 'Cadenas'];

describe('actualización masiva segura de productos', () => {
  it('actualiza únicamente el proveedor seleccionado', () => {
    const plan = buildProductMassUpdatePlan([
      { 'ID interno': 'product-1', Proveedor: 'IMPORTADORA ABC' },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });

    expect(plan.summary).toMatchObject({ productsModified: 1, productsNotFound: 0, errors: 0 });
    expect(plan.upserts).toHaveLength(1);
    expect(plan.upserts[0].supplierIds).toEqual(['supplier-abc']);
    expect(plan.upserts[0].purchasePrice).toBe(120000);
    expect(plan.upserts[0].salePrice).toBe(160000);
    expect(plan.upserts[0].stock).toBe(4);
  });

  it('actualiza múltiples campos sin tocar stock ni Kardex', () => {
    const plan = buildProductMassUpdatePlan([
      {
        Código: 'P-001',
        Nombre: 'Anillo Omega Premium',
        Categoría: 'Cadenas',
        Peso: 9.2,
        'Precio compra': 130000,
        'Precio venta': 180000,
        'Código de barras': '770000999',
        Observaciones: 'Actualizado desde Excel',
      },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('name', 'category', 'weightGrams', 'purchasePrice', 'salePrice', 'reference', 'description'),
    });

    expect(plan.upserts).toHaveLength(1);
    expect(plan.upserts[0]).toMatchObject({
      id: 'product-1',
      name: 'Anillo Omega Premium',
      category: 'Cadenas',
      weightGrams: 9.2,
      purchasePrice: 130000,
      salePrice: 180000,
      reference: '770000999',
      description: 'Actualizado desde Excel',
      stock: 4,
      minStock: 1,
    });
  });

  it('conserva celdas vacías cuando el modo seguro está activo', () => {
    const plan = buildProductMassUpdatePlan([
      {
        'ID interno': 'product-1',
        Proveedor: 'IMPORTADORA ABC',
        'Precio compra': '',
        'Precio venta': '',
        Observaciones: '',
      },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds', 'purchasePrice', 'salePrice', 'description'),
    });

    expect(plan.upserts).toHaveLength(1);
    expect(plan.upserts[0].supplierIds).toEqual(['supplier-abc']);
    expect(plan.upserts[0].purchasePrice).toBe(120000);
    expect(plan.upserts[0].salePrice).toBe(160000);
    expect(plan.upserts[0].description).toBe('Observación original');
    expect(plan.previewRows.filter(row => row.status === 'preserved')).toHaveLength(3);
  });

  it('permite vaciar campos opcionales cuando el modo seguro está desactivado', () => {
    const plan = buildProductMassUpdatePlan([
      {
        'ID interno': 'product-1',
        Proveedor: '',
        Observaciones: '',
      },
    ], [product()], contacts, categories, {
      safeMode: false,
      selectedFields: selected('supplierIds', 'description'),
    });

    expect(plan.upserts).toHaveLength(1);
    expect(plan.upserts[0].supplierIds).toEqual([]);
    expect(plan.upserts[0].description).toBe('');
  });

  it('respeta la selección de campos aunque el Excel contenga otros valores', () => {
    const plan = buildProductMassUpdatePlan([
      {
        'ID interno': 'product-1',
        Proveedor: 'IMPORTADORA ABC',
        'Precio venta': 999999,
      },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });

    expect(plan.upserts[0].supplierIds).toEqual(['supplier-abc']);
    expect(plan.upserts[0].salePrice).toBe(160000);
    expect(plan.previewRows.some(row => row.field === 'Precio venta')).toBe(false);
  });


  it('respeta el orden ID, código y nombre exacto con fallback seguro', () => {
    const byCode = buildProductMassUpdatePlan([
      { 'ID interno': 'id-antiguo', Código: 'P-001', Proveedor: 'IMPORTADORA ABC' },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });
    expect(byCode.upserts).toHaveLength(1);
    expect(byCode.upserts[0].id).toBe('product-1');

    const byName = buildProductMassUpdatePlan([
      { 'ID interno': 'id-antiguo', Código: 'codigo-antiguo', Nombre: 'Anillo Omega', Proveedor: 'IMPORTADORA ABC' },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });
    expect(byName.upserts).toHaveLength(1);
    expect(byName.upserts[0].id).toBe('product-1');
  });

  it('genera la vista previa sin crear productos ni inventar IDs', () => {
    const plan = buildProductMassUpdatePlan([
      { 'ID interno': 'missing-id', Código: 'NUEVO-1', Nombre: 'Producto inexistente', Proveedor: 'OMEGA' },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });

    expect(plan.upserts).toEqual([]);
    expect(plan.summary.productsNotFound).toBe(1);
    expect(plan.sourceResults[0].outcome).toBe('not_found');
  });

  it('clasifica productos modificados, sin cambios, no encontrados y con error para el reporte final', () => {
    const plan = buildProductMassUpdatePlan([
      { 'ID interno': 'product-1', Proveedor: 'IMPORTADORA ABC' },
      { 'ID interno': 'product-2', Proveedor: 'OMEGA' },
      { 'ID interno': 'missing', Proveedor: 'OMEGA' },
      { 'ID interno': 'product-3', Proveedor: 'PROVEEDOR INEXISTENTE' },
    ], [
      product(),
      product({ id: 'product-2', code: 'P-002', name: 'Producto Dos' }),
      product({ id: 'product-3', code: 'P-003', name: 'Producto Tres' }),
    ], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });

    expect(plan.summary).toEqual({
      productsFound: 3,
      productsModified: 1,
      productsUnchanged: 1,
      productsNotFound: 1,
      errors: 1,
    });
    expect(plan.sourceResults.map(result => result.outcome)).toEqual([
      'modified', 'unchanged', 'not_found', 'error',
    ]);
  });


  it('mantiene el dry run sin escrituras y ejecuta un único applyProductChanges al confirmar', async () => {
    const applyChanges = vi.fn(async () => undefined);
    const plan = buildProductMassUpdatePlan([
      { 'ID interno': 'product-1', Proveedor: 'IMPORTADORA ABC' },
    ], [product()], contacts, categories, {
      safeMode: true,
      selectedFields: selected('supplierIds'),
    });

    expect(applyChanges).not.toHaveBeenCalled();
    await applyProductMassUpdatePlan(plan, applyChanges);
    expect(applyChanges).toHaveBeenCalledTimes(1);
    expect(applyChanges).toHaveBeenCalledWith({
      upserts: [expect.objectContaining({ id: 'product-1', supplierIds: ['supplier-abc'] })],
      deleteIds: [],
    });
  });

  it('construye la plantilla completa sin incluir stock', () => {
    const rows = buildProductUpdateTemplateRows([product()], contacts);
    expect(rows[0]).toEqual({
      internalId: 'product-1',
      code: 'P-001',
      name: 'Anillo Omega',
      category: 'Anillos',
      supplier: 'OMEGA',
      weightGrams: 8.4,
      purchasePrice: 120000,
      salePrice: 160000,
      barcode: '770000001',
      status: 'Activo',
      observations: 'Observación original',
    });
    expect(rows[0]).not.toHaveProperty('stock');
  });
});
