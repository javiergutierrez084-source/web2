// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

const post = (url: string, body: object) => fetch(url, {
  method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
});

afterEach(async () => { await stopLanServer(); });

describe('QA LAN 2.1.4 - ciclo real del servicio, registro y heartbeat', () => {
  it('registro, ping, /health y estado IPC comparten la misma instancia y contadores', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan214-'));
    try {
      const started = await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Integrado', userDataPath, version: '2.1' });
      expect(started.running).toBe(true);
      const base = `http://127.0.0.1:${port}`;

      const registerResponse = await post(`${base}/client/register`, {
        name: 'Cliente QA', hostname: 'cliente-qa', ip: '192.168.1.30', version: '2.1',
        operatingSystem: 'Windows', localTime: new Date().toISOString(),
      });
      expect(registerResponse.status).toBe(201);
      const registration = await registerResponse.json() as { clientId: string; sessionToken: string; serverId: string };
      expect(registration.serverId).toBe(started.serverId);

      const beforePing = getLanServerState();
      expect(beforePing.activeClients).toBe(1);
      expect(beforePing.heartbeatsReceived).toBe(0);

      const pingResponse = await post(`${base}/client/ping`, {
        clientId: registration.clientId,
        sessionToken: registration.sessionToken,
        timestamp: new Date().toISOString(),
      });
      expect(pingResponse.status).toBe(200);
      const ping = await pingResponse.json() as { serverId: string; activityCount: number };
      expect(ping.serverId).toBe(started.serverId);
      expect(ping.activityCount).toBe(1);

      const health = await (await fetch(`${base}/health`)).json() as { activeClients: number; connectedClients: number; heartbeatsReceived: number; serverId: string };
      const ipcState = getLanServerState();
      expect(health.serverId).toBe(started.serverId);
      expect(health.activeClients).toBe(1);
      expect(health.connectedClients).toBe(1);
      expect(health.heartbeatsReceived).toBe(1);
      expect(ipcState.activeClients).toBe(health.activeClients);
      expect(ipcState.connectedClients).toBe(health.connectedClients);
      expect(ipcState.heartbeatsReceived).toBe(health.heartbeatsReceived);
      expect(ipcState.requestsHandled).toBeGreaterThanOrEqual(3);
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });

  it('mantiene el heartbeat fuera de LanCommunicationPanel y monta el servicio antes del login', () => {
    const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8');
    const panel = fs.readFileSync(path.resolve('src/components/LanCommunicationPanel.tsx'), 'utf8');
    const service = fs.readFileSync(path.resolve('src/components/LanClientConnectionService.tsx'), 'utf8');
    expect(app).toContain('<LanClientConnectionService />');
    expect(app.indexOf('<LanClientConnectionService />')).toBeLessThan(app.indexOf('<AppRouter />'));
    expect(service).toContain('sendLanHeartbeat');
    expect(service).toContain('10_000');
    expect(panel).not.toContain('sendLanHeartbeat');
  });

  it('el proceso Electron expone una sola instancia y escucha en todas las interfaces cuando se configura loopback', () => {
    const main = fs.readFileSync(path.resolve('electron/main.js'), 'utf8');
    expect(main).toContain('const listenHost = requestedHost === "127.0.0.1"');
    expect(main).toContain('? "0.0.0.0" : requestedHost');
    expect(main).toContain('startLanServer({');
    expect(main).toContain('getLanServerState()');
  });
});
