// @vitest-environment jsdom
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it, vi } from 'vitest';
import type { Contact } from '@/data/mockData';
import type { BulkImportProductRecord, CategoryRecord } from '@/domain/models';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function post(baseUrl: string, route: string, body: Record<string, unknown>) {
  return fetch(`${baseUrl}${route}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
}

describe('LAN v2.4.4 - carga masiva conserva POST /repository/call', () => {
  afterEach(async () => {
    await stopLanServer();
    localStorage.clear();
    vi.restoreAllMocks();
  });

  it('transporta contactos, categorías y productos por el Repository existente', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan244-'));
    const port = 55500 + Math.floor(Math.random() * 500);
    const baseUrl = `http://127.0.0.1:${port}`;
    const calls: Array<{ method: string; args: Record<string, unknown> }> = [];
    const contacts: Contact[] = [{
      id: 'supplier-existing', type: 'supplier', name: 'Proveedor Existente',
      document: '', phone: '', email: '', address: '',
    }];

    const provider = vi.fn(async (method: string, args: Record<string, unknown>) => {
      calls.push({ method, args });
      if (method === 'getContacts') return { items: contacts, total: contacts.length, page: 1, pageSize: contacts.length };
      if (method === 'applyContactChanges') return { ok: true };
      if (method === 'bulkPutCategories') return { ok: true };
      if (method === 'bulkPutProducts') return { ok: true };
      throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
    });

    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor',
      userDataPath,
      version: '2.4.4',
      executeRepositoryCall: provider,
      authenticateUser: async () => ({
        success: true,
        userId: 'master-1',
        username: 'master',
        displayName: 'Maestro',
        role: 'master',
        permissions: ['manage_products', 'manage_contacts'],
      }),
    });

    const register = await (await post(baseUrl, '/client/register', {
      deviceInstanceId: 'device-244',
      name: 'Cliente',
      hostname: 'cliente',
      version: '2.4.4',
      localTime: new Date().toISOString(),
    })).json() as { clientId: string; sessionToken: string };
    const login = await (await post(baseUrl, '/login', {
      username: 'master',
      password: 'ok',
      ...register,
    })).json() as { authToken: string };

    saveLanConfig({
      ...createDefaultLanConfig(),
      mode: 'lan',
      role: 'client',
      clientServerIp: '127.0.0.1',
      clientServerPort: port,
      clientId: register.clientId,
      sessionToken: register.sessionToken,
      authToken: login.authToken,
    });

    const repository = new ApiRepository({ baseUrl });
    expect(await repository.fetchContacts()).toEqual(contacts);

    const newSupplier: Contact = {
      id: 'supplier-new', type: 'supplier', name: 'Proveedor Nuevo',
      document: '', phone: '', email: '', address: '',
    };
    await repository.applyContactChanges({ upserts: [newSupplier], deleteIds: [] });

    const category: CategoryRecord = {
      id: 'category-1', name: 'Anillos', name_key: 'anillos',
      created_at: new Date().toISOString(), auto_created: true,
    };
    await repository.bulkPutCategories([category]);

    const product: BulkImportProductRecord = {
      id: 'product-1', code: 'P-1', name: 'Anillo', category: 'Anillos',
      purchase_price: 100, sale_price: 150, weight_grams: 1, margin: 50,
      stock: 1, min_stock: 0, description: '', supplier_ids: ['supplier-new'],
      created_at: new Date().toISOString(),
    };
    await repository.bulkPutProducts([product]);

    expect(calls.map(call => call.method)).toEqual([
      'getContacts',
      'applyContactChanges',
      'bulkPutCategories',
      'bulkPutProducts',
    ]);
    expect(calls[3].args).toEqual({ products: [product] });
  });
});
