// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1', () => {
      const address = listener.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_FREE_PORT'));
      listener.close(error => error ? reject(error) : resolve(address.port));
    });
    listener.on('error', reject);
  });
}

async function post<T = Record<string, unknown>>(url: string, body: Record<string, unknown>) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Connection: 'close' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { success?: boolean; error?: string };
  return { response, payload };
}

const sleep = (milliseconds: number) => new Promise(resolve => setTimeout(resolve, milliseconds));

describe('LAN 2.2 robust client management', () => {
  const temporaryPaths: string[] = [];

  afterEach(async () => {
    await stopLanServer();
    for (const directory of temporaryPaths.splice(0)) fs.rmSync(directory, { recursive: true, force: true });
  });

  async function start(timeoutMs = 60_000) {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-robust-'));
    temporaryPaths.push(userDataPath);
    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor robusto',
      userDataPath,
      version: '2.1',
      sessionPolicy: {
        inactiveMs: Math.max(10, Math.floor(timeoutMs / 2)),
        timeoutMs,
        retentionMs: Math.max(500, timeoutMs * 4),
      },
      authenticateUser: async (username: string, password: string) => username === 'master' && password === 'ok'
        ? {
          success: true,
          userId: 'user-master',
          username,
          displayName: 'Maestro',
          role: 'master',
          permissions: ['manage_products', 'view_reports'],
        }
        : { success: false },
      executeRepositoryCall: async (method: string) => ({ method, ok: true }),
    });
    return `http://127.0.0.1:${port}`;
  }

  async function register(baseUrl: string, connectionId: string, name = 'Equipo original', ip = '192.168.1.20') {
    return post<{ clientId: string; sessionToken: string; machineId: string; reused?: boolean }>(`${baseUrl}/client/register`, {
      machineId: 'machine-permanent-001',
      deviceInstanceId: 'machine-permanent-001',
      connectionId,
      name,
      hostname: name.toLowerCase().replace(/\s+/g, '-'),
      ip,
      operatingSystem: 'Windows 11',
      version: '2.1',
      localTime: new Date().toISOString(),
      rememberDevice: true,
    });
  }

  it('reuses one registered record per Machine ID and replaces the previous active runtime session', async () => {
    const baseUrl = await start();
    const first = await register(baseUrl, 'runtime-a');
    expect(first.response.status).toBe(201);

    const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
      clientId: first.payload.clientId,
      sessionToken: first.payload.sessionToken,
      username: 'master',
      password: 'ok',
      rememberDevice: true,
    });
    expect(login.response.status).toBe(200);

    const second = await register(baseUrl, 'runtime-b', 'Equipo renombrado', '192.168.1.77');
    expect(second.response.status).toBe(200);
    expect(second.payload).toMatchObject({
      clientId: first.payload.clientId,
      machineId: 'machine-permanent-001',
      reused: true,
    });
    expect(second.payload.sessionToken).not.toBe(first.payload.sessionToken);

    const oldHeartbeat = await post(`${baseUrl}/client/ping`, {
      clientId: first.payload.clientId,
      sessionToken: first.payload.sessionToken,
      machineId: 'machine-permanent-001',
      connectionId: 'runtime-a',
      timestamp: new Date().toISOString(),
    });
    expect(oldHeartbeat.response.status).toBe(401);

    const newHeartbeat = await post(`${baseUrl}/client/ping`, {
      clientId: second.payload.clientId,
      sessionToken: second.payload.sessionToken,
      machineId: 'machine-permanent-001',
      connectionId: 'runtime-b',
      timestamp: new Date().toISOString(),
    });
    expect(newHeartbeat.response.status).toBe(200);

    const clientPayload = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      clients: Array<Record<string, unknown>>;
      registeredClients: Array<Record<string, unknown>>;
      connectedClients: Array<Record<string, unknown>>;
    };
    expect(clientPayload.registeredClients).toHaveLength(1);
    expect(clientPayload.connectedClients).toHaveLength(1);
    expect(clientPayload.clients[0]).toMatchObject({
      clientId: first.payload.clientId,
      machineId: 'machine-permanent-001',
      name: 'Equipo renombrado',
      ip: '192.168.1.77',
      status: 'connected',
      version: '2.1',
    });
    expect(clientPayload.clients[0].registeredAt).toBeTruthy();
    expect(clientPayload.clients[0].connectedAt).toBeTruthy();

    const users = await fetch(`${baseUrl}/users`).then(response => response.json()) as {
      users: Array<{ authToken: string; status: string }>;
    };
    expect(users.users).toHaveLength(1);
    expect(users.users[0]).toMatchObject({ authToken: login.payload.authToken, status: 'inactive' });

    const restore = await post(`${baseUrl}/auth/restore`, {
      clientId: second.payload.clientId,
      sessionToken: second.payload.sessionToken,
      authToken: login.payload.authToken,
    });
    expect(restore.response.status).toBe(200);
    const restoredUsers = await fetch(`${baseUrl}/users`).then(response => response.json()) as {
      users: Array<{ authToken: string; status: string }>;
    };
    expect(restoredUsers.users[0]).toMatchObject({ authToken: login.payload.authToken, status: 'connected' });
  });

  it('cleans duplicated legacy records and orphaned user sessions for the same Machine ID on startup', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-orphans-'));
    temporaryPaths.push(userDataPath);
    const now = Date.now();
    const older = new Date(now - 10_000).toISOString();
    const newer = new Date(now - 1_000).toISOString();
    const expiresAt = new Date(now + 86_400_000).toISOString();
    fs.writeFileSync(path.join(userDataPath, 'lan-runtime-state.json'), JSON.stringify({
      clients: [
        {
          clientId: 'legacy-old', sessionToken: 'token-old', machineId: 'machine-duplicate', deviceInstanceId: 'machine-duplicate',
          name: 'Registro antiguo', hostname: 'old', ip: '192.168.1.10', version: '2.1', status: 'connected',
          registeredAt: older, connectedAt: older, createdAt: older, lastActivity: older, lastHeartbeat: older, expiresAt,
          rememberDevice: true, heartbeatCount: 0, activityCount: 0, totalLatencyMs: 0,
        },
        {
          clientId: 'legacy-new', sessionToken: 'token-new', machineId: 'machine-duplicate', deviceInstanceId: 'machine-duplicate',
          name: 'Registro vigente', hostname: 'new', ip: '192.168.1.20', version: '2.1', status: 'connected',
          registeredAt: newer, connectedAt: newer, createdAt: newer, lastActivity: newer, lastHeartbeat: newer, expiresAt,
          rememberDevice: true, heartbeatCount: 0, activityCount: 0, totalLatencyMs: 0,
        },
      ],
      userSessions: [
        {
          authToken: 'orphan-auth', clientId: 'legacy-old', userId: 'u-old', username: 'old', displayName: 'Old', role: 'master',
          permissions: ['view_reports'], loginAt: older, createdAt: older, lastActivity: older, expiresAt, rememberDevice: true,
          status: 'connected', endReason: null,
        },
      ],
      counters: {},
    }), 'utf8');

    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor limpieza', userDataPath, version: '2.1' });
    const baseUrl = `http://127.0.0.1:${port}`;
    const clients = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      registeredClients: Array<{ clientId: string; machineId: string; name: string }>;
    };
    const users = await fetch(`${baseUrl}/users`).then(response => response.json()) as { users: unknown[] };

    expect(clients.registeredClients).toHaveLength(1);
    expect(clients.registeredClients[0]).toMatchObject({
      clientId: 'legacy-new',
      machineId: 'machine-duplicate',
      name: 'Registro vigente',
    });
    expect(users.users).toHaveLength(0);
  });

  it('uses heartbeat only for presence and records last commercial activity separately', async () => {
    const baseUrl = await start();
    const registration = await register(baseUrl, 'runtime-activity');
    const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
      clientId: registration.payload.clientId,
      sessionToken: registration.payload.sessionToken,
      username: 'master',
      password: 'ok',
    });
    expect(login.response.status).toBe(200);

    const before = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      clients: Array<{ lastActivity: string; lastHeartbeat: string; activityCount: number }>;
    };
    await sleep(10);
    const heartbeat = await post(`${baseUrl}/client/ping`, {
      clientId: registration.payload.clientId,
      sessionToken: registration.payload.sessionToken,
      machineId: registration.payload.machineId,
      connectionId: 'runtime-activity',
      timestamp: new Date(Date.now() - 5).toISOString(),
    });
    expect(heartbeat.response.status).toBe(200);

    const afterHeartbeat = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      clients: Array<{ lastActivity: string; lastHeartbeat: string; activityCount: number; currentLatencyMs: number }>;
    };
    expect(afterHeartbeat.clients[0].lastActivity).toBe(before.clients[0].lastActivity);
    expect(new Date(afterHeartbeat.clients[0].lastHeartbeat).getTime())
      .toBeGreaterThanOrEqual(new Date(before.clients[0].lastHeartbeat).getTime());
    expect(afterHeartbeat.clients[0].activityCount).toBe(0);
    expect(afterHeartbeat.clients[0].currentLatencyMs).toBeGreaterThanOrEqual(0);

    await sleep(10);
    const repositoryCall = await post(`${baseUrl}/repository/call`, {
      clientId: registration.payload.clientId,
      sessionToken: registration.payload.sessionToken,
      authToken: login.payload.authToken,
      method: 'getDashboardMetrics',
      args: [],
    });
    expect(repositoryCall.response.status).toBe(200);

    const afterActivity = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      clients: Array<{ lastActivity: string; activityCount: number }>;
    };
    expect(new Date(afterActivity.clients[0].lastActivity).getTime())
      .toBeGreaterThan(new Date(afterHeartbeat.clients[0].lastActivity).getTime());
    expect(afterActivity.clients[0].activityCount).toBe(1);
  });

  it('marks a client disconnected after the heartbeat timeout while retaining its registered equipment record', async () => {
    const baseUrl = await start(60);
    const registration = await register(baseUrl, 'runtime-timeout');
    expect(registration.response.status).toBe(201);

    await sleep(85);
    const payload = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      registeredClients: Array<{ status: string; machineId: string }>;
      connectedClients: Array<Record<string, unknown>>;
    };
    expect(payload.registeredClients).toHaveLength(1);
    expect(payload.registeredClients[0]).toMatchObject({
      status: 'disconnected',
      machineId: 'machine-permanent-001',
    });
    expect(payload.connectedClients).toHaveLength(0);

    const reconnect = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/reconnect`, {
      clientId: registration.payload.clientId,
      sessionToken: registration.payload.sessionToken,
      machineId: 'machine-permanent-001',
      connectionId: 'runtime-timeout',
      ip: '192.168.1.90',
    });
    expect(reconnect.response.status).toBe(200);
    expect(reconnect.payload.sessionToken).toBe(registration.payload.sessionToken);

    const restored = await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      registeredClients: Array<{ status: string; ip: string }>;
      connectedClients: Array<Record<string, unknown>>;
    };
    expect(restored.registeredClients[0]).toMatchObject({ status: 'connected', ip: '192.168.1.90' });
    expect(restored.connectedClients).toHaveLength(1);
  });
});
