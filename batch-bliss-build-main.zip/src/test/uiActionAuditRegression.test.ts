// @vitest-environment node
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const source = (relativePath: string): string => readFileSync(resolve(process.cwd(), relativePath), 'utf8');

const auditedFiles = [
  'src/pages/Inventory.tsx',
  'src/pages/InventoryAdjustments.tsx',
  'src/pages/NewProduct.tsx',
  'src/pages/Purchases.tsx',
  'src/pages/NewPurchase.tsx',
  'src/components/ExpenseInvoiceDialog.tsx',
  'src/components/ExpenseConceptCatalog.tsx',
  'src/components/PurchaseDocumentCenter.tsx',
  'src/pages/AccountsPayable.tsx',
  'src/pages/Sales.tsx',
  'src/pages/Quotations.tsx',
  'src/pages/NewQuotation.tsx',
  'src/pages/Contacts.tsx',
  'src/pages/UsersPage.tsx',
  'src/pages/CashRegister.tsx',
  'src/pages/OwnerFinances.tsx',
  'src/pages/Reports.tsx',
  'src/pages/SettingsPage.tsx',
  'src/pages/ActivityPage.tsx',
  'src/components/PdfDocumentActions.tsx',
];

describe('auditoría de acciones visibles de JoyaControl', () => {
  it('no conserva callbacks de click vacíos en los módulos auditados', () => {
    for (const file of auditedFiles) {
      const content = source(file);
      expect(content, file).not.toMatch(/onClick\s*=\s*\{\s*\(.*?\)\s*=>\s*\{\s*\}\s*\}/s);
      expect(content, file).not.toMatch(/onClick\s*=\s*\{\s*async\s*\(.*?\)\s*=>\s*\{\s*\}\s*\}/s);
    }
  });

  it('mantiene conectadas las acciones críticas a sus manejadores reales', () => {
    expect(source('src/pages/Inventory.tsx')).toContain('onClick={() => startEdit(p.id)}');
    expect(source('src/pages/Inventory.tsx')).toContain('onClick={saveEditCategory}');
    expect(source('src/pages/Purchases.tsx')).toContain('onEdit={handleEdit}');
    expect(source('src/pages/Purchases.tsx')).toContain('onDuplicate={handleDuplicate}');
    expect(source('src/pages/AccountsPayable.tsx')).toContain('onClick={() => openEdit(invoice)}');
    expect(source('src/pages/AccountsPayable.tsx')).toContain('await updateSupplierInvoiceSafe(editing.id');
    expect(source('src/pages/Sales.tsx')).toContain('onClick={handleAnnul}');
    expect(source('src/pages/Quotations.tsx')).toContain("await updateQuotationStatus(id, 'cancelled')");
    expect(source('src/pages/Contacts.tsx')).toContain('onClick={saveEditContact}');
    expect(source('src/pages/UsersPage.tsx')).toContain('onClick={() => toggleActive(u)}');
    expect(source('src/pages/CashRegister.tsx')).toContain('onClick={handleClose}');
    expect(source('src/pages/OwnerFinances.tsx')).toContain('confirmWithdrawalCancellation');
    expect(source('src/pages/SettingsPage.tsx')).toContain('onClick={handleSave}');
  });

  it('no presenta la vista previa PDF como un botón habilitado sin operación', () => {
    const content = source('src/components/PdfDocumentActions.tsx');
    expect(content).toContain('role="status"');
    expect(content).toContain('aria-label="Vista previa activa"');
    expect(content).not.toMatch(/<Button[^>]*>\s*<Eye[^>]*\/>\s*Vista previa/s);
  });

  it('protege las acciones no soportadas de gastos heredados', () => {
    const content = source('src/components/PurchaseDocumentCenter.tsx');
    expect(content).toContain("const inheritedReadOnly = document.source === 'legacy_expense'");
    expect(content).toContain('disabled={editDisabled}');
    expect(content).toContain('disabled={deleteDisabled}');
  });
});
