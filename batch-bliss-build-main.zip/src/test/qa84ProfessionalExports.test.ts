import { describe, expect, it } from 'vitest';
import type { Contact, FinancialMovement, Invoice, Product } from '@/data/mockData';
import {
  buildInventoryPdfDocument,
  buildInventoryRows,
  buildInvoiceExcelRows,
  buildSalesPdfDocument,
  buildSalesSummaryRows,
} from '@/lib/professionalExports';

const company = { name: 'JoyaControl', nit: '900', phone: '1', city: 'Bogotá', address: 'Calle 1', email: 'a@b.co', logoUrl: '' };
const contact: Contact = { id: 'c1', type: 'client', name: 'Cliente Uno', document: '123', phone: '', email: '', address: '' };
const product: Product = { id: 'p1', code: 'P-1', name: 'Anillo', category: 'Anillos', purchasePrice: 60000, averagePurchasePrice: 60000, salePrice: 100000, weightGrams: 5, availableGrams: 50, margin: 40, stock: 10, minStock: 2, supplierIds: ['s1'] };
const supplier: Contact = { id: 's1', type: 'supplier', name: 'Proveedor Uno', document: '9001', phone: '', email: '', address: '' };
const invoice: Invoice = { id: 'i1', number: 'FV-1', clientId: 'c1', clientName: 'Cliente Uno', items: [{ productId: 'p1', code: 'P-1', name: 'Anillo', quantity: 2, weightGrams: 5, totalGramsSold: 10, unitPrice: 100000, subtotal: 200000, costPrice: 60000 }], subtotal: 200000, discount: 0, tax: 0, total: 200000, date: '2026-07-16', status: 'paid', paymentMethod: 'Efectivo', clientNotes: 'Entregar hoy' };
const movement: FinancialMovement = { id: 'm1', type: 'sale_income', amount: 200000, originBalanceBefore: 0, originBalanceAfter: 200000, destinationBalanceBefore: 0, destinationBalanceAfter: 0, reference: 'FV-1', documentType: 'invoice', documentId: 'i1', observation: '', userId: 'u1', userName: 'Ana', date: '2026-07-16', createdAt: '2026-07-16T10:00:00' };

describe('QA 8.4 professional exports', () => {
  it('builds the individual invoice Excel from the same invoice data', () => {
    const rows = buildInvoiceExcelRows(invoice, contact, [movement]);
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ invoiceNumber: 'FV-1', document: '123', quantity: 2, grams: 10, total: 200000, user: 'Ana', observations: 'Entregar hoy' });
  });

  it('keeps filtered sales order and computes exact totals', () => {
    const context = { company, invoices: [invoice], contacts: [contact], products: [product], financialMovements: [movement], currentUserName: 'Admin', filters: { search: '', status: '', dateFrom: '', dateTo: '', user: '', sortOrder: 'desc' as const } };
    const rows = buildSalesSummaryRows(context);
    expect(rows[0].cost).toBe(120000);
    expect(rows[0].profit).toBe(80000);
    const pdf = buildSalesPdfDocument(context);
    expect(pdf.rows[0][0]).toBe('FV-1');
    expect(pdf.summaryLines?.find(line => line.label === 'Total ventas')?.value).toContain('200');
  });

  it('builds inventory rows and professional PDF totals from filtered products only', () => {
    const context = { company, products: [product], contacts: [supplier], currentUserName: 'Admin', filtersDescription: 'Categoría: Anillos' };
    const rows = buildInventoryRows(context);
    expect(rows[0]).toMatchObject({ code: 'P-1', supplier: 'Proveedor Uno', grams: 50, inventoryValue: 600000 });
    const pdf = buildInventoryPdfDocument(context);
    expect(pdf.rows).toHaveLength(1);
    expect(pdf.subtitle).toContain('Categoría: Anillos');
    expect(pdf.summaryLines?.find(line => line.label === 'Cantidad productos')?.value).toBe('1');
  });
});
