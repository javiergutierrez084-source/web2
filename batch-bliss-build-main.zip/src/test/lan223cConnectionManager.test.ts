// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => {
  const config = {
    mode: 'lan',
    role: 'client',
    autoReconnect: true,
    heartbeatIntervalSeconds: 10,
    clientId: 'client-stable',
    sessionToken: 'session-stable',
    authToken: null as string | null,
  };
  let addressReady = true;
  return {
    config,
    get addressReady() { return addressReady; },
    setAddressReady(value: boolean) { addressReady = value; },
    ensure: vi.fn(async () => ({ ...config })),
    rediscover: vi.fn(async () => { addressReady = true; return { ...config }; }),
    restoreUser: vi.fn(async () => null),
    heartbeat: vi.fn(async () => ({
      latencyMs: 1,
      lastSeen: new Date().toISOString(),
      activityCount: 1,
      serverId: 'server-stable',
      events: [],
      latestEventSequence: 0,
    })),
  };
});

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ ...mocks.config }),
  ensureLanClientSession: mocks.ensure,
  rediscoverTrustedLanServer: mocks.rediscover,
  restoreLanUser: mocks.restoreUser,
  sendLanHeartbeat: mocks.heartbeat,
  normalizeHeartbeatIntervalSeconds: (value: unknown) => Math.min(15, Math.max(10, Number(value) || 12)),
}));

vi.mock('@/lib/LanServerDescriptor', () => ({
  LanServerDescriptor: {
    changedEvent: 'joyacontrol-lan-server-descriptor-changed',
    hasAddress: () => mocks.addressReady,
    getBaseUrl: () => {
      if (!mocks.addressReady) throw new Error('LAN_SERVER_DESCRIPTOR_ADDRESS_NOT_AVAILABLE');
      return 'http://192.168.1.20:47831';
    },
    toJSON: () => ({ ip: mocks.addressReady ? '192.168.1.20' : '', serverId: 'server-stable' }),
  },
}));

beforeEach(() => {
  vi.useFakeTimers();
  mocks.setAddressReady(true);
  mocks.config.clientId = 'client-stable';
  mocks.config.sessionToken = 'session-stable';
  mocks.config.authToken = null;
  vi.clearAllMocks();
  vi.resetModules();
});

afterEach(() => {
  vi.useRealTimers();
});

async function runInitialCycle() {
  const { LanConnectionManager } = await import('@/lib/LanConnectionManager');
  LanConnectionManager.start();
  await vi.advanceTimersByTimeAsync(0);
  await Promise.resolve();
  return LanConnectionManager;
}

describe('LAN 2.2.3C connection manager after bootstrap', () => {
  it('continues reconnect and heartbeat with an already prepared descriptor', async () => {
    const manager = await runInitialCycle();

    expect(mocks.ensure).toHaveBeenCalledTimes(1);
    expect(mocks.heartbeat).toHaveBeenCalledTimes(1);
    expect(manager.getConnectionState()).toBe('ONLINE');

    manager.stop();
  });


  it('uses the configured 10-second heartbeat instead of the former aggressive interval', async () => {
    const manager = await runInitialCycle();
    expect(mocks.heartbeat).toHaveBeenCalledTimes(1);

    await vi.advanceTimersByTimeAsync(9_999);
    expect(mocks.heartbeat).toHaveBeenCalledTimes(1);

    await vi.advanceTimersByTimeAsync(1);
    await Promise.resolve();
    expect(mocks.heartbeat).toHaveBeenCalledTimes(2);

    manager.stop();
  });

  it('rediscovers the trusted server instead of surfacing an unavailable descriptor error', async () => {
    mocks.setAddressReady(false);
    const manager = await runInitialCycle();

    expect(mocks.rediscover).toHaveBeenCalledTimes(1);
    expect(mocks.ensure).toHaveBeenCalledTimes(1);
    expect(mocks.heartbeat).toHaveBeenCalledTimes(1);
    expect(manager.getConnectionState()).toBe('ONLINE');

    manager.stop();
  });
});
