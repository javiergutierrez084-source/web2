// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  restoreError: new Error('LAN_AUTH_SESSION_CONFIRMED_EXPIRED'),
  config: {
    mode: 'lan' as const,
    role: 'client' as const,
    clientId: 'CLIENT-1',
    sessionToken: 'SESSION-1',
    authToken: 'AUTH-1',
  },
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: vi.fn(),
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  ensureLanClientSession: vi.fn(async () => mocks.config),
  loadLanConfig: vi.fn(() => mocks.config),
  restoreLanUserWithGrace: vi.fn(async () => { throw mocks.restoreError; }),
  logoutLanUser: vi.fn(async () => undefined),
}));

describe('JOYACONTROL LAN V2.2 startup expiration handling', () => {
  beforeEach(() => {
    vi.resetModules();
    sessionStorage.clear();
    sessionStorage.setItem('joyacontrol_session', JSON.stringify({
      id: 'u1', username: 'master', displayName: 'Maestro', role: 'master',
    }));
  });

  it('clears the local authenticated view only after confirmed server expiration', async () => {
    mocks.restoreError = new Error('LAN_AUTH_SESSION_CONFIRMED_EXPIRED');
    const { restoreLanSession } = await import('@/lib/auth');

    await expect(restoreLanSession()).resolves.toBeNull();
    expect(sessionStorage.getItem('joyacontrol_session')).toBeNull();
  });

  it('keeps the local authenticated view during a temporary communication failure', async () => {
    mocks.restoreError = new Error('LAN_AUTH_RESTORE_TIMEOUT');
    const { restoreLanSession } = await import('@/lib/auth');

    await expect(restoreLanSession()).resolves.toBeNull();
    expect(sessionStorage.getItem('joyacontrol_session')).not.toBeNull();
  });
});
