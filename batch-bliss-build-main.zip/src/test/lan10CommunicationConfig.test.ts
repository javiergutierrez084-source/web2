// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  buildHealthUrl,
  createDefaultLanConfig,
  isValidNetworkAddress,
  isValidPort,
  LAN_CONFIG_STORAGE_KEY,
  normalizeHeartbeatIntervalSeconds,
  loadLanConfig,
  probeLanServer,
  resetLanConfig,
  saveLanConfig,
  validateLanConfig,
} from '@/lib/LanCommunicationConfig';

describe('LAN 1.0 communication configuration', () => {
  beforeEach(() => localStorage.clear());

  it('validates IPv4, hostnames and ports', () => {
    expect(isValidNetworkAddress('192.168.1.20')).toBe(true);
    expect(isValidNetworkAddress('servidor-joya.local')).toBe(true);
    expect(isValidNetworkAddress('999.1.1.1')).toBe(false);
    expect(isValidPort(47831)).toBe(true);
    expect(isValidPort(0)).toBe(false);
    expect(isValidPort(70000)).toBe(false);
  });

  it('persists and reads LAN config independently', () => {
    const config = createDefaultLanConfig();
    config.mode = 'lan';
    config.role = 'client';
    config.clientServerIp = '192.168.0.10';
    config.clientServerPort = 5000;
    saveLanConfig(config);
    expect(loadLanConfig()).toMatchObject({ mode: 'lan', clientServerIp: '192.168.0.10', clientServerPort: 5000 });
    expect(localStorage.getItem(LAN_CONFIG_STORAGE_KEY)).toContain('192.168.0.10');
  });

  it('rejects invalid configuration', () => {
    const config = createDefaultLanConfig();
    config.role = 'client';
    config.clientServerIp = '300.0.0.1';
    config.clientServerPort = 0;
    expect(validateLanConfig(config).length).toBeGreaterThanOrEqual(2);
    expect(() => saveLanConfig(config)).toThrow();
  });

  it('resets to Local mode', () => {
    const config = createDefaultLanConfig();
    config.mode = 'lan';
    saveLanConfig(config);
    const reset = resetLanConfig();
    expect(reset.mode).toBe('local');
    expect(loadLanConfig().mode).toBe('local');
  });

  it('keeps a permanent Machine ID across LAN config resets and normalizes heartbeat to 10–15 seconds', () => {
    const first = createDefaultLanConfig();
    first.deviceName = 'Equipo antes del cambio';
    first.heartbeatIntervalSeconds = 10;
    saveLanConfig(first);

    const reset = resetLanConfig();
    reset.deviceName = 'Equipo renombrado';
    saveLanConfig(reset);

    expect(loadLanConfig().machineId).toBe(first.machineId);
    expect(loadLanConfig().deviceInstanceId).toBe(first.machineId);
    expect(normalizeHeartbeatIntervalSeconds(3)).toBe(10);
    expect(normalizeHeartbeatIntervalSeconds(12)).toBe(12);
    expect(normalizeHeartbeatIntervalSeconds(30)).toBe(15);
    expect(normalizeHeartbeatIntervalSeconds(undefined)).toBe(12);
  });

  it('probes the future health endpoint without changing repositories', async () => {
    const config = createDefaultLanConfig();
    config.role = 'client';
    config.clientServerIp = '192.168.1.5';
    config.clientServerPort = 47831;
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => ({ status: 'ok', time: new Date().toISOString() }) }));
    const result = await probeLanServer(config);
    expect(buildHealthUrl(config)).toBe('http://192.168.1.5:47831/health');
    expect(result.ok).toBe(true);
    expect(result.serverStatus).toBe('ok');
    vi.unstubAllGlobals();
  });
});
