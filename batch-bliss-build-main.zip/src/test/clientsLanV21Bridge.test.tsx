// @vitest-environment jsdom
import { act, render } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Contact } from '@/data/mockData';

const ana: Contact = {
  id: 'client-ana', type: 'client', name: 'Ana Gómez', document: '123',
  phone: '3001112233', email: 'ana@example.com', address: 'Centro', notes: '',
};

const mocks = vi.hoisted(() => ({
  repositoryHandler: null as null | ((request: { method: string; args?: Record<string, unknown> }) => Promise<unknown>),
  reload: vi.fn(async () => undefined),
  getClients: vi.fn(),
  searchClients: vi.fn(),
  getClientById: vi.fn(),
  createClient: vi.fn(),
  updateClient: vi.fn(),
  deleteClient: vi.fn(),
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    products: [], contacts: [], invoices: [], purchaseInvoices: [], expenses: [], layaways: [],
    cashSessions: [], financialAccounts: [], financialMovements: [], financialSummary: null,
    reloadFromDatabase: mocks.reload,
  }),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => ({ loginUser: vi.fn() }),
}));

vi.mock('@/lib/DashboardRepositoryService', () => ({
  DashboardRepositoryService: { buildServerMetrics: vi.fn() },
}));

vi.mock('@/lib/SalesRepositoryService', () => ({
  SalesRepositoryService: {
    getSalesWorkspace: vi.fn(),
    getClients: mocks.getClients,
    searchClients: mocks.searchClients,
    getClientById: mocks.getClientById,
    createClient: mocks.createClient,
    updateClient: mocks.updateClient,
    deleteClient: mocks.deleteClient,
    querySales: vi.fn(), getSaleById: vi.fn(), createSale: vi.fn(), updateSaleStatus: vi.fn(),
    cancelSale: vi.fn(), applyContactChanges: vi.fn(), createQuotation: vi.fn(),
    updateQuotationStatus: vi.fn(), createLayaway: vi.fn(), updateLayaway: vi.fn(),
    deleteLayaway: vi.fn(), addLayawayPayment: vi.fn(), completeLayaway: vi.fn(),
  },
}));

import LanAuthenticationBridge from '@/components/LanAuthenticationBridge';

beforeEach(() => {
  mocks.repositoryHandler = null;
  mocks.reload.mockClear();
  mocks.getClients.mockReset().mockResolvedValue([ana]);
  mocks.searchClients.mockReset().mockResolvedValue([ana]);
  mocks.getClientById.mockReset().mockResolvedValue(ana);
  mocks.createClient.mockReset().mockResolvedValue(ana);
  mocks.updateClient.mockReset().mockResolvedValue({ ...ana, phone: '3110000000' });
  mocks.deleteClient.mockReset().mockResolvedValue(undefined);

  window.joyaControlLan = {
    onAuthRequest: () => () => undefined,
    onRepositoryRequest: handler => {
      mocks.repositoryHandler = request => handler({
        ...request,
        args: {
          ...(request.args || {}),
          __joyaControlAuthorizedLanSession: {
            id: 'server-authorized-user',
            username: 'master',
            displayName: 'Master',
            role: 'master',
            permissions: ['manage_contacts', 'create_sales', 'edit_sales', 'cancel_invoices', 'manage_layaways'],
          },
        },
      });
      return () => { mocks.repositoryHandler = null; };
    },
  } as typeof window.joyaControlLan;
});

describe('Clients LAN V2.1 server dispatcher', () => {
  it('dispatches all Client operations and refreshes state after writes', async () => {
    const view = render(<LanAuthenticationBridge />);
    expect(mocks.repositoryHandler).not.toBeNull();

    await expect(mocks.repositoryHandler?.({ method: 'getSalesClients', args: {} })).resolves.toEqual([ana]);
    await expect(mocks.repositoryHandler?.({ method: 'searchSalesClients', args: { text: 'Ana' } })).resolves.toEqual([ana]);
    await expect(mocks.repositoryHandler?.({ method: 'getSalesClientById', args: { id: ana.id } })).resolves.toEqual(ana);

    await act(async () => {
      await expect(mocks.repositoryHandler?.({ method: 'createSalesClient', args: { client: ana } })).resolves.toEqual(ana);
      await expect(mocks.repositoryHandler?.({ method: 'updateSalesClient', args: { client: { ...ana, phone: '3110000000' } } })).resolves.toMatchObject({ phone: '3110000000' });
      await expect(mocks.repositoryHandler?.({ method: 'deleteSalesClient', args: { id: ana.id } })).resolves.toBeUndefined();
    });

    expect(mocks.getClients).toHaveBeenCalledTimes(1);
    expect(mocks.searchClients).toHaveBeenCalledWith('Ana');
    expect(mocks.getClientById).toHaveBeenCalledWith(ana.id);
    expect(mocks.createClient).toHaveBeenCalledWith(ana);
    expect(mocks.updateClient).toHaveBeenCalledTimes(1);
    expect(mocks.deleteClient).toHaveBeenCalledWith(ana.id);
    expect(mocks.reload).toHaveBeenCalledTimes(3);

    view.unmount();
    expect(mocks.repositoryHandler).toBeNull();
  });
});
