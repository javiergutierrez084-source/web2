import { describe, expect, it } from 'vitest';
import { adjustInvoiceItemsToFinalTotal } from '@/lib/InvoiceTotalAdjustmentService';
import { buildInvoiceDocumentData } from '@/lib/invoicePdf';
import type { InvoiceItem, Invoice } from '@/data/mockData';

const items: InvoiceItem[] = [
  { productId: 'p1', code: 'A', name: 'Anillo', quantity: 5, weightGrams: 5, unitPrice: 201000, subtotal: 1005000 },
];

describe('QA #8 - ajuste manual del total', () => {
  it.each([1000000, 1010000, 1005000])('acepta total final %s', finalTotal => {
    const result = adjustInvoiceItemsToFinalTotal(items, finalTotal);
    expect(result.calculatedTotal).toBe(1005000);
    expect(result.finalTotal).toBe(finalTotal);
    expect(result.items.reduce((sum, item) => sum + item.subtotal, 0)).toBe(finalTotal);
    expect(result.items[0].quantity).toBe(5);
    expect(result.items[0].weightGrams).toBe(5);
    expect(result.items[0].costPrice).toBeUndefined();
  });

  it.each([0, -1, Number.NaN, Number.POSITIVE_INFINITY])('rechaza total inválido %s', finalTotal => {
    expect(() => adjustInvoiceItemsToFinalTotal(items, finalTotal)).toThrow('INVALID_MANUAL_TOTAL');
  });

  it('el PDF conserva únicamente el total final y no crea descuento o recargo', () => {
    const adjusted = adjustInvoiceItemsToFinalTotal(items, 1000000);
    const invoice: Invoice = {
      id: 'f1', number: 'FAC-1', clientId: 'c1', clientName: 'Cliente', items: adjusted.items,
      subtotal: adjusted.finalTotal, discount: 0, tax: 0, total: adjusted.finalTotal,
      date: '2026-07-16', status: 'paid', tipoDocumento: 'factura',
    };
    const document = buildInvoiceDocumentData({
      invoice, type: 'sale', company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
    });
    expect(document.total).toBe(1000000);
    expect(document.discount).toBe(0);
    expect(document.tax).toBe(0);
    expect(JSON.stringify(document)).not.toContain('Precio ajustado');
    expect(JSON.stringify(document)).not.toContain('Recargo');
  });
});

it('calcula la diferencia auditable sin alterar los artículos', () => {
  const result = adjustInvoiceItemsToFinalTotal(items, 1000000);
  expect(result.finalTotal - result.calculatedTotal).toBe(-5000);
  expect(result.items[0].quantity).toBe(items[0].quantity);
  expect(result.items[0].weightGrams).toBe(items[0].weightGrams);
});
