// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { detectLanIpv4, LanServerDescriptor } from '../../electron/lanServerDescriptor.js';
import { refreshLanServerNetworkAddress, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}
const post = (url: string, body: object) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
afterEach(async () => { await stopLanServer(); });

describe('LAN automatic Principal Server IPv4', () => {
  it('accepts only private IPv4 addresses from physical interfaces and ignores virtual adapters', () => {
    expect(detectLanIpv4({
      'vEthernet (WSL)': [{ address: '172.28.64.1', family: 'IPv4', internal: false }],
      'Docker Desktop': [{ address: '192.168.65.1', family: 'IPv4', internal: false }],
      'VMware Network Adapter VMnet8': [{ address: '192.168.220.1', family: 'IPv4', internal: false }],
      'Tailscale VPN': [{ address: '10.80.70.60', family: 'IPv4', internal: false }],
      'Wi-Fi': [{ address: '192.168.20.5', family: 'IPv4', internal: false }],
      'Ethernet': [{ address: '10.0.0.18', family: 'IPv4', internal: false }],
    })).toBe('10.0.0.18');
    expect(detectLanIpv4({
      Docker: [{ address: '172.20.0.1', family: 'IPv4', internal: false }],
      WSL: [{ address: '172.21.0.1', family: 'IPv4', internal: false }],
      Loopback: [{ address: '127.0.0.1', family: 'IPv4', internal: true }],
    })).toBe('');
  });

  it('removes loopback, preserves the last LAN IP and keeps server identity through DHCP changes', () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan226-descriptor-'));
    try {
      fs.writeFileSync(path.join(userDataPath, 'lan-server-descriptor.json'), JSON.stringify({
        serverId: 'SERVER-ABC', companyId: 'COMPANY-ABC', serverName: 'Servidor Principal',
        ip: '127.0.0.1', port: 47831, protocolVersion: 'LAN-1', baseUrl: 'http://127.0.0.1:47831',
        enabled: true, addressMode: 'automatic',
      }), 'utf8');
      const descriptor = new LanServerDescriptor(userDataPath);
      expect(descriptor.load()).toMatchObject({ ip: '', baseUrl: '', networkAvailable: false });
      expect(descriptor.refreshDetectedIp('192.168.20.5')).toMatchObject({
        serverId: 'SERVER-ABC', companyId: 'COMPANY-ABC', ip: '192.168.20.5', lastLanIp: '192.168.20.5', ipSource: 'automatic', networkAvailable: true,
      });
      expect(descriptor.refreshDetectedIp('')).toMatchObject({
        serverId: 'SERVER-ABC', companyId: 'COMPANY-ABC', ip: '', baseUrl: '', lastLanIp: '192.168.20.5', ipSource: 'unavailable', networkAvailable: false,
      });
      expect(descriptor.refreshDetectedIp('192.168.20.18')).toMatchObject({
        serverId: 'SERVER-ABC', companyId: 'COMPANY-ABC', ip: '192.168.20.18', lastLanIp: '192.168.20.18', ipSource: 'automatic', networkAvailable: true,
      });
    } finally { fs.rmSync(userDataPath, { recursive: true, force: true }); }
  });

  it('updates health and server-info after an IP change without duplicating the client session', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan226-runtime-'));
    const port = await freePort();
    try {
      const descriptor = new LanServerDescriptor(userDataPath);
      descriptor.update({ serverId: 'SERVER-STABLE', companyId: 'COMPANY-STABLE', addressMode: 'automatic', enabled: true });
      descriptor.refreshDetectedIp('192.168.20.5');
      const started = await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Principal', descriptor, userDataPath, version: '2.1' });
      const baseUrl = `http://127.0.0.1:${port}`;
      const registerResponse = await post(`${baseUrl}/client/register`, {
        name: 'Cliente estable', hostname: 'cliente-estable', ip: '192.168.20.30', version: '2.1', operatingSystem: 'Windows', localTime: new Date().toISOString(), deviceInstanceId: 'DEVICE-STABLE',
      });
      const registration = await registerResponse.json() as { clientId: string; sessionToken: string };
      expect(registerResponse.status).toBe(201);
      expect(refreshLanServerNetworkAddress('')).toMatchObject({
        serverId: started.serverId,
        companyId: started.companyId,
        ip: '',
        lastLanIp: expect.any(String),
        networkAvailable: false,
      });
      const offlineHealth = await (await fetch(`${baseUrl}/health`)).json() as Record<string, unknown>;
      expect(offlineHealth).toMatchObject({ serverId: started.serverId, companyId: started.companyId, ip: null, baseUrl: null, networkAvailable: false });

      expect(refreshLanServerNetworkAddress('192.168.20.18')).toMatchObject({ serverId: started.serverId, companyId: started.companyId, ip: '192.168.20.18' });
      const health = await (await fetch(`${baseUrl}/health`)).json() as Record<string, unknown>;
      const info = await (await fetch(`${baseUrl}/server-info`)).json() as Record<string, unknown>;
      expect(health).toMatchObject({ serverId: started.serverId, companyId: started.companyId, ip: '192.168.20.18', baseUrl: `http://192.168.20.18:${port}`, networkAvailable: true });
      expect(info).toMatchObject({ serverId: started.serverId, companyId: started.companyId, ip: '192.168.20.18', baseUrl: `http://192.168.20.18:${port}`, networkAvailable: true });
      expect((await post(`${baseUrl}/client/ping`, { clientId: registration.clientId, sessionToken: registration.sessionToken, timestamp: new Date().toISOString() })).status).toBe(200);
      const clients = await (await fetch(`${baseUrl}/clients`)).json() as { clients: Array<{ clientId: string }> };
      expect(clients.clients).toHaveLength(1);
      expect(clients.clients[0].clientId).toBe(registration.clientId);
    } finally { await stopLanServer(); fs.rmSync(userDataPath, { recursive: true, force: true }); }
  });

  it('detects the automatic address before creating the Electron window and exposes the required UI', () => {
    const main = fs.readFileSync(path.resolve('electron/main.js'), 'utf8');
    const panel = fs.readFileSync(path.resolve('src/components/LanCommunicationPanel.tsx'), 'utf8');
    const startupLoad = main.indexOf('const loadedDescriptor = descriptorStore.load();');
    const startupDetect = main.indexOf('descriptorStore.refreshDetectedIp();', startupLoad);
    const windowCreation = main.indexOf('await createWindow();', startupLoad);
    expect(startupLoad).toBeGreaterThan(-1);
    expect(startupDetect).toBeGreaterThan(startupLoad);
    expect(startupDetect).toBeLessThan(windowCreation);
    expect(panel).toContain('label="IP actual"');
    expect(panel).toContain('label="Origen"');
    expect(panel).toContain('Detectada automáticamente');
    expect(panel).toContain('label="Última actualización"');
    expect(panel).toContain('Sin conexión de red');
  });
});
