import { readFileSync } from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  mockContacts,
  mockExpenses,
  mockProducts,
  type Contact,
  type Product,
  type PurchaseInvoice,
} from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import { buildPurchaseDocumentRows } from '@/lib/PurchaseDocumentsService';
import { createSupplierHistoryService } from '@/lib/SupplierHistoryService';

const supplier: Contact = {
  id: 'supplier-abc', type: 'supplier', name: 'IMPORTADORA ABC', document: '',
  phone: '', email: '', address: '',
};

const product: Product = {
  id: 'product-1', code: 'P-001', name: 'Producto', category: 'General',
  purchasePrice: 100, salePrice: 150, weightGrams: 12, margin: 50,
  stock: 0, minStock: 0, supplierIds: ['supplier-abc'],
};

const purchase: PurchaseInvoice = {
  id: 'purchase-1', number: 'COM-001', supplierId: 'supplier-abc', supplierName: 'IMPORTADORA ABC',
  items: [{ productId: product.id, code: product.code, name: product.name, quantity: 3, weightGrams: 12, unitPrice: 100, subtotal: 300 }],
  subtotal: 300, discount: 0, tax: 0, total: 300, date: '2026-07-20', status: 'pending',
};

const payable: SupplierInvoiceView = {
  id: 'payable-1', supplierId: supplier.id, supplierName: supplier.name,
  invoiceNumber: purchase.number, issueDate: purchase.date, dueDate: '2026-08-20',
  total: purchase.total, initialValue: purchase.total, pendingBalance: 150,
  sourceType: 'purchase_invoice', sourceId: purchase.id, status: 'partial', notes: '', payments: [],
};

describe('regresión de trazabilidad documental de proveedores', () => {
  it('recupera el histórico del proveedor existente Oro Fino desde la misma vista de Compras', () => {
    const existingSupplier = mockContacts.find(contact => contact.name === 'Oro Fino S.A.S')!;
    const documents = buildPurchaseDocumentRows({
      purchases: [],
      payables: [],
      legacyExpenses: mockExpenses,
    });
    const purchaseCenterRows = documents.filter(document =>
      document.supplierId === existingSupplier.id && document.status !== 'cancelled');

    const history = createSupplierHistoryService({
      contacts: mockContacts,
      products: mockProducts,
      documents,
      supplierInvoices: [],
      inventoryAdjustments: [],
    }).getSupplierHistory(existingSupplier.id);

    expect(purchaseCenterRows).toHaveLength(1);
    expect(history.documentos.map(document => document.id)).toEqual(
      purchaseCenterRows.map(document => document.id),
    );
    expect(history.totalInvertido).toBe(150_000);
    expect(history.totalGramos).toBe(0);
    expect(history.numeroEntradas).toBe(1);
    expect(history.ultimaCompra).toBe('2026-02-22');
  });

  it('Contactos coincide exactamente con la fila visible en Compras', () => {
    const documents = buildPurchaseDocumentRows({
      purchases: [purchase],
      payables: [payable],
      legacyExpenses: [],
    });
    const purchaseCenterRows = documents.filter(document =>
      document.supplierId === supplier.id && document.status !== 'cancelled');

    const history = createSupplierHistoryService({
      contacts: [supplier],
      products: [product],
      documents,
      supplierInvoices: [payable],
      inventoryAdjustments: [],
    }).getSupplierHistory(supplier.id);

    expect(purchaseCenterRows).toHaveLength(1);
    expect(history.documentos.map(document => document.id)).toEqual(
      purchaseCenterRows.map(document => document.id),
    );
    expect(history.totalInvertido).toBe(
      purchaseCenterRows.reduce((sum, document) => sum + document.total, 0),
    );
    expect(history.totalInvertido).toBe(300);
    expect(history.totalGramos).toBe(36);
    expect(history.numeroEntradas).toBe(1);
    expect(history.ultimaCompra).toBe('2026-07-20');
  });



  it('reconstruye el histórico de Oro Fino mediante sus productos asociados', () => {
    const existingSupplier = mockContacts.find(contact => contact.name === 'Oro Fino S.A.S')!;
    const associatedProducts = mockProducts.filter(item =>
      item.supplierIds?.includes(existingSupplier.id));
    const directProduct = associatedProducts.find(item => item.supplierIds?.length === 1)!;
    const sharedProduct = associatedProducts.find(item => (item.supplierIds?.length ?? 0) > 1)!;

    const directPurchase: PurchaseInvoice = {
      id: 'oro-direct',
      number: 'COM-ORO-DIRECTA',
      supplierId: existingSupplier.id,
      supplierName: existingSupplier.name,
      items: [{
        productId: directProduct.id,
        code: directProduct.code,
        name: directProduct.name,
        quantity: 1,
        weightGrams: directProduct.weightGrams,
        unitPrice: 450_000,
        subtotal: 450_000,
      }],
      subtotal: 450_000,
      discount: 0,
      tax: 0,
      total: 450_000,
      date: '2026-07-20',
      status: 'paid',
    };
    const historicalPurchase: PurchaseInvoice = {
      id: 'oro-historical-without-supplier',
      number: 'COM-ORO-HISTORICA',
      supplierId: '',
      supplierName: '',
      items: [{
        productId: sharedProduct.id,
        code: sharedProduct.code,
        name: sharedProduct.name,
        quantity: 2,
        weightGrams: sharedProduct.weightGrams,
        unitPrice: 320_000,
        subtotal: 640_000,
      }],
      subtotal: 640_000,
      discount: 0,
      tax: 0,
      total: 640_000,
      date: '2026-06-15',
      status: 'paid',
    };

    const history = createSupplierHistoryService({
      contacts: mockContacts,
      products: mockProducts,
      documents: buildPurchaseDocumentRows({
        purchases: [directPurchase, historicalPurchase, { ...historicalPurchase }],
        payables: [],
        legacyExpenses: [],
      }),
      supplierInvoices: [],
      inventoryAdjustments: [],
    }).getSupplierHistory(existingSupplier.id);

    expect(history.trazabilidad).toEqual({
      productosAsociados: 6,
      documentosPorSupplierId: 1,
      documentosPorSupplierName: 0,
      documentosPorProductos: 1,
      documentosDuplicadosDescartados: 2,
    });
    expect(history.totalInvertido).toBe(1_090_000);
    expect(history.totalGramos).toBeCloseTo(11.9, 6);
    expect(history.numeroEntradas).toBe(2);
    expect(history.ultimaCompra).toBe('2026-07-20');
  });

  it('el hook construye la misma fuente que Compras y Contacts solo consume el servicio', () => {
    const hookSource = readFileSync(path.join(process.cwd(), 'src/hooks/useSupplierHistoryService.ts'), 'utf8');
    const contactsSource = readFileSync(path.join(process.cwd(), 'src/pages/Contacts.tsx'), 'utf8');

    expect(hookSource).toContain('buildPurchaseDocumentRows');
    expect(hookSource).toContain('fetchSupplierInvoices');
    expect(hookSource).toContain('legacyExpenses: expenses');
    expect(hookSource).toContain('documents,');

    expect(contactsSource).toContain('useSupplierHistoryService');
    expect(contactsSource).toContain('supplierHistoryService.getSupplierHistory');
    expect(contactsSource).not.toContain('calculateSupplierPurchaseSummary');
    expect(contactsSource).not.toContain('fetchInventoryAdjustments');
    expect(contactsSource).not.toContain('purchaseInvoices');
    expect(contactsSource).not.toContain('inventoryAdjustments');
  });
});
