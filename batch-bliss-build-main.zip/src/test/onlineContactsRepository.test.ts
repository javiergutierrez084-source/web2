import { describe, expect, it, vi } from 'vitest';
import {
  OnlineContactsRepository,
  ONLINE_CONTACTS_CACHE_TTL_MS,
} from '@/lib/OnlineContactsRepository';

const CONNECTION = {
  url: 'https://midominio.com',
  port: 443,
  sessionId: 'a'.repeat(43),
  serverId: '11111111-1111-4111-8111-111111111111',
  version: '3.0.0',
};

const CONTACTS = [
  {
    id: 'client-1',
    type: 'client' as const,
    name: 'Cliente Uno',
    document: '1001',
    phone: '3001001001',
    email: 'cliente@correo.test',
    address: 'Calle 1',
    notes: '',
    status: 'active' as const,
  },
  {
    id: 'supplier-1',
    type: 'supplier' as const,
    name: 'Proveedor Oro',
    document: '9001',
    phone: '3009001001',
    email: 'proveedor@correo.test',
    address: 'Carrera 2',
    notes: '',
    status: 'active' as const,
  },
];

describe('OnlineContactsRepository', () => {
  it('consulta lista, detalle y búsqueda usando solo recursos GET', async () => {
    const transport = vi.fn(async ({ resource, args }) => {
      const data = resource === 'contacts'
        ? CONTACTS
        : resource === 'contact'
          ? CONTACTS.find(contact => contact.id === args?.id)
          : CONTACTS.filter(contact => contact.name.toLowerCase().includes(String(args?.query).toLowerCase()));
      return {
        ok: true as const,
        resource,
        data,
        latencyMs: 12,
        communicatedAt: '2026-07-28T20:00:00.000Z',
      };
    });
    const repository = new OnlineContactsRepository(CONNECTION, { transport: transport as never });

    const all = await repository.getContacts();
    const detail = await repository.getContact('client-1');
    const search = await repository.searchContacts('oro');

    expect(all.totalClients).toBe(1);
    expect(all.totalSuppliers).toBe(1);
    expect(detail.id).toBe('client-1');
    expect(search.map(contact => contact.id)).toEqual(['supplier-1']);
    expect(transport.mock.calls.map(([options]) => options.resource)).toEqual([
      'contacts',
      'contact',
      'contactsSearch',
    ]);
  });

  it('mantiene cache en memoria durante 60 segundos y lo renueva al vencer', async () => {
    let now = Date.parse('2026-07-28T20:00:00.000Z');
    const transport = vi.fn(async ({ resource }) => ({
      ok: true as const,
      resource,
      data: CONTACTS,
      latencyMs: 10,
      communicatedAt: new Date(now).toISOString(),
    }));
    const repository = new OnlineContactsRepository(CONNECTION, {
      transport: transport as never,
      now: () => now,
    });

    const first = await repository.getContacts();
    now += ONLINE_CONTACTS_CACHE_TTL_MS - 1;
    const cached = await repository.getContacts();
    now += 2;
    const renewed = await repository.getContacts();

    expect(first.fromCache).toBe(false);
    expect(cached.fromCache).toBe(true);
    expect(renewed.fromCache).toBe(false);
    expect(transport).toHaveBeenCalledTimes(2);
  });

  it('no guarda contactos en localStorage y no expone escrituras', async () => {
    const setItem = vi.spyOn(Storage.prototype, 'setItem');
    const repository = new OnlineContactsRepository(CONNECTION, {
      transport: (async ({ resource }) => ({
        ok: true,
        resource,
        data: CONTACTS,
        latencyMs: 1,
        communicatedAt: '2026-07-28T20:00:00.000Z',
      })) as never,
    });

    await repository.getContacts();
    expect(setItem).not.toHaveBeenCalled();
    const methods = Object.getOwnPropertyNames(OnlineContactsRepository.prototype);
    expect(methods).toEqual(expect.arrayContaining(['getContacts', 'getContact', 'searchContacts', 'clearCache']));
    expect(methods).not.toEqual(expect.arrayContaining(['create', 'update', 'delete', 'post', 'put', 'patch', 'sync']));
    setItem.mockRestore();
  });

  it('propaga token inválido, expirado, timeout y servidor apagado', async () => {
    for (const code of [
      'HTTPS_SESSION_INVALID',
      'HTTPS_SESSION_EXPIRED',
      'HTTPS_TIMEOUT',
      'HTTPS_SERVER_NOT_FOUND',
    ]) {
      const repository = new OnlineContactsRepository(CONNECTION, {
        transport: (async () => ({ ok: false, errorCode: code, errorMessage: code })) as never,
      });
      await expect(repository.getContacts()).rejects.toMatchObject({ code });
    }
  });
});
