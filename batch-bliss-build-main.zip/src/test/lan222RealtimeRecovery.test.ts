// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { publishLanRepositoryEvent, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

const post = (url: string, body: object) => fetch(url, {
  method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
});

afterEach(async () => { await stopLanServer(); });

describe('QA LAN 2.2.2 - eventos comerciales de solo invalidación', () => {
  it('entrega PRODUCTS_UPDATED por el heartbeat sin crear sincronización comercial', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan222-'));
    try {
      await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1' });
      const base = `http://127.0.0.1:${port}`;
      const registered = await (await post(`${base}/client/register`, {
        name: 'Cliente QA', hostname: 'cliente-qa', version: '2.1', localTime: new Date().toISOString(), deviceInstanceId: 'device-qa-222',
      })).json() as { clientId: string; sessionToken: string };
      publishLanRepositoryEvent('PRODUCTS_UPDATED');
      const ping = await (await post(`${base}/client/ping`, {
        clientId: registered.clientId, sessionToken: registered.sessionToken, timestamp: new Date().toISOString(), lastEventSequence: 0,
      })).json() as { repositoryEvents: Array<{ type: string; sequence: number }>; latestEventSequence: number };
      expect(ping.repositoryEvents).toHaveLength(1);
      expect(ping.repositoryEvents[0].type).toBe('PRODUCTS_UPDATED');
      expect(ping.latestEventSequence).toBe(ping.repositoryEvents[0].sequence);
      const secondPing = await (await post(`${base}/client/ping`, {
        clientId: registered.clientId, sessionToken: registered.sessionToken, timestamp: new Date().toISOString(), lastEventSequence: ping.latestEventSequence,
      })).json() as { repositoryEvents: unknown[] };
      expect(secondPing.repositoryEvents).toHaveLength(0);
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });

  it('centraliza estado, reconexión e invalidación en LanConnectionManager', () => {
    const manager = fs.readFileSync(path.resolve('src/lib/LanConnectionManager.ts'), 'utf8');
    const inventory = fs.readFileSync(path.resolve('src/pages/Inventory.tsx'), 'utf8');
    expect(manager).toContain("'ONLINE'");
    expect(manager).toContain("'OFFLINE'");
    expect(manager).toContain("'RECONNECTING'");
    expect(manager).toContain('restoreLanUser');
    expect(manager).toContain('invalidateCache');
    expect(inventory).not.toContain('/health');
    expect(inventory).not.toContain('sendLanHeartbeat');
  });
});
