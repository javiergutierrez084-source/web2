import { describe, expect, it, vi } from 'vitest';
import {
  ONLINE_REPOSITORY_CACHE_TTL_MS,
  OnlineRepositoryReadError,
  OnlineRepositoryReader,
  isOnlineRepositorySessionError,
  type OnlineReadResource,
} from '@/lib/OnlineRepositoryReader';

const DATA = {
  me: {
    id: 'user-admin-1',
    usuario: 'admin',
    nombre: 'Administrador Principal',
    rol: 'admin',
    permisos: ['view_reports', 'manage_settings'],
  },
  company: {
    nombreEmpresa: 'JoyaControl Principal',
    nit: '900123456-7',
    direccion: 'Calle Principal 10',
    ciudad: 'Bogotá',
    telefonos: ['3001234567'],
    correo: 'contacto@joyacontrol.test',
    logo: '',
    configuracionImpresion: null,
  },
  permissions: { permisos: ['view_reports', 'manage_settings'] },
};

const CONNECTION = {
  url: 'https://midominio.com',
  port: 443,
  sessionId: 'a'.repeat(43),
  serverId: '11111111-1111-4111-8111-111111111111',
  version: '3.0.0',
};

describe('OnlineRepositoryReader', () => {
  it('usa cache en memoria durante 60 segundos y la renueva automáticamente al vencer', async () => {
    let clock = Date.parse('2026-07-28T20:00:00.000Z');
    const transport = vi.fn(async ({ resource }: { resource: OnlineReadResource }) => ({
      ok: true as const,
      resource,
      data: DATA[resource],
      latencyMs: 25,
      communicatedAt: new Date(clock).toISOString(),
    }));
    const reader = new OnlineRepositoryReader(CONNECTION, {
      now: () => clock,
      transport: transport as never,
    });

    const first = await reader.getSnapshot();
    expect(first.fromCache).toBe(false);
    expect(first.permissions).toEqual(DATA.permissions.permisos);
    expect(transport).toHaveBeenCalledTimes(3);

    clock += ONLINE_REPOSITORY_CACHE_TTL_MS - 1;
    const cached = await reader.getSnapshot();
    expect(cached.fromCache).toBe(true);
    expect(transport).toHaveBeenCalledTimes(3);

    clock += 2;
    const renewed = await reader.getSnapshot();
    expect(renewed.fromCache).toBe(false);
    expect(transport).toHaveBeenCalledTimes(6);
  });

  it('permite forzar la renovación antes del vencimiento', async () => {
    let clock = Date.parse('2026-07-28T20:00:00.000Z');
    const transport = vi.fn(async ({ resource }: { resource: OnlineReadResource }) => ({
      ok: true as const,
      resource,
      data: DATA[resource],
      latencyMs: 10,
      communicatedAt: new Date(clock).toISOString(),
    }));
    const reader = new OnlineRepositoryReader(CONNECTION, {
      now: () => clock,
      transport: transport as never,
    });

    await reader.getSnapshot();
    clock += 1_000;
    await reader.getSnapshot(true);
    expect(transport).toHaveBeenCalledTimes(6);
  });

  it('propaga sesión inválida o expirada para volver al login', async () => {
    for (const code of ['HTTPS_SESSION_INVALID', 'HTTPS_SESSION_EXPIRED']) {
      const reader = new OnlineRepositoryReader(CONNECTION, {
        transport: (async () => ({ ok: false, errorCode: code, errorMessage: 'Sesión no disponible' })) as never,
      });
      await expect(reader.getSnapshot()).rejects.toMatchObject({ code });
      expect(isOnlineRepositorySessionError(new OnlineRepositoryReadError(code, 'error'))).toBe(true);
    }
  });

  it('no expone operaciones de escritura', () => {
    const methods = Object.getOwnPropertyNames(OnlineRepositoryReader.prototype);
    expect(methods).toEqual(expect.arrayContaining(['getMe', 'getCompany', 'getPermissions', 'getSnapshot', 'clearCache']));
    expect(methods).not.toEqual(expect.arrayContaining(['create', 'update', 'delete', 'post', 'put', 'sync']));
  });
});
