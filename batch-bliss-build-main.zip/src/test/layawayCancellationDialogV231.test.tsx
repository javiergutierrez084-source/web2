// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Layaway } from '@/domain/models';

const mocks = vi.hoisted(() => ({
  deleteLayaway: vi.fn(),
  querySales: vi.fn(),
  toast: vi.fn(),
}));

const layaway: Layaway = {
  id: 'layaway-1', invoiceId: 'invoice-1', completed: false,
  invoice: {
    id: 'invoice-1', number: 'SEP-1', clientId: 'client-1', clientName: 'Cliente Uno',
    subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-21', status: 'pending',
    paymentMethod: 'Efectivo', items: [],
  },
  payments: [{ id: 'payment-1', amount: 40, date: '2026-07-21', method: 'Efectivo' }],
};

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
    invoices: [layaway.invoice],
    contacts: [{ id: 'client-1', type: 'client', name: 'Cliente Uno', document: '1', phone: '', email: '', address: '' }],
    layaways: [layaway], products: [],
    financialAccounts: [{ id: 'account-caja-principal', name: 'Caja Principal', kind: 'cash', active: true, balance: 0, createdAt: '', updatedAt: '' }],
    financialMovements: [],
    recordLayawayPayment: vi.fn(), completeLayaway: vi.fn(), updateLayaway: vi.fn(),
    deleteLayaway: mocks.deleteLayaway, cancelInvoice: vi.fn(),
  }),
}));
vi.mock('@/contexts/AuthContext', () => ({ useAuth: () => ({ user: { username: 'admin', displayName: 'Admin' } }) }));
vi.mock('@/hooks/use-toast', () => ({ useToast: () => ({ toast: mocks.toast }) }));
vi.mock('@/lib/SalesRepositoryService', () => ({ SalesRepositoryService: { querySales: mocks.querySales } }));
vi.mock('@/components/InvoicePreview', () => ({ default: () => null }));
vi.mock('@/components/PdfDocumentActions', () => ({ default: () => null }));
vi.mock('@/components/DirectPdfActionButton', () => ({ default: () => null }));
vi.mock('@/components/ExcelExportButton', () => ({ default: () => null }));
vi.mock('@/components/ClientSearchCombobox', () => ({ default: () => null }));

import Sales from '@/pages/Sales';

describe('JOYACONTROL V2.3.1 - diálogo de cancelación de separados', () => {
  afterEach(() => cleanup());
  beforeEach(() => {
    mocks.deleteLayaway.mockReset().mockResolvedValue(undefined);
    mocks.querySales.mockReset().mockResolvedValue([]);
    mocks.toast.mockReset();
  });

  it('exige una resolución financiera y envía devolución al Repository', async () => {
    render(<MemoryRouter><Sales /></MemoryRouter>);
    fireEvent.click(screen.getByRole('button', { name: /Separados/i }));
    fireEvent.click(await screen.findByRole('button', { name: 'Cancelar SEP-1' }));

    expect(screen.getByText('Este separado posee abonos registrados.')).not.toBeNull();
    expect(screen.getByText(/Total abonado:/)).not.toBeNull();
    expect(screen.getByText('Devolver dinero al cliente')).not.toBeNull();
    expect(screen.getByText('Convertir en saldo a favor del cliente')).not.toBeNull();
    expect(screen.getByText('Cancelar operación')).not.toBeNull();

    fireEvent.click(screen.getByText('Devolver dinero al cliente'));
    fireEvent.click(screen.getByRole('button', { name: 'Confirmar cancelación' }));

    await waitFor(() => expect(mocks.deleteLayaway).toHaveBeenCalledWith('layaway-1', 'refund'));
  });

  it('cierra sin ejecutar cambios cuando se elige Cancelar operación', async () => {
    render(<MemoryRouter><Sales /></MemoryRouter>);
    fireEvent.click(screen.getByRole('button', { name: /Separados/i }));
    fireEvent.click(await screen.findByRole('button', { name: 'Cancelar SEP-1' }));
    fireEvent.click(screen.getByText('Cancelar operación'));
    fireEvent.click(screen.getByRole('button', { name: 'Cerrar sin cambios' }));

    await waitFor(() => expect(screen.queryByText('Este separado posee abonos registrados.')).toBeNull());
    expect(mocks.deleteLayaway).not.toHaveBeenCalled();
  });
});
