// @vitest-environment jsdom
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it, vi } from 'vitest';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';


Object.defineProperty(Element.prototype, 'scrollIntoView', { value: vi.fn(), configurable: true });

const recordInvoice = vi.fn(async () => undefined);
const toast = vi.fn();

vi.mock('@/hooks/use-toast', () => ({ useToast: () => ({ toast }) }));
vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    products: [{ id: 'product-1', code: 'P-1', name: 'Anillo', category: 'Joyas', purchasePrice: 100, salePrice: 600, weightGrams: 1, margin: 500, stock: 10, minStock: 1 }],
    contacts: [{ id: 'customer-1', type: 'client', name: 'Cliente Crédito', document: '123', phone: '', email: '', address: '' }],
    setContacts: vi.fn(),
    invoices: [],
    layaways: [],
    financialAccounts: [
      { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash', active: true, balance: 1000, createdAt: '', updatedAt: '' },
      { id: LAYAWAY_RESERVE_ACCOUNT_ID, name: 'Caja Separados', kind: 'cash', active: true, balance: 500, createdAt: '', updatedAt: '' },
    ],
    financialMovements: [
      {
        id: 'credit-1', type: 'adjustment', amount: 500,
        originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0, destinationBalanceAfter: 0,
        reference: 'SEP-0001', documentType: 'layaway', documentId: 'layaway-1', observation: 'Cliente Crédito',
        userId: 'u1', userName: 'Admin', date: '2026-07-21', createdAt: '2026-07-21T10:00:00.000Z',
        movementCode: 'CUSTOMER_CREDIT', referenceType: 'CUSTOMER', referenceId: 'customer-1', customerId: 'customer-1', status: 'COMPLETED',
      },
    ],
    recordInvoice,
    recordLayaway: vi.fn(),
    createQuotation: vi.fn(),
  }),
}));

import NewInvoice from '@/pages/NewInvoice';

describe('JOYACONTROL LAN V2.3.3 - aplicación de saldo en Ventas', () => {
  it('muestra el saldo, permite aplicarlo y lo envía como medio de pago', async () => {
    render(<MemoryRouter><NewInvoice /></MemoryRouter>);

    const clientInput = screen.getByPlaceholderText('Buscar por nombre, documento o teléfono...');
    fireEvent.focus(clientInput);
    fireEvent.click(screen.getByRole('option', { name: /Cliente Crédito/ }));

    const productSearch = screen.getByPlaceholderText('Buscar por código o nombre...');
    fireEvent.change(productSearch, { target: { value: 'Anillo' } });
    fireEvent.click(screen.getByRole('button', { name: /P-1.*Anillo/ }));

    expect(screen.getByText('Saldo disponible')).toBeTruthy();
    expect(screen.getAllByText(/500/).length).toBeGreaterThan(0);

    const creditInput = screen.getByText('Saldo disponible').closest('.rounded-lg')?.querySelector('input') as HTMLInputElement;
    fireEvent.change(creditInput, { target: { value: '500' } });
    fireEvent.click(screen.getByRole('button', { name: 'Aplicar saldo' }));

    expect(screen.getByText('Por pagar').parentElement?.textContent).toMatch(/100/);
    fireEvent.click(screen.getByRole('button', { name: 'Guardar Factura' }));

    await waitFor(() => expect(recordInvoice).toHaveBeenCalledTimes(1));
    expect(recordInvoice.mock.calls[0]?.[2]).toMatchObject({
      customerCredit: { customerId: 'customer-1', amount: 500 },
    });
    expect(recordInvoice.mock.calls[0]?.[1]).toEqual([
      expect.objectContaining({ accountId: MAIN_CASH_ACCOUNT_ID, amount: 100 }),
    ]);
  });
});
