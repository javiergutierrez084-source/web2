// @vitest-environment jsdom
import { fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { FinancialMovement } from '@/data/mockData';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 100,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: '',
  documentType: 'manual',
  documentId: '',
  observation: '',
  userId: 'user-1',
  userName: 'Admin',
  date: '2026-07-21',
  createdAt: '2026-07-21T10:00:00.000Z',
  status: 'COMPLETED',
  ...overrides,
});

const appState = {
  company: { name: 'JoyaControl', nit: '', address: '', phone: '', email: '', logo: '' },
  contacts: [{ id: 'customer-1', type: 'client' as const, name: 'Cliente Crédito', document: '123', phone: '', email: '', address: '' }],
  invoices: [],
  expenses: [],
  purchaseInvoices: [],
  products: [],
  layaways: [],
  financialAccounts: [
    { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash' as const, active: true, balance: 300, createdAt: '', updatedAt: '' },
    { id: LAYAWAY_RESERVE_ACCOUNT_ID, name: 'Caja Separados', kind: 'cash' as const, active: true, balance: 350, createdAt: '', updatedAt: '' },
  ],
  financialMovements: [
    movement({
      id: 'credit-1',
      amount: 500,
      movementCode: 'CUSTOMER_CREDIT',
      customerId: 'customer-1',
      referenceType: 'CUSTOMER',
      referenceId: 'customer-1',
      reference: 'SEP-0001',
      documentType: 'layaway',
      documentId: 'layaway-1',
    }),
    movement({
      id: 'credit-use-1',
      type: 'transfer',
      amount: 150,
      originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      destinationAccountId: MAIN_CASH_ACCOUNT_ID,
      movementCode: 'CUSTOMER_CREDIT_USED',
      customerId: 'customer-1',
      relatedMovementId: 'credit-1',
      referenceType: 'SALE',
      referenceId: 'invoice-1',
      reference: 'FAC-0001',
      documentType: 'customer_credit_used',
      documentId: 'invoice-1',
    }),
  ],
};

vi.mock('@/contexts/AppContext', () => ({ useApp: () => appState }));

import Reports from '@/pages/Reports';

beforeEach(() => {
  window.URL.createObjectURL = vi.fn(() => 'blob:test');
  window.URL.revokeObjectURL = vi.fn();
});

describe('JOYACONTROL LAN V2.3.3 - Reportes de saldo a favor', () => {
  it('muestra origen, utilización, saldo disponible y relaciones del ledger', () => {
    render(<MemoryRouter><Reports /></MemoryRouter>);
    fireEvent.click(screen.getByRole('button', { name: 'Saldos a favor' }));

    expect(screen.getByText('Saldos a favor de clientes')).toBeTruthy();
    expect(screen.getByText('Cliente Crédito')).toBeTruthy();
    expect(screen.getByText('SEP-0001')).toBeTruthy();
    expect(screen.getByText('FAC-0001')).toBeTruthy();
    expect(screen.getByText(/MovementId: credit-1/)).toBeTruthy();
    expect(screen.getByText(/Related: credit-1/)).toBeTruthy();
    expect(screen.getAllByText(/350/).length).toBeGreaterThan(0);
  });
});
