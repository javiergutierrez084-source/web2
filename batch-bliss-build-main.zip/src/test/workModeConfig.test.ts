// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  config: {
    mode: 'local' as 'local' | 'lan',
    role: 'client' as 'client' | 'server',
    serverStarted: false,
  },
  saveLanConfig: vi.fn(),
  descriptor: { ip: '192.168.1.10' },
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ ...mocks.config }),
  saveLanConfig: mocks.saveLanConfig,
}));

vi.mock('@/lib/LanServerDescriptor', () => ({
  LanServerDescriptor: {
    load: () => ({ ...mocks.descriptor }),
  },
}));

import {
  activateLanClientWorkMode,
  activateLocalWorkMode,
  deriveWorkModePreference,
  getEffectiveWorkMode,
  loadWorkModePreference,
  saveWorkModePreference,
  WORK_MODE_STORAGE_KEY,
} from '@/config/workMode';

describe('central work-mode configuration', () => {
  beforeEach(() => {
    localStorage.clear();
    mocks.config.mode = 'local';
    mocks.config.role = 'client';
    mocks.config.serverStarted = false;
    mocks.descriptor.ip = '192.168.1.10';
    mocks.saveLanConfig.mockClear();
  });

  it('preserves the mode of installations created before the selector existed', () => {
    expect(deriveWorkModePreference({ ...mocks.config } as never)).toBe('local');
    mocks.config.mode = 'lan';
    expect(deriveWorkModePreference({ ...mocks.config } as never)).toBe('lan');
    expect(loadWorkModePreference()).toBe('lan');
  });

  it('persists automatic mode separately from the existing LAN configuration', () => {
    saveWorkModePreference('auto');
    expect(localStorage.getItem(WORK_MODE_STORAGE_KEY)).toBe('auto');
    expect(loadWorkModePreference()).toBe('auto');
    expect(mocks.saveLanConfig).not.toHaveBeenCalled();
  });

  it('activates Local by selecting Dexie transport without touching a Principal Server', () => {
    mocks.config.mode = 'lan';
    mocks.config.role = 'client';
    expect(activateLocalWorkMode()).toBe('local');
    expect(mocks.saveLanConfig).toHaveBeenCalledWith(expect.objectContaining({ mode: 'local', role: 'client' }));

    mocks.saveLanConfig.mockClear();
    mocks.config.role = 'server';
    expect(activateLocalWorkMode()).toBe('server');
    expect(mocks.saveLanConfig).not.toHaveBeenCalled();
  });

  it('activates ApiRepository only through the existing LAN client configuration', () => {
    mocks.config.mode = 'local';
    expect(activateLanClientWorkMode()).toBe('lan');
    expect(mocks.saveLanConfig).toHaveBeenCalledWith(expect.objectContaining({
      mode: 'lan',
      role: 'client',
      serverStarted: false,
    }));
  });

  it('reports Principal Server, LAN client and Local as distinct effective modes', () => {
    expect(getEffectiveWorkMode({ ...mocks.config, mode: 'local', role: 'client' } as never)).toBe('local');
    expect(getEffectiveWorkMode({ ...mocks.config, mode: 'lan', role: 'client' } as never)).toBe('lan');
    expect(getEffectiveWorkMode({ ...mocks.config, mode: 'lan', role: 'server' } as never)).toBe('server');
  });
});
