// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import {
  createDefaultLanConfig,
  loadLanConfig,
  saveLanConfig,
  validateAndRememberLanServer,
  validateLanServerCompatibility,
  type LanServerInfo,
} from '@/lib/LanCommunicationConfig';

const serverInfo: LanServerInfo = {
  serverId: 'server-1',
  serverName: 'Servidor Principal',
  companyId: 'company-1',
  company: 'JoyaControl',
  version: '2.1',
  protocolVersion: 'LAN-1',
  repository: 'Dexie',
  mode: 'desktop',
  maxClients: 3,
  connectedClients: 0,
  features: { sales: true, inventory: true, reports: true, sync: false },
};

describe('LAN 2.1 complete connection cycle', () => {
  beforeEach(() => {
    localStorage.clear();
    vi.restoreAllMocks();
  });

  it('accepts the expected version, protocol and first company identity', () => {
    const config = createDefaultLanConfig();
    expect(validateLanServerCompatibility(serverInfo, config)).toEqual({ compatible: true, errors: [] });
  });

  it('rejects another company after the server has been trusted', () => {
    const config = { ...createDefaultLanConfig(), trustedCompanyId: 'company-trusted' };
    expect(validateLanServerCompatibility(serverInfo, config)).toEqual({ compatible: false, errors: ['LAN_COMPANY_MISMATCH'] });
  });

  it('rejects incompatible version and protocol', () => {
    const config = createDefaultLanConfig();
    expect(validateLanServerCompatibility({ ...serverInfo, version: '2.0' }, config).errors).toContain('LAN_INCOMPATIBLE_VERSION');
    expect(validateLanServerCompatibility({ ...serverInfo, protocolVersion: 'LAN-2' }, config).errors).toContain('LAN_INCOMPATIBLE_PROTOCOL');
  });

  it('validates health and server-info, then remembers server and company IDs', async () => {
    const config = {
      ...createDefaultLanConfig(),
      mode: 'lan' as const,
      role: 'client' as const,
      clientServerIp: '192.168.1.50',
      clientServerPort: 47831,
    };
    const fetchMock = vi.spyOn(globalThis, 'fetch')
      .mockResolvedValueOnce(new Response(JSON.stringify({
        status: 'online', version: '2.1', serverName: 'Servidor Principal', serverId: 'server-1', companyId: 'company-1', database: 'ready', time: new Date().toISOString(), mode: 'desktop', protocolVersion: 'LAN-1',
      }), { status: 200, headers: { 'Content-Type': 'application/json' } }))
      .mockResolvedValueOnce(new Response(JSON.stringify(serverInfo), { status: 200, headers: { 'Content-Type': 'application/json' } }));

    const result = await validateAndRememberLanServer(config);
    expect(result.config).toMatchObject({ trustedCompanyId: 'company-1', lastServerId: 'server-1', serverName: 'Servidor Principal' });
    expect(loadLanConfig()).toMatchObject({ trustedCompanyId: 'company-1', lastServerId: 'server-1' });
    expect(fetchMock.mock.calls.map(call => String(call[0]))).toEqual([
      'http://192.168.1.50:47831/health',
      'http://192.168.1.50:47831/server-info',
    ]);
  });

  it('persists automatic reconnection preference independently from commercial data', () => {
    const config = { ...createDefaultLanConfig(), autoReconnect: false, lastServerId: 'server-1', trustedCompanyId: 'company-1' };
    saveLanConfig(config);
    expect(loadLanConfig()).toMatchObject({ autoReconnect: false, lastServerId: 'server-1', trustedCompanyId: 'company-1' });
  });
});
