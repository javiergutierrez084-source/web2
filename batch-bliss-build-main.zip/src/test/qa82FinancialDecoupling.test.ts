// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { hashPassword, setSession } from '@/lib/authCore';
import { applyInventoryAdjustment } from '@/repositories/dexieDataSource';
import {
  createExceptionalCashAdjustment,
  fetchExceptionalCashHistory,
  repairHistoricalInventoryFinancialMovements,
} from '@/lib/ExceptionalCashMaintenance';
import { runFinancialConsistencyAudit } from '@/lib/FinancialConsistencyAudit';

const now = '2026-07-16T12:00:00.000Z';
const user = {
  id: 'qa82-user', username: 'qa82', display_name: 'QA 8.2', password_hash: '',
  role: 'master' as const, active: true, created_at: now, last_login: null,
};
const product = {
  id: 'qa82-product', code: 'QA82', name: 'Producto QA82', category: 'Anillos',
  purchase_price: 100, sale_price: 150, weight_grams: 10, margin: 50,
  stock: 10, min_stock: 0, description: '', supplier_ids: [], reference: 'QA82',
  available_grams: 100, average_purchase_price: 100, last_purchase_date: '', created_at: now,
};
const cash = {
  id: 'account-caja-principal', name: 'Caja Principal', kind: 'cash' as const,
  active: true, balance: 100000, created_at: now, updated_at: now,
};

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  user.password_hash = await hashPassword('clave-segura');
  await localDb.users.put(user);
  await localDb.products.put(product);
  await localDb.financial_accounts.put(cash);
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
});

const adjustmentInput = {
  productId: product.id, type: 'increase' as const, quantity: 2, grams: 20,
  totalCost: 2000, unitCost: 1000, valuePerGram: 100, purchasePrice: 100,
  notes: 'Regularización física', date: '2026-07-16', supplierId: 'supplier-x',
  supplierName: 'Proveedor', paymentStatus: 'paid' as const, accountId: cash.id,
};

describe('QA #8.2 - desacoplamiento financiero de ajustes', () => {
  it('crear y editar un ajuste no crea ni modifica movimientos o cuentas por pagar', async () => {
    const created = await applyInventoryAdjustment(adjustmentInput);
    expect(await localDb.financial_movements.count()).toBe(0);
    expect(await localDb.supplier_invoices.count()).toBe(0);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);

    await applyInventoryAdjustment({ ...adjustmentInput, operation: 'update', adjustmentId: created.adjustment.id, quantity: 3, grams: 30, totalCost: 3300, notes: 'Editado' });
    expect(await localDb.financial_movements.count()).toBe(0);
    expect(await localDb.supplier_invoices.count()).toBe(0);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
  });

  it('eliminar revierte un movimiento heredado solo por document_type + document_id', async () => {
    const created = await applyInventoryAdjustment(adjustmentInput);
    await localDb.financial_accounts.update(cash.id, { balance: 98000 });
    await localDb.financial_movements.add({
      id: 'legacy-exact', type: 'inventory_purchase', amount: 2000,
      origin_account_id: cash.id, destination_account_id: '',
      origin_balance_before: 100000, origin_balance_after: 98000,
      destination_balance_before: 0, destination_balance_after: 0,
      reference: 'Ajuste', document_type: 'inventory_adjustment', document_id: created.adjustment.id,
      observation: '', user_id: user.id, user_name: user.display_name,
      movement_date: '2026-07-16', created_at: now,
    });
    await localDb.financial_movements.add({
      id: 'legacy-similar', type: 'inventory_purchase', amount: 2000,
      origin_account_id: cash.id, destination_account_id: '',
      origin_balance_before: 98000, origin_balance_after: 96000,
      destination_balance_before: 0, destination_balance_after: 0,
      reference: 'Ajuste', document_type: 'purchase', document_id: created.adjustment.id,
      observation: '', user_id: user.id, user_name: user.display_name,
      movement_date: '2026-07-16', created_at: now,
    });

    await applyInventoryAdjustment({ ...adjustmentInput, operation: 'delete', adjustmentId: created.adjustment.id });
    expect(await localDb.financial_movements.get('legacy-exact')).toBeUndefined();
    expect(await localDb.financial_movements.get('legacy-similar')).toBeDefined();
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
  });
});

describe('QA #8.2 - corrección excepcional de Caja', () => {
  it('aplica correcciones positiva y negativa con reautenticación y Activity Log', async () => {
    await createExceptionalCashAdjustment({ accountId: cash.id, direction: 'positive', amount: 30000, reason: 'Auditoría', observation: 'Diferencia confirmada', password: 'clave-segura', confirmed: true });
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(130000);
    await createExceptionalCashAdjustment({ accountId: cash.id, direction: 'negative', amount: 10000, reason: 'Corrección', observation: 'Salida excepcional', password: 'clave-segura', confirmed: true });
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(120000);
    expect(await localDb.activity_log.where('action').equals('EXCEPTIONAL_CASH_ADJUSTMENT').count()).toBe(2);
    const history = await fetchExceptionalCashHistory({ reason: 'auditor' });
    expect(history).toHaveLength(1);
    expect(history[0].balanceBefore).toBe(100000);
    expect(history[0].balanceAfter).toBe(130000);
  });

  it('rechaza cero, textos vacíos, falta de confirmación y contraseña incorrecta', async () => {
    const base = { accountId: cash.id, direction: 'positive' as const, amount: 1, reason: 'R', observation: 'O', password: 'clave-segura', confirmed: true };
    await expect(createExceptionalCashAdjustment({ ...base, amount: 0 })).rejects.toThrow('INVALID_EXCEPTIONAL_CASH_AMOUNT');
    await expect(createExceptionalCashAdjustment({ ...base, reason: ' ' })).rejects.toThrow('EXCEPTIONAL_CASH_REASON_REQUIRED');
    await expect(createExceptionalCashAdjustment({ ...base, observation: '' })).rejects.toThrow('EXCEPTIONAL_CASH_OBSERVATION_REQUIRED');
    await expect(createExceptionalCashAdjustment({ ...base, confirmed: false })).rejects.toThrow('EXCEPTIONAL_CASH_CONFIRMATION_REQUIRED');
    await expect(createExceptionalCashAdjustment({ ...base, password: 'incorrecta' })).rejects.toThrow('INVALID_REAUTHENTICATION');
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
  });
});

describe('QA #8.2 - auditoría y reparación histórica', () => {
  it('detecta y repara solo movimientos inequívocos', async () => {
    const created = await applyInventoryAdjustment(adjustmentInput);
    await localDb.financial_accounts.update(cash.id, { balance: 98000 });
    await localDb.financial_movements.add({
      id: 'bad-adjustment-movement', type: 'inventory_purchase', amount: 2000,
      origin_account_id: cash.id, destination_account_id: '', origin_balance_before: 100000,
      origin_balance_after: 98000, destination_balance_before: 0, destination_balance_after: 0,
      reference: 'Bug histórico', document_type: 'inventory_adjustment', document_id: created.adjustment.id,
      observation: '', user_id: user.id, user_name: user.display_name, movement_date: '2026-07-16', created_at: now,
    });
    const audit = await runFinancialConsistencyAudit();
    expect(audit.findings.some(finding => finding.type === 'INVENTORY_ADJUSTMENT_FINANCIAL_AUDIT')).toBe(true);

    const report = await repairHistoricalInventoryFinancialMovements('clave-segura', true);
    expect(report.corrected).toBe(1);
    expect(await localDb.financial_movements.get('bad-adjustment-movement')).toBeUndefined();
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
    expect(await localDb.activity_log.where('action').equals('INVENTORY_ADJUSTMENT_FINANCIAL_REPAIR').count()).toBe(1);
  });
});
