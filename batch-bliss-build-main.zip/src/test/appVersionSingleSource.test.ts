import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { describe, expect, it } from 'vitest';
import packageJson from '../../package.json';
import { APP_VERSION, APP_VERSION_LABEL, APP_VERSION_TEXT } from '@/config/appVersion';

const projectRoot = fileURLToPath(new URL('../..', import.meta.url));
const readProjectFile = (relativePath: string) => readFileSync(resolve(projectRoot, relativePath), 'utf8');

const VERSION_UI_FILES = [
  'src/pages/LoginPage.tsx',
  'src/pages/SetupPage.tsx',
  'src/components/SplashScreen.tsx',
  'src/components/SetupWizard.tsx',
];

const MANUAL_APP_VERSION_PATTERN = /(?:\b[vV]2(?:\.\d+){0,2}\b|\b2\.(?:0|1)(?:\.\d+)?\b|Versi[oó]n\s+[vV]?2(?:\.\d+){0,2})/;

describe('application version single source', () => {
  it('reads the official version exclusively from package.json', () => {
    expect(APP_VERSION).toBe(packageJson.version);
    expect(APP_VERSION_LABEL).toBe(`v${packageJson.version}`);
    expect(APP_VERSION_TEXT).toBe(`Versión ${packageJson.version}`);
  });

  it('uses the centralized module in every visible application version surface', () => {
    for (const relativePath of VERSION_UI_FILES) {
      const source = readProjectFile(relativePath);
      expect(source).toContain("@/config/appVersion");
      expect(source).not.toMatch(MANUAL_APP_VERSION_PATTERN);
    }
  });

  it('keeps backup metadata synchronized through the centralized version module', () => {
    const source = readProjectFile('src/lib/backup.ts');
    expect(source).toContain("from '@/config/appVersion'");
    expect(source).not.toContain("from '../../package.json'");
  });

  it('lets electron-builder and Electron use package.json version without package overrides', () => {
    expect(packageJson.build).toBeDefined();
    expect((packageJson.build as Record<string, unknown>).extraMetadata).toBeUndefined();
    expect((packageJson.build as Record<string, unknown>).artifactName).toBeUndefined();
    expect(packageJson.scripts.win).toContain('electron-builder --win');
    expect(packageJson.scripts.dist).toBe('electron-builder');
  });
});
