// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { LanServerDescriptor, type LanServerDescriptorData } from '@/lib/LanServerDescriptor';
import {
  createDefaultLanConfig,
  loadLanConfig,
  rediscoverTrustedLanServer,
  saveLanConfig,
} from '@/lib/LanCommunicationConfig';

const OLD_IP = '192.168.20.5';
const NEW_IP = '192.168.20.80';

let persistedDescriptor: LanServerDescriptorData;

beforeEach(async () => {
  localStorage.clear();
  sessionStorage.clear();
  vi.restoreAllMocks();

  persistedDescriptor = {
    serverId: 'ABC123',
    companyId: 'COMPANY-1',
    serverName: 'Servidor Principal',
    ip: OLD_IP,
    port: 47831,
    protocolVersion: 'LAN-1',
    baseUrl: `http://${OLD_IP}:47831`,
    enabled: false,
    allowMultipleUserSessions: false,
  };

  window.joyaControlLan = {
    getServerDescriptorSync: () => ({ ...persistedDescriptor }),
    loadServerDescriptor: async () => ({ ...persistedDescriptor }),
    saveServerDescriptor: async descriptor => {
      persistedDescriptor = { ...descriptor };
      return { ...persistedDescriptor };
    },
    discoverServers: async () => [{
      serverId: 'ABC123',
      companyId: 'COMPANY-1',
      serverName: 'Servidor Principal',
      company: 'Empresa',
      version: '2.1',
      protocolVersion: 'LAN-1',
      repository: 'Dexie',
      mode: 'desktop',
      maxClients: 20,
      connectedClients: 1,
      features: { sales: true, inventory: true, reports: true, sync: false },
      ip: NEW_IP,
      port: 47831,
      latencyMs: 4,
    }],
  } as typeof window.joyaControlLan;

  await LanServerDescriptor.refresh();
});

describe('LAN 2.2.3C identity preservation after server IP change', () => {
  it('updates only the descriptor address and preserves server, client, device and auth identity', async () => {
    const initial = {
      ...createDefaultLanConfig(),
      mode: 'lan' as const,
      role: 'client' as const,
      clientId: 'CLIENT-1',
      deviceInstanceId: 'DEVICE-1',
      sessionToken: 'SESSION-1',
      authToken: 'AUTH-1',
      autoReconnect: true,
    };
    saveLanConfig(initial);

    const before = loadLanConfig();
    await rediscoverTrustedLanServer(before);
    const after = loadLanConfig();
    const descriptor = LanServerDescriptor.toJSON();

    expect(descriptor).toMatchObject({
      serverId: 'ABC123',
      companyId: 'COMPANY-1',
      ip: NEW_IP,
      baseUrl: `http://${NEW_IP}:47831`,
    });
    expect(after.clientId).toBe(before.clientId);
    expect(after.deviceInstanceId).toBe(before.deviceInstanceId);
    expect(after.sessionToken).toBe(before.sessionToken);
    expect(after.authToken).toBe(before.authToken);
  });
});
