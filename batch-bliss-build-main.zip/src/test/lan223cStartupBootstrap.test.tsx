// @vitest-environment jsdom
import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const mocks = vi.hoisted(() => {
  const order: string[] = [];
  const descriptor = {
    addressReady: true,
    load: vi.fn(() => { order.push('descriptor.load'); return {}; }),
    refresh: vi.fn(async () => { order.push('descriptor.refresh'); return {}; }),
    hasAddress: vi.fn(() => descriptor.addressReady),
  };
  const config = {
    mode: 'lan',
    role: 'client',
    autoReconnect: true,
  };
  return {
    order,
    descriptor,
    config,
    loadLanConfig: vi.fn(() => ({ ...config })),
    rediscover: vi.fn(async () => { order.push('descriptor.rediscover'); descriptor.addressReady = true; return { ...config }; }),
    validate: vi.fn(async () => { order.push('descriptor.validate'); return {}; }),
    restore: vi.fn(async () => { order.push('session.restore'); return null; }),
    start: vi.fn(() => { order.push('manager.start'); }),
    stop: vi.fn(),
  };
});

vi.mock('@/lib/LanServerDescriptor', () => ({
  LanServerDescriptor: mocks.descriptor,
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: mocks.loadLanConfig,
  rediscoverTrustedLanServer: mocks.rediscover,
  validateAndRememberLanServer: mocks.validate,
}));

vi.mock('@/lib/auth', () => ({ restoreLanSession: mocks.restore }));

vi.mock('@/lib/LanConnectionManager', () => ({
  LanConnectionManager: {
    start: mocks.start,
    stop: mocks.stop,
  },
}));

import LanBootstrapProvider from '@/components/LanBootstrapProvider';

function ProtectedChild() {
  mocks.order.push('auth.tree.mounted');
  return <div data-testid="auth-tree">Auth tree</div>;
}

beforeEach(() => {
  vi.useFakeTimers();
  mocks.order.length = 0;
  mocks.config.mode = 'lan';
  mocks.config.role = 'client';
  mocks.config.autoReconnect = true;
  mocks.descriptor.addressReady = true;
  vi.clearAllMocks();
});

afterEach(() => {
  cleanup();
  vi.useRealTimers();
});

describe('LAN 2.2.3C startup bootstrap', () => {
  it('mounts the auth tree only after descriptor, session and manager bootstrap', async () => {
    render(
      <LanBootstrapProvider>
        <ProtectedChild />
      </LanBootstrapProvider>,
    );

    expect(screen.queryByTestId('auth-tree')).toBeNull();
    expect(mocks.start).not.toHaveBeenCalled();

    await act(async () => {
      await Promise.resolve();
      await vi.advanceTimersByTimeAsync(3_000);
    });

    expect(screen.getByTestId('auth-tree')).not.toBeNull();
    expect(mocks.rediscover).not.toHaveBeenCalled();
    expect(mocks.order).toEqual([
      'descriptor.load',
      'descriptor.refresh',
      'descriptor.validate',
      'session.restore',
      'manager.start',
      'auth.tree.mounted',
    ]);
  });

  it('discovers a missing client address before any authenticated child can mount', async () => {
    mocks.descriptor.addressReady = false;

    render(
      <LanBootstrapProvider>
        <ProtectedChild />
      </LanBootstrapProvider>,
    );

    expect(screen.queryByTestId('auth-tree')).toBeNull();

    await act(async () => {
      await Promise.resolve();
      await vi.advanceTimersByTimeAsync(3_000);
    });

    expect(screen.getByTestId('auth-tree')).not.toBeNull();
    expect(mocks.order.indexOf('descriptor.rediscover')).toBeLessThan(mocks.order.indexOf('session.restore'));
    expect(mocks.order.indexOf('session.restore')).toBeLessThan(mocks.order.indexOf('auth.tree.mounted'));
  });

  it('does not require a server address in Desktop local or Principal Server mode', async () => {
    mocks.config.mode = 'local';
    mocks.config.role = 'server';
    mocks.descriptor.addressReady = false;

    render(
      <LanBootstrapProvider>
        <ProtectedChild />
      </LanBootstrapProvider>,
    );

    await act(async () => {
      await Promise.resolve();
      await vi.advanceTimersByTimeAsync(3_000);
    });

    expect(screen.getByTestId('auth-tree')).not.toBeNull();
    expect(mocks.rediscover).not.toHaveBeenCalled();
    expect(mocks.validate).not.toHaveBeenCalled();
  });

  it('keeps Repository creation outside bootstrap and manager startup', () => {
    const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8');
    const auth = fs.readFileSync(path.resolve('src/contexts/AuthContext.tsx'), 'utf8');
    const manager = fs.readFileSync(path.resolve('src/lib/LanConnectionManager.ts'), 'utf8');
    const service = fs.readFileSync(path.resolve('src/components/LanClientConnectionService.tsx'), 'utf8');
    const bootstrap = fs.readFileSync(path.resolve('src/components/LanBootstrapProvider.tsx'), 'utf8');

    expect(app).toContain("effectiveMode === 'lan'");
    expect(app).toContain('<LanBootstrapProvider key="lan-client">');
    expect(app.indexOf('<WorkModeProvider>')).toBeLessThan(app.indexOf('<WorkModeApplication />'));
    expect(auth).not.toContain('restoreLanSession');
    expect(manager).not.toContain('RepositoryRegistry');
    expect(manager).not.toContain('getDataRepository');
    expect(manager).not.toContain('getActiveRepositoryMode');
    expect(service).not.toContain('LanConnectionManager.start');
    expect(bootstrap).toContain('LanConnectionManager.start()');
  });
});
