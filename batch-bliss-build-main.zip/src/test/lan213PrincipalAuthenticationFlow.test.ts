// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';
import { DexieRepository } from '@/repositories/DexieRepository';
import { getDataRepository, resetDataRepository } from '@/repositories/RepositoryRegistry';
import { clearRepositoryRuntimeConfig } from '@/repositories/RepositoryConfig';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { loginUser } from '@/lib/auth';

function setMode(mode: 'local' | 'lan', role: 'server' | 'client', session = false) {
  saveLanConfig({
    ...createDefaultLanConfig(),
    mode,
    role,
    clientId: session ? 'client-1' : null,
    sessionToken: session ? 'device-token' : null,
    clientServerIp: '127.0.0.1',
    clientServerPort: 47831,
  });
  resetDataRepository();
}

describe('LAN 2.1.3 Principal Server authentication isolation', () => {
  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    clearRepositoryRuntimeConfig();
    resetDataRepository();
    vi.restoreAllMocks();
  });

  it('Local mode authenticates with DexieRepository without LAN device tokens', async () => {
    setMode('local', 'server');
    const repository = getDataRepository();
    const loginSpy = vi.spyOn(repository, 'loginUser').mockResolvedValue({ id: 'u1', username: 'maestro', displayName: 'Maestro', role: 'master' });

    expect(repository).toBeInstanceOf(DexieRepository);
    await expect(loginUser('maestro', 'clave')).resolves.toMatchObject({ username: 'maestro' });
    expect(loginSpy).toHaveBeenCalledWith('maestro', 'clave');
  });

  it('Principal Server authenticates with DexieRepository even without clientId, sessionToken or authToken', async () => {
    setMode('lan', 'server');
    const repository = getDataRepository();
    const loginSpy = vi.spyOn(repository, 'loginUser').mockResolvedValue({ id: 'u1', username: 'maestro', displayName: 'Maestro', role: 'master' });

    expect(repository).toBeInstanceOf(DexieRepository);
    await expect(loginUser('maestro', 'clave')).resolves.toMatchObject({ role: 'master' });
    expect(loginSpy).toHaveBeenCalledOnce();
    expect(sessionStorage.getItem('joyacontrol_lan_access_token')).toBeNull();
  });

  it('LAN Client reconstructs a missing device session instead of emitting LAN_SESSION_NOT_AVAILABLE', async () => {
    setMode('lan', 'client', false);
    expect(getDataRepository()).toBeInstanceOf(ApiRepository);
    const error = await loginUser('usuario', 'clave').catch(value => value as Error);
    expect(error).toBeInstanceOf(Error);
    expect(error.message).not.toBe('LAN_SESSION_NOT_AVAILABLE');
  });

  it('mounts the LAN authentication bridge only inside the authenticated application tree', async () => {
    const source = await import('node:fs/promises').then(fs => fs.readFile(new URL('file://' + process.cwd() + '/src/App.tsx'), 'utf8'));
    const authenticatedTree = source.indexOf('<AppProvider>');
    const bridge = source.indexOf('<LanAuthenticationBridge />');
    const provider = source.lastIndexOf('<AuthProvider>');
    expect(bridge).toBeGreaterThan(authenticatedTree);
    expect(source.slice(provider, authenticatedTree)).not.toContain('<LanAuthenticationBridge />');
  });
});
