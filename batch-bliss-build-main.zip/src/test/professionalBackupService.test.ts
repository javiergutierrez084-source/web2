/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { BackupDestination, BackupType, type BackupEnvelope } from '@/types/backup';

const mocks = vi.hoisted(() => ({
  mode: 'server' as 'server' | 'local' | 'lan',
  createBackup: vi.fn(),
  restoreBackup: vi.fn(),
  loadSettings: vi.fn(),
  saveSettings: vi.fn(),
  listHistory: vi.fn(),
  getDatabaseVersion: vi.fn(),
  logActivity: vi.fn(),
}));

vi.mock('@/config/workMode', () => ({ getEffectiveWorkMode: () => mocks.mode }));
vi.mock('@/lib/auth', () => ({
  getSession: () => ({ id: 'session-1', userId: 'user-1', username: 'master', displayName: 'Maestro', role: 'master', permissions: ['*'] }),
  logActivity: mocks.logActivity,
}));
vi.mock('@/lib/BackupManager', () => ({
  BackupManager: {
    createBackup: mocks.createBackup,
    restoreBackup: mocks.restoreBackup,
    loadSettings: mocks.loadSettings,
    saveSettings: mocks.saveSettings,
    listHistory: mocks.listHistory,
    getDatabaseVersion: mocks.getDatabaseVersion,
    isOPFSSupported: () => true,
  },
}));

import { ProfessionalBackupService } from '@/lib/ProfessionalBackupService';

const envelope: BackupEnvelope = {
  version: 6,
  databaseVersion: 6,
  createdAt: '2026-07-29T20:00:00.000Z',
  checksum: 'checksum-interno',
  deviceId: 'device-1',
  appVersion: '3.1.0',
  metadata: {
    version: 6,
    schemaVersion: 6,
    databaseVersion: 6,
    appVersion: '3.1.0',
    buildVersion: '3.1.0',
    createdAt: '2026-07-29T20:00:00.000Z',
    createdBy: 'Maestro',
    deviceId: 'device-1',
    recordCount: 1,
    backupType: BackupType.AUTOMATIC,
    destination: BackupDestination.LOCAL,
    checksumScope: 'document-v1',
  },
  data: {
    appName: 'JoyaControl',
    version: 6,
    createdAt: '2026-07-29T20:00:00.000Z',
    tables: { products: [{ id: 'p1' }] },
  },
};

describe('ProfessionalBackupService', () => {
  beforeEach(() => {
    mocks.mode = 'server';
    mocks.createBackup.mockReset().mockResolvedValue(envelope);
    mocks.restoreBackup.mockReset().mockResolvedValue(undefined);
    mocks.loadSettings.mockReset().mockResolvedValue({
      backupEnabled: true,
      backupInterval: '15m',
      backupHour: 22,
      backupFolder: 'D:/COPIAS JOYACONTROL',
      maxBackups: 100,
      deleteOldBackups: true,
      verifyChecksum: true,
      backupBeforeRestore: true,
      backupOnStartup: false,
      backupOnExit: true,
      backupOnImport: false,
      compressionEnabled: false,
      defaultDestination: BackupDestination.LOCAL,
    });
    mocks.saveSettings.mockReset().mockResolvedValue(undefined);
    mocks.listHistory.mockReset().mockResolvedValue([]);
    mocks.getDatabaseVersion.mockReset().mockResolvedValue(6);
    mocks.logActivity.mockReset().mockResolvedValue(undefined);
    Object.defineProperty(window, 'joyaControlBackup', {
      configurable: true,
      writable: true,
      value: {
        writeBackup: vi.fn().mockResolvedValue({
          filePath: 'D:/COPIAS JOYACONTROL/JOYACONTROL BACKUPS/AUTO/joyacontrol_auto.jcb',
          checksum: 'sha256',
          size: 100,
        }),
        getStatus: vi.fn().mockResolvedValue({ configuredFolder: 'D:/COPIAS JOYACONTROL', rootPath: 'D:/COPIAS JOYACONTROL/JOYACONTROL BACKUPS', external: { status: 'success' } }),
        setFolder: vi.fn().mockResolvedValue({}),
        selectFolder: vi.fn().mockResolvedValue({ canceled: false, folderPath: 'E:/NUEVAS COPIAS' }),
        openFolder: vi.fn().mockResolvedValue({ opened: true }),
      },
    });
    localStorage.clear();
  });

  it('crea backup interno y réplica AUTO solo en el Servidor Principal', async () => {
    const result = await ProfessionalBackupService.createAutomaticBackup('interval');
    expect(result.internalCompleted).toBe(true);
    expect(result.externalCompleted).toBe(true);
    expect(mocks.createBackup).toHaveBeenCalledWith(BackupType.AUTOMATIC, BackupDestination.LOCAL);
    expect(window.joyaControlBackup?.writeBackup).toHaveBeenCalledWith(expect.objectContaining({ category: 'AUTO' }));
    expect(mocks.logActivity).toHaveBeenCalledWith(expect.anything(), 'BACKUP_INTERNAL_COMPLETED', 'BACKUP', expect.any(String), expect.any(String));
    expect(mocks.logActivity).toHaveBeenCalledWith(expect.anything(), 'BACKUP_EXTERNAL_COMPLETED', 'BACKUP', expect.any(String), expect.any(String));
  });

  it('no ejecuta copias automáticas en modo local o cliente LAN', async () => {
    for (const mode of ['local', 'lan'] as const) {
      mocks.mode = mode;
      const result = await ProfessionalBackupService.createAutomaticBackup('interval');
      expect(result.skipped).toBe(true);
    }
    expect(mocks.createBackup).not.toHaveBeenCalled();
  });

  it('conserva el respaldo interno correcto aunque falle el disco externo', async () => {
    vi.mocked(window.joyaControlBackup!.writeBackup).mockRejectedValueOnce(new Error('Ruta no encontrada'));
    const result = await ProfessionalBackupService.createAutomaticBackup('cash-close');
    expect(result.internalCompleted).toBe(true);
    expect(result.externalCompleted).toBe(false);
    expect(result.externalError).toMatch(/Ruta no encontrada/);
    expect(mocks.logActivity).toHaveBeenCalledWith(expect.anything(), 'BACKUP_EXTERNAL_FAILED', 'BACKUP', expect.any(String), expect.any(String));
  });

  it('serializa operaciones concurrentes mediante una sola cola', async () => {
    let active = 0;
    let maximum = 0;
    mocks.createBackup.mockImplementation(async () => {
      active += 1;
      maximum = Math.max(maximum, active);
      await new Promise(resolve => setTimeout(resolve, 5));
      active -= 1;
      return envelope;
    });
    await Promise.all([
      ProfessionalBackupService.createAutomaticBackup('interval'),
      ProfessionalBackupService.createAutomaticBackup('cash-close'),
      ProfessionalBackupService.createManualBackup(),
    ]);
    expect(maximum).toBe(1);
  });

  it('crea RESTORE POINT y restaura sin duplicar el respaldo preventivo interno', async () => {
    await ProfessionalBackupService.restoreBackup(envelope);
    expect(window.joyaControlBackup?.writeBackup).toHaveBeenCalledWith(expect.objectContaining({ category: 'RESTORE_POINTS' }));
    expect(mocks.restoreBackup).toHaveBeenCalledWith(envelope, { skipPreRestore: true });
    expect(mocks.logActivity).toHaveBeenCalledWith(expect.anything(), 'BACKUP_RESTORE_COMPLETED', 'BACKUP', expect.any(String), expect.any(String));
  });

  it('crea una copia en la primera detección de versión y solo repite cuando la base cambia', async () => {
    await ProfessionalBackupService.runDatabaseUpdateBackupIfNeeded();
    expect(mocks.createBackup).toHaveBeenCalledTimes(1);

    await ProfessionalBackupService.runDatabaseUpdateBackupIfNeeded();
    expect(mocks.createBackup).toHaveBeenCalledTimes(1);

    mocks.getDatabaseVersion.mockResolvedValue(7);
    await ProfessionalBackupService.runDatabaseUpdateBackupIfNeeded();
    expect(mocks.createBackup).toHaveBeenCalledTimes(2);
  });

  it('reemplaza y persiste la carpeta seleccionada una sola vez', async () => {
    const selected = await ProfessionalBackupService.selectExternalFolder();
    expect(selected).toBe('E:/NUEVAS COPIAS');
    expect(mocks.saveSettings).toHaveBeenCalledWith(expect.objectContaining({
      backupFolder: 'E:/NUEVAS COPIAS',
      backupInterval: '15m',
    }));
    expect(mocks.logActivity).toHaveBeenCalledWith(expect.anything(), 'BACKUP_PATH_CHANGED', 'BACKUP', expect.any(String), expect.any(String));
  });
});
