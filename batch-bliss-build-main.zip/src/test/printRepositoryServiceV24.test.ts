import { beforeEach, describe, expect, it, vi } from 'vitest';
import { PrintRepositoryService } from '@/lib/PrintRepositoryService';
import { createDefaultPrintConfiguration } from '@/lib/PrintConfigurationDefaults';
import * as RepositoryRegistry from '@/repositories/RepositoryRegistry';

vi.mock('@/repositories/RepositoryRegistry', async () => {
  const actual = await vi.importActual<typeof import('@/repositories/RepositoryRegistry')>('@/repositories/RepositoryRegistry');
  return { ...actual, getActiveRepositoryMode: vi.fn(), getDataRepository: vi.fn() };
});

vi.mock('@/lib/authCore', async () => {
  const actual = await vi.importActual<typeof import('@/lib/authCore')>('@/lib/authCore');
  return { ...actual, getSession: () => ({ id: 'u1', username: 'master', displayName: 'Master', role: 'master' }) };
});

vi.mock('@/lib/LanCommunicationConfig', async () => {
  const actual = await vi.importActual<typeof import('@/lib/LanCommunicationConfig')>('@/lib/LanCommunicationConfig');
  return { ...actual, loadLanConfig: () => ({ clientId: 'client-1', deviceName: 'Cliente Uno' }) };
});

describe('PrintRepositoryService V2.4', () => {
  beforeEach(() => {
    vi.mocked(RepositoryRegistry.getActiveRepositoryMode).mockReturnValue('local');
    Object.defineProperty(window, 'joyaControlPrint', {
      configurable: true,
      value: {
        command: vi.fn(async payload => ({ id: 'job-1', status: 'pending', requestId: (payload as any).request?.requestId })),
        getWorkspace: vi.fn(async () => ({ printers: [], configuration: createDefaultPrintConfiguration(), jobs: [] })),
        savePdf: vi.fn(),
      },
    });
  });

  it('submits physical printing to the server bridge without window.print', async () => {
    const blob = new Blob(['pdf-content'], { type: 'application/pdf' });
    const result = await PrintRepositoryService.submitPdf({
      blob,
      format: 'letter',
      document: {
        kind: 'table', id: 'report-1', title: 'Reporte de Caja', filename: 'Reporte_Caja', company: { name: 'Joya', nit: '', phone: '', email: '', city: '', address: '', logoUrl: '' },
        columns: [{ header: 'Valor' }], rows: [['100']], date: '2026-07-21',
      },
    });
    expect(result.status).toBe('pending');
    expect(window.joyaControlPrint?.command).toHaveBeenCalledWith(expect.objectContaining({ action: 'submit' }));
  });

  it('builds a server-routed test page without adding another transport', async () => {
    const command = vi.fn(async payload => ({
      id: 'test-job-1',
      status: 'pending',
      requestId: (payload as any).request?.requestId,
      printerName: null,
    }));
    Object.defineProperty(window, 'joyaControlPrint', {
      configurable: true,
      value: {
        command,
        getWorkspace: vi.fn(),
        savePdf: vi.fn(),
      },
    });
    const configuration = createDefaultPrintConfiguration();
    configuration.documentSettings.report.printerName = 'Laser';
    const result = await PrintRepositoryService.testPrint({
      target: 'report',
      settings: configuration.documentSettings.report,
      workspace: {
        printers: [{ name: 'Laser', displayName: 'Laser principal', description: '', status: 0, isDefault: true, available: true, type: 'local' }],
        configuration,
        jobs: [],
        server: { name: 'SERVER-01', platform: 'win32' },
      },
      waitForResult: false,
    });
    expect(result.status).toBe('pending');
    const payload = command.mock.calls[0][0] as any;
    expect(payload.action).toBe('submit');
    expect(payload.request).toMatchObject({ isTestPrint: true, configurationTarget: 'report', requestedPrinterName: 'Laser', contentType: 'text/html' });
    const html = new TextDecoder().decode(Uint8Array.from(atob(payload.request.contentBase64), character => character.charCodeAt(0)));
    expect(html).toContain('JOYACONTROL');
    expect(html).toContain('SERVER-01');
    expect(html).toContain('Cliente Uno');
  });
});
