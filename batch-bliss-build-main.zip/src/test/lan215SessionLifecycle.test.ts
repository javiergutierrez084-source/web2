// @vitest-environment jsdom
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';
import {
  createDefaultLanConfig,
  disconnectLanClient,
  ensureLanClientSession,
  loadLanConfig,
  saveLanConfig,
  sendLanHeartbeat,
} from '@/lib/LanCommunicationConfig';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

let userDataPath = '';

beforeEach(() => {
  localStorage.clear();
  Object.defineProperty(window, 'joyaControlLan', {
    configurable: true,
    value: { getSystemIdentity: vi.fn(async () => ({ hostname: 'cliente-ciclo', ip: '127.0.0.1' })) },
  });
});

afterEach(async () => {
  await stopLanServer();
  if (userDataPath) fs.rmSync(userDataPath, { recursive: true, force: true });
  userDataPath = '';
  localStorage.clear();
});

describe('QA LAN 2.1.5 - ciclo de vida persistente de la sesión de equipo', () => {
  it('reabre y reconstruye la sesión diez veces sin LAN_SESSION_NOT_AVAILABLE', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan215-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Ciclo', userDataPath, version: '2.1' });

    const initial = {
      ...createDefaultLanConfig(),
      mode: 'lan' as const,
      role: 'client' as const,
      clientServerIp: '127.0.0.1',
      clientServerPort: port,
      deviceName: 'Cliente Ciclo',
      timeoutMs: 3000,
    };
    saveLanConfig(initial);

    let previousClientId: string | null = null;
    for (let cycle = 1; cycle <= 10; cycle += 1) {
      const ready = await ensureLanClientSession();
      expect(ready.clientId).toBeTruthy();
      expect(ready.sessionToken).toBeTruthy();
      if (previousClientId) expect(ready.clientId).toBe(previousClientId);
      previousClientId = ready.clientId;

      await expect(sendLanHeartbeat(loadLanConfig())).resolves.toMatchObject({ serverId: ready.lastServerId });
      await expect(disconnectLanClient(loadLanConfig())).resolves.toBeUndefined();

      // Simula cierre/reapertura del renderer: la configuración persiste y el
      // siguiente arranque debe restaurar la sesión antes de cualquier login.
      const reopened = await ensureLanClientSession();
      expect(reopened.clientId).toBe(previousClientId);
      await expect(sendLanHeartbeat(reopened)).resolves.toBeDefined();
    }
  });

  it('comparte una sola promesa de recuperación entre consumidores concurrentes', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan215-race-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Carrera', userDataPath, version: '2.1' });
    saveLanConfig({
      ...createDefaultLanConfig(), mode: 'lan', role: 'client',
      clientServerIp: '127.0.0.1', clientServerPort: port, deviceName: 'Cliente Carrera',
    });

    const sessions = await Promise.all(Array.from({ length: 8 }, () => ensureLanClientSession()));
    expect(new Set(sessions.map(item => item.clientId)).size).toBe(1);
    expect(new Set(sessions.map(item => item.sessionToken)).size).toBe(1);
  });

  it('ApiRepository espera la recuperación de sesión antes de evaluar credenciales', () => {
    const source = fs.readFileSync(path.resolve('src/repositories/ApiRepository.ts'), 'utf8');
    const ensureIndex = source.indexOf('config = await ensureLanClientSession()');
    const unavailableIndex = source.indexOf("throw new Error('LAN_SESSION_NOT_AVAILABLE')");
    expect(ensureIndex).toBeGreaterThan(-1);
    expect(unavailableIndex).toBeGreaterThan(ensureIndex);
  });
});
