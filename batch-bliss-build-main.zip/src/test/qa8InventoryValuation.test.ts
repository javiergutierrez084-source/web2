import { describe, expect, it } from 'vitest';
import { applyAdjustmentValue, reverseAdjustmentValue } from '@/lib/InventoryAdjustmentValuation';

describe('QA #8 - valorización al editar y eliminar ajustes', () => {
  it('eliminar una salida restaura la cantidad valorizada al promedio anterior', () => {
    const baseValue = reverseAdjustmentValue({
      currentValue: 800,
      direction: 'decrease',
      adjustmentCost: 0,
      basisDelta: 2,
      averageBefore: 100,
    });
    expect(baseValue).toBe(1000);
  });

  it('editar una salida mantiene el costo promedio y recalcula el valor', () => {
    const result = applyAdjustmentValue({
      baseValue: 1000,
      baseBasis: 10,
      direction: 'decrease',
      adjustmentCost: 0,
      basisDelta: 3,
      fallbackAverage: 100,
    });
    expect(result.averageUsed).toBe(100);
    expect(result.valueAfter).toBe(700);
  });

  it('eliminar una entrada revierte únicamente su costo incorporado', () => {
    expect(reverseAdjustmentValue({
      currentValue: 1500,
      direction: 'increase',
      adjustmentCost: 500,
      basisDelta: 5,
      averageBefore: 100,
    })).toBe(1000);
  });
});
