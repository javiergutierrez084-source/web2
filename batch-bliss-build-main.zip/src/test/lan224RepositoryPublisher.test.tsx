// @vitest-environment jsdom
import { act, render } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Product } from '@/data/mockData';

const mocks = vi.hoisted(() => ({
  state: {
    products: [] as Product[],
    categories: ['Anillos'] as string[],
    isLoading: false,
  },
  notify: vi.fn(async () => null),
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => mocks.state,
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ mode: 'lan', role: 'server' }),
}));

import LanRepositoryChangePublisher from '@/components/LanRepositoryChangePublisher';

const product = (overrides: Partial<Product> = {}): Product => ({
  id: 'product-1',
  code: 'P-001',
  name: 'Producto Uno',
  category: 'Anillos',
  purchasePrice: 100,
  salePrice: 150,
  weightGrams: 1,
  margin: 50,
  stock: 5,
  minStock: 1,
  description: '',
  supplierIds: [],
  ...overrides,
});

beforeEach(() => {
  mocks.state.products = [];
  mocks.state.categories = ['Anillos'];
  mocks.state.isLoading = false;
  mocks.notify.mockClear();
  window.joyaControlLan = {
    notifyRepositoryChanged: mocks.notify,
  } as typeof window.joyaControlLan;
});

describe('LAN 2.2.4 server repository change publisher', () => {
  it('publishes PRODUCTS_UPDATED for create, edit and delete', async () => {
    const view = render(<LanRepositoryChangePublisher />);

    mocks.state.products = [product()];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    mocks.state.products = [product({ salePrice: 175 })];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    mocks.state.products = [];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    expect(mocks.notify.mock.calls.map(call => call[0])).toEqual([
      'PRODUCTS_UPDATED',
      'PRODUCTS_UPDATED',
      'PRODUCTS_UPDATED',
    ]);
  });

  it('publishes CATEGORIES_UPDATED for create, edit and delete', async () => {
    const view = render(<LanRepositoryChangePublisher />);

    mocks.state.categories = ['Anillos', 'Cadenas'];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    mocks.state.categories = ['Anillos', 'Collares'];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    mocks.state.categories = ['Anillos'];
    await act(async () => view.rerender(<LanRepositoryChangePublisher />));

    expect(mocks.notify.mock.calls.map(call => call[0])).toEqual([
      'CATEGORIES_UPDATED',
      'CATEGORIES_UPDATED',
      'CATEGORIES_UPDATED',
    ]);
  });
});
