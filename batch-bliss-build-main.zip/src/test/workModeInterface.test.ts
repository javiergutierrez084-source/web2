import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const read = (relativePath: string): string => (
  fs.readFileSync(path.resolve(process.cwd(), relativePath), 'utf8')
);

describe('work-mode interface architecture', () => {
  it('shows the same selector before local setup/login and in Settings', () => {
    expect(read('src/pages/LoginPage.tsx')).toContain('<WorkModeSelector variant="login" />');
    expect(read('src/pages/SetupPage.tsx')).toContain('<WorkModeSelector variant="login" />');
    expect(read('src/pages/SettingsPage.tsx')).toContain('<WorkModeSelector variant="settings" />');
  });

  it('uses the existing LAN bootstrap only for effective LAN clients', () => {
    const app = read('src/App.tsx');
    expect(app).toContain("effectiveMode === 'lan'");
    expect(app).toContain('<LanBootstrapProvider key="lan-client">');
    expect(app).toContain('<WorkModeStartupBoundary>');
    expect(app).toContain('<AuthProvider>');
  });

  it('does not add repositories, endpoints or Electron integration', () => {
    const workMode = read('src/config/workMode.ts');
    const provider = read('src/contexts/WorkModeContext.tsx');

    expect(workMode).toContain("mode: 'lan'");
    expect(workMode).toContain("role: 'client'");
    expect(provider).toContain('discoverLanServers');
    expect(provider).not.toMatch(/fetch\s*\(/);
    expect(provider).not.toContain('/repository/call');
    expect(provider).not.toContain('ipcRenderer');
  });

  it('keeps the selected work mode independent from the LAN installation role', () => {
    const workMode = read('src/config/workMode.ts');
    expect(workMode).toContain('joyacontrol_work_mode_preference');
    expect(workMode).toContain("if (current.role === 'server')");
    expect(workMode).not.toContain('new ApiRepository');
    expect(workMode).not.toContain('new DexieRepository');
  });
});
