import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import {
  buildDashboardSnapshot,
  calculateBankDepositsForDate,
} from '@/lib/DashboardMetricsService';

const account = (
  id: string,
  kind: FinancialAccount['kind'],
  balance = 0,
): FinancialAccount => ({
  id,
  name: id,
  kind,
  balance,
  active: true,
  createdAt: '2026-07-01T00:00:00.000Z',
  updatedAt: '2026-07-01T00:00:00.000Z',
});

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 100,
  originAccountId: '',
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationAccountId: 'bank-1',
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 100,
  reference: 'Movimiento',
  documentType: 'financial_account',
  documentId: 'bank-1',
  observation: '',
  userId: 'u1',
  userName: 'Admin',
  date: '2026-07-27',
  createdAt: '2026-07-27T10:00:00.000Z',
  movementCode: 'BANK_IN',
  status: 'POSTED',
  ...overrides,
});

const accounts = [
  account('cash-main', 'cash', 2_000),
  account('bank-1', 'bank', 1_000),
  account('wallet-1', 'wallet', 500),
];

const snapshot = (movements: FinancialMovement[], date: string) => buildDashboardSnapshot({
  products: [],
  contacts: [],
  invoices: [],
  purchases: [],
  expenses: [],
  layaways: [],
  cashSessions: [],
  accounts,
  movements,
  financialSummary: null,
  backupStatusAvailable: false,
  now: new Date(`${date}T12:00:00`),
});

describe('Dashboard - Bancos Hoy', () => {
  it('suma únicamente consignaciones externas del día a cuentas bancarias activas', () => {
    const movements = [
      movement({ id: 'opening', amount: 1_000, movementCode: 'OPENING_BALANCE', type: 'opening_balance' }),
      movement({ id: 'sale-bank', amount: 300, movementCode: 'SALE_PAYMENT', type: 'sale_income', documentType: 'invoice' }),
      movement({ id: 'cash-to-bank', amount: 200, originAccountId: 'cash-main', movementCode: 'BANK_TRANSFER', type: 'transfer', documentType: 'transfer' }),
      movement({ id: 'bank-to-wallet', amount: 150, originAccountId: 'bank-1', destinationAccountId: 'wallet-1', movementCode: 'BANK_TRANSFER', type: 'transfer', documentType: 'transfer' }),
      movement({ id: 'yesterday', amount: 400, date: '2026-07-26' }),
      movement({ id: 'cancelled', amount: 900, status: 'CANCELLED' }),
      movement({ id: 'reversal', amount: 700, movementCode: 'REVERSAL', documentType: 'owner_withdrawal_cancellation' }),
    ];

    expect(calculateBankDepositsForDate(accounts, movements, '2026-07-27')).toBe(500);
    expect(snapshot(movements, '2026-07-27').financialPosition.banksToday).toBe(500);
  });

  it('muestra cero cuando no existen consignaciones en la fecha seleccionada', () => {
    const movements = [movement({ id: 'previous-day', date: '2026-07-26', amount: 450 })];

    expect(calculateBankDepositsForDate(accounts, movements, '2026-07-27')).toBe(0);
    expect(snapshot(movements, '2026-07-27').financialPosition.banksToday).toBe(0);
  });

  it('resta la anulación de una venta bancaria sin alterar el saldo bancario acumulado', () => {
    const movements = [
      movement({
        id: 'opening-bank',
        type: 'opening_balance',
        amount: 1_000,
        movementCode: 'OPENING_BALANCE',
        destinationAccountId: 'bank-1',
        destinationBalanceAfter: 1_000,
        date: '2026-07-26',
      }),
      movement({
        id: 'opening-wallet',
        type: 'opening_balance',
        amount: 500,
        movementCode: 'OPENING_BALANCE',
        destinationAccountId: 'wallet-1',
        destinationBalanceAfter: 500,
        date: '2026-07-26',
      }),
      movement({
        id: 'sale-bank',
        type: 'sale_income',
        amount: 300,
        movementCode: 'SALE_PAYMENT',
        documentType: 'invoice',
        documentId: 'invoice-1',
        referenceType: 'SALE',
        referenceId: 'invoice-1',
        destinationAccountId: 'bank-1',
        destinationBalanceBefore: 1_000,
        destinationBalanceAfter: 1_300,
      }),
      movement({
        id: 'sale-bank-cancel',
        amount: 300,
        movementCode: 'SALE_CANCEL',
        documentType: 'invoice_cancellation',
        documentId: 'invoice-1',
        referenceType: 'SALE',
        referenceId: 'invoice-1',
        relatedMovementId: 'sale-bank',
        originAccountId: 'bank-1',
        destinationAccountId: undefined,
        originBalanceBefore: 1_300,
        originBalanceAfter: 1_000,
        destinationBalanceBefore: 0,
        destinationBalanceAfter: 0,
      }),
    ];

    expect(calculateBankDepositsForDate(accounts, movements, '2026-07-27')).toBe(0);

    const result = snapshot(movements, '2026-07-27');
    expect(result.financialPosition.banksToday).toBe(0);
    expect(result.financialPosition.banks).toBe(1_500);
  });

  it('refleja como salida del día una anulación de una venta bancaria anterior', () => {
    const movements = [
      movement({
        id: 'previous-sale-bank',
        type: 'sale_income',
        amount: 300,
        movementCode: 'SALE_PAYMENT',
        documentType: 'invoice',
        documentId: 'invoice-previous',
        referenceType: 'SALE',
        referenceId: 'invoice-previous',
        destinationAccountId: 'bank-1',
        date: '2026-07-26',
      }),
      movement({
        id: 'previous-sale-bank-cancel',
        amount: 300,
        movementCode: 'SALE_CANCEL',
        documentType: 'invoice_cancellation',
        documentId: 'invoice-previous',
        referenceType: 'SALE',
        referenceId: 'invoice-previous',
        relatedMovementId: 'previous-sale-bank',
        originAccountId: 'bank-1',
        destinationAccountId: undefined,
      }),
    ];

    expect(calculateBankDepositsForDate(accounts, movements, '2026-07-27')).toBe(-300);
    expect(snapshot(movements, '2026-07-27').financialPosition.banksToday).toBe(-300);
  });

  it('cambia automáticamente el corte cuando cambia la fecha del snapshot', () => {
    const movements = [
      movement({ id: 'day-1', date: '2026-07-27', amount: 125 }),
      movement({ id: 'day-2', date: '2026-07-28', amount: 275 }),
    ];

    expect(snapshot(movements, '2026-07-27').financialPosition.banksToday).toBe(125);
    expect(snapshot(movements, '2026-07-28').financialPosition.banksToday).toBe(275);
  });
});
