import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function post(url: string, body: Record<string, unknown>) {
  return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Connection: 'close' }, body: JSON.stringify(body) });
}
async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { cache: 'no-store' });
  expect(response.status).toBe(200);
  return response.json() as Promise<T>;
}

describe('LAN 2.1.9 - recuperación tras reinicio del Servidor Principal', () => {
  afterEach(async () => { await stopLanServer(); });

  it('conserva equipo, token, usuario y estadísticas durante 20 reinicios', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan219-'));
    const port = 51000 + Math.floor(Math.random() * 1000);
    const base = `http://127.0.0.1:${port}`;
    const options = {
      host: '127.0.0.1', port, serverName: 'Servidor persistente', userDataPath, version: '2.1',
      sessionPolicy: { inactiveMs: 5000, timeoutMs: 10000, retentionMs: 60000 },
      authenticateUser: async (username: string, password: string) => username === 'master' && password === 'ok'
        ? { success: true, userId: 'u1', username, displayName: 'Maestro', role: 'master', permissions: ['*'] }
        : { success: false },
    };

    await startLanServer(options);
    const deviceInstanceId = 'persistent-physical-device';
    const registration = await (await post(`${base}/client/register`, {
      deviceInstanceId, name: 'PC Cliente', hostname: 'pc-cliente', ip: '192.168.10.20', version: '2.1', localTime: new Date().toISOString(),
    })).json() as { clientId: string; sessionToken: string };
    const loginResponse = await post(`${base}/login`, { username: 'master', password: 'ok', ...registration });
    expect(loginResponse.status).toBe(200);
    const login = await loginResponse.json() as { authToken: string };

    for (let cycle = 1; cycle <= 20; cycle += 1) {
      await stopLanServer();
      await startLanServer(options);
      await new Promise(resolve => setTimeout(resolve, 15));

      const reconnectResponse = await post(`${base}/client/reconnect`, {
        ...registration, deviceInstanceId, ip: `192.168.10.${20 + cycle}`,
      });
      expect(reconnectResponse.status).toBe(200);
      const reconnect = await reconnectResponse.json() as { clientId: string; sessionToken: string; restoredUsers: number };
      expect(reconnect.clientId).toBe(registration.clientId);
      expect(reconnect.sessionToken).toBe(registration.sessionToken);

      const restore = await post(`${base}/auth/restore`, { ...registration, authToken: login.authToken });
      expect(restore.status).toBe(200);

      const ping = await post(`${base}/client/ping`, { ...registration, deviceInstanceId, timestamp: new Date().toISOString() });
      expect(ping.status).toBe(200);

      const clients = await getJson<{ clients: Array<{ clientId: string; activityCount: number; status: string }> }>(`${base}/clients`);
      const users = await getJson<{ users: Array<{ userId: string; clientId: string; status: string }> }>(`${base}/users`);
      expect(clients.clients).toHaveLength(1);
      expect(clients.clients[0]).toMatchObject({ clientId: registration.clientId, activityCount: cycle, status: 'connected' });
      expect(users.users).toHaveLength(1);
      expect(users.users[0]).toMatchObject({ userId: 'u1', clientId: registration.clientId, status: 'connected' });
      expect(getLanServerState()).toMatchObject({ activeClients: 1, connectedUsers: 1, heartbeatsReceived: cycle });
    }
  }, 30000);

  it('incluye autoarranque persistente y eventos IPC dedicados', () => {
    const main = fs.readFileSync(path.resolve('electron/main.js'), 'utf8');
    const preload = fs.readFileSync(path.resolve('electron/preload.cjs'), 'utf8');
    expect(main).toContain('lan-server-config.json');
    expect(main).toContain('startConfiguredLanServer(persistedServer)');
    expect(main).toContain("webContents.send('lan-server-event'");
    expect(preload).toContain("ipcRenderer.on('lan-server-event'");
  });
});
