// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import { applyInventoryAdjustment } from '@/repositories/dexieDataSource';

const user = {
  id: 'qa8-user', username: 'qa8', display_name: 'QA 8', password_hash: '',
  role: 'master' as const, active: true, created_at: '2026-07-16T00:00:00.000Z', last_login: null,
};

const product = {
  id: 'qa8-product', code: 'QA8', name: 'Producto QA8', category: 'Anillos',
  purchase_price: 100, sale_price: 150, weight_grams: 10, margin: 50,
  stock: 10, min_stock: 0, description: '', supplier_ids: [],
  reference: 'QA8', available_grams: 100, average_purchase_price: 100,
  last_purchase_date: '', created_at: '2026-07-16T00:00:00.000Z',
};

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.products.put(product);
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
});

describe('QA #8 - transacciones de ajustes', () => {
  it('crea, edita y elimina sin duplicar el ajuste y conserva la auditoría', async () => {
    const created = await applyInventoryAdjustment({
      operation: 'create', productId: product.id, type: 'decrease', quantity: 2, grams: 20,
      totalCost: 0, unitCost: 0, valuePerGram: 0, purchasePrice: 100,
      notes: 'Salida QA', date: '2026-07-16',
    });
    expect((await localDb.products.get(product.id))?.stock).toBe(8);
    expect((await localDb.products.get(product.id))?.available_grams).toBe(80);
    expect(await localDb.inventory_adjustments.count()).toBe(1);
    expect((await localDb.activity_log.filter(row => row.entity_id === created.adjustment.id).toArray()).map(x => x.action))
      .toContain('INVENTORY_ADJUSTMENT_CREATED');

    await applyInventoryAdjustment({
      operation: 'update', adjustmentId: created.adjustment.id, productId: product.id,
      type: 'decrease', quantity: 3, grams: 30, totalCost: 0, unitCost: 0,
      valuePerGram: 0, purchasePrice: 100, notes: 'Salida editada', date: '2099-01-01',
    });
    const edited = await localDb.inventory_adjustments.get(created.adjustment.id);
    expect(await localDb.inventory_adjustments.count()).toBe(1);
    expect(edited?.adjustment_date).toBe('2026-07-16');
    expect((await localDb.products.get(product.id))?.stock).toBe(7);
    expect((await localDb.products.get(product.id))?.available_grams).toBe(70);
    expect((await localDb.products.get(product.id))?.average_purchase_price).toBe(100);

    await applyInventoryAdjustment({
      operation: 'delete', adjustmentId: created.adjustment.id, productId: product.id,
      type: 'decrease', quantity: 3, grams: 30, totalCost: 0, unitCost: 0,
      valuePerGram: 0, purchasePrice: 100, notes: 'Salida editada', date: '2026-07-16',
    });
    expect(await localDb.inventory_adjustments.count()).toBe(0);
    expect((await localDb.products.get(product.id))?.stock).toBe(10);
    expect((await localDb.products.get(product.id))?.available_grams).toBe(100);
    const actions = (await localDb.activity_log.filter(row => row.entity_id === created.adjustment.id).toArray()).map(x => x.action);
    expect(actions).toEqual(expect.arrayContaining([
      'INVENTORY_ADJUSTMENT_CREATED',
      'INVENTORY_ADJUSTMENT_UPDATED',
      'INVENTORY_ADJUSTMENT_DELETED',
    ]));
  });

  it('revierte completamente una edición inválida', async () => {
    const created = await applyInventoryAdjustment({
      productId: product.id, type: 'decrease', quantity: 2, grams: 20,
      totalCost: 0, unitCost: 0, valuePerGram: 0, purchasePrice: 100,
      notes: 'Salida QA', date: '2026-07-16',
    });
    const beforeProduct = await localDb.products.get(product.id);
    const beforeAdjustment = await localDb.inventory_adjustments.get(created.adjustment.id);
    const beforeLogs = await localDb.activity_log.count();

    await expect(applyInventoryAdjustment({
      operation: 'update', adjustmentId: created.adjustment.id, productId: product.id,
      type: 'decrease', quantity: 999, grams: 9990, totalCost: 0, unitCost: 0,
      valuePerGram: 0, purchasePrice: 100, notes: 'Debe fallar', date: '2026-07-16',
    })).rejects.toThrow();

    expect(await localDb.products.get(product.id)).toEqual(beforeProduct);
    expect(await localDb.inventory_adjustments.get(created.adjustment.id)).toEqual(beforeAdjustment);
    expect(await localDb.activity_log.count()).toBe(beforeLogs);
  });
});
