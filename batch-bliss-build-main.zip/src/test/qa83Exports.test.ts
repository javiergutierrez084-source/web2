import { describe, expect, it } from 'vitest';
import { buildExcelMatrix } from '@/lib/excelExport';
import { calculateFinancialSummary } from '@/lib/DashboardMetricsService';

describe('QA 8.3 exportaciones y auditoría financiera', () => {
  it('genera Excel con encabezados y valores visibles', () => {
    const matrix = buildExcelMatrix([
      { header: 'Factura', value: (row: { number: string }) => row.number },
      { header: 'Total', value: (row: { total: number }) => row.total },
    ], [{ number: 'FV-001', total: 1000000 }]);
    expect(matrix).toEqual([['Factura', 'Total'], ['FV-001', 1000000]]);
  });

  it('ignora movimientos financieros originados por ajustes de inventario', () => {
    const summary = calculateFinancialSummary({
      accounts: [], payables: [], expenses: [], invoices: [], products: [], today: '2026-07-16',
      movements: [{
        id: 'm1', type: 'expense', amount: 30000, originAccountId: 'cash',
        originBalanceBefore: 100000, originBalanceAfter: 70000, destinationBalanceBefore: 0, destinationBalanceAfter: 0,
        reference: 'Ajuste', documentType: 'inventory_adjustment', documentId: 'a1', observation: '',
        userId: 'u1', userName: 'Admin', date: '2026-07-16', createdAt: '2026-07-16T10:00:00Z',
      }],
    });
    expect(summary.expensesToday).toBe(0);
    expect(summary.incomeToday).toBe(0);
  });
});
