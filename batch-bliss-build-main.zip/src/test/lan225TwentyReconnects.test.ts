// @vitest-environment node
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

const post = (url: string, body: object) => fetch(url, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Connection: 'close' },
  body: JSON.stringify(body),
});

let userDataPath = '';
afterEach(async () => {
  await stopLanServer();
  if (userDataPath) fs.rmSync(userDataPath, { recursive: true, force: true });
  userDataPath = '';
});

describe('LAN 2.2.5 session identity under repeated reconnection', () => {
  it('preserves one client and one user session through 20 consecutive reconnects', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan225-20x-'));
    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor LAN 2.2.5',
      userDataPath,
      version: '2.1',
      authenticateUser: async (username: string, password: string) => username === 'master' && password === 'ok'
        ? { success: true, userId: 'user-master', username, displayName: 'Master', role: 'master', permissions: ['*'] }
        : { success: false },
    });

    const baseUrl = `http://127.0.0.1:${port}`;
    const deviceInstanceId = 'lan225-device-stable';
    const registeredResponse = await post(`${baseUrl}/client/register`, {
      deviceInstanceId,
      name: 'Cliente LAN',
      hostname: 'cliente-lan',
      ip: '192.168.20.10',
      version: '2.1',
      localTime: new Date().toISOString(),
    });
    expect(registeredResponse.status).toBe(201);
    const session = await registeredResponse.json() as { clientId: string; sessionToken: string };

    const loginResponse = await post(`${baseUrl}/login`, {
      username: 'master',
      password: 'ok',
      clientId: session.clientId,
      sessionToken: session.sessionToken,
    });
    expect(loginResponse.status).toBe(200);

    for (let cycle = 0; cycle < 20; cycle += 1) {
      const disconnect = await post(`${baseUrl}/client/disconnect`, session);
      expect(disconnect.status).toBe(200);

      const reconnect = await post(`${baseUrl}/client/reconnect`, {
        ...session,
        deviceInstanceId,
        ip: `192.168.20.${20 + cycle}`,
        operatingSystem: 'Windows 11',
      });
      expect(reconnect.status).toBe(200);
      const restored = await reconnect.json() as { clientId: string; sessionToken: string };
      expect(restored.clientId).toBe(session.clientId);
      expect(restored.sessionToken).toBe(session.sessionToken);

      const ping = await post(`${baseUrl}/client/ping`, {
        ...session,
        deviceInstanceId,
        timestamp: new Date().toISOString(),
      });
      expect(ping.status).toBe(200);
    }

    const clients = await (await fetch(`${baseUrl}/clients`, { cache: 'no-store' })).json() as { clients: Array<{ clientId: string }> };
    const users = await (await fetch(`${baseUrl}/users`, { cache: 'no-store' })).json() as { users: Array<{ clientId: string }> };

    expect(clients.clients).toHaveLength(1);
    expect(clients.clients[0].clientId).toBe(session.clientId);
    expect(users.users).toHaveLength(1);
    expect(users.users[0].clientId).toBe(session.clientId);
    expect(getLanServerState()).toMatchObject({ activeClients: 1, connectedUsers: 1, heartbeatsReceived: 20 });
  });
});
