// @vitest-environment jsdom
import { act, cleanup, render, screen } from '@testing-library/react';
import fs from 'node:fs';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  LanConnectionEventDetail,
  LanGlobalConnectionState,
} from '@/lib/LanConnectionManager';

const mocks = vi.hoisted(() => {
  const listeners = new Set<(detail: LanConnectionEventDetail) => void>();
  let state: LanGlobalConnectionState = 'OFFLINE';

  return {
    listeners,
    getState: () => state,
    setState(next: LanGlobalConnectionState) {
      state = next;
    },
    emit(type: LanConnectionEventDetail['type'], next: LanGlobalConnectionState) {
      state = next;
      const detail: LanConnectionEventDetail = {
        type,
        state: next,
        at: new Date().toISOString(),
      };
      listeners.forEach(listener => listener(detail));
    },
  };
});

vi.mock('@/lib/LanConnectionManager', () => ({
  LanConnectionManager: {
    getConnectionState: mocks.getState,
    subscribe: (listener: (detail: LanConnectionEventDetail) => void) => {
      mocks.listeners.add(listener);
      return () => mocks.listeners.delete(listener);
    },
  },
}));

import LanConnectionStateProvider, {
  useLanConnectionState,
} from '@/contexts/LanConnectionStateContext';

function ConnectionProbe() {
  const { connectionState, managerState } = useLanConnectionState();
  return (
    <div>
      <span data-testid="visual-state">{connectionState}</span>
      <span data-testid="manager-state">{managerState}</span>
    </div>
  );
}

afterEach(() => cleanup());

beforeEach(() => {
  mocks.listeners.clear();
  mocks.setState('OFFLINE');
});

describe('global LAN visual connection state', () => {
  it('propagates automatic reconnect transitions from Buscando to Conectado', () => {
    render(
      <LanConnectionStateProvider>
        <ConnectionProbe />
      </LanConnectionStateProvider>,
    );

    expect(screen.getByTestId('visual-state').textContent).toBe('disconnected');

    act(() => mocks.emit('SERVER_RECONNECTING', 'RECONNECTING'));
    expect(screen.getByTestId('visual-state').textContent).toBe('connecting');
    expect(screen.getByTestId('manager-state').textContent).toBe('RECONNECTING');

    act(() => mocks.emit('SERVER_ONLINE', 'ONLINE'));
    expect(screen.getByTestId('visual-state').textContent).toBe('connected');
    expect(screen.getByTestId('manager-state').textContent).toBe('ONLINE');
  });

  it('retains the current manager snapshot while the LAN panel is not mounted', () => {
    const view = render(
      <LanConnectionStateProvider>
        <div>Otra pantalla</div>
      </LanConnectionStateProvider>,
    );

    act(() => mocks.emit('SERVER_RECONNECTING', 'RECONNECTING'));
    act(() => mocks.emit('SERVER_ONLINE', 'ONLINE'));

    view.rerender(
      <LanConnectionStateProvider>
        <ConnectionProbe />
      </LanConnectionStateProvider>,
    );

    expect(screen.getByTestId('visual-state').textContent).toBe('connected');
    expect(screen.getByTestId('manager-state').textContent).toBe('ONLINE');
  });


  it('keeps the panel read-only and mounts the shared provider above LAN bootstrap', () => {
    const panel = fs.readFileSync(
      path.resolve('src/components/LanCommunicationPanel.tsx'),
      'utf8',
    );
    const app = fs.readFileSync(path.resolve('src/App.tsx'), 'utf8');

    expect(panel).toContain('useLanConnectionState');
    expect(panel).not.toContain('useState<LanConnectionState>');
    expect(panel).not.toContain('setConnectionState(');
    expect(panel).not.toContain('LAN_CONNECTION_STATE_EVENT');
    expect(app).toContain('<LanConnectionStateProvider>');
    expect(app).toContain('<LanBootstrapProvider key="lan-client">');
    expect(app.indexOf('<LanConnectionStateProvider>')).toBeLessThan(
      app.indexOf('<WorkModeApplication />'),
    );
  });

  it('removes its manager subscription when the global provider unmounts', () => {
    const view = render(
      <LanConnectionStateProvider>
        <ConnectionProbe />
      </LanConnectionStateProvider>,
    );

    expect(mocks.listeners.size).toBe(1);
    view.unmount();
    expect(mocks.listeners.size).toBe(0);
  });
});
