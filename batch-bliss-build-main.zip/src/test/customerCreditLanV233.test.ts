// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';
import type { Invoice, Product } from '@/data/mockData';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const privateLanIp = (): string => {
  for (const addresses of Object.values(os.networkInterfaces())) {
    for (const address of addresses || []) {
      if (address.family !== 'IPv4' || address.internal) continue;
      const parts = address.address.split('.').map(Number);
      if (parts[0] === 10 || (parts[0] === 192 && parts[1] === 168) || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)) return address.address;
    }
  }
  throw new Error('NO_PRIVATE_LAN_IP_FOR_TEST');
};

const freePort = (): Promise<number> => new Promise((resolve, reject) => {
  const socket = net.createServer();
  socket.once('error', reject);
  socket.listen(0, '127.0.0.1', () => {
    const address = socket.address();
    if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
    socket.close(error => error ? reject(error) : resolve(address.port));
  });
});

const post = async <T,>(url: string, body: object): Promise<T> => {
  const response = await fetch(url, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
};

const invoice: Invoice = {
  id: 'invoice-credit-lan', number: 'FAC-CREDIT-LAN', clientId: 'client-credit', clientName: 'Cliente Crédito',
  items: [{ productId: 'p1', code: 'P1', name: 'Producto', quantity: 1, weightGrams: 1, unitPrice: 400, subtotal: 400 }],
  subtotal: 400, discount: 0, tax: 0, total: 400, date: '2026-07-21', status: 'paid', paymentMethod: 'Saldo a favor + Efectivo',
};
const product: Product = {
  id: 'p1', code: 'P1', name: 'Producto', category: 'General', purchasePrice: 100,
  salePrice: 400, weightGrams: 1, margin: 300, stock: 9, minStock: 1,
};

afterEach(async () => {
  await stopLanServer();
  localStorage.clear();
  vi.restoreAllMocks();
});

describe('JOYACONTROL LAN V2.3.3 - transporte de saldo a favor', () => {
  it('transporta la aplicación del crédito dentro de createSale usando únicamente POST /repository/call', async () => {
    const port = await freePort();
    const lanIp = privateLanIp();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-credit-lan-'));
    const provider = vi.fn(async (method: string) => {
      if (method === 'createSale') return [product];
      throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
    });

    try {
      await startLanServer({
        host: '0.0.0.0', port, serverName: 'Servidor Crédito LAN', userDataPath, version: '2.3.3',
        executeRepositoryCall: provider,
        authenticateUser: async () => ({
          success: true, userId: 'master-1', username: 'master', displayName: 'Master', role: 'master',
          permissions: ['create_sales'],
        }),
      });
      const baseUrl = `http://${lanIp}:${port}`;
      const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
        name: 'Cliente Crédito', hostname: 'credit-client', version: '2.3.3', localTime: new Date().toISOString(), deviceInstanceId: 'credit-device',
      });
      const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
        username: 'master', password: 'secret', clientId: registered.clientId, sessionToken: registered.sessionToken,
      });
      saveLanConfig({
        ...createDefaultLanConfig(), mode: 'lan', role: 'client', clientServerIp: lanIp, clientServerPort: port,
        clientId: registered.clientId, sessionToken: registered.sessionToken, authToken: login.authToken,
      });

      const repository = new ApiRepository({ baseUrl });
      await expect(repository.insertInvoiceWithFinancials(
        invoice,
        [{ accountId: MAIN_CASH_ACCOUNT_ID, amount: 150, paymentMethod: 'Efectivo' }],
        { customerCredit: { customerId: 'client-credit', amount: 250 } },
      )).resolves.toEqual([product]);

      expect(provider).toHaveBeenCalledTimes(1);
      expect(provider.mock.calls[0]?.[0]).toBe('createSale');
      expect(provider.mock.calls[0]?.[1]).toMatchObject({
        invoice: { id: invoice.id, clientId: 'client-credit', total: 400 },
        allocations: [{ accountId: MAIN_CASH_ACCOUNT_ID, amount: 150 }],
        options: { customerCredit: { customerId: 'client-credit', amount: 250 } },
      });
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  }, 30_000);
});
