// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

const EXPECTED_MAX_CLIENTS = 5;

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1', () => {
      const address = listener.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_FREE_PORT'));
      listener.close(error => error ? reject(error) : resolve(address.port));
    });
    listener.on('error', reject);
  });
}

async function post<T = Record<string, unknown>>(url: string, body: Record<string, unknown>) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Connection: 'close' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { success?: boolean; error?: string };
  return { response, payload };
}

const sleep = (milliseconds: number) => new Promise(resolve => setTimeout(resolve, milliseconds));

describe('LAN client limit counts only connected Machine IDs', () => {
  const temporaryPaths: string[] = [];

  afterEach(async () => {
    await stopLanServer();
    for (const directory of temporaryPaths.splice(0)) fs.rmSync(directory, { recursive: true, force: true });
  });

  async function start(options: { inactiveMs?: number; timeoutMs?: number } = {}) {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-limit-'));
    temporaryPaths.push(userDataPath);
    const inactiveMs = options.inactiveMs ?? 30_000;
    const timeoutMs = options.timeoutMs ?? 60_000;
    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor límite LAN',
      userDataPath,
      version: '2.1',
      sessionPolicy: {
        inactiveMs,
        timeoutMs,
        retentionMs: Math.max(500, timeoutMs * 4),
      },
    });
    return `http://127.0.0.1:${port}`;
  }

  async function register(baseUrl: string, index: number, connectionSuffix = 'a') {
    const machineId = `machine-limit-${index}`;
    return post<{ clientId: string; sessionToken: string; machineId: string; reused?: boolean }>(`${baseUrl}/client/register`, {
      machineId,
      deviceInstanceId: machineId,
      connectionId: `runtime-${index}-${connectionSuffix}`,
      name: `Equipo ${index}`,
      hostname: `equipo-${index}`,
      ip: `192.168.10.${index}`,
      operatingSystem: 'Windows 11',
      version: '2.1',
      localTime: new Date().toISOString(),
      rememberDevice: true,
    });
  }

  async function clientState(baseUrl: string) {
    return await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      registeredClients: Array<{ machineId: string; status: string }>;
      connectedClients: Array<{ machineId: string; status: string }>;
    };
  }

  it('accepts a new client when 7 are registered but only 2 are connected and MAX is 5', async () => {
    const baseUrl = await start({ inactiveMs: 30, timeoutMs: 1_000 });

    for (let index = 1; index <= 5; index += 1) {
      const historical = await register(baseUrl, index);
      expect(historical.response.status).toBe(201);
    }
    await sleep(50);

    const sixth = await register(baseUrl, 6);
    const seventh = await register(baseUrl, 7);
    expect(sixth.response.status).toBe(201);
    expect(seventh.response.status).toBe(201);

    const before = await clientState(baseUrl);
    expect(before.registeredClients).toHaveLength(7);
    expect(before.registeredClients.filter(client => client.status === 'inactive')).toHaveLength(5);
    expect(before.connectedClients).toHaveLength(2);

    const accepted = await register(baseUrl, 8);
    expect(accepted.response.status).toBe(201);
    expect(accepted.payload.error).toBeUndefined();

    const after = await clientState(baseUrl);
    expect(after.registeredClients).toHaveLength(8);
    expect(after.connectedClients).toHaveLength(3);
  });

  it('rejects a sixth connected Machine ID when 5 connected slots are occupied', async () => {
    const baseUrl = await start();
    for (let index = 1; index <= EXPECTED_MAX_CLIENTS; index += 1) {
      const registration = await register(baseUrl, index);
      expect(registration.response.status).toBe(201);
    }

    const rejected = await register(baseUrl, 6);
    expect(rejected.response.status).toBe(403);
    expect(rejected.payload.error).toBe('LAN_MAX_CLIENTS_REACHED');

    const state = await clientState(baseUrl);
    expect(state.connectedClients).toHaveLength(EXPECTED_MAX_CLIENTS);
  });

  it('replaces the runtime of an existing Machine ID without consuming another slot', async () => {
    const baseUrl = await start();
    const registrations = [];
    for (let index = 1; index <= EXPECTED_MAX_CLIENTS; index += 1) {
      const registration = await register(baseUrl, index);
      expect(registration.response.status).toBe(201);
      registrations.push(registration);
    }

    const replacement = await register(baseUrl, 1, 'replacement');
    expect(replacement.response.status).toBe(200);
    expect(replacement.payload).toMatchObject({
      clientId: registrations[0].payload.clientId,
      machineId: 'machine-limit-1',
      reused: true,
    });
    expect(replacement.payload.sessionToken).not.toBe(registrations[0].payload.sessionToken);

    const state = await clientState(baseUrl);
    expect(state.registeredClients).toHaveLength(EXPECTED_MAX_CLIENTS);
    expect(state.connectedClients).toHaveLength(EXPECTED_MAX_CLIENTS);
    expect(new Set(state.connectedClients.map(client => client.machineId)).size).toBe(EXPECTED_MAX_CLIENTS);
  });

  it('releases slots immediately after heartbeat timeout marks clients disconnected', async () => {
    const baseUrl = await start({ inactiveMs: 30, timeoutMs: 70 });
    for (let index = 1; index <= EXPECTED_MAX_CLIENTS; index += 1) {
      const registration = await register(baseUrl, index);
      expect(registration.response.status).toBe(201);
    }

    await sleep(95);
    const expiredState = await clientState(baseUrl);
    expect(expiredState.registeredClients).toHaveLength(EXPECTED_MAX_CLIENTS);
    expect(expiredState.registeredClients.every(client => client.status === 'disconnected')).toBe(true);
    expect(expiredState.connectedClients).toHaveLength(0);

    const accepted = await register(baseUrl, 6);
    expect(accepted.response.status).toBe(201);
    const finalState = await clientState(baseUrl);
    expect(finalState.registeredClients).toHaveLength(EXPECTED_MAX_CLIENTS + 1);
    expect(finalState.connectedClients).toHaveLength(1);
  });
});
