// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  calculateOwnerFinanceDashboard,
  type OwnerWithdrawal,
} from '@/lib/OwnerFinanceService';
import {
  createOwnerWithdrawalConceptLocal,
  createOwnerWithdrawalLocal,
  fetchOwnerFinanceWorkspaceLocal,
  saveOwnerFinanceSettingsLocal,
  updateOwnerWithdrawalConceptLocal,
} from '@/lib/OwnerFinanceLocalDataService';

const now = '2026-07-25T12:00:00.000Z';
const user = {
  id: 'owner-user', username: 'owner', display_name: 'Propietario', password_hash: '',
  role: 'master' as const, active: true, created_at: now, last_login: null,
};
const account = {
  id: 'account-owner', name: 'Caja Principal', kind: 'cash' as const,
  active: true, balance: 100_000, created_at: now, updated_at: now,
};

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.financial_accounts.put(account);
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
});

describe('Finanzas del Propietario V1 - configuración y conceptos', () => {
  it('crea, edita y desactiva conceptos sin eliminar los utilizados', async () => {
    const created = await createOwnerWithdrawalConceptLocal('Mantenimiento personal');
    const edited = await updateOwnerWithdrawalConceptLocal(created.id, { name: 'Mantenimiento del propietario' });
    expect(edited.name).toBe('Mantenimiento del propietario');

    const withdrawal = await createOwnerWithdrawalLocal({
      withdrawalDate: now,
      conceptId: created.id,
      amount: 500,
      observations: 'Prueba de concepto utilizado',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    });
    expect(withdrawal.conceptName).toBe('Mantenimiento del propietario');

    const renamedAfterUse = await updateOwnerWithdrawalConceptLocal(created.id, { name: 'Nombre posterior del concepto' });
    expect(renamedAfterUse.name).toBe('Nombre posterior del concepto');

    const deactivated = await updateOwnerWithdrawalConceptLocal(created.id, { active: false });
    expect(deactivated.active).toBe(false);
    await expect(createOwnerWithdrawalLocal({
      withdrawalDate: now,
      conceptId: created.id,
      amount: 100,
      observations: '',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    })).rejects.toThrow('OWNER_CONCEPT_INACTIVE');

    const workspace = await fetchOwnerFinanceWorkspaceLocal();
    expect(workspace.concepts.find(concept => concept.id === created.id)).toMatchObject({
      name: 'Nombre posterior del concepto',
      active: false,
    });
    expect(workspace.withdrawals.find(item => item.id === withdrawal.id)?.conceptName)
      .toBe('Mantenimiento del propietario');
    expect((await localDb.financial_movements.get(withdrawal.financialMovementId))?.reference)
      .toBe('Mantenimiento del propietario');
  });

  it('conserva la edición y desactivación de un concepto inicial sin recrear el nombre original', async () => {
    const initial = await fetchOwnerFinanceWorkspaceLocal();
    const other = initial.concepts.find(concept => concept.name === 'Otros');
    expect(other).toBeTruthy();

    await updateOwnerWithdrawalConceptLocal(other!.id, { name: 'Imprevistos', active: false });
    const reloaded = await fetchOwnerFinanceWorkspaceLocal();

    expect(reloaded.concepts.find(concept => concept.id === other!.id)).toMatchObject({
      name: 'Imprevistos',
      active: false,
      isDefault: true,
    });
    expect(reloaded.concepts.some(concept => concept.name === 'Otros')).toBe(false);
    expect(reloaded.concepts.filter(concept => concept.id === other!.id)).toHaveLength(1);
  });

  it('registra retiros con cada concepto inicial y conserva el concepto en el movimiento', async () => {
    const workspace = await fetchOwnerFinanceWorkspaceLocal();
    expect(workspace.concepts.map(concept => concept.name)).toEqual(expect.arrayContaining([
      'Retiro del propietario',
      'Pago de sueldos',
      'Pago de comisiones',
      'Reinversión',
      'Caja menor',
      'Otros',
    ]));

    for (const concept of workspace.concepts.filter(item => item.isDefault)) {
      await createOwnerWithdrawalLocal({
        withdrawalDate: now,
        conceptId: concept.id,
        amount: 100,
        observations: `Retiro ${concept.name}`,
        accountId: account.id,
        paymentMethod: 'EFECTIVO',
      });
    }

    const movements = await localDb.financial_movements
      .filter(movement => movement.document_type === 'owner_withdrawal')
      .toArray();
    expect(movements).toHaveLength(6);
    expect(movements.every(movement => movement.movement_code === 'CASH_OUT')).toBe(true);
    expect(movements.map(movement => movement.reference)).toEqual(expect.arrayContaining([
      'Retiro del propietario',
      'Pago de sueldos',
      'Pago de comisiones',
      'Reinversión',
      'Caja menor',
      'Otros',
    ]));
  });

  it('guardar el porcentaje no genera retiros ni movimientos automáticos', async () => {
    const movementsBefore = await localDb.financial_movements.count();
    const balanceBefore = (await localDb.financial_accounts.get(account.id))?.balance;

    const settings = await saveOwnerFinanceSettingsLocal({
      projectedWithdrawalPercentage: 50,
      monthlyProfitGoal: 20_000_000,
      financialPeriod: 'FORTNIGHTLY',
    });

    expect(settings).toMatchObject({
      projectedWithdrawalPercentage: 50,
      monthlyProfitGoal: 20_000_000,
      financialPeriod: 'FORTNIGHTLY',
      periodKey: '2026-07',
      periodStatus: 'OPEN',
    });
    expect(await localDb.financial_movements.count()).toBe(movementsBefore);
    expect((await localDb.financial_accounts.get(account.id))?.balance).toBe(balanceBefore);
    expect((await fetchOwnerFinanceWorkspaceLocal()).settings).toEqual(settings);
  });
});

describe('Finanzas del Propietario V1 - cálculo proyectado', () => {
  it('calcula utilidad mensual, meta y sugerido sin crear retiros', () => {
    const activeWithdrawal: OwnerWithdrawal = {
      id: 'w1', withdrawalDate: now, userId: user.id, userName: user.display_name,
      conceptId: 'c1', conceptName: 'Otros', amount: 20, observations: '',
      accountId: account.id, accountName: account.name, paymentMethod: 'EFECTIVO',
      status: 'ACTIVE', financialMovementId: 'm1', createdAt: now,
    };
    const dashboard = calculateOwnerFinanceDashboard({
      now: new Date('2026-07-25T12:00:00'),
      projectedWithdrawalPercentage: 40,
      monthlyProfitGoal: 120,
      invoices: [
        { id: 'today', date: '2026-07-25', status: 'paid', total: 150, totalCost: 50 },
        { id: 'week', date: '2026-07-20', status: 'paid', total: 50, totalCost: 30 },
        { id: 'month', date: '2026-07-10', status: 'paid', total: 90, totalCost: 40 },
        { id: 'previous', date: '2026-06-30', status: 'paid', total: 60, totalCost: 30 },
      ],
      expenses: [
        { id: 'e-today', date: '2026-07-25', status: 'paid', total: 10 },
        { id: 'e-week', date: '2026-07-20', status: 'paid', total: 5 },
        { id: 'e-month', date: '2026-07-10', status: 'paid', total: 5 },
      ],
      withdrawals: [activeWithdrawal],
    });

    expect(dashboard).toMatchObject({
      monthlyProfitGoal: 120,
      profitMonth: 130,
      availableProfit: 130,
      withdrawnProfit: 20,
      availableBalance: 130,
      projectedWithdrawalPercentage: 40,
      suggestedWithdrawalValue: 52,
      monthlyGoalProgressBarPercentage: 100,
      monthlyGoalReachedValue: 130,
      monthlyGoalRemainingValue: 0,
      monthlyGoalReached: true,
    });
    expect(dashboard.monthlyGoalProgressPercentage).toBeCloseTo(108.3333333333);
  });
});
