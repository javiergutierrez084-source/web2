// @vitest-environment jsdom
import { fireEvent, render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';
import FinancialTraceabilityPanel from '@/components/FinancialTraceabilityPanel';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

class ResizeObserverMock { observe() {} unobserve() {} disconnect() {} }
vi.stubGlobal('ResizeObserver', ResizeObserverMock);

const company = { name: 'JoyaControl', nit: '', address: '', phone: '', email: '', logo: '' };
const accounts = [{ id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash' as const, active: true, balance: 100, createdAt: '', updatedAt: '' }];
const movements = [{
  id: 'm1', type: 'opening_balance' as const, amount: 100, destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0, destinationBalanceAfter: 100,
  reference: 'Saldo inicial', documentType: 'financial_account', documentId: MAIN_CASH_ACCOUNT_ID,
  observation: 'Apertura', userId: 'u1', userName: 'Admin', date: '2026-07-21', createdAt: '2026-07-21T08:00:00.000Z',
  movementCode: 'OPENING_BALANCE' as const, referenceType: 'FINANCIAL_ACCOUNT' as const, referenceId: MAIN_CASH_ACCOUNT_ID,
  status: 'POSTED' as const,
}];

describe('JOYACONTROL LAN V2.3.2 - panel de trazabilidad', () => {
  it('muestra composición, libro mayor, filtros y auditoría sin corregir datos automáticamente', () => {
    render(<FinancialTraceabilityPanel company={company} accounts={accounts} movements={movements} contacts={[]} invoices={[]} purchases={[]} expenses={[]} layaways={[]} initialComposition="mainCash" />);
    expect(screen.getByText('Trazabilidad Financiera')).not.toBeNull();
    expect(screen.getAllByText('Caja Principal').length).toBeGreaterThan(0);
    expect(screen.getByText('1 movimientos')).not.toBeNull();
    expect(screen.getByRole('button', { name: 'Auditoría financiera' })).not.toBeNull();
    fireEvent.click(screen.getByRole('button', { name: 'Auditoría financiera' }));
    expect(screen.getByText('No se detectaron inconsistencias')).not.toBeNull();
  });
});
