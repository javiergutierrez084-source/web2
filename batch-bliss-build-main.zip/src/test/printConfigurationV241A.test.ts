import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PrintQueueService } from '../../electron/printQueueService.js';

const tempDirs: string[] = [];
const tempDir = () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-print-v241a-'));
  tempDirs.push(dir);
  return dir;
};

const printers = [
  { name: 'Laser', displayName: 'Laser principal', description: '', status: 0, statusLabel: 'Lista', isDefault: true, available: true, offline: false, virtual: false, pdf: false, xps: false, shared: false, local: true, type: 'local' },
  { name: 'Ticket', displayName: 'Térmica 80', description: '', status: 0, statusLabel: 'Lista', isDefault: false, available: true, offline: false, virtual: false, pdf: false, xps: false, shared: true, local: false, type: 'network' },
];

const configuration = () => ({
  defaultPrinterName: 'Laser',
  profilePrinters: {},
  documentPrinters: {},
  documentSettings: {
    invoiceLetter: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 2, silent: true, margin: 'default', scale: 95, colorMode: 'color' },
    invoiceTicket80: { printerName: 'Ticket', paperSize: 'ticket80', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
    invoiceTicket58: { printerName: 'Ticket', paperSize: 'ticket58', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
    quotation: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
    report: { printerName: 'Laser', paperSize: 'a4', orientation: 'landscape', copies: 1, silent: true, margin: 'printableArea', scale: 90, colorMode: 'monochrome' },
    label: { printerName: 'Ticket', paperSize: 'label', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
    barcode: { printerName: 'Ticket', paperSize: 'barcode', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
    pdf: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
  },
  automaticRetry: true,
  retryDelayMs: 30_000,
  updatedAt: new Date().toISOString(),
});

const waitUntil = async (predicate: () => boolean, timeoutMs = 3000) => {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error('WAIT_TIMEOUT');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
};

afterEach(() => {
  for (const dir of tempDirs.splice(0)) fs.rmSync(dir, { recursive: true, force: true });
});

describe('JOYACONTROL LAN V2.4.1A printer configuration', () => {
  it('persists all document settings on the server and restores them after restart', async () => {
    const dir = tempDir();
    const adapter = { discoverPrinters: async () => printers, printJob: async () => undefined };
    const first = new PrintQueueService({ userDataPath: dir, adapter });
    first.start();
    first.saveConfiguration(configuration());
    first.stop();

    const restarted = new PrintQueueService({ userDataPath: dir, adapter });
    restarted.start();
    const workspace = await restarted.getWorkspace();
    expect(Object.keys(workspace.configuration.documentSettings)).toHaveLength(8);
    expect(workspace.configuration.documentSettings.invoiceLetter).toMatchObject({ printerName: 'Laser', copies: 2, scale: 95 });
    expect(workspace.configuration.documentSettings.invoiceTicket58.paperSize).toBe('ticket58');
    expect(workspace.configuration.documentSettings.report).toMatchObject({ orientation: 'landscape', margin: 'printableArea', colorMode: 'monochrome' });
    restarted.stop();
  });

  it('keeps a disappeared printer configured while returning the current server list', async () => {
    const service = new PrintQueueService({
      userDataPath: tempDir(),
      adapter: {
        discoverPrinters: async () => printers.filter(printer => printer.name === 'Laser'),
        getPrinterEnvironment: async () => ({
          printers: printers.filter(printer => printer.name === 'Laser'),
          spooler: { status: 'running', checkedAt: new Date().toISOString(), message: 'Print Spooler en ejecución' },
          server: { name: 'SERVER-01', platform: 'win32' },
          discoveredAt: new Date().toISOString(),
        }),
        printJob: async () => undefined,
      },
    });
    service.start();
    const next = configuration();
    next.documentSettings.invoiceTicket80.printerName = 'Impresora desconectada';
    service.saveConfiguration(next);
    const workspace = await service.getWorkspace();
    expect(workspace.printers.map((printer: { name: string }) => printer.name)).toEqual(['Laser']);
    expect(workspace.configuration.documentSettings.invoiceTicket80.printerName).toBe('Impresora desconectada');
    expect(workspace.spooler.status).toBe('running');
    expect(workspace.server.name).toBe('SERVER-01');
    service.stop();
  });

  it('does not print a job cancelled while printer discovery is still running', async () => {
    let releaseDiscovery: (() => void) | undefined;
    const discoveryGate = new Promise<void>(resolve => { releaseDiscovery = resolve; });
    let printed = false;
    const service = new PrintQueueService({
      userDataPath: tempDir(),
      adapter: {
        discoverPrinters: async () => { await discoveryGate; return printers; },
        printJob: async () => { printed = true; },
      },
    });
    service.start();
    service.saveConfiguration(configuration());
    const job = service.submit({
      requestId: 'cancel-during-discovery',
      documentType: 'report',
      documentId: 'report-cancel',
      documentNumber: 'REPORT-CANCEL',
      title: 'Reporte cancelado',
      format: 'letter',
      contentType: 'text/html',
      contentBase64: Buffer.from('<h1>Cancelar</h1>').toString('base64'),
      requester: { userId: 'u1', username: 'master', displayName: 'Master', clientId: 'client-1', deviceName: 'Cliente Uno' },
      requestedAt: new Date().toISOString(),
      configurationTarget: 'report',
    });
    expect(service.cancel(job.id).status).toBe('cancelled');
    releaseDiscovery?.();
    await new Promise(resolve => setTimeout(resolve, 50));
    expect(service.jobs.find((item: { id: string }) => item.id === job.id)?.status).toBe('cancelled');
    expect(printed).toBe(false);
    service.stop();
  });

  it('prints a test job with the selected printer options and records its result', async () => {
    const calls: Array<{ printer: string; settings: Record<string, unknown> }> = [];
    const service = new PrintQueueService({
      userDataPath: tempDir(),
      adapter: {
        discoverPrinters: async () => printers,
        printJob: async (_job: unknown, printer: { name: string }, settings: Record<string, unknown>) => {
          calls.push({ printer: printer.name, settings });
        },
      },
    });
    service.start();
    service.saveConfiguration(configuration());
    const job = service.submit({
      requestId: 'test-page-1',
      documentType: 'other',
      documentId: 'print-test-report',
      documentNumber: 'TEST-1',
      title: 'Prueba de impresión JOYACONTROL',
      format: 'a4',
      contentType: 'text/html',
      contentBase64: Buffer.from('<h1>JOYACONTROL</h1>').toString('base64'),
      requester: { userId: 'u1', username: 'master', displayName: 'Master', clientId: 'client-1', deviceName: 'Cliente Uno' },
      requestedAt: new Date().toISOString(),
      configurationTarget: 'report',
      requestedPrinterName: 'Laser',
      printOptions: { orientation: 'landscape', copies: 3, silent: true, margin: 'printableArea', scale: 88, colorMode: 'monochrome', paperSize: 'a4' },
      isTestPrint: true,
    });
    await waitUntil(() => service.jobs.find((item: { id: string }) => item.id === job.id)?.status === 'completed');
    expect(calls).toEqual([{ printer: 'Laser', settings: expect.objectContaining({ orientation: 'landscape', copies: 3, scale: 88, colorMode: 'monochrome' }) }]);
    const history = (await service.getWorkspace()).jobs.find((item: { id: string }) => item.id === job.id);
    expect(history).toMatchObject({ status: 'completed', printerName: 'Laser', isTestPrint: true, configurationTarget: 'report' });
    service.stop();
  });
});
