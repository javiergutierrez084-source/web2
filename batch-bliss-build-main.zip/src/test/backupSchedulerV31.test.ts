/** @vitest-environment jsdom */
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  mode: 'server' as 'server' | 'local' | 'lan',
  ensure: vi.fn(),
  automatic: vi.fn(),
  loadSettings: vi.fn(),
}));

vi.mock('@/config/workMode', () => ({ getEffectiveWorkMode: () => mocks.mode }));
vi.mock('@/lib/BackupManager', () => ({ BackupManager: { loadSettings: mocks.loadSettings } }));
vi.mock('@/lib/ProfessionalBackupService', () => ({
  PROFESSIONAL_BACKUP_INTERVAL_MS: 15 * 60 * 1000,
  ProfessionalBackupService: {
    ensureProfessionalSettings: mocks.ensure,
    createAutomaticBackup: mocks.automatic,
  },
}));

import { BackupScheduler } from '@/lib/BackupScheduler';

describe('BackupScheduler v3.1', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    BackupScheduler.dispose();
    mocks.mode = 'server';
    mocks.ensure.mockReset().mockResolvedValue({ backupEnabled: true });
    mocks.automatic.mockReset().mockResolvedValue(undefined);
    mocks.loadSettings.mockReset().mockResolvedValue({ backupOnStartup: false });
  });

  it('programa una copia cada 15 minutos en Servidor Principal', async () => {
    await BackupScheduler.init();
    expect(BackupScheduler.isArmed()).toBe(true);
    expect(BackupScheduler.getNextRunAt()).toBe(Date.now() + 15 * 60 * 1000);
    await vi.advanceTimersByTimeAsync(15 * 60 * 1000);
    expect(mocks.automatic).toHaveBeenCalledWith('interval');
    expect(BackupScheduler.getNextRunAt()).toBe(Date.now() + 15 * 60 * 1000);
  });


  it('respeta el estado persistido OFF y no arma el temporizador', async () => {
    mocks.ensure.mockResolvedValue({ backupEnabled: false });
    await BackupScheduler.init();
    expect(BackupScheduler.isArmed()).toBe(false);
    expect(BackupScheduler.getNextRunAt()).toBeNull();
    await vi.advanceTimersByTimeAsync(30 * 60 * 1000);
    expect(mocks.automatic).not.toHaveBeenCalledWith('interval');
  });

  it('reactiva un único temporizador al cambiar de OFF a ON', async () => {
    mocks.ensure.mockResolvedValueOnce({ backupEnabled: false });
    await BackupScheduler.init();
    mocks.ensure.mockResolvedValue({ backupEnabled: true });
    await BackupScheduler.onSettingsChanged();
    await BackupScheduler.onSettingsChanged();
    expect(BackupScheduler.isArmed()).toBe(true);
    await vi.advanceTimersByTimeAsync(15 * 60 * 1000);
    expect(mocks.automatic).toHaveBeenCalledTimes(1);
    expect(mocks.automatic).toHaveBeenCalledWith('interval');
  });

  it('no programa copias automáticas en modo local o LAN', async () => {
    mocks.mode = 'lan';
    await BackupScheduler.init();
    expect(BackupScheduler.isArmed()).toBe(false);
    expect(BackupScheduler.getNextRunAt()).toBeNull();
    expect(mocks.ensure).not.toHaveBeenCalled();
  });

  it('ejecuta respaldo de inicio solo cuando la configuración existente lo solicita', async () => {
    mocks.loadSettings.mockResolvedValue({ backupOnStartup: true });
    await BackupScheduler.init();
    expect(mocks.automatic).toHaveBeenCalledWith('startup');
  });
});
