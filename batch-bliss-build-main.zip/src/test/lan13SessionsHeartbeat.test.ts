// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import net from 'node:net';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { drainLanActivityEvents, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
    socket.on('error', reject);
  });
}

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
const post = (url: string, body: object) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

describe('LAN 1.3 persistent sessions and heartbeat', () => {
  let baseUrl = '';
  let userDataPath = '';

  beforeEach(async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joyacontrol-lan13-'));
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1',
      sessionPolicy: { inactiveMs: 400, timeoutMs: 800, retentionMs: 1500 },
    });
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterEach(async () => {
    await stopLanServer();
    drainLanActivityEvents();
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  async function register(index = 1) {
    const response = await post(`${baseUrl}/client/register`, {
      name: `Equipo ${index}`, hostname: `equipo-${index}`, ip: `192.168.1.${10 + index}`,
      operatingSystem: 'Windows', version: '2.1', localTime: new Date().toISOString(),
    });
    return { response, payload: await response.json() };
  }

  it('receives heartbeat, validates session and updates latency without counting it as commercial activity', async () => {
    const { payload } = await register();
    const ping = await post(`${baseUrl}/client/ping`, {
      clientId: payload.clientId, sessionToken: payload.sessionToken,
      timestamp: new Date(Date.now() - 12).toISOString(), debug: true,
    });
    expect(ping.status).toBe(200);
    const pingPayload = await ping.json();
    expect(pingPayload.success).toBe(true);
    expect(pingPayload.latencyMs).toBeGreaterThanOrEqual(0);
    expect(pingPayload.activityCount).toBe(0);

    const clients = await (await fetch(`${baseUrl}/clients`)).json();
    expect(clients.clients[0]).toMatchObject({ status: 'connected', operatingSystem: 'Windows', activityCount: 0 });
    expect(clients.clients[0].lastHeartbeat).toBeTruthy();
    expect(clients.clients[0].averageLatencyMs).toBeTypeOf('number');

    const health = await (await fetch(`${baseUrl}/health`)).json();
    expect(health.heartbeatsReceived).toBe(1);
    expect(health.activeClients).toBe(1);
    expect(health.averageResponseTimeMs).toBeTypeOf('number');
    expect(drainLanActivityEvents().some(event => event.action === 'LAN_HEARTBEAT_RECEIVED')).toBe(true);
  });

  it('marks inactive then disconnected, retains the registered record and releases the client slot', async () => {
    await register(1);
    await register(2);
    await sleep(450);
    let clients = await (await fetch(`${baseUrl}/clients`)).json();
    expect(clients.clients.every((client: { status: string }) => client.status === 'inactive')).toBe(true);

    await sleep(450);
    clients = await (await fetch(`${baseUrl}/clients`)).json();
    expect(clients.clients.every((client: { status: string }) => client.status === 'disconnected')).toBe(true);

    const third = await register(3);
    expect(third.response.status).toBe(201);
    const all = await (await fetch(`${baseUrl}/clients`)).json();
    expect(all.clients).toHaveLength(3);
    expect(all.clients.filter((client: { status: string }) => client.status === 'connected')).toHaveLength(1);
    expect(drainLanActivityEvents().filter(event => event.action === 'LAN_CLIENT_TIMEOUT')).toHaveLength(2);
  });

  it('reconnects a valid session preserving clientId and activity history', async () => {
    const { payload } = await register();
    await post(`${baseUrl}/client/ping`, { clientId: payload.clientId, sessionToken: payload.sessionToken, timestamp: new Date().toISOString() });
    await post(`${baseUrl}/client/disconnect`, { clientId: payload.clientId, sessionToken: payload.sessionToken });
    const reconnect = await post(`${baseUrl}/client/reconnect`, {
      clientId: payload.clientId, sessionToken: payload.sessionToken, ip: '192.168.1.50', operatingSystem: 'Windows 11',
    });
    expect(reconnect.status).toBe(200);
    const reconnectPayload = await reconnect.json();
    expect(reconnectPayload.clientId).toBe(payload.clientId);

    const clients = await (await fetch(`${baseUrl}/clients`)).json();
    expect(clients.clients).toHaveLength(1);
    expect(clients.clients[0]).toMatchObject({ clientId: payload.clientId, status: 'connected', activityCount: 0, ip: '192.168.1.50' });
    expect(drainLanActivityEvents().some(event => event.action === 'LAN_CLIENT_RECONNECTED')).toBe(true);
  });

  it('reactiva una sesión desconectada retenida preservando clientId e historial', async () => {
    const first = await register();
    await sleep(850);
    const reconnect = await post(`${baseUrl}/client/reconnect`, {
      clientId: first.payload.clientId, sessionToken: first.payload.sessionToken,
    });
    expect(reconnect.status).toBe(200);
    expect(await reconnect.json()).toMatchObject({ clientId: first.payload.clientId, sessionToken: first.payload.sessionToken });

    const clients = await (await fetch(`${baseUrl}/clients`)).json();
    expect(clients.clients).toHaveLength(1);
    expect(clients.clients[0]).toMatchObject({ clientId: first.payload.clientId, status: 'connected' });
    const events = drainLanActivityEvents();
    expect(events.some(event => event.action === 'LAN_AUTO_RECONNECTED')).toBe(true);
  });
});
