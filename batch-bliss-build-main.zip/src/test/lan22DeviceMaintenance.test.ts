// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {
  drainLanActivityEvents,
  startLanServer,
  stopLanServer,
} from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const listener = net.createServer();
    listener.listen(0, '127.0.0.1', () => {
      const address = listener.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_FREE_PORT'));
      listener.close(error => error ? reject(error) : resolve(address.port));
    });
    listener.on('error', reject);
  });
}

async function post<T = Record<string, unknown>>(url: string, body: Record<string, unknown>) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Connection: 'close' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { success?: boolean; error?: string };
  return { response, payload };
}

const sleep = (milliseconds: number) => new Promise(resolve => setTimeout(resolve, milliseconds));
const masterActor = {
  userId: 'master-user',
  username: 'master',
  displayName: 'Usuario Maestro',
  role: 'master',
};

describe('LAN 2.2 registered-device maintenance', () => {
  const temporaryPaths: string[] = [];

  afterEach(async () => {
    await stopLanServer();
    for (const directory of temporaryPaths.splice(0)) fs.rmSync(directory, { recursive: true, force: true });
  });

  async function start(options: { inactiveMs?: number; timeoutMs?: number } = {}) {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-maintenance-'));
    temporaryPaths.push(userDataPath);
    const timeoutMs = options.timeoutMs ?? 60_000;
    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor mantenimiento LAN',
      userDataPath,
      version: '2.1',
      sessionPolicy: {
        inactiveMs: options.inactiveMs ?? Math.max(30, Math.floor(timeoutMs / 2)),
        timeoutMs,
        retentionMs: Math.max(1_000, timeoutMs * 10),
      },
    });
    return `http://127.0.0.1:${port}`;
  }

  async function register(baseUrl: string, index: number, suffix = 'a') {
    const machineId = `machine-maintenance-${index}`;
    return post<{ clientId: string; sessionToken: string; machineId: string; reused?: boolean }>(`${baseUrl}/client/register`, {
      machineId,
      deviceInstanceId: machineId,
      connectionId: `runtime-${index}-${suffix}`,
      name: `Equipo ${index}`,
      hostname: `equipo-${index}`,
      ip: `192.168.30.${index}`,
      operatingSystem: 'Windows 11',
      version: '2.1',
      localTime: new Date().toISOString(),
      rememberDevice: true,
    });
  }

  async function clients(baseUrl: string) {
    return await fetch(`${baseUrl}/clients`).then(response => response.json()) as {
      registeredClients: Array<{ clientId: string; machineId: string; status: string }>;
      connectedClients: Array<{ clientId: string; machineId: string; status: string }>;
    };
  }

  it('removes 5 disconnected registrations while preserving 2 connected clients', async () => {
    const baseUrl = await start({ inactiveMs: 30, timeoutMs: 70 });
    for (let index = 1; index <= 5; index += 1) {
      expect((await register(baseUrl, index)).response.status).toBe(201);
    }
    await sleep(95);
    expect((await register(baseUrl, 6)).response.status).toBe(201);
    expect((await register(baseUrl, 7)).response.status).toBe(201);

    const before = await clients(baseUrl);
    expect(before.registeredClients).toHaveLength(7);
    expect(before.connectedClients).toHaveLength(2);

    const maintenance = await post<{ removedCount: number; registeredClients: number; connectedClients: number }>(`${baseUrl}/clients/maintenance`, {
      action: 'remove-disconnected',
      actor: masterActor,
    });

    expect(maintenance.response.status).toBe(200);
    expect(maintenance.payload).toMatchObject({
      success: true,
      removedCount: 5,
      registeredClients: 2,
      connectedClients: 2,
    });
    const after = await clients(baseUrl);
    expect(after.registeredClients).toHaveLength(2);
    expect(after.connectedClients).toHaveLength(2);
    expect(drainLanActivityEvents().filter(event => event.action === 'LAN_DEVICE_REMOVED')).toHaveLength(5);

    // Registry cleanup must not change the five-slot connected-client limit.
    expect((await register(baseUrl, 8)).response.status).toBe(201);
    expect((await register(baseUrl, 9)).response.status).toBe(201);
    expect((await register(baseUrl, 10)).response.status).toBe(201);
    const limitReached = await register(baseUrl, 11);
    expect(limitReached.response.status).toBe(403);
    expect(limitReached.payload.error).toBe('LAN_MAX_CLIENTS_REACHED');
  });

  it('prevents deletion of a connected device', async () => {
    const baseUrl = await start();
    const registration = await register(baseUrl, 1);
    const maintenance = await post(`${baseUrl}/clients/maintenance`, {
      action: 'remove-client',
      clientId: registration.payload.clientId,
      actor: masterActor,
    });

    expect(maintenance.response.status).toBe(409);
    expect(maintenance.payload.error).toBe('LAN_CONNECTED_DEVICE_CANNOT_BE_REMOVED');
    const state = await clients(baseUrl);
    expect(state.registeredClients).toHaveLength(1);
    expect(state.connectedClients).toHaveLength(1);
  });

  it('removes one disconnected device from the history', async () => {
    const baseUrl = await start({ inactiveMs: 25, timeoutMs: 55 });
    const registration = await register(baseUrl, 1);
    await sleep(80);
    const before = await clients(baseUrl);
    expect(before.registeredClients[0].status).toBe('disconnected');

    const maintenance = await post<{ removedCount: number }>(`${baseUrl}/clients/maintenance`, {
      action: 'remove-client',
      clientId: registration.payload.clientId,
      actor: masterActor,
    });
    expect(maintenance.response.status).toBe(200);
    expect(maintenance.payload.removedCount).toBe(1);
    expect((await clients(baseUrl)).registeredClients).toHaveLength(0);
  });

  it('registers a removed Machine ID again automatically on reconnect', async () => {
    const baseUrl = await start({ inactiveMs: 25, timeoutMs: 55 });
    const first = await register(baseUrl, 1);
    await sleep(80);
    expect((await post(`${baseUrl}/clients/maintenance`, {
      action: 'remove-client',
      clientId: first.payload.clientId,
      actor: masterActor,
    })).response.status).toBe(200);

    const reconnectAttempt = await post(`${baseUrl}/client/reconnect`, {
      clientId: first.payload.clientId,
      sessionToken: first.payload.sessionToken,
      machineId: first.payload.machineId,
      connectionId: 'runtime-old-reconnect',
    });
    expect(reconnectAttempt.response.status).toBe(401);

    const registeredAgain = await register(baseUrl, 1, 'new');
    expect(registeredAgain.response.status).toBe(201);
    expect(registeredAgain.payload.machineId).toBe(first.payload.machineId);
    expect(registeredAgain.payload.clientId).not.toBe(first.payload.clientId);
    const state = await clients(baseUrl);
    expect(state.registeredClients).toHaveLength(1);
    expect(state.connectedClients).toHaveLength(1);
  });

  it('removes only non-connected equipment older than the selected retention period', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-maintenance-age-'));
    temporaryPaths.push(userDataPath);
    const now = Date.now();
    const expiresAt = new Date(now + 10 * 24 * 60 * 60 * 1000).toISOString();
    const makeClient = (clientId: string, machineId: string, lastSeen: number) => ({
      clientId,
      sessionToken: `token-${clientId}`,
      machineId,
      deviceInstanceId: machineId,
      name: clientId,
      hostname: clientId,
      ip: '192.168.40.10',
      version: '2.1',
      operatingSystem: 'Windows 11',
      registeredAt: new Date(lastSeen).toISOString(),
      connectedAt: new Date(lastSeen).toISOString(),
      createdAt: new Date(lastSeen).toISOString(),
      lastActivity: new Date(lastSeen).toISOString(),
      lastHeartbeat: new Date(lastSeen).toISOString(),
      expiresAt,
      rememberDevice: true,
      status: 'inactive',
      heartbeatCount: 0,
      activityCount: 0,
      totalLatencyMs: 0,
    });
    fs.writeFileSync(path.join(userDataPath, 'lan-runtime-state.json'), JSON.stringify({
      clients: [
        makeClient('old-client', 'old-machine', now - 45 * 24 * 60 * 60 * 1000),
        makeClient('recent-client', 'recent-machine', now - 10 * 24 * 60 * 60 * 1000),
        makeClient('current-client', 'current-machine', now),
      ],
      userSessions: [],
      counters: {},
    }), 'utf8');
    await startLanServer({
      host: '127.0.0.1',
      port,
      serverName: 'Servidor mantenimiento por antigüedad',
      userDataPath,
      version: '2.1',
      sessionPolicy: { inactiveMs: 30_000, timeoutMs: 60_000, retentionMs: 365 * 24 * 60 * 60 * 1000 },
    });
    const baseUrl = `http://127.0.0.1:${port}`;

    const maintenance = await post<{ removedCount: number }>(`${baseUrl}/clients/maintenance`, {
      action: 'remove-older-than',
      days: 30,
      actor: masterActor,
    });
    expect(maintenance.response.status).toBe(200);
    expect(maintenance.payload.removedCount).toBe(1);
    const state = await clients(baseUrl);
    expect(state.registeredClients.map(client => client.machineId).sort()).toEqual(['current-machine', 'recent-machine']);
  });

  it('heartbeat timeout frees presence while preserving history until maintenance removes it', async () => {
    const baseUrl = await start({ inactiveMs: 25, timeoutMs: 55 });
    await register(baseUrl, 1);
    await sleep(80);

    const timedOut = await clients(baseUrl);
    expect(timedOut.registeredClients).toHaveLength(1);
    expect(timedOut.connectedClients).toHaveLength(0);
    expect(timedOut.registeredClients[0].status).toBe('disconnected');

    const maintenance = await post<{ connectedClients: number }>(`${baseUrl}/clients/maintenance`, {
      action: 'remove-disconnected',
      actor: masterActor,
    });
    expect(maintenance.response.status).toBe(200);
    expect(maintenance.payload.connectedClients).toBe(0);
    expect((await clients(baseUrl)).registeredClients).toHaveLength(0);
  });
});
