// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';
import { DexieRepository } from '@/repositories/DexieRepository';
import { clearRepositoryRuntimeConfig, configureRepository, getRepositoryConfig } from '@/repositories/RepositoryConfig';
import { getDataRepository, resetDataRepository } from '@/repositories/RepositoryRegistry';
import { createDefaultLanConfig, loadLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { loginUser } from '@/lib/auth';

const session = {
  id: 'master-1',
  username: 'maestro',
  displayName: 'Usuario Maestro',
  role: 'master' as const,
};

function persist(mode: 'local' | 'lan', role: 'server' | 'client', withSession = false) {
  saveLanConfig({
    ...createDefaultLanConfig(),
    mode,
    role,
    clientServerIp: '192.168.1.20',
    clientServerPort: 47831,
    clientId: withSession ? 'client-1' : null,
    sessionToken: withSession ? 'session-1' : null,
  });
  clearRepositoryRuntimeConfig();
  resetDataRepository();
}

describe('QA LAN 2.1.2 Principal Server authentication selection', () => {
  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    clearRepositoryRuntimeConfig();
    resetDataRepository();
    vi.restoreAllMocks();
  });

  it('Local login uses DexieRepository', async () => {
    persist('local', 'client');
    const repository = getDataRepository();
    expect(repository).toBeInstanceOf(DexieRepository);
    const localLogin = vi.spyOn(repository, 'loginUser').mockResolvedValue(session);
    await expect(loginUser('maestro', 'clave')).resolves.toEqual(session);
    expect(localLogin).toHaveBeenCalledWith('maestro', 'clave');
  });

  it('Principal Server login uses DexieRepository and cannot emit LAN_SESSION_NOT_AVAILABLE', async () => {
    persist('lan', 'server');
    const repository = getDataRepository();
    expect(repository).toBeInstanceOf(DexieRepository);
    const serverLogin = vi.spyOn(repository, 'loginUser').mockResolvedValue(session);
    await expect(loginUser('maestro', 'clave')).resolves.toEqual(session);
    expect(getRepositoryConfig().mode).toBe('local');
    expect(serverLogin).toHaveBeenCalledOnce();
  });

  it('LAN client without cached device session attempts to reconstruct it before login', async () => {
    persist('lan', 'client', false);
    expect(getDataRepository()).toBeInstanceOf(ApiRepository);
    const error = await loginUser('maestro', 'clave').catch(value => value as Error);
    expect(error).toBeInstanceOf(Error);
    expect(error.message).not.toBe('LAN_SESSION_NOT_AVAILABLE');
  });

  it('LAN client with valid session performs remote login', async () => {
    persist('lan', 'client', true);
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({
      success: true,
      userId: session.id,
      username: session.username,
      displayName: session.displayName,
      role: session.role,
      permissions: [],
      authToken: 'auth-1',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));

    await expect(loginUser('maestro', 'clave')).resolves.toEqual(session);
    expect(getDataRepository()).toBeInstanceOf(ApiRepository);
    expect(fetchMock).toHaveBeenCalledWith('http://192.168.1.20:47831/login', expect.objectContaining({ method: 'POST' }));
  });

  it('runtime mode overrides cannot force a Principal Server into ApiRepository', () => {
    persist('lan', 'server');
    configureRepository({ mode: 'lan', apiBaseUrl: 'http://invalid:9999' });
    resetDataRepository();
    expect(getRepositoryConfig().mode).toBe('local');
    expect(getDataRepository()).toBeInstanceOf(DexieRepository);
  });

  it('normalizes malformed or legacy roles safely as server, never client', () => {
    localStorage.setItem('system_network_config', JSON.stringify({ mode: 'lan', role: 'Servidor Principal' }));
    expect(loadLanConfig().role).toBe('server');
    expect(getRepositoryConfig().mode).toBe('local');
    expect(getDataRepository()).toBeInstanceOf(DexieRepository);
  });
});
