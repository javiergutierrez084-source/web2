import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

describe('proveedor en Editar Producto', () => {
  it('reutiliza selección, creación y asociación del formulario Nuevo Producto', () => {
    const source = fs.readFileSync(path.resolve(process.cwd(), 'src/pages/Inventory.tsx'), 'utf8');

    expect(source).toContain('toggleEditSupplier');
    expect(source).toContain('createAndAssociateEditSupplier');
    expect(source).toContain("type: 'supplier' as const");
    expect(source).toContain('setContacts([newContact, ...contacts])');
    expect(source).toContain('supplierIds: Array.isArray(editForm.supplierIds)');
    expect(source).toContain('Crear y Asociar');
  });
});
