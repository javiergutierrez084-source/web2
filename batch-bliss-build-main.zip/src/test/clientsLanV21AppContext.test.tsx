// @vitest-environment jsdom
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Contact } from '@/data/mockData';
import type { SalesWorkspace } from '@/lib/SalesRepositoryService';

const ana: Contact = {
  id: 'client-ana', type: 'client', name: 'Ana Gómez', document: '123',
  phone: '3001112233', email: 'ana@example.com', address: 'Centro', notes: '',
};
const beatriz: Contact = {
  id: 'client-beatriz', type: 'client', name: 'Beatriz López', document: '456',
  phone: '3004445566', email: 'bea@example.com', address: 'Norte', notes: '',
};

const workspace: SalesWorkspace = {
  company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
  contacts: [ana], invoices: [], layaways: [], quotations: [], financialAccounts: [],
  financialMovements: [], financialSummary: null,
};

const mocks = vi.hoisted(() => ({
  getWorkspace: vi.fn(),
  createClient: vi.fn(),
  updateClient: vi.fn(),
  deleteClient: vi.fn(),
  applyChanges: vi.fn(),
  invalidate: vi.fn(),
  fetchProducts: vi.fn(),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getActiveRepositoryMode: () => 'lan',
}));

vi.mock('@/lib/database', () => ({
  fetchProducts: mocks.fetchProducts,
}));

vi.mock('@/lib/categoryService', () => ({
  getAllCategoryNames: vi.fn(async () => ['Anillos']),
}));

vi.mock('@/lib/BackupManager', () => ({ BackupManager: { isBusy: vi.fn(() => false) } }));
vi.mock('@/lib/BackupScheduler', () => ({ BackupScheduler: { init: vi.fn(), dispose: vi.fn() } }));

vi.mock('@/lib/SalesRepositoryService', () => ({
  SalesRepositoryService: {
    getSalesWorkspace: mocks.getWorkspace,
    createClient: mocks.createClient,
    updateClient: mocks.updateClient,
    deleteClient: mocks.deleteClient,
    applyContactChanges: mocks.applyChanges,
    invalidate: mocks.invalidate,
  },
}));

import { AppProvider, useApp } from '@/contexts/AppContext';

function Probe() {
  const { contacts, setContacts, isLoading } = useApp();
  return (
    <div>
      <span data-testid="loading">{String(isLoading)}</span>
      <span data-testid="clients">{contacts.filter(contact => contact.type === 'client').map(contact => contact.name).join(',')}</span>
      <button type="button" onClick={() => setContacts([beatriz, ...contacts])}>Crear cliente</button>
    </div>
  );
}

beforeEach(() => {
  mocks.getWorkspace.mockReset().mockResolvedValue(workspace);
  mocks.createClient.mockReset().mockResolvedValue(beatriz);
  mocks.updateClient.mockReset().mockResolvedValue(beatriz);
  mocks.deleteClient.mockReset().mockResolvedValue(undefined);
  mocks.applyChanges.mockReset().mockResolvedValue(undefined);
  mocks.invalidate.mockReset();
  mocks.fetchProducts.mockReset().mockResolvedValue([]);
});

describe('Clients LAN V2.1 AppContext integration', () => {
  it('loads server clients and makes a newly created client immediately selectable while persisting remotely', async () => {
    render(<AppProvider><Probe /></AppProvider>);

    await waitFor(() => expect(screen.getByTestId('loading').textContent).toBe('false'));
    expect(screen.getByTestId('clients').textContent).toBe('Ana Gómez');

    fireEvent.click(screen.getByRole('button', { name: 'Crear cliente' }));

    await waitFor(() => expect(screen.getByTestId('clients').textContent).toBe('Beatriz López,Ana Gómez'));
    await waitFor(() => expect(mocks.createClient).toHaveBeenCalledWith(beatriz));
    expect(mocks.applyChanges).not.toHaveBeenCalled();
  });
});
