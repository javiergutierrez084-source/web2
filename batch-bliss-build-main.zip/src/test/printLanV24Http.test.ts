// @vitest-environment node
import { afterEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function post<T>(url: string, body: object): Promise<T> {
  const response = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
}

afterEach(async () => { await stopLanServer(); });

describe('JOYACONTROL LAN V2.4 centralized print transport', () => {
  it('uses only /repository/call and accepts a complete print document larger than the legacy payload limit', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-print-http-'));
    const executeRepositoryCall = vi.fn(async (method: string, args: Record<string, unknown>) => ({ method, size: JSON.stringify(args).length }));
    try {
      await startLanServer({
        host: '127.0.0.1', port, serverName: 'Print Server', userDataPath, version: '2.1',
        authenticateUser: async () => ({ success: true, userId: 'u1', username: 'master', displayName: 'Master', role: 'master', permissions: [] }),
        executeRepositoryCall,
      });
      const baseUrl = `http://127.0.0.1:${port}`;
      const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
        name: 'Cliente Print', hostname: 'print-client', version: '2.1', localTime: new Date().toISOString(), deviceInstanceId: 'print-device',
      });
      const login = await post<{ authToken: string }>(`${baseUrl}/login`, { username: 'master', password: 'x', ...registered });
      const contentBase64 = Buffer.alloc(96 * 1024, 7).toString('base64');
      const result = await post<{ data: { method: string; size: number } }>(`${baseUrl}/repository/call`, {
        method: 'submitPrintJob',
        args: { request: { requestId: 'large-print', documentType: 'report', documentId: 'r1', documentNumber: 'R-1', title: 'Reporte', format: 'letter', contentType: 'application/pdf', contentBase64, requester: { userId: 'u1', username: 'master', displayName: 'Master', clientId: registered.clientId, deviceName: 'Cliente Print' }, requestedAt: new Date().toISOString() } },
        clientId: registered.clientId, sessionToken: registered.sessionToken, authToken: login.authToken,
      });
      expect(result.data.method).toBe('submitPrintJob');
      expect(result.data.size).toBeGreaterThan(32 * 1024);
      expect(executeRepositoryCall).toHaveBeenCalledTimes(1);
      expect(executeRepositoryCall.mock.calls[0][0]).toBe('submitPrintJob');
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });

  it('accepts ten authenticated clients printing simultaneously through the same endpoint', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-print-http-10-'));
    const executeRepositoryCall = vi.fn(async (method: string, args: Record<string, unknown>) => ({
      method,
      requestId: (args.request as { requestId?: string } | undefined)?.requestId,
      status: 'pending',
    }));
    try {
      await startLanServer({
        host: '127.0.0.1', port, serverName: 'Print Server', userDataPath, version: '2.1',
        authenticateUser: async username => ({ success: true, userId: `u-${username}`, username, displayName: username, role: 'master', permissions: [] }),
        executeRepositoryCall,
      });
      const baseUrl = `http://127.0.0.1:${port}`;
      const clients: Array<{ clientId: string; sessionToken: string; authToken: string }> = [];
      for (let index = 1; index <= 10; index += 1) {
        const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
          name: `Cliente ${index}`, hostname: `print-client-${index}`, version: '2.1', localTime: new Date().toISOString(), deviceInstanceId: `print-device-${index}`,
        });
        const login = await post<{ authToken: string }>(`${baseUrl}/login`, { username: `user-${index}`, password: 'x', ...registered });
        clients.push({ ...registered, authToken: login.authToken });
      }
      const rejected = await fetch(`${baseUrl}/client/register`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
          name: 'Cliente 11', hostname: 'print-client-11', version: '2.1', localTime: new Date().toISOString(), deviceInstanceId: 'print-device-11',
        }),
      });
      expect(rejected.status).toBe(403);

      const contentBase64 = Buffer.alloc(128 * 1024, 5).toString('base64');
      await Promise.all(clients.map((client, index) => post(`${baseUrl}/repository/call`, {
        method: 'submitPrintJob',
        args: { request: {
          requestId: `print-${index + 1}`, documentType: 'invoice', documentId: `invoice-${index + 1}`, documentNumber: `FAC-${index + 1}`,
          title: `Factura ${index + 1}`, format: index % 2 === 0 ? 'letter' : 'ticket80', contentType: 'application/pdf', contentBase64,
          requester: { userId: `u-${index + 1}`, username: `user-${index + 1}`, displayName: `Usuario ${index + 1}`, clientId: client.clientId, deviceName: `Cliente ${index + 1}` },
          requestedAt: new Date().toISOString(),
        } },
        clientId: client.clientId, sessionToken: client.sessionToken, authToken: client.authToken,
      })));

      expect(executeRepositoryCall).toHaveBeenCalledTimes(10);
      expect(executeRepositoryCall.mock.calls.every(call => call[0] === 'submitPrintJob')).toBe(true);
      const info = await (await fetch(`${baseUrl}/server-info`)).json();
      expect(info.maxClients).toBe(10);
      expect(info.connectedClients).toBe(10);
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });


  it('returns the centralized printer configuration to an authenticated LAN client through /repository/call', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-print-config-http-'));
    const workspace = {
      printers: [{ name: 'Laser', displayName: 'Laser principal', description: '', status: 0, isDefault: true, available: true, type: 'local' }],
      configuration: {
        defaultPrinterName: 'Laser', profilePrinters: {}, documentPrinters: {}, automaticRetry: true, retryDelayMs: 30000,
        documentSettings: {
          invoiceLetter: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
          invoiceTicket80: { printerName: null, paperSize: 'ticket80', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
          invoiceTicket58: { printerName: null, paperSize: 'ticket58', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
          quotation: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
          report: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
          label: { printerName: null, paperSize: 'label', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
          barcode: { printerName: null, paperSize: 'barcode', orientation: 'portrait', copies: 1, silent: true, margin: 'none', scale: 100, colorMode: 'monochrome' },
          pdf: { printerName: 'Laser', paperSize: 'letter', orientation: 'portrait', copies: 1, silent: true, margin: 'default', scale: 100, colorMode: 'color' },
        },
        updatedAt: new Date().toISOString(),
      },
      jobs: [], spooler: { status: 'running', checkedAt: new Date().toISOString(), message: 'Print Spooler en ejecución' },
      server: { name: 'SERVER-01', platform: 'win32' }, discoveredAt: new Date().toISOString(),
    };
    const executeRepositoryCall = vi.fn(async method => method === 'getPrintWorkspace' ? workspace : null);
    try {
      await startLanServer({
        host: '127.0.0.1', port, serverName: 'Print Server', userDataPath, version: '2.1',
        authenticateUser: async () => ({ success: true, userId: 'u1', username: 'master', displayName: 'Master', role: 'master', permissions: [] }),
        executeRepositoryCall,
      });
      const baseUrl = `http://127.0.0.1:${port}`;
      const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
        name: 'Cliente Config', hostname: 'config-client', version: '2.1', localTime: new Date().toISOString(), deviceInstanceId: 'config-device',
      });
      const login = await post<{ authToken: string }>(`${baseUrl}/login`, { username: 'master', password: 'x', ...registered });
      const response = await post<{ data: typeof workspace }>(`${baseUrl}/repository/call`, {
        method: 'getPrintWorkspace', args: {}, clientId: registered.clientId, sessionToken: registered.sessionToken, authToken: login.authToken,
      });
      expect(response.data.configuration.documentSettings.invoiceLetter.printerName).toBe('Laser');
      expect(response.data.server.name).toBe('SERVER-01');
      expect(executeRepositoryCall).toHaveBeenCalledWith('getPrintWorkspace', {});
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });

});
