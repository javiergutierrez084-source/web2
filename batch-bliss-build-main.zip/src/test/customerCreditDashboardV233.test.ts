import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement, Invoice } from '@/data/mockData';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const now = new Date('2026-07-21T12:00:00.000Z');
const today = '2026-07-21';

const account = (id: string, name: string, balance: number): FinancialAccount => ({
  id,
  name,
  kind: 'cash',
  active: true,
  balance,
  createdAt: today,
  updatedAt: today,
});


const paidInvoice: Invoice = {
  id: 'invoice-1',
  number: 'FAC-001',
  clientId: 'customer-1',
  clientName: 'Cliente',
  items: [],
  subtotal: 400,
  discount: 0,
  tax: 0,
  total: 400,
  date: today,
  status: 'paid',
  tipoDocumento: 'factura',
};

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 0,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: '',
  documentType: 'manual',
  documentId: '',
  observation: '',
  userId: 'user-1',
  userName: 'Admin',
  date: today,
  createdAt: `${today}T10:00:00.000Z`,
  status: 'COMPLETED',
  ...overrides,
});

describe('JOYACONTROL LAN V2.3.3 - Dashboard y saldo a favor', () => {
  it('cuenta CUSTOMER_CREDIT_USED como parte de la venta sin duplicar el ingreso', () => {
    const movements: FinancialMovement[] = [
      movement({
        id: 'opening-main',
        type: 'opening_balance',
        amount: 0,
        destinationAccountId: MAIN_CASH_ACCOUNT_ID,
        movementCode: 'OPENING_BALANCE',
        referenceType: 'FINANCIAL_ACCOUNT',
        referenceId: MAIN_CASH_ACCOUNT_ID,
        documentId: MAIN_CASH_ACCOUNT_ID,
      }),
      movement({
        id: 'opening-reserve',
        type: 'opening_balance',
        amount: 500,
        destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationBalanceAfter: 500,
        movementCode: 'OPENING_BALANCE',
        referenceType: 'FINANCIAL_ACCOUNT',
        referenceId: LAYAWAY_RESERVE_ACCOUNT_ID,
        documentId: LAYAWAY_RESERVE_ACCOUNT_ID,
      }),
      movement({
        id: 'credit-source',
        type: 'adjustment',
        amount: 500,
        movementCode: 'CUSTOMER_CREDIT',
        referenceType: 'CUSTOMER',
        referenceId: 'customer-1',
        customerId: 'customer-1',
        reference: 'SEP-001',
        documentId: 'layaway-1',
      }),
      movement({
        id: 'credit-use',
        type: 'transfer',
        amount: 250,
        originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationAccountId: MAIN_CASH_ACCOUNT_ID,
        originBalanceBefore: 500,
        originBalanceAfter: 250,
        destinationBalanceBefore: 0,
        destinationBalanceAfter: 250,
        movementCode: 'CUSTOMER_CREDIT_USED',
        relatedMovementId: 'credit-source',
        referenceType: 'SALE',
        referenceId: 'invoice-1',
        customerId: 'customer-1',
        reference: 'FAC-001',
        documentId: 'invoice-1',
      }),
      movement({
        id: 'cash-payment',
        type: 'sale_income',
        amount: 150,
        destinationAccountId: MAIN_CASH_ACCOUNT_ID,
        destinationBalanceBefore: 250,
        destinationBalanceAfter: 400,
        movementCode: 'SALE_PAYMENT',
        referenceType: 'SALE',
        referenceId: 'invoice-1',
        reference: 'FAC-001',
        documentId: 'invoice-1',
      }),
    ];

    const snapshot = buildDashboardSnapshot({
      products: [],
      contacts: [],
      invoices: [paidInvoice],
      purchases: [],
      expenses: [],
      layaways: [],
      cashSessions: [],
      accounts: [
        account(MAIN_CASH_ACCOUNT_ID, 'Caja Principal', 400),
        account(LAYAWAY_RESERVE_ACCOUNT_ID, 'Caja Separados', 250),
      ],
      movements,
      financialSummary: null,
      backupStatusAvailable: false,
      now,
    });

    expect(snapshot.today).toMatchObject({ count: 1, value: 400 });
    expect(snapshot.month).toMatchObject({ count: 1, value: 400 });
    expect(snapshot.financialPosition).toMatchObject({
      mainCash: 400,
      layawayReserve: 250,
      totalAvailable: 400,
    });
  });
});
