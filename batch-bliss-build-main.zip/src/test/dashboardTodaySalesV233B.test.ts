import { describe, expect, it } from 'vitest';
import type { Invoice } from '@/data/mockData';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';

const TODAY = '2026-07-21';
const YESTERDAY = '2026-07-20';

const invoice = (
  id: string,
  total: number,
  date = TODAY,
  status: Invoice['status'] = 'paid',
  tipoDocumento: Invoice['tipoDocumento'] = 'factura',
): Invoice => ({
  id,
  number: `FAC-${id}`,
  clientId: 'customer-1',
  clientName: 'Cliente',
  items: [],
  subtotal: total,
  discount: 0,
  tax: 0,
  total,
  date,
  status,
  tipoDocumento,
});

const snapshot = (invoices: Invoice[]) => buildDashboardSnapshot({
  products: [], contacts: [], invoices, purchases: [], expenses: [], layaways: [],
  cashSessions: [], accounts: [], movements: [], financialSummary: null,
  backupStatusAvailable: false, now: new Date(`${TODAY}T12:00:00`),
});

describe('JOYACONTROL v3.2.1 - Ventas Hoy desde facturas válidas', () => {
  it('cuenta las facturas pagadas realizadas hoy', () => {
    expect(snapshot([
      invoice('1', 800_000),
      invoice('2', 1_250_000),
    ]).today).toEqual({ count: 2, value: 2_050_000 });
  });

  it('excluye facturas anuladas, pendientes, cotizaciones y fechas distintas', () => {
    expect(snapshot([
      invoice('paid', 450_000),
      invoice('cancelled', 800_000, TODAY, 'cancelled'),
      invoice('pending', 900_000, TODAY, 'pending'),
      invoice('quote', 700_000, TODAY, 'paid', 'cotizacion'),
      invoice('yesterday', 600_000, YESTERDAY),
    ]).today).toEqual({ count: 1, value: 450_000 });
  });

  it('incluye ventas válidas aunque no exista FinancialMovement asociado', () => {
    const result = snapshot([invoice('historical', 990_000)]);
    expect(result.today).toEqual({ count: 1, value: 990_000 });
    expect(result.recentSales).toHaveLength(1);
  });
});
