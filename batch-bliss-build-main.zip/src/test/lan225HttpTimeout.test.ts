// @vitest-environment node
import http from 'node:http';
import net from 'node:net';
import { afterEach, describe, expect, it } from 'vitest';
import { lanFetch } from '@/lib/LanFetchDiagnostics';

const servers: http.Server[] = [];

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function listen(handler: http.RequestListener): Promise<string> {
  const port = await freePort();
  const server = http.createServer(handler);
  servers.push(server);
  await new Promise<void>((resolve, reject) => {
    server.once('error', reject);
    server.listen(port, '127.0.0.1', resolve);
  });
  return `http://127.0.0.1:${port}`;
}

afterEach(async () => {
  await Promise.all(servers.splice(0).map(server => new Promise<void>(resolve => server.close(() => resolve()))));
});

describe('LAN 2.2.5 abortable HTTP transport', () => {
  it('aborts a request that never returns headers', async () => {
    const baseUrl = await listen(() => undefined);
    const started = Date.now();

    await expect(lanFetch(`${baseUrl}/health`, {
      timeoutMs: 80,
      timeoutError: 'LAN_HEALTH_TIMEOUT',
    })).rejects.toThrow('LAN_HEALTH_TIMEOUT');

    expect(Date.now() - started).toBeLessThan(1000);
  });

  it('keeps the AbortController active while the response body is pending', async () => {
    const baseUrl = await listen((_request, response) => {
      response.writeHead(200, { 'Content-Type': 'application/json' });
      response.flushHeaders();
      response.write('{"status":');
    });

    const response = await lanFetch(`${baseUrl}/server-info`, {
      timeoutMs: 80,
      timeoutError: 'LAN_SERVER_INFO_TIMEOUT',
    });

    await expect(response.json()).rejects.toThrow('LAN_SERVER_INFO_TIMEOUT');
  });

  it('forwards caller cancellation to the owned AbortController', async () => {
    const baseUrl = await listen(() => undefined);
    const controller = new AbortController();
    const pending = lanFetch(`${baseUrl}/client/reconnect`, {
      signal: controller.signal,
      timeoutMs: 10_000,
      timeoutError: 'LAN_CLIENT_RECONNECT_TIMEOUT',
    });

    controller.abort(new Error('LAN_MANAGER_STOPPED'));
    await expect(pending).rejects.toThrow('LAN_MANAGER_STOPPED');
  });
});
