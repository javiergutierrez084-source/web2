import { describe, expect, it } from 'vitest';
import type {
  Contact,
  InventoryAdjustment,
  Product,
  PurchaseInvoice,
} from '@/data/mockData';
import { SupplierRelationResolver } from '@/lib/SupplierRelationResolver';

const supplier = (id: string, name: string): Contact => ({
  id,
  type: 'supplier',
  name,
  document: '',
  phone: '',
  email: '',
  address: '',
});

const product = (overrides: Partial<Product> = {}): Product => ({
  id: 'product-1',
  code: 'P-001',
  name: 'Producto',
  category: 'General',
  purchasePrice: 100,
  salePrice: 150,
  weightGrams: 10,
  margin: 50,
  stock: 0,
  minStock: 0,
  supplierIds: [],
  ...overrides,
});

const purchase = (overrides: Partial<PurchaseInvoice> = {}): PurchaseInvoice => ({
  id: 'purchase-1',
  number: 'COM-001',
  supplierId: '',
  supplierName: '',
  items: [{
    productId: 'product-1', code: 'P-001', name: 'Producto', quantity: 1,
    weightGrams: 10, unitPrice: 100, subtotal: 100,
  }],
  subtotal: 100,
  discount: 0,
  tax: 0,
  total: 100,
  date: '2026-07-01',
  status: 'paid',
  ...overrides,
});

const adjustment = (overrides: Partial<InventoryAdjustment> = {}): InventoryAdjustment => ({
  id: 'adjustment-1',
  productId: 'product-1',
  productCode: 'P-001',
  productName: 'Producto',
  type: 'increase',
  quantity: 1,
  grams: 10,
  totalCost: 100,
  unitCost: 100,
  valuePerGram: 10,
  purchasePrice: 100,
  averagePriceBefore: 0,
  averagePriceAfter: 100,
  stockBefore: 0,
  stockAfter: 1,
  gramsBefore: 0,
  gramsAfter: 10,
  notes: '',
  date: '2026-07-01',
  createdAt: '2026-07-01T12:00:00.000Z',
  ...overrides,
});

describe('SupplierRelationResolver', () => {
  const suppliers = [supplier('supplier-1', 'Proveedor Águila'), supplier('supplier-2', 'Proveedor Dos')];

  it('resuelve una compra únicamente por supplierId', () => {
    const resolver = new SupplierRelationResolver(suppliers, []);
    expect(resolver.resolvePurchase(purchase({ supplierId: 'supplier-1' }))).toMatchObject({
      supplierId: 'supplier-1',
      source: 'purchase-id',
    });
  });

  it('resuelve una compra histórica únicamente por nombre normalizado', () => {
    const resolver = new SupplierRelationResolver(suppliers, []);
    expect(resolver.resolvePurchase(purchase({ supplierName: '  PROVEEDOR AGUILA  ' }))).toMatchObject({
      supplierId: 'supplier-1',
      source: 'purchase-name',
    });
  });

  it('prioriza el ID válido cuando el documento contiene ID y nombre', () => {
    const resolver = new SupplierRelationResolver(suppliers, []);
    expect(resolver.resolvePurchase(purchase({
      supplierId: 'supplier-2',
      supplierName: 'Proveedor Águila',
    }))).toMatchObject({ supplierId: 'supplier-2', source: 'purchase-id' });
  });

  it('resuelve ajustes por ID y por nombre sin modificar el objeto', () => {
    const resolver = new SupplierRelationResolver(suppliers, []);
    const byId = adjustment({ supplierId: 'supplier-1' });
    const byName = adjustment({ id: 'adjustment-2', supplierName: 'proveedor aguila' });

    expect(resolver.resolveAdjustment(byId)?.source).toBe('adjustment-id');
    expect(resolver.resolveAdjustment(byName)).toMatchObject({
      supplierId: 'supplier-1',
      source: 'adjustment-name',
    });
    expect(byName.supplierId).toBeUndefined();
  });

  it('resuelve compras antiguas después de asociar masivamente el producto', () => {
    const products = [product({ supplierIds: ['supplier-1'] })];
    const resolver = new SupplierRelationResolver(suppliers, products);

    expect(resolver.resolvePurchase(purchase())).toMatchObject({
      supplierId: 'supplier-1',
      source: 'product-supplier-ids',
    });
  });

  it('no atribuye automáticamente un documento cuando el producto tiene varios proveedores', () => {
    const products = [product({ supplierIds: ['supplier-1', 'supplier-2'] })];
    const resolver = new SupplierRelationResolver(suppliers, products);

    expect(resolver.resolvePurchase(purchase())).toBeNull();
    expect(resolver.resolveAdjustment(adjustment())).toBeNull();
    expect(resolver.isProductRelatedToSupplier(products[0], 'supplier-1')).toBe(true);
    expect(resolver.isProductRelatedToSupplier(products[0], 'supplier-2')).toBe(true);
  });

  it('no resuelve nombres ambiguos para evitar relacionar al proveedor incorrecto', () => {
    const resolver = new SupplierRelationResolver([
      supplier('supplier-1', 'Proveedor Repetido'),
      supplier('supplier-2', 'Proveedor Repetido'),
    ], []);

    expect(resolver.resolvePurchase(purchase({ supplierName: 'Proveedor Repetido' }))).toBeNull();
  });

  it('localiza compras históricas por producto aunque el producto tenga varios proveedores', () => {
    const shared = product({ supplierIds: ['supplier-1', 'supplier-2'] });
    const resolver = new SupplierRelationResolver(suppliers, [shared]);
    const historical = purchase({ supplierId: '', supplierName: '' });

    expect(resolver.purchaseContainsSupplierProduct(historical, 'supplier-1')).toBe(true);
    expect(resolver.purchaseContainsSupplierProduct(historical, 'supplier-2')).toBe(true);
  });

  it('localiza líneas históricas por código cuando productId no está disponible', () => {
    const products = [product({ id: 'current-product', code: 'COD-HIST', supplierIds: ['supplier-1'] })];
    const resolver = new SupplierRelationResolver(suppliers, products);
    const historical = purchase({
      supplierId: '',
      supplierName: '',
      items: [{
        productId: '', code: 'COD-HIST', name: 'Nombre antiguo', quantity: 2,
        weightGrams: 0, unitPrice: 100, subtotal: 200,
      }],
    });

    expect(resolver.purchaseContainsSupplierProduct(historical, 'supplier-1')).toBe(true);
    expect(resolver.getProductsForPurchase(historical).map(item => item.id)).toEqual(['current-product']);
  });

  it('no reemplaza una relación histórica existente por la asociación del producto', () => {
    const products = [product({ supplierIds: ['supplier-1'] })];
    const resolver = new SupplierRelationResolver(suppliers, products);
    const historical = purchase({
      supplierId: 'supplier-historico-eliminado',
      supplierName: 'Proveedor histórico diferente',
    });

    expect(resolver.resolvePurchase(historical)).toBeNull();
    expect(resolver.purchaseContainsSupplierProduct(historical, 'supplier-1')).toBe(true);
  });

});
