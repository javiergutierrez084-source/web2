import { describe, expect, it } from 'vitest';
import { calculateFinancialSummary, isOperatingExpenseMovement, isSalesInvoice } from '@/lib/DashboardMetricsService';
import type { FinancialMovement } from '@/data/mockData';

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: 'm1',
  type: 'expense',
  amount: 30000,
  originAccountId: 'cash',
  originBalanceBefore: 100000,
  originBalanceAfter: 70000,
  destinationAccountId: '',
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'REF',
  documentType: 'expense',
  documentId: 'd1',
  observation: '',
  userId: 'u1',
  userName: 'Admin',
  date: '2026-07-16',
  createdAt: '2026-07-16T10:00:00.000Z',
  ...overrides,
});

describe('DashboardMetricsService', () => {
  it('excludes inventory adjustments from operating expenses', () => {
    expect(isOperatingExpenseMovement(movement({ documentType: 'inventory_adjustment' }))).toBe(false);
    expect(isOperatingExpenseMovement(movement({ documentType: 'stock_adjustment' }))).toBe(false);
    expect(isOperatingExpenseMovement(movement({ type: 'inventory_purchase', documentType: 'inventory_adjustment' }))).toBe(false);
  });

  it('keeps real paid expenses in expensesToday', () => {
    const summary = calculateFinancialSummary({
      accounts: [],
      payables: [],
      expenses: [{ id: 'e1', number: 'G-1', supplierId: '', supplierName: 'Proveedor', total: 10000, description: 'Servicios', date: '2026-07-16', paymentMethod: 'Efectivo', status: 'paid' }],
      invoices: [],
      products: [],
      today: '2026-07-16',
      movements: [
        movement({ amount: 10000, documentType: 'expense', documentId: 'e1' }),
        movement({ amount: 30000, type: 'inventory_purchase', documentType: 'inventory_adjustment', documentId: 'a1' }),
      ],
    });

    expect(summary.expensesToday).toBe(10000);
    expect(summary.expenses).toBe(10000);
  });

  it('excludes transfers, reversals and cancelled documents from dashboard metrics', () => {
    const summary = calculateFinancialSummary({
      accounts: [], payables: [], expenses: [], products: [], today: '2026-07-16',
      invoices: [
        { id: 'i1', number: 'F-1', clientId: '', clientName: 'A', items: [], subtotal: 50000, discount: 0, tax: 0, total: 50000, date: '2026-07-16', status: 'cancelled' },
      ],
      movements: [
        movement({ type: 'transfer', documentType: 'transfer' }),
        movement({ type: 'sale_income', documentType: 'invoice_cancellation' }),
      ],
    });

    expect(summary.sales).toBe(0);
    expect(summary.incomeToday).toBe(0);
    expect(summary.expensesToday).toBe(0);
  });

  it('refreshes balances after an exceptional cash adjustment without changing sales or profit KPIs', () => {
    const invoice = {
      id: 'i-paid', number: 'F-2', clientId: '', clientName: 'Cliente',
      items: [{ id: 'ii1', productId: 'p1', name: 'Producto', quantity: 1, unitPrice: 100000, subtotal: 100000, costPrice: 60000 }],
      subtotal: 100000, discount: 0, tax: 0, total: 100000, date: '2026-07-16', status: 'paid' as const,
    };
    const baseInput = {
      payables: [], expenses: [], products: [], invoices: [invoice], today: '2026-07-16',
      movements: [movement({
        id: 'sale-1', type: 'sale_income', amount: 100000, documentType: 'invoice', documentId: invoice.id,
        originAccountId: undefined, originBalanceBefore: 0, originBalanceAfter: 0,
        destinationAccountId: 'cash', destinationBalanceBefore: 33134700, destinationBalanceAfter: 33234700,
      })],
    };

    const before = calculateFinancialSummary({
      ...baseInput,
      accounts: [{ id: 'cash', name: 'Caja', kind: 'cash' as const, balance: 33234700, active: true }],
    });
    const after = calculateFinancialSummary({
      ...baseInput,
      accounts: [{ id: 'cash', name: 'Caja', kind: 'cash' as const, balance: 33195000, active: true }],
      movements: [
        ...baseInput.movements,
        movement({
          id: 'cash-fix', type: 'adjustment', amount: 39700, documentType: 'exceptional_cash_adjustment',
          documentId: 'cash-fix', originAccountId: 'cash', destinationAccountId: '',
          originBalanceBefore: 33234700, originBalanceAfter: 33195000,
          createdAt: '2026-07-16T11:00:00.000Z',
        }),
      ],
    });

    expect(after.cash).toBe(before.cash - 39700);
    expect(after.totalFunds).toBe(before.totalFunds - 39700);
    expect(after.sales).toBe(before.sales);
    expect(after.grossProfit).toBe(before.grossProfit);
    expect(after.netProfit).toBe(before.netProfit);
    expect(after.availableProfit).toBe(before.availableProfit);
    expect(after.incomeToday).toBe(before.incomeToday);
    expect(after.expensesToday).toBe(before.expensesToday);
  });

  it('excluye facturas pendientes y anuladas de las ventas efectivas', () => {
    const baseInvoice = {
      number: 'F-TEST', clientId: '', clientName: 'Cliente', items: [],
      subtotal: 0, discount: 0, tax: 0, date: '2026-07-16',
    };
    const invoices = [
      { ...baseInvoice, id: 'paid', status: 'paid' as const, total: 100_000 },
      { ...baseInvoice, id: 'pending', status: 'pending' as const, total: 200_000 },
      { ...baseInvoice, id: 'cancelled', status: 'cancelled' as const, total: 300_000 },
    ];

    expect(invoices.filter(isSalesInvoice).reduce((sum, invoice) => sum + invoice.total, 0)).toBe(100_000);
  });

});
