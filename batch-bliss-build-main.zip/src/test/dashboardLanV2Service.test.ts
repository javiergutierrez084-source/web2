import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { DashboardSnapshot, DashboardSnapshotInput } from '@/lib/DashboardMetricsService';

const mocks = vi.hoisted(() => ({
  mode: 'lan' as 'lan' | 'local',
  remoteMetrics: vi.fn<() => Promise<DashboardSnapshot>>(),
  backupHistory: vi.fn(),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getActiveRepositoryMode: () => mocks.mode,
  getDataRepository: () => ({
    getDashboardMetrics: mocks.remoteMetrics,
  }),
}));

vi.mock('@/lib/BackupManager', () => ({
  BackupManager: {
    listHistory: mocks.backupHistory,
  },
}));

import { DashboardRepositoryService } from '@/lib/DashboardRepositoryService';

const emptyInput: DashboardSnapshotInput = {
  products: [],
  contacts: [],
  invoices: [],
  purchases: [],
  expenses: [],
  layaways: [],
  cashSessions: [],
  accounts: [],
  movements: [],
  financialSummary: null,
  now: new Date('2026-07-20T12:00:00'),
};

const remoteSnapshot: DashboardSnapshot = {
  today: { count: 2, value: 500 },
  month: { count: 8, value: 2400 },
  financialPosition: { mainCash: 1000, layawayReserve: 200, banks: 800, totalAvailable: 1800, mainCashUpdatedAt: '2026-07-21T10:00:00.000Z', mainCashStatus: 'RECONCILED', banksUpdatedAt: '2026-07-21T10:00:00.000Z', totalAvailableUpdatedAt: '2026-07-21T10:00:00.000Z' },
  inventory: { products: 4, activeProducts: 3, saleValue: 8000, totalWeightGrams: 25, totalCost: 4000 },
  layaways: { count: 1, pendingValue: 300, clients: 1 },
  customers: { registered: 6, newThisMonth: 2, active: 3 },
  purchasesMonth: 700,
  salesLast30Days: [],
  topProducts: [],
  recentSales: [],
  alerts: [],
};

beforeEach(() => {
  mocks.mode = 'lan';
  mocks.remoteMetrics.mockReset();
  mocks.remoteMetrics.mockResolvedValue(remoteSnapshot);
  mocks.backupHistory.mockReset();
  mocks.backupHistory.mockResolvedValue([]);
  DashboardRepositoryService.clearBackupStatusCache();
});

describe('Dashboard LAN V2 Repository service', () => {
  it('loads every LAN Dashboard metric through exactly one remote call', async () => {
    const result = await DashboardRepositoryService.getDashboardMetrics();

    expect(result).toEqual(remoteSnapshot);
    expect(mocks.remoteMetrics).toHaveBeenCalledTimes(1);
    expect(mocks.remoteMetrics).toHaveBeenCalledWith();
    expect(mocks.backupHistory).not.toHaveBeenCalled();
  });

  it('builds Desktop and Principal Server metrics from Repository-backed state without remote traffic', async () => {
    mocks.mode = 'local';

    const result = await DashboardRepositoryService.getDashboardMetrics(emptyInput);

    expect(result.today).toEqual({ count: 0, value: 0 });
    expect(result.salesLast30Days).toHaveLength(30);
    expect(mocks.remoteMetrics).not.toHaveBeenCalled();
    expect(mocks.backupHistory).toHaveBeenCalledTimes(1);
  });
});
