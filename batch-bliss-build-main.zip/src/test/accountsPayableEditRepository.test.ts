// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { hashPassword, setSession } from '@/lib/authCore';
import { insertSupplierInvoice, updateSupplierInvoiceSafe } from '@/repositories/dexieDataSource';

const now = '2026-07-27T12:00:00.000Z';

describe('auditoría funcional - persistencia de edición de CxP', () => {
  beforeEach(async () => {
    await localDb.delete();
    await localDb.open();
    await localDb.users.put({
      id: 'audit-user', username: 'audit', display_name: 'Auditor UI',
      password_hash: await hashPassword('audit'), role: 'master', active: true,
      created_at: now, last_login: null,
    });
    setSession({ id: 'audit-user', username: 'audit', displayName: 'Auditor UI', role: 'master' });
  });

  it('persiste todos los campos permitidos y registra PAYABLE_EDITED', async () => {
    const created = await insertSupplierInvoice({
      supplier_id: 'supplier-1', supplier_name: 'Proveedor Uno', invoice_number: 'FAC-001',
      issue_date: '2026-07-01', due_date: '2026-07-31', total: 1_500_000, notes: 'Original',
    });

    await updateSupplierInvoiceSafe(created.id, {
      supplierId: 'supplier-2', supplierName: 'Proveedor Dos', invoiceNumber: 'FAC-002',
      issueDate: '2026-07-02', dueDate: '2026-08-02', total: 1_750_000,
      notes: 'Actualizada', status: 'pending',
    });

    const stored = await localDb.supplier_invoices.get(created.id);
    expect(stored).toMatchObject({
      supplier_id: 'supplier-2', supplier_name: 'Proveedor Dos', invoice_number: 'FAC-002',
      issue_date: '2026-07-02', due_date: '2026-08-02', total: 1_750_000,
      pending_balance: 1_750_000, notes: 'Actualizada', status: 'pending',
    });
    expect(await localDb.activity_log.where('action').equals('PAYABLE_EDITED').count()).toBe(1);
  });
});
