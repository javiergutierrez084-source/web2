import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import type { Layaway } from '@/domain/models';
import { calculateBankDepositsForDate } from '@/lib/DashboardMetricsService';
import { buildFinancialCompositions } from '@/lib/FinancialTraceabilityService';
import {
  buildBankMovementComposition,
  calculateActiveLayawayBankFunds,
} from '@/lib/LayawayBankAccountingService';
import { LAYAWAY_RESERVE_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const date = '2026-08-05';
const bankId = 'bank-1';

const accounts: FinancialAccount[] = [
  { id: bankId, name: 'Banco Principal', kind: 'bank', active: true, balance: 0, createdAt: date, updatedAt: date },
  { id: LAYAWAY_RESERVE_ACCOUNT_ID, name: 'Caja Separados', kind: 'cash', active: true, balance: 0, createdAt: date, updatedAt: date },
];

const movement = (input: Partial<FinancialMovement> & Pick<FinancialMovement, 'id' | 'amount' | 'movementCode'>): FinancialMovement => ({
  id: input.id,
  type: input.type || 'adjustment',
  amount: input.amount,
  originAccountId: input.originAccountId,
  destinationAccountId: input.destinationAccountId,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: input.amount,
  reference: input.reference || input.id,
  documentType: input.documentType || 'layaway',
  documentId: input.documentId || 'layaway-1',
  observation: input.observation || '',
  userId: 'user-1',
  userName: 'Admin',
  date: input.date || date,
  createdAt: input.createdAt || `${input.date || date}T12:00:00.000Z`,
  movementCode: input.movementCode,
  referenceType: input.referenceType || 'LAYAWAY',
  referenceId: input.referenceId || 'layaway-1',
  status: input.status || 'POSTED',
  relatedMovementId: input.relatedMovementId,
});

const layaway = (payments: Array<{ id: string; amount: number }>, completed = false, status: 'pending' | 'paid' | 'cancelled' = 'pending'): Layaway => ({
  id: 'layaway-1',
  invoiceId: 'invoice-1',
  invoice: {
    id: 'invoice-1',
    number: 'SEP-0001',
    date,
    clientId: 'client-1',
    clientName: 'Cliente',
    items: [],
    subtotal: 1_000_000,
    discount: 0,
    tax: 0,
    total: 1_000_000,
    paymentMethod: 'Banco',
    status,
  } as Layaway['invoice'],
  payments: payments.map(payment => ({ ...payment, date, method: 'Banco', accountId: bankId })),
  completed,
  completedDate: completed ? date : undefined,
});

describe('JoyaControl v3.3 - abonos de separados por banco', () => {
  it('mantiene Banco Hoy sin cambios y presenta el abono como fondo informativo', () => {
    const movements = [movement({
      id: 'layaway-payment-300',
      amount: 300_000,
      movementCode: 'LAYAWAY_PAYMENT',
      destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
    })];
    const activeLayaway = layaway([{ id: 'payment-1', amount: 300_000 }]);

    expect(calculateBankDepositsForDate(accounts, movements, date)).toBe(0);
    expect(calculateActiveLayawayBankFunds(accounts, [activeLayaway]).total).toBe(300_000);
    expect(buildFinancialCompositions({ accounts: accounts.map(account => account.id === LAYAWAY_RESERVE_ACCOUNT_ID ? { ...account, balance: 300_000 } : account), movements, contacts: [], invoices: [], purchases: [], expenses: [], layaways: [activeLayaway] }).layawayReserve.total).toBe(300_000);
  });

  it('acumula varios abonos bancarios sin crear ventas', () => {
    const activeLayaway = layaway([
      { id: 'payment-1', amount: 300_000 },
      { id: 'payment-2', amount: 700_000 },
    ]);
    expect(calculateActiveLayawayBankFunds(accounts, [activeLayaway]).total).toBe(1_000_000);
  });

  it('al completar el separado elimina el fondo informativo y no registra un nuevo ingreso bancario', () => {
    const completedLayaway = layaway([
      { id: 'payment-1', amount: 300_000 },
      { id: 'payment-2', amount: 700_000 },
    ], true, 'paid');
    const completion = movement({
      id: 'layaway-completed',
      amount: 1_000_000,
      movementCode: 'LAYAWAY_COMPLETED',
      type: 'transfer',
      originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      destinationAccountId: bankId,
      documentType: 'layaway_completion',
      referenceType: 'SALE',
      referenceId: 'invoice-1',
    });

    expect(calculateActiveLayawayBankFunds(accounts, [completedLayaway]).total).toBe(0);
    expect(calculateBankDepositsForDate(accounts, [completion], date)).toBe(0);
  });

  it('al anular el separado vuelve el fondo informativo a cero', () => {
    const cancelledLayaway = layaway([{ id: 'payment-1', amount: 300_000 }], false, 'cancelled');
    const refund = movement({
      id: 'layaway-refund',
      amount: 300_000,
      movementCode: 'LAYAWAY_REFUND',
      originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      documentType: 'layaway_refund',
    });

    expect(calculateActiveLayawayBankFunds(accounts, [cancelledLayaway]).total).toBe(0);
    expect(calculateBankDepositsForDate(accounts, [refund], date)).toBe(0);
  });

  it('separa ventas bancarias y fondos de separados en la composición', () => {
    const activeLayaway = layaway([{ id: 'payment-1', amount: 300_000 }]);
    const movements = [
      movement({
        id: 'sale-bank-400',
        amount: 400_000,
        movementCode: 'SALE_PAYMENT',
        type: 'sale_income',
        destinationAccountId: bankId,
        documentType: 'invoice',
        documentId: 'invoice-sale',
        referenceType: 'SALE',
        referenceId: 'invoice-sale',
      }),
      movement({
        id: 'layaway-payment-300',
        amount: 300_000,
        movementCode: 'LAYAWAY_PAYMENT',
        destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      }),
    ];

    expect(calculateBankDepositsForDate(accounts, movements, date)).toBe(400_000);
    expect(buildBankMovementComposition({ accounts, movements, layaways: [activeLayaway], dateFrom: date, dateTo: date })).toEqual({
      bankSales: 400_000,
      otherIncome: 0,
      transfers: 0,
      layawayFunds: 300_000,
      totalMovements: 700_000,
    });
  });
});
