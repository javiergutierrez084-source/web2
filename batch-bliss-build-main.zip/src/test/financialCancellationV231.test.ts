import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement, Invoice } from '@/data/mockData';
import {
  buildDashboardSnapshot,
  calculateFinancialSummary,
} from '@/lib/DashboardMetricsService';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const account: FinancialAccount = {
  id: MAIN_CASH_ACCOUNT_ID,
  name: 'Caja Principal',
  kind: 'cash',
  active: true,
  balance: 0,
  createdAt: '2026-07-21T00:00:00.000Z',
  updatedAt: '2026-07-21T00:00:00.000Z',
};

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'sale_income',
  amount: 250,
  destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 250,
  reference: 'FV-1',
  documentType: 'invoice',
  documentId: 'sale-1',
  observation: 'Venta',
  userId: 'user-1',
  userName: 'Usuario',
  date: '2026-07-21',
  createdAt: '2026-07-21T10:00:00.000Z',
  movementCode: 'SALE_PAYMENT',
  status: 'POSTED',
  ...overrides,
});


const paidInvoice: Invoice = {
  id: 'sale-1',
  number: 'FV-1',
  clientId: 'customer-1',
  clientName: 'Cliente',
  items: [],
  subtotal: 250,
  discount: 0,
  tax: 0,
  total: 250,
  date: '2026-07-21',
  status: 'paid',
  tipoDocumento: 'factura',
};

const sale = movement({});
const cancellation = movement({
  id: 'cancel-1',
  type: 'adjustment',
  originAccountId: MAIN_CASH_ACCOUNT_ID,
  destinationAccountId: undefined,
  originBalanceBefore: 250,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'Anulación FV-1',
  documentType: 'invoice_cancellation',
  observation: 'Anulación de venta',
  movementCode: 'SALE_CANCEL',
  relatedMovementId: sale.id,
  status: 'COMPLETED',
});

describe('JOYACONTROL v3.2.1 - cancelación comercial y trazabilidad financiera', () => {
  it('aumenta al crear la venta y disminuye inmediatamente al registrar SALE_CANCEL', () => {
    const before = buildDashboardSnapshot({
      products: [], contacts: [], invoices: [paidInvoice], purchases: [], expenses: [], layaways: [],
      cashSessions: [], accounts: [account], movements: [sale], financialSummary: null,
      backupStatusAvailable: false, now: new Date('2026-07-21T12:00:00'),
    });
    expect(before.today).toEqual({ count: 1, value: 250 });

    const after = buildDashboardSnapshot({
      products: [], contacts: [], invoices: [{ ...paidInvoice, status: 'cancelled' }], purchases: [], expenses: [], layaways: [],
      cashSessions: [], accounts: [account], movements: [sale, cancellation], financialSummary: null,
      backupStatusAvailable: false, now: new Date('2026-07-21T12:00:00'),
    });
    expect(after.today).toEqual({ count: 0, value: 0 });
  });

  it('mantiene el mismo neto en FinancialSummary y no cuenta movimientos revertidos', () => {
    const summary = calculateFinancialSummary({
      accounts: [account], movements: [sale, cancellation], payables: [], expenses: [], invoices: [], products: [],
      today: '2026-07-21',
    });
    expect(summary.incomeToday).toBe(0);

    const reversedCancellation = { ...cancellation, status: 'REVERSED' as const };
    const withoutActiveCancellation = calculateFinancialSummary({
      accounts: [account], movements: [sale, reversedCancellation], payables: [], expenses: [], invoices: [], products: [],
      today: '2026-07-21',
    });
    expect(withoutActiveCancellation.incomeToday).toBe(250);
  });
});
