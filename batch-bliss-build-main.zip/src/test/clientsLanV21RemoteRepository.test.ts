// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import Dexie from 'dexie';
import type { Contact } from '@/data/mockData';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

function privateLanIp(): string {
  for (const addresses of Object.values(os.networkInterfaces())) {
    for (const address of addresses || []) {
      if (address.family !== 'IPv4' || address.internal) continue;
      const parts = address.address.split('.').map(Number);
      if (parts[0] === 10 || (parts[0] === 192 && parts[1] === 168) || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)) {
        return address.address;
      }
    }
  }
  throw new Error('NO_PRIVATE_LAN_IP_FOR_TEST');
}

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function post<T>(baseUrl: string, route: string, body: object): Promise<T> {
  const response = await fetch(`${baseUrl}${route}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
}

const ana: Contact = {
  id: 'client-ana', type: 'client', name: 'Ana Gómez', document: '123',
  phone: '3001112233', email: 'ana@example.com', address: 'Centro', notes: '',
};
const beatriz: Contact = {
  id: 'client-beatriz', type: 'client', name: 'Beatriz López', document: '456',
  phone: '3004445566', email: 'bea@example.com', address: 'Norte', notes: '',
};

afterEach(async () => {
  await stopLanServer();
  localStorage.clear();
  vi.restoreAllMocks();
});

describe('JoyaControl LAN V2.1 Clients Repository transport', () => {
  it('lists, searches, reads, creates, edits and deletes clients through /repository/call without opening Dexie', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-clients-v21-'));
    const port = await freePort();
    const lanIp = privateLanIp();
    const baseUrl = `http://${lanIp}:${port}`;
    let clients = [ana];
    const provider = vi.fn(async (method: string, args: Record<string, unknown>) => {
      switch (method) {
        case 'getSalesClients': return clients;
        case 'searchSalesClients': {
          const text = String(args.text || '').toLowerCase();
          return clients.filter(client => [client.name, client.document, client.phone].join(' ').toLowerCase().includes(text));
        }
        case 'getSalesClientById': return clients.find(client => client.id === String(args.id || '')) || null;
        case 'createSalesClient': {
          const client = args.client as Contact;
          clients = [client, ...clients];
          return client;
        }
        case 'updateSalesClient': {
          const client = args.client as Contact;
          clients = clients.map(current => current.id === client.id ? client : current);
          return client;
        }
        case 'deleteSalesClient':
          clients = clients.filter(client => client.id !== String(args.id || ''));
          return undefined;
        default: throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
      }
    });

    try {
      await startLanServer({
        host: '0.0.0.0', port, serverName: 'Servidor Clientes LAN', userDataPath, version: '2.1',
        executeRepositoryCall: provider,
        authenticateUser: async () => ({
          success: true, userId: 'master-1', username: 'master', displayName: 'Master',
          role: 'master', permissions: ['manage_contacts'],
        }),
      });

      const registered = await post<{ clientId: string; sessionToken: string }>(baseUrl, '/client/register', {
        name: 'Cliente Ventas', hostname: 'cliente-ventas', version: '2.1',
        localTime: new Date().toISOString(), deviceInstanceId: 'clients-device-1',
      });
      const login = await post<{ authToken: string }>(baseUrl, '/login', {
        username: 'master', password: 'secret',
        clientId: registered.clientId, sessionToken: registered.sessionToken,
      });
      saveLanConfig({
        ...createDefaultLanConfig(), mode: 'lan', role: 'client',
        clientServerIp: lanIp, clientServerPort: port,
        clientId: registered.clientId, sessionToken: registered.sessionToken, authToken: login.authToken,
      });

      const dexieOpen = vi.spyOn(Dexie.prototype, 'open');
      const repository = new ApiRepository({ baseUrl });

      expect(await repository.getSalesClients()).toEqual([ana]);
      expect(await repository.searchSalesClients('ana')).toEqual([ana]);
      expect(await repository.getSalesClientById(ana.id)).toEqual(ana);
      expect(await repository.createSalesClient(beatriz)).toEqual(beatriz);
      const edited = { ...beatriz, phone: '3119990000' };
      expect(await repository.updateSalesClient(edited)).toEqual(edited);
      await expect(repository.deleteSalesClient(ana.id)).resolves.toBeUndefined();
      expect(await repository.getSalesClients()).toEqual([edited]);

      expect(provider.mock.calls.map(call => call[0])).toEqual([
        'getSalesClients',
        'searchSalesClients',
        'getSalesClientById',
        'createSalesClient',
        'updateSalesClient',
        'deleteSalesClient',
        'getSalesClients',
      ]);
      expect(dexieOpen).not.toHaveBeenCalled();
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  }, 30_000);
});
