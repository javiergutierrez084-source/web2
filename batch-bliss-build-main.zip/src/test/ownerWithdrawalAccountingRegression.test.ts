import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';
import { buildFinancialCompositions } from '@/lib/FinancialTraceabilityService';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';
import {
  calculateOwnerFinanceDashboard,
  type OwnerWithdrawal,
} from '@/lib/OwnerFinanceService';

const periodDate = '2026-07-15';
const openingTimestamp = '2026-07-01T08:00:00.000Z';
const withdrawalTimestamp = '2026-07-15T10:00:00.000Z';
const cancellationTimestamp = '2026-07-15T11:00:00.000Z';

const account = (balance: number): FinancialAccount => ({
  id: MAIN_CASH_ACCOUNT_ID,
  name: 'Caja Principal',
  kind: 'cash',
  active: true,
  balance,
  createdAt: openingTimestamp,
  updatedAt: cancellationTimestamp,
});

const openingMovement: FinancialMovement = {
  id: 'opening-main-cash',
  type: 'opening_balance',
  amount: 3_600_000,
  destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 3_600_000,
  reference: 'Saldo inicial',
  documentType: 'financial_account',
  documentId: MAIN_CASH_ACCOUNT_ID,
  observation: 'Saldo inicial',
  userId: 'owner-user',
  userName: 'Propietario',
  date: '2026-07-01',
  createdAt: openingTimestamp,
  movementCode: 'OPENING_BALANCE',
  referenceType: 'FINANCIAL_ACCOUNT',
  referenceId: MAIN_CASH_ACCOUNT_ID,
  status: 'POSTED',
};

const withdrawalMovement = (status: FinancialMovement['status'] = 'POSTED'): FinancialMovement => ({
  id: 'owner-withdrawal-movement',
  type: 'adjustment',
  amount: 1_000_000,
  originAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 3_600_000,
  originBalanceAfter: 2_600_000,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'Retiro del propietario',
  documentType: 'owner_withdrawal',
  documentId: 'owner-withdrawal-1',
  observation: 'Retiro',
  userId: 'owner-user',
  userName: 'Propietario',
  date: periodDate,
  createdAt: withdrawalTimestamp,
  movementCode: 'CASH_OUT',
  referenceType: 'MANUAL',
  referenceId: 'owner-concept-owner-withdrawal',
  status,
});

const reversalMovement: FinancialMovement = {
  id: 'owner-withdrawal-reversal',
  type: 'adjustment',
  amount: 1_000_000,
  destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 2_600_000,
  destinationBalanceAfter: 3_600_000,
  reference: 'Retiro del propietario',
  documentType: 'owner_withdrawal_cancellation',
  documentId: 'owner-withdrawal-1',
  observation: 'Anulación',
  userId: 'owner-user',
  userName: 'Propietario',
  date: periodDate,
  createdAt: cancellationTimestamp,
  movementCode: 'REVERSAL',
  relatedMovementId: 'owner-withdrawal-movement',
  referenceType: 'MANUAL',
  referenceId: 'owner-concept-owner-withdrawal',
  status: 'POSTED',
};

const activeWithdrawal: OwnerWithdrawal = {
  id: 'owner-withdrawal-1',
  withdrawalDate: withdrawalTimestamp,
  periodKey: '2026-07',
  userId: 'owner-user',
  userName: 'Propietario',
  conceptId: 'owner-concept-owner-withdrawal',
  conceptName: 'Retiro del propietario',
  amount: 1_000_000,
  observations: '',
  accountId: MAIN_CASH_ACCOUNT_ID,
  accountName: 'Caja Principal',
  paymentMethod: 'EFECTIVO',
  status: 'ACTIVE',
  financialMovementId: 'owner-withdrawal-movement',
  createdAt: withdrawalTimestamp,
};

const annulledWithdrawal: OwnerWithdrawal = {
  ...activeWithdrawal,
  status: 'ANULADO',
  cancelledAt: cancellationTimestamp,
  cancelledBy: 'Propietario',
  cancellationReason: 'Corrección',
  reversalMovementId: 'owner-withdrawal-reversal',
};

const ownerDashboard = (withdrawals: OwnerWithdrawal[]) => calculateOwnerFinanceDashboard({
  periodKey: '2026-07',
  projectedWithdrawalPercentage: 30,
  monthlyProfitGoal: 5_000_000,
  invoices: [{
    id: 'invoice-profit',
    date: periodDate,
    status: 'paid',
    total: 3_600_000,
    totalCost: 0,
  }],
  expenses: [],
  withdrawals,
});

const commercialSnapshot = (movements: FinancialMovement[], balance: number) => buildDashboardSnapshot({
  products: [],
  contacts: [],
  invoices: [{
    id: 'invoice-1', number: 'FV-1', clientId: 'customer-1', clientName: 'Cliente',
    items: [], subtotal: 500_000, discount: 0, tax: 0, total: 500_000,
    date: periodDate, status: 'paid', tipoDocumento: 'factura',
  }],
  purchases: [],
  expenses: [],
  layaways: [],
  cashSessions: [],
  accounts: [account(balance)],
  movements: [
    {
      id: 'sale-payment',
      type: 'sale_income',
      amount: 500_000,
      destinationAccountId: MAIN_CASH_ACCOUNT_ID,
      originBalanceBefore: 0,
      originBalanceAfter: 0,
      destinationBalanceBefore: 3_100_000,
      destinationBalanceAfter: 3_600_000,
      reference: 'FV-1',
      documentType: 'invoice',
      documentId: 'invoice-1',
      observation: '',
      userId: 'seller',
      userName: 'Vendedor',
      date: periodDate,
      createdAt: `${periodDate}T09:00:00.000Z`,
      movementCode: 'SALE_PAYMENT',
      referenceType: 'SALE',
      referenceId: 'invoice-1',
      status: 'POSTED',
    },
    ...movements,
  ],
  financialSummary: null,
  backupStatusAvailable: false,
  now: new Date(`${periodDate}T12:00:00.000Z`),
});

describe('Finanzas del Propietario - regresión contable de retiros', () => {
  it('resta el retiro una sola vez de utilidad mensual y lo restaura al anular', () => {
    expect(ownerDashboard([])).toMatchObject({
      profitMonth: 3_600_000,
      withdrawnProfit: 0,
      availableBalance: 3_600_000,
    });
    expect(ownerDashboard([activeWithdrawal])).toMatchObject({
      profitMonth: 2_600_000,
      availableProfit: 2_600_000,
      withdrawnProfit: 1_000_000,
      availableBalance: 2_600_000,
    });
    expect(ownerDashboard([annulledWithdrawal])).toMatchObject({
      profitMonth: 3_600_000,
      availableProfit: 3_600_000,
      withdrawnProfit: 0,
      availableBalance: 3_600_000,
    });
  });

  it('sincroniza Caja Principal y Total Disponible al crear y anular', () => {
    const afterWithdrawal = buildFinancialCompositions({
      accounts: [account(2_600_000)],
      movements: [openingMovement, withdrawalMovement()],
    });
    expect(afterWithdrawal.mainCash.total).toBe(2_600_000);
    expect(afterWithdrawal.totalAvailable.total).toBe(2_600_000);

    const afterCancellation = buildFinancialCompositions({
      accounts: [account(3_600_000)],
      movements: [openingMovement, withdrawalMovement(), reversalMovement],
    });
    expect(afterCancellation.mainCash.total).toBe(3_600_000);
    expect(afterCancellation.totalAvailable.total).toBe(3_600_000);
  });

  it('mantiene correctas instalaciones antiguas que marcaron el original REVERSED', () => {
    const legacy = buildFinancialCompositions({
      accounts: [account(3_600_000)],
      movements: [openingMovement, withdrawalMovement('REVERSED'), reversalMovement],
    });
    expect(legacy.mainCash.total).toBe(3_600_000);
    expect(legacy.totalAvailable.total).toBe(3_600_000);
  });

  it('no altera Ventas de hoy ni la cantidad de facturas comerciales', () => {
    const before = commercialSnapshot([], 3_600_000);
    const afterWithdrawal = commercialSnapshot([withdrawalMovement()], 2_600_000);
    const afterCancellation = commercialSnapshot([withdrawalMovement(), reversalMovement], 3_600_000);

    expect(before.today).toEqual({ count: 1, value: 500_000 });
    expect(afterWithdrawal.today).toEqual(before.today);
    expect(afterCancellation.today).toEqual(before.today);
  });
});
