// @vitest-environment jsdom
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import Dexie from 'dexie';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

const AUTHORIZED_SESSION_ARGUMENT = '__joyaControlAuthorizedLanSession';

const FULL_OPERATIONAL_PERMISSIONS = [
  'view_reports', 'view_purchases', 'manage_inventory', 'manage_products',
  'manage_contacts', 'manage_settings', 'create_sales', 'edit_sales',
  'cancel_invoices', 'manage_purchases', 'manage_quotations',
  'manage_layaways', 'manage_cash', 'manage_expenses', 'manage_finances',
  'manage_accounts_payable', 'view_accounts_payable', 'view_activity_log',
  'write_activity_log', 'system_maintenance',
];

const product = {
  id: 'product-1', code: 'JOY-001', name: 'Anillo', category: 'Anillos',
  purchasePrice: 50, salePrice: 90, weightGrams: 3, margin: 80,
  stock: 4, minStock: 1, description: '', supplierIds: ['supplier-1'],
};
const editedProduct = { ...product, name: 'Anillo editado', salePrice: 95, stock: 6 };
const category = { id: 'category-1', name: 'Anillos', name_key: 'anillos', created_at: '2026-07-24T00:00:00.000Z', auto_created: false };
const supplier = { id: 'supplier-1', type: 'supplier', name: 'Proveedor Uno', document: '9001', phone: '', email: '', address: '', notes: '' };
const client = { id: 'client-1', type: 'client', name: 'Cliente Uno', document: '1001', phone: '', email: '', address: '', notes: '' };
const purchase = { id: 'purchase-1', number: 'COMP-1', supplierId: supplier.id, supplierName: supplier.name, date: '2026-07-24', status: 'pending', items: [], total: 100 };
const invoice = { id: 'invoice-1', number: 'FAC-1', clientId: client.id, clientName: client.name, date: '2026-07-24', status: 'paid', items: [], subtotal: 100, tax: 0, discount: 0, total: 100, paymentMethod: 'cash' };
const expense = { id: 'expense-1', number: 'GAS-1', date: '2026-07-24', concept: 'Transporte', total: 10, paymentMethod: 'cash' };
const cashSession = { id: 'cash-1', openedAt: '2026-07-24T08:00:00.000Z', openedBy: 'Master', initialAmount: 100 };
const adjustmentInput = { productId: product.id, type: 'positive', quantity: 2, reason: 'Conteo', date: '2026-07-24' };
const adjustmentResult = { adjustment: { id: 'adj-1', ...adjustmentInput }, product: editedProduct };
const ownerFinanceSettings = {
  projectedWithdrawalPercentage: 30,
  monthlyProfitGoal: 10_000,
  financialPeriod: 'MONTHLY' as const,
};
const ownerFinanceConcept = {
  id: 'owner-concept-owner-withdrawal',
  name: 'Retiro del propietario',
  nameKey: 'retiro del propietario',
  active: true,
  isDefault: true,
  createdAt: '2026-07-24T00:00:00.000Z',
  updatedAt: '2026-07-24T00:00:00.000Z',
};
const ownerWithdrawal = {
  id: 'owner-withdrawal-1',
  withdrawalDate: '2026-07-24T12:00:00.000Z',
  userId: 'user-1',
  userName: 'Master',
  conceptId: ownerFinanceConcept.id,
  conceptName: ownerFinanceConcept.name,
  amount: 100,
  observations: 'QA',
  accountId: 'account-1',
  accountName: 'Caja principal',
  paymentMethod: 'EFECTIVO',
  status: 'ACTIVE' as const,
  financialMovementId: 'movement-1',
  createdAt: '2026-07-24T12:00:00.000Z',
};
const ownerFinanceWorkspace = {
  dashboard: {
    monthlyProfitGoal: 10_000,
    profitMonth: 1_000,
    availableProfit: 1_000,
    withdrawnProfit: 100,
    availableBalance: 900,
    projectedWithdrawalPercentage: 30,
    suggestedWithdrawalValue: 270,
    monthlyGoalProgressPercentage: 10,
    monthlyGoalProgressBarPercentage: 10,
    monthlyGoalReachedValue: 1_000,
    monthlyGoalRemainingValue: 9_000,
    monthlyGoalReached: false,
    exceedsAvailable: false,
  },
  withdrawals: [ownerWithdrawal],
  concepts: [ownerFinanceConcept],
  settings: ownerFinanceSettings,
  accounts: [{ id: 'account-1', name: 'Caja principal', balance: 900 }],
  users: [{ id: 'user-1', displayName: 'Master' }],
  paymentMethods: ['EFECTIVO'],
};

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_FREE_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function post<T>(url: string, body: Record<string, unknown>): Promise<{ response: Response; payload: T & { error?: string } }> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return { response, payload: await response.json() as T & { error?: string } };
}

async function configureAuthenticatedClient(baseUrl: string, port: number) {
  const registration = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
    deviceInstanceId: crypto.randomUUID(),
    name: 'Cliente LAN QA',
    hostname: 'cliente-lan-qa',
    version: '2.1',
    localTime: new Date().toISOString(),
  });
  const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
    username: 'master', password: 'ok', ...registration.payload,
  });
  saveLanConfig({
    ...createDefaultLanConfig(),
    mode: 'lan', role: 'client',
    clientServerIp: '127.0.0.1', clientServerPort: port,
    clientId: registration.payload.clientId,
    sessionToken: registration.payload.sessionToken,
    authToken: login.payload.authToken,
  });
  return { ...registration.payload, authToken: login.payload.authToken };
}

function providerResult(method: string) {
  switch (method) {
    case 'getProducts': return { items: [editedProduct], total: 1, page: 1, pageSize: 1 };
    case 'getCategories': return { items: [category], total: 1, page: 1, pageSize: 1 };
    case 'fetchContacts': return [supplier, client];
    case 'fetchPurchaseInvoices': return [purchase];
    case 'fetchExpenses': return [expense];
    case 'fetchInventoryAdjustments': return [adjustmentResult.adjustment];
    case 'applyInventoryAdjustment': return adjustmentResult;
    case 'getSalesWorkspace': return {
      company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
      contacts: [client], invoices: [invoice], layaways: [], quotations: [],
      financialAccounts: [], financialMovements: [], financialSummary: null,
    };
    case 'querySales': return [invoice];
    case 'createSale': return [editedProduct];
    case 'cancelSale': return {
      invoiceId: invoice.id, cancelledAt: '2026-07-24T10:00:00.000Z', cancelledBy: 'Master', restoredProducts: [editedProduct],
    };
    case 'createSalesLayaway': return { id: 'layaway-1', invoice };
    case 'updateSalesLayaway': return { layaway: { id: 'layaway-1', invoice }, updatedProducts: [] };
    case 'addSalesLayawayPayment': return { payment: { id: 'pay-1', amount: 20, date: '2026-07-24', method: 'cash' }, invoiceId: invoice.id, completed: false };
    case 'completeSalesLayaway': return invoice.id;
    case 'deleteSalesLayaway': return { invoiceId: invoice.id, restoredProducts: [editedProduct], resolution: 'refund', refundAmount: 20 };
    case 'fetchCashSessions': return [cashSession];
    case 'fetchSupplierPaymentsForReports': return [];
    case 'fetchFinancialSummary': return { totalCash: 100, totalBank: 0, totalAssets: 100 };
    case 'fetchOwnerFinanceWorkspace': return ownerFinanceWorkspace;
    case 'createOwnerWithdrawal': return ownerWithdrawal;
    case 'cancelOwnerWithdrawal': return { ...ownerWithdrawal, status: 'ANULADO' };
    case 'createOwnerWithdrawalConcept': return ownerFinanceConcept;
    case 'updateOwnerWithdrawalConcept': return { ...ownerFinanceConcept, name: 'Retiro editado' };
    case 'saveOwnerFinanceSettings': return ownerFinanceSettings;
    case 'fetchActivityLog': return [];
    case 'findCategoryByKey': return category;
    default: return undefined;
  }
}

afterEach(async () => {
  await stopLanServer();
  localStorage.clear();
  vi.restoreAllMocks();
});

describe('LAN 2.5 - autorización completa del Repository principal', () => {
  it('habilita las operaciones diarias y todas viajan únicamente por POST /repository/call', async () => {
    const port = await freePort();
    const baseUrl = `http://127.0.0.1:${port}`;
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-full-'));
    const provider = vi.fn(async (method: string, _args: Record<string, unknown>) => providerResult(method));

    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor Principal', userDataPath, version: '2.1',
      authenticateUser: async () => ({
        success: true, userId: 'user-1', username: 'master', displayName: 'Master', role: 'master',
        permissions: FULL_OPERATIONAL_PERMISSIONS,
      }),
      executeRepositoryCall: provider,
    });
    await configureAuthenticatedClient(baseUrl, port);

    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    const dexieOpen = vi.spyOn(Dexie.prototype, 'open');
    const repository = new ApiRepository({ baseUrl });

    // Productos y categorías: crear, editar y eliminar.
    await repository.upsertProduct(product as never);
    await repository.upsertProduct({ ...product, id: 'product-large', description: 'x'.repeat(64 * 1024) } as never);
    await repository.applyProductChanges({ upserts: [editedProduct], deleteIds: [] } as never);
    await repository.deleteProduct(product.id);
    await repository.putCategory(category as never);
    await repository.putCategory({ ...category, name: 'Anillos finos', name_key: 'anillos finos' } as never);
    await repository.deleteCategory(category.id);

    // Proveedores y clientes: crear, editar y eliminar.
    await repository.upsertContact(supplier as never);
    await repository.upsertContact({ ...supplier, phone: '3000000000' } as never);
    await repository.deleteContact(supplier.id);
    await repository.upsertContact(client as never);
    await repository.applyContactChanges({ upserts: [{ ...client, phone: '3100000000' }], deleteIds: [] } as never);
    await repository.deleteContact(client.id);

    // Compras y actualización atómica de existencias.
    await repository.createPurchaseWithInventory(purchase as never, 'account-1');
    await repository.updatePurchaseWithInventory({ ...purchase, total: 120 } as never);
    await repository.markPurchaseAsPaid(purchase.id, 'account-1');
    await repository.deletePurchaseWithInventory(purchase.id);

    // Inventario, conteos, ajustes y consulta del Kardex.
    await repository.applyInventoryAdjustment(adjustmentInput as never);
    await repository.fetchInventoryAdjustments();

    // Venta, actualización, anulación y reversión completa usada por devolución.
    await repository.insertInvoiceWithFinancials(invoice as never, [], {});
    await repository.updateInvoiceStatus(invoice.id, 'paid');
    await repository.cancelInvoice(invoice.id, 'Anulación QA');
    await repository.insertInvoiceWithFinancials({ ...invoice, id: 'invoice-return' } as never, [], {});
    await repository.cancelInvoice('invoice-return', 'Devolución total QA');

    // Separados: reservar, editar, abonar, convertir y liberar con devolución.
    await repository.insertLayaway({ id: 'layaway-1', invoice } as never);
    await repository.updateLayaway('layaway-1', invoice as never);
    await repository.addLayawayPayment('layaway-1', { amount: 20, date: '2026-07-24', method: 'cash', accountId: 'account-1' });
    await repository.completeLayawayDb('layaway-1', '2026-07-24');
    await repository.deleteSalesLayaway('layaway-1', 'refund');

    // Caja, ingreso por venta y egreso.
    await repository.insertCashSession(cashSession as never);
    await repository.closeCashSession(cashSession.id, '2026-07-24T18:00:00.000Z', 'Master', 'Cierre QA');
    await repository.insertExpenseWithFinancials(expense as never, 'account-1');

    // Reportes y configuración permitida por rol.
    await repository.querySales({ text: 'FAC', status: 'paid' } as never);
    await repository.fetchSupplierPaymentsForReports();
    await repository.fetchFinancialSummary();
    await repository.fetchOwnerFinanceWorkspace();
    await repository.createOwnerWithdrawal({
      withdrawalDate: ownerWithdrawal.withdrawalDate,
      conceptId: ownerFinanceConcept.id,
      amount: ownerWithdrawal.amount,
      observations: ownerWithdrawal.observations,
      accountId: ownerWithdrawal.accountId,
      paymentMethod: ownerWithdrawal.paymentMethod,
    });
    await repository.cancelOwnerWithdrawal(ownerWithdrawal.id, 'Anulación QA');
    await repository.createOwnerWithdrawalConcept('Concepto QA');
    await repository.updateOwnerWithdrawalConcept(ownerFinanceConcept.id, { name: 'Retiro editado' });
    await repository.saveOwnerFinanceSettings(ownerFinanceSettings);
    await repository.fetchActivityLog(100);
    await repository.saveCompany({ name: 'JoyaControl', nit: '123', phone: '', city: '', address: '', email: '', logoUrl: '' });

    const operationalRequests = fetchSpy.mock.calls.map(([input, init]) => ({
      url: new URL(typeof input === 'string' ? input : input instanceof URL ? input.toString() : input.url),
      method: String(init?.method || 'GET').toUpperCase(),
      body: typeof init?.body === 'string' ? JSON.parse(init.body) as Record<string, unknown> : {},
    }));
    expect(operationalRequests.length).toBeGreaterThan(25);
    expect(operationalRequests.every(request => request.url.pathname === '/repository/call')).toBe(true);
    expect(operationalRequests.every(request => request.method === 'POST')).toBe(true);
    expect(operationalRequests.every(request => request.body.clientId && request.body.sessionToken && request.body.authToken)).toBe(true);
    expect(dexieOpen).not.toHaveBeenCalled();

    const methods = provider.mock.calls.map(call => call[0]);
    expect(methods).toEqual(expect.arrayContaining([
      'upsertProduct', 'applyProductChanges', 'deleteProduct', 'putCategory', 'deleteCategory',
      'upsertContact', 'applyContactChanges', 'deleteContact',
      'createPurchaseWithInventory', 'updatePurchaseWithInventory', 'markPurchaseAsPaid', 'deletePurchaseWithInventory',
      'applyInventoryAdjustment', 'fetchInventoryAdjustments',
      'createSale', 'updateSaleStatus', 'cancelSale',
      'createSalesLayaway', 'updateSalesLayaway', 'addSalesLayawayPayment', 'completeSalesLayaway', 'deleteSalesLayaway',
      'insertCashSession', 'closeCashSession', 'insertExpenseWithFinancials',
      'querySales', 'fetchSupplierPaymentsForReports', 'fetchFinancialSummary',
      'fetchOwnerFinanceWorkspace', 'createOwnerWithdrawal', 'cancelOwnerWithdrawal',
      'createOwnerWithdrawalConcept', 'updateOwnerWithdrawalConcept', 'saveOwnerFinanceSettings',
      'fetchActivityLog', 'saveCompany',
    ]));

    const context = (provider.mock.calls[0][1] as {
      __joyaControlAuthorizedLanSession?: { id?: string; permissions?: string[] };
    }).__joyaControlAuthorizedLanSession;
    expect(context?.id).toBe('user-1');
    expect(context?.permissions).toContain('manage_products');
    const largeProductCall = provider.mock.calls.find(call => (
      call[0] === 'upsertProduct'
      && (call[1] as { product?: { id?: string } }).product?.id === 'product-large'
    ));
    expect((largeProductCall?.[1] as { product?: { description?: string } }).product?.description).toHaveLength(64 * 1024);
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  it('rechaza permisos insuficientes aunque el rol sea master y no ejecuta Repository', async () => {
    const port = await freePort();
    const baseUrl = `http://127.0.0.1:${port}`;
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-permission-'));
    const provider = vi.fn();
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor Principal', userDataPath, version: '2.1',
      authenticateUser: async () => ({
        success: true, userId: 'limited-1', username: 'limited', displayName: 'Limitado', role: 'master',
        permissions: ['create_sales'],
      }),
      executeRepositoryCall: provider,
    });
    const credentials = await configureAuthenticatedClient(baseUrl, port);
    const { response, payload } = await post(`${baseUrl}/repository/call`, {
      method: 'upsertProduct', args: { product }, ...credentials,
    });
    expect(response.status).toBe(403);
    expect(payload.error).toBe('LAN_PERMISSION_DENIED');
    expect(provider).not.toHaveBeenCalled();
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  it('rechaza usuarios sin sesión antes de permisos y antes de Repository', async () => {
    const port = await freePort();
    const baseUrl = `http://127.0.0.1:${port}`;
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-unauthorized-'));
    const provider = vi.fn();
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor Principal', userDataPath, version: '2.1',
      executeRepositoryCall: provider,
    });
    const { response, payload } = await post(`${baseUrl}/repository/call`, {
      method: 'getProducts', args: {},
    });
    expect(response.status).toBe(401);
    expect(payload.error).toBe('LAN_SESSION_TOKEN_REQUIRED');
    expect(provider).not.toHaveBeenCalled();
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  it('mantiene sincronizados los 78 métodos y un único transporte operativo', () => {
    const contractSource = fs.readFileSync(path.resolve(process.cwd(), 'src/lib/LanRepositoryContract.ts'), 'utf8');
    const serverSource = fs.readFileSync(path.resolve(process.cwd(), 'electron/lanServer.js'), 'utf8');
    const bridgeSource = fs.readFileSync(path.resolve(process.cwd(), 'src/components/LanAuthenticationBridge.tsx'), 'utf8');
    const apiSource = fs.readFileSync(path.resolve(process.cwd(), 'src/repositories/ApiRepository.ts'), 'utf8');

    const contractBlock = contractSource
      .split('export interface LanRepositoryArgs {', 2)[1]
      .split('\n}\n\nexport type LanRepositoryMethod', 1)[0];
    const serverBlock = serverSource
      .split('const REPOSITORY_METHOD_PERMISSIONS = Object.freeze({', 2)[1]
      .split('\n});\n\nfunction repositoryMethodAllowed', 1)[0];

    const contractMethods = [...contractBlock.matchAll(/^  ([A-Za-z_$][\w$]*):/gm)].map(match => match[1]).sort();
    const serverMethods = [...serverBlock.matchAll(/^  ([A-Za-z_$][\w$]*):/gm)].map(match => match[1]).sort();
    const bridgeMethods = [...bridgeSource.matchAll(/case '([^']+)'/g)].map(match => match[1]).sort();

    expect(contractMethods).toHaveLength(78);
    expect(serverMethods).toEqual(contractMethods);
    expect(bridgeMethods).toEqual(contractMethods);
    expect(contractMethods.every(method => apiSource.includes(`'${method}'`))).toBe(true);
    expect(apiSource.match(/new URL\('repository\/call'/g) || []).toHaveLength(1);
    expect(apiSource).not.toMatch(/from ['"]dexie['"]|localDb|dexieDataSource/);
  });

  it('sobrescribe cualquier contexto LAN falsificado y rechaza métodos fuera del contrato', async () => {
    const port = await freePort();
    const baseUrl = `http://127.0.0.1:${port}`;
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-context-'));
    const provider = vi.fn(async (_method: string, args: Record<string, unknown>) => args[AUTHORIZED_SESSION_ARGUMENT]);
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor Principal', userDataPath, version: '2.1',
      authenticateUser: async () => ({
        success: true, userId: 'server-user', username: 'server-user', displayName: 'Usuario autorizado', role: 'admin',
        permissions: FULL_OPERATIONAL_PERMISSIONS,
      }),
      executeRepositoryCall: provider,
    });
    const credentials = await configureAuthenticatedClient(baseUrl, port);

    const authorized = await post<{ data: { id: string; username: string; permissions: string[] } }>(`${baseUrl}/repository/call`, {
      method: 'getProducts',
      args: {
        [AUTHORIZED_SESSION_ARGUMENT]: {
          id: 'attacker', username: 'attacker', displayName: 'Atacante', role: 'master', permissions: ['manage_users'],
        },
      },
      ...credentials,
    });
    expect(authorized.response.status).toBe(200);
    const authoritativeContext = authorized.payload.data;
    expect(authoritativeContext.id).toBe('server-user');
    expect(authoritativeContext.username).toBe('server-user');
    expect(authoritativeContext.permissions).toContain('manage_products');
    expect(authoritativeContext.permissions).not.toContain('manage_users');

    const unknown = await post(`${baseUrl}/repository/call`, {
      method: 'repositoryMethodThatDoesNotExist', args: {}, ...credentials,
    });
    expect(unknown.response.status).toBe(403);
    expect(unknown.payload.error).toBe('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
    expect(provider).toHaveBeenCalledTimes(1);
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  it('valida clientId y authToken antes de ejecutar Repository', async () => {
    const port = await freePort();
    const baseUrl = `http://127.0.0.1:${port}`;
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-tokens-'));
    const provider = vi.fn();
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor Principal', userDataPath, version: '2.1',
      authenticateUser: async () => ({
        success: true, userId: 'user-1', username: 'master', displayName: 'Master', role: 'master',
        permissions: FULL_OPERATIONAL_PERMISSIONS,
      }),
      executeRepositoryCall: provider,
    });
    const credentials = await configureAuthenticatedClient(baseUrl, port);

    const missingClient = await post(`${baseUrl}/repository/call`, {
      method: 'getProducts', args: {}, sessionToken: credentials.sessionToken,
    });
    expect(missingClient.response.status).toBe(401);
    expect(missingClient.payload.error).toBe('LAN_CLIENT_ID_REQUIRED');

    const missingAuth = await post(`${baseUrl}/repository/call`, {
      method: 'getProducts', args: {},
      sessionToken: credentials.sessionToken, clientId: credentials.clientId,
    });
    expect(missingAuth.response.status).toBe(401);
    expect(missingAuth.payload.error).toBe('LAN_AUTH_TOKEN_REQUIRED');

    const invalidAuth = await post(`${baseUrl}/repository/call`, {
      method: 'getProducts', args: {}, ...credentials, authToken: 'invalid-token',
    });
    expect(invalidAuth.response.status).toBe(401);
    expect(invalidAuth.payload.error).toBeTruthy();
    expect(provider).not.toHaveBeenCalled();
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });
});
