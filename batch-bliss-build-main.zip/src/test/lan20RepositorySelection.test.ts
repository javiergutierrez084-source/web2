// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';
import { DexieRepository } from '@/repositories/DexieRepository';
import { clearRepositoryRuntimeConfig, getRepositoryConfig } from '@/repositories/RepositoryConfig';
import { getActiveRepositoryMode, getDataRepository, resetDataRepository } from '@/repositories/RepositoryRegistry';
import { createDefaultLanConfig, loadLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';

const saveMode = (mode: 'local' | 'lan', role: 'server' | 'client') => {
  saveLanConfig({
    ...createDefaultLanConfig(),
    mode,
    role,
    clientServerIp: '192.168.1.50',
    clientServerPort: 47831,
    clientId: role === 'client' ? 'client-1' : null,
    sessionToken: role === 'client' ? 'device-token' : null,
  });
  clearRepositoryRuntimeConfig();
  resetDataRepository();
};

describe('LAN 2.0 repository selection and remote login', () => {
  beforeEach(() => {
    localStorage.clear();
    sessionStorage.clear();
    vi.restoreAllMocks();
    clearRepositoryRuntimeConfig();
    resetDataRepository();
  });

  it('uses DexieRepository in Local mode and on the Principal Server', () => {
    saveMode('local', 'client');
    expect(getDataRepository()).toBeInstanceOf(DexieRepository);
    expect(getActiveRepositoryMode()).toBe('local');

    saveMode('lan', 'server');
    expect(getDataRepository()).toBeInstanceOf(DexieRepository);
    expect(getActiveRepositoryMode()).toBe('local');
  });

  it('selects ApiRepository automatically only for a LAN client', () => {
    saveMode('lan', 'client');
    expect(getRepositoryConfig()).toMatchObject({
      mode: 'lan',
      apiBaseUrl: 'http://192.168.1.50:47831',
    });
    expect(getDataRepository()).toBeInstanceOf(ApiRepository);
    expect(getActiveRepositoryMode()).toBe('lan');
  });

  it('ApiRepository.loginUser calls POST /login and persists only authToken', async () => {
    saveMode('lan', 'client');
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({
      success: true,
      userId: 'user-1',
      username: 'maestro',
      displayName: 'Usuario Maestro',
      role: 'master',
      permissions: ['manage_settings'],
      authToken: 'user-auth-token',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } }));

    const session = await getDataRepository().loginUser('maestro', 'secreto');

    expect(session).toEqual({
      id: 'user-1',
      username: 'maestro',
      displayName: 'Usuario Maestro',
      role: 'master',
    });
    expect(fetchMock).toHaveBeenCalledTimes(1);
    const [url, request] = fetchMock.mock.calls[0];
    expect(url).toBe('http://192.168.1.50:47831/login');
    expect(request?.method).toBe('POST');
    expect(JSON.parse(String(request?.body))).toEqual({
      username: 'maestro',
      password: 'secreto',
      clientId: 'client-1',
      sessionToken: 'device-token',
    });
    expect(loadLanConfig().authToken).toBe('user-auth-token');
    expect(localStorage.getItem('joyacontrol_repository_mode')).toBeNull();
  });

  it('does not call Dexie authentication when operating as LAN client', async () => {
    saveMode('lan', 'client');
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({
      success: false,
      error: 'INVALID_CREDENTIALS',
    }), { status: 401, headers: { 'Content-Type': 'application/json' } }));

    await expect(getDataRepository().loginUser('usuario', 'incorrecta')).rejects.toThrow('INVALID_CREDENTIALS');
    expect(getDataRepository()).toBeInstanceOf(ApiRepository);
  });

  it('changes repository automatically when LAN configuration changes', () => {
    saveMode('local', 'client');
    const localRepository = getDataRepository();
    expect(localRepository).toBeInstanceOf(DexieRepository);

    const config = loadLanConfig();
    saveLanConfig({ ...config, mode: 'lan', role: 'client', clientId: 'client-1', sessionToken: 'device-token' });
    const lanRepository = getDataRepository();
    expect(lanRepository).toBeInstanceOf(ApiRepository);
    expect(lanRepository).not.toBe(localRepository);
  });
});
