// @vitest-environment jsdom
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { DashboardSnapshot } from '@/lib/DashboardMetricsService';

const mocks = vi.hoisted(() => ({
  getDashboardMetrics: vi.fn<() => Promise<DashboardSnapshot>>(),
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    products: [], contacts: [], invoices: [], purchaseInvoices: [], expenses: [], layaways: [],
    cashSessions: [], financialAccounts: [], financialMovements: [], financialSummary: null, isLoading: false,
  }),
}));
vi.mock('@/contexts/AuthContext', () => ({ useAuth: () => ({ user: { role: 'master', displayName: 'Admin' } }) }));
vi.mock('@/repositories/RepositoryRegistry', () => ({ getActiveRepositoryMode: () => 'lan' }));
vi.mock('@/lib/DashboardRepositoryService', () => ({ DashboardRepositoryService: { getDashboardMetrics: mocks.getDashboardMetrics } }));

import Dashboard from '@/pages/Dashboard';

class ResizeObserverMock {
  observe() {}
  unobserve() {}
  disconnect() {}
}
vi.stubGlobal('ResizeObserver', ResizeObserverMock);


const snapshot: DashboardSnapshot = {
  today: { count: 1, value: 800 }, month: { count: 2, value: 1200 },
  financialPosition: {
    mainCash: 500, layawayReserve: 100, banks: 700, banksToday: 250, totalAvailable: 1200,
    mainCashUpdatedAt: '2026-07-21T10:00:00.000Z', mainCashStatus: 'RECONCILED',
    banksUpdatedAt: '2026-07-21T11:00:00.000Z', totalAvailableUpdatedAt: '2026-07-21T11:00:00.000Z',
  },
  inventory: { products: 0, activeProducts: 0, saleValue: 0, totalWeightGrams: 0, totalCost: 0 },
  layaways: { count: 0, pendingValue: 0, clients: 0 }, customers: { registered: 0, newThisMonth: 0, active: 0 },
  purchasesMonth: 0, salesLast30Days: [], topProducts: [], recentSales: [], alerts: [],
};

beforeEach(() => {
  mocks.getDashboardMetrics.mockReset();
  mocks.getDashboardMetrics.mockResolvedValue(snapshot);
});

describe('JOYACONTROL LAN V2.3.2 - Dashboard trazable', () => {
  it('elimina Ingresos Hoy/Egresos Hoy y enlaza la composición financiera', async () => {
    render(<MemoryRouter><Dashboard /></MemoryRouter>);
    await waitFor(() => expect(screen.getAllByText('Caja Principal').length).toBeGreaterThan(0));
    expect(screen.queryByText(/Ingresos hoy/i)).toBeNull();
    expect(screen.queryByText(/Egresos hoy/i)).toBeNull();
    expect(screen.getByText('Conciliado con Ledger')).not.toBeNull();
    expect(screen.getByText('Bancos Hoy')).not.toBeNull();
    expect(screen.getByLabelText('Bancos Hoy. Valor consignado a cuentas bancarias durante el día actual.')).not.toBeNull();
    expect(screen.getByText('Saldo acumulado')).not.toBeNull();
    const links = screen.getAllByRole('link', { name: /Ver composición/i });
    expect(links.some(link => link.getAttribute('href') === '/reportes?tab=traceability&composition=mainCash')).toBe(true);
    expect(links.some(link => link.getAttribute('href') === '/reportes?tab=traceability&composition=banks')).toBe(true);
  });
});
