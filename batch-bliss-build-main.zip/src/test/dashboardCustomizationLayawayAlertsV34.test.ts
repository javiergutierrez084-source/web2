import { beforeEach, describe, expect, it } from 'vitest';
import type { Layaway } from '@/domain/models';
import {
  createDefaultDashboardPreferences,
  loadDashboardPreferences,
  saveDashboardPreferences,
} from '@/lib/DashboardPreferencesService';
import {
  buildLayawayAlertSummary,
  calculateLayawayAlertInfo,
  ensureLayawayDeadlines,
  loadLayawayDeadlineRegistry,
  saveLayawayAlertSettings,
} from '@/lib/LayawayAlertService';

const createLayaway = (id: string, date: string, amount = 1_000_000): Layaway => ({
  id,
  invoiceId: `invoice-${id}`,
  invoice: {
    id: `invoice-${id}`,
    number: `SEP-${id}`,
    clientId: `client-${id}`,
    clientName: `Cliente ${id}`,
    items: [],
    subtotal: amount,
    discount: 0,
    tax: 0,
    total: amount,
    date,
    status: 'pending',
    tipoDocumento: 'factura',
  },
  payments: [],
  completed: false,
});

describe('JoyaControl v3.4 - Dashboard personalizable', () => {
  beforeEach(() => window.localStorage.clear());

  it('mantiene los widgets actuales activos por defecto y persiste por usuario', () => {
    const defaults = createDefaultDashboardPreferences();
    expect(defaults.visible['sales.today']).toBe(true);
    expect(defaults.visible['cash.main']).toBe(true);
    expect(defaults.visible['charts.salesDay']).toBe(true);

    defaults.visible['sales.today'] = false;
    saveDashboardPreferences('user-a', defaults);

    expect(loadDashboardPreferences('user-a').visible['sales.today']).toBe(false);
    expect(loadDashboardPreferences('user-b').visible['sales.today']).toBe(true);
  });
});

describe('JoyaControl v3.4 - Alertas de separados', () => {
  beforeEach(() => window.localStorage.clear());

  it('aplica el plazo nuevo solo a separados creados posteriormente', () => {
    saveLayawayAlertSettings({ defaultTermDays: 30, noRecentPaymentDays: 30, updatedAt: '' });
    const first = createLayaway('1', '2026-08-01');
    let registry = ensureLayawayDeadlines([first]);
    expect(registry[first.id].dueDate).toBe('2026-08-31');

    saveLayawayAlertSettings({ defaultTermDays: 60, noRecentPaymentDays: 30, updatedAt: '' });
    const second = createLayaway('2', '2026-08-10');
    registry = ensureLayawayDeadlines([first, second]);

    expect(registry[first.id].dueDate).toBe('2026-08-31');
    expect(registry[second.id].dueDate).toBe('2026-10-09');
    expect(loadLayawayDeadlineRegistry()[first.id].termDays).toBe(30);
  });

  it('clasifica verde, amarillo, naranja y rojo según días restantes', () => {
    const layaway = createLayaway('status', '2026-08-01');
    saveLayawayAlertSettings({ defaultTermDays: 30, noRecentPaymentDays: 30, updatedAt: '' });
    const deadline = ensureLayawayDeadlines([layaway])[layaway.id];

    expect(calculateLayawayAlertInfo(layaway, deadline, new Date('2026-08-20T12:00:00')).tone).toBe('green');
    expect(calculateLayawayAlertInfo(layaway, deadline, new Date('2026-08-24T12:00:00')).tone).toBe('yellow');
    expect(calculateLayawayAlertInfo(layaway, deadline, new Date('2026-08-29T12:00:00')).tone).toBe('orange');
    expect(calculateLayawayAlertInfo(layaway, deadline, new Date('2026-09-04T12:00:00')).tone).toBe('red');
  });

  it('genera el resumen y la fecha próxima usada por el Dashboard', () => {
    saveLayawayAlertSettings({ defaultTermDays: 30, noRecentPaymentDays: 30, updatedAt: '' });
    const layaways = [createLayaway('a', '2026-08-01'), createLayaway('b', '2026-08-20')];
    const registry = ensureLayawayDeadlines(layaways);
    const summary = buildLayawayAlertSummary(layaways, registry, new Date('2026-08-29T12:00:00'));

    expect(summary.active).toBe(2);
    expect(summary.upcoming).toBe(1);
    expect(summary.nearestDueDate).toBe('2026-08-31');
  });
});
