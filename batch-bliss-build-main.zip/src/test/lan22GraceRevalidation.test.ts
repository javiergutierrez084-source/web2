// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => {
  let restoreAttempt = 0;
  let restoreSucceedsOnSecondAttempt = true;
  const calls: string[] = [];

  const json = (status: number, payload: unknown) => new Response(JSON.stringify(payload), {
    status,
    headers: { 'Content-Type': 'application/json' },
  });

  return {
    calls,
    reset(secondSucceeds: boolean) {
      restoreAttempt = 0;
      restoreSucceedsOnSecondAttempt = secondSucceeds;
      calls.length = 0;
    },
    lanFetch: vi.fn(async (url: string) => {
      const pathname = new URL(url).pathname;
      calls.push(pathname);
      if (pathname === '/auth/restore') {
        restoreAttempt += 1;
        if (restoreAttempt === 1 || !restoreSucceedsOnSecondAttempt) {
          return json(401, { success: false, error: 'LAN_USER_SESSION_EXPIRED' });
        }
        return json(200, {
          success: true,
          userId: 'u1',
          username: 'master',
          displayName: 'Maestro',
          role: 'master',
          authToken: 'AUTH-STABLE',
          expiresAt: '2026-08-20T00:00:00.000Z',
          rememberDevice: true,
        });
      }
      if (pathname === '/health') {
        return json(200, {
          status: 'online',
          version: '2.1',
          serverName: 'Servidor',
          serverId: 'SERVER-1',
          companyId: 'COMPANY-1',
          database: 'ready',
          time: new Date().toISOString(),
          mode: 'desktop',
          protocolVersion: 'LAN-1',
        });
      }
      if (pathname === '/server-info') {
        return json(200, {
          serverId: 'SERVER-1',
          serverName: 'Servidor',
          companyId: 'COMPANY-1',
          company: 'JoyaControl',
          version: '2.1',
          protocolVersion: 'LAN-1',
          repository: 'Dexie',
          mode: 'desktop',
          maxClients: 3,
          connectedClients: 1,
          features: { sales: true, inventory: true, reports: true, sync: false },
          ip: '192.168.20.5',
          port: 47831,
          baseUrl: 'http://192.168.20.5:47831',
        });
      }
      if (pathname === '/client/reconnect') {
        return json(200, {
          success: true,
          clientId: 'CLIENT-1',
          sessionToken: 'SESSION-1',
          serverId: 'SERVER-1',
        });
      }
      throw new Error(`UNEXPECTED_${pathname}`);
    }),
  };
});

vi.mock('@/lib/LanFetchDiagnostics', () => ({
  lanFetch: mocks.lanFetch,
  readLanJson: async <T,>(response: Response, fallback: T): Promise<T> => {
    try { return await response.json() as T; }
    catch { return fallback; }
  },
}));

vi.mock('@/lib/LanServerDescriptor', () => ({
  isValidLanIpv4: () => true,
  LanServerDescriptor: {
    changedEvent: 'joyacontrol-lan-server-descriptor-changed',
    load: () => ({
      serverId: 'SERVER-1', companyId: 'COMPANY-1', serverName: 'Servidor',
      ip: '192.168.20.5', port: 47831, protocolVersion: 'LAN-1',
      baseUrl: 'http://192.168.20.5:47831', enabled: false,
      addressMode: 'remote', lastLanIp: '192.168.20.5', ipSource: 'discovered',
      ipUpdatedAt: new Date().toISOString(), networkAvailable: true,
    }),
    getServerId: () => 'SERVER-1',
    getCompanyId: () => 'COMPANY-1',
    getBaseUrl: () => 'http://192.168.20.5:47831',
    hasAddress: () => true,
    toJSON: () => ({ ip: '192.168.20.5', serverId: 'SERVER-1', companyId: 'COMPANY-1' }),
    saveSync: (patch: unknown) => patch,
    rememberServer: async (server: unknown) => server,
  },
}));

const config = {
  mode: 'lan' as const,
  role: 'client' as const,
  deviceName: 'PC Cliente',
  sharedKey: 'shared',
  timeoutMs: 3000,
  automaticRetries: 3,
  syncIntervalSeconds: 60,
  logLevel: 'info' as const,
  lastConnection: null,
  serverStarted: false,
  clientId: 'CLIENT-1',
  sessionToken: 'SESSION-1',
  authToken: 'AUTH-STABLE',
  rememberDevice: true,
  allowMultipleUserSessions: false,
  autoReconnect: true,
  deviceInstanceId: 'DEVICE-1',
};

beforeEach(() => {
  localStorage.clear();
  mocks.lanFetch.mockClear();
  Object.defineProperty(window, 'joyaControlLan', {
    configurable: true,
    value: {
      getSystemIdentity: async () => ({ hostname: 'pc-cliente', ip: '192.168.20.12' }),
    },
  });
});

describe('JOYACONTROL LAN V2.2 session-expiration grace period', () => {
  it('keeps the authenticated session when automatic revalidation succeeds', async () => {
    mocks.reset(true);
    const module = await import('@/lib/LanCommunicationConfig');
    module.saveLanConfig(config);
    const expirationEvents: Event[] = [];
    window.addEventListener(module.LAN_AUTH_SESSION_EXPIRED_EVENT, event => expirationEvents.push(event));

    const restored = await module.restoreLanUserWithGrace(module.loadLanConfig());

    expect(restored).toMatchObject({ userId: 'u1', authToken: 'AUTH-STABLE' });
    expect(module.loadLanConfig().authToken).toBe('AUTH-STABLE');
    expect(expirationEvents).toHaveLength(0);
    expect(mocks.calls.filter(path => path === '/auth/restore')).toHaveLength(2);
    expect(mocks.calls).toContain('/client/reconnect');
  });

  it('clears authentication only after the server confirms expiration twice', async () => {
    mocks.reset(false);
    vi.resetModules();
    const module = await import('@/lib/LanCommunicationConfig');
    module.saveLanConfig(config);
    const expirationEvents: Event[] = [];
    window.addEventListener(module.LAN_AUTH_SESSION_EXPIRED_EVENT, event => expirationEvents.push(event));

    await expect(module.restoreLanUserWithGrace(module.loadLanConfig()))
      .rejects.toThrow('LAN_AUTH_SESSION_CONFIRMED_EXPIRED');

    expect(module.loadLanConfig().authToken).toBeNull();
    expect(expirationEvents).toHaveLength(1);
    expect(mocks.calls.filter(path => path === '/auth/restore')).toHaveLength(2);
  });
});
