// @vitest-environment jsdom
import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  preference: 'local' as 'local' | 'lan' | 'auto',
  config: { mode: 'local' as 'local' | 'lan', role: 'client' as 'client' | 'server' },
  activateLocal: vi.fn(() => 'local' as const),
  activateLan: vi.fn(() => 'lan' as const),
  discover: vi.fn(async () => [] as Array<Record<string, unknown>>),
  remember: vi.fn(async () => ({})),
  resetRepository: vi.fn(),
  clearSession: vi.fn(),
  reload: vi.fn(),
}));

vi.mock('@/config/workMode', () => ({
  loadWorkModePreference: () => mocks.preference,
  saveWorkModePreference: vi.fn(),
  getEffectiveWorkMode: () => mocks.config.mode === 'lan' && mocks.config.role === 'client'
    ? 'lan'
    : mocks.config.mode === 'lan' && mocks.config.role === 'server'
      ? 'server'
      : 'local',
  activateLocalWorkMode: mocks.activateLocal,
  activateLanClientWorkMode: mocks.activateLan,
}));

vi.mock('@/lib/authCore', () => ({ clearSession: mocks.clearSession }));
vi.mock('@/repositories/RepositoryRegistry', () => ({ resetDataRepository: mocks.resetRepository }));
vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ ...mocks.config, autoReconnect: true }),
  discoverLanServers: mocks.discover,
}));
vi.mock('@/lib/LanServerDescriptor', () => ({
  LanServerDescriptor: {
    changedEvent: 'descriptor-changed',
    load: () => ({ serverId: '', companyId: '', serverName: '', ip: '', port: 47831, baseUrl: '' }),
    toJSON: () => ({ serverId: '', companyId: '', serverName: '', ip: '', port: 47831, baseUrl: '' }),
    hasAddress: () => false,
    rememberServer: mocks.remember,
  },
}));

import { WorkModeProvider, useWorkMode } from '@/contexts/WorkModeContext';

function Probe() {
  const mode = useWorkMode();
  return (
    <div>
      <span data-testid="phase">{mode.phase}</span>
      <span data-testid="effective">{mode.effectiveMode}</span>
      <span data-testid="server">{mode.detectedServer?.serverName || ''}</span>
      {mode.phase === 'awaiting-confirmation' && (
        <button type="button" onClick={() => void mode.confirmAutomaticServer(true)}>Conectar</button>
      )}
    </div>
  );
}

async function renderProvider() {
  render(<WorkModeProvider><Probe /></WorkModeProvider>);
  await act(async () => { await Promise.resolve(); await Promise.resolve(); });
}

beforeEach(() => {
  mocks.preference = 'local';
  mocks.config.mode = 'local';
  mocks.config.role = 'client';
  mocks.activateLocal.mockClear();
  mocks.activateLan.mockClear();
  mocks.discover.mockReset().mockResolvedValue([]);
  mocks.remember.mockClear();
  mocks.resetRepository.mockClear();
  mocks.clearSession.mockClear();
  Object.defineProperty(window, 'joyaControlLan', {
    configurable: true,
    value: { discoverServers: vi.fn() },
  });
});

afterEach(() => cleanup());

describe('work-mode startup resolution', () => {
  it('enters Local without performing LAN discovery', async () => {
    await renderProvider();
    expect(screen.getByTestId('phase').textContent).toBe('ready');
    expect(screen.getByTestId('effective').textContent).toBe('local');
    expect(mocks.activateLocal).toHaveBeenCalledTimes(1);
    expect(mocks.discover).not.toHaveBeenCalled();
  });

  it('keeps a Principal Server on its local Repository in automatic mode', async () => {
    mocks.preference = 'auto';
    mocks.config.mode = 'lan';
    mocks.config.role = 'server';
    await renderProvider();
    expect(screen.getByTestId('effective').textContent).toBe('server');
    expect(mocks.discover).not.toHaveBeenCalled();
  });

  it('falls back automatically to Local when discovery finds no server', async () => {
    mocks.preference = 'auto';
    await renderProvider();
    expect(mocks.discover).toHaveBeenCalledTimes(1);
    expect(screen.getByTestId('phase').textContent).toBe('ready');
    expect(screen.getByTestId('effective').textContent).toBe('local');
  });

  it('asks before connecting and then activates the existing LAN client transport', async () => {
    mocks.preference = 'auto';
    mocks.discover.mockResolvedValue([{
      serverId: 'server-1',
      companyId: 'company-1',
      serverName: 'Servidor Principal',
      company: 'Joya',
      version: '2.1',
      protocolVersion: 'LAN-1',
      repository: 'Dexie',
      mode: 'desktop',
      maxClients: 10,
      connectedClients: 1,
      features: { sales: true, inventory: true, reports: true, sync: true },
      ip: '192.168.1.50',
      port: 47831,
      latencyMs: 4,
    }]);

    await renderProvider();
    expect(screen.getByTestId('phase').textContent).toBe('awaiting-confirmation');
    expect(screen.getByTestId('server').textContent).toBe('Servidor Principal');

    await act(async () => { screen.getByRole('button', { name: 'Conectar' }).click(); await Promise.resolve(); });
    expect(mocks.remember).toHaveBeenCalledTimes(1);
    expect(mocks.activateLan).toHaveBeenCalledTimes(1);
    expect(screen.getByTestId('effective').textContent).toBe('lan');
    expect(screen.getByTestId('phase').textContent).toBe('ready');
  });
});
