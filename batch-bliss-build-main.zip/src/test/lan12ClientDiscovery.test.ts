// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import net from 'node:net';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { drainLanActivityEvents, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      const port = address.port;
      socket.close(error => error ? reject(error) : resolve(port));
    });
    socket.on('error', reject);
  });
}

async function post(url: string, body: object) {
  return fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

describe('LAN 1.2 client discovery and registration', () => {
  let baseUrl = '';
  let userDataPath = '';

  beforeEach(async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joyacontrol-lan12-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1' });
    baseUrl = `http://127.0.0.1:${port}`;
  });

  afterEach(async () => {
    await stopLanServer();
    drainLanActivityEvents();
    fs.rmSync(userDataPath, { recursive: true, force: true });
  });

  it('publishes server-info without consulting repositories', async () => {
    const response = await fetch(`${baseUrl}/server-info`);
    expect(response.status).toBe(200);
    const payload = await response.json();
    expect(payload).toMatchObject({
      serverName: 'Servidor QA', company: 'JoyaControl', version: '2.1',
      protocolVersion: 'LAN-1', repository: 'Dexie', mode: 'desktop',
      maxClients: 3, connectedClients: 0,
      features: { sales: true, inventory: true, reports: true, sync: false },
    });
  });

  it('registers two clients, exposes them and rejects the next device', async () => {
    const register = (index: number) => post(`${baseUrl}/client/register`, {
      name: `Equipo ${index}`, hostname: `equipo-${index}`, ip: `192.168.1.${index + 10}`,
      version: '2.1', localTime: new Date().toISOString(),
    });
    const first = await register(1);
    const second = await register(2);
    const rejected = await register(3);
    expect(first.status).toBe(201);
    expect(second.status).toBe(201);
    expect(rejected.status).toBe(403);
    expect(await rejected.json()).toEqual({ success: false, error: 'LAN_MAX_CLIENTS_REACHED' });

    const clientsResponse = await fetch(`${baseUrl}/clients`);
    const clientsPayload = await clientsResponse.json();
    expect(clientsPayload.clients).toHaveLength(2);
    expect(clientsPayload.clients[0]).toMatchObject({ name: 'Equipo 1', hostname: 'equipo-1', status: 'connected' });
    expect(clientsPayload.clients[0].sessionToken).toBeUndefined();

    const health = await (await fetch(`${baseUrl}/health`)).json();
    expect(health.connectedClients).toBe(2);
    expect(health.protocolVersion).toBe('LAN-1');
    expect(health.uptime).toBeTypeOf('number');
    expect(health.memoryUsed).toBeGreaterThan(0);
    expect(health.requestsHandled).toBeGreaterThanOrEqual(5);

    const events = drainLanActivityEvents();
    expect(events.filter(event => event.action === 'LAN_CLIENT_REGISTERED')).toHaveLength(2);
    expect(events.some(event => event.action === 'LAN_MAX_CLIENTS_REACHED')).toBe(true);
  });

  it('disconnects a registered client using its session token', async () => {
    const response = await post(`${baseUrl}/client/register`, {
      name: 'Caja', hostname: 'caja-01', ip: '192.168.1.20', version: '2.1', localTime: new Date().toISOString(),
    });
    const registration = await response.json();
    const disconnected = await post(`${baseUrl}/client/disconnect`, {
      clientId: registration.clientId, sessionToken: registration.sessionToken,
    });
    expect(disconnected.status).toBe(200);
    const payload = await (await fetch(`${baseUrl}/clients`)).json();
    expect(payload.clients).toHaveLength(1);
    expect(payload.clients[0].status).toBe('disconnected');
    expect(drainLanActivityEvents().some(event => event.action === 'LAN_CLIENT_DISCONNECTED')).toBe(true);
  });

  it('rejects incompatible client versions', async () => {
    const response = await post(`${baseUrl}/client/register`, {
      name: 'Antiguo', hostname: 'old-pc', ip: '192.168.1.30', version: '2.0', localTime: new Date().toISOString(),
    });
    expect(response.status).toBe(409);
    expect(await response.json()).toEqual({ success: false, error: 'LAN_INCOMPATIBLE_VERSION' });
    expect(drainLanActivityEvents().some(event => event.action === 'LAN_CLIENT_REJECTED')).toBe(true);
  });
});
