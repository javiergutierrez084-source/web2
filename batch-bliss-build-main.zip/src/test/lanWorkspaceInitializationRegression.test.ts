import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';

const read = (relativePath: string): string => (
  fs.readFileSync(path.resolve(process.cwd(), relativePath), 'utf8')
);

describe('LAN workspace initialization regression', () => {
  it('keeps the installed React application as the only UI bundle', () => {
    const bootstrap = read('src/components/LanBootstrapProvider.tsx');
    const appContext = read('src/contexts/AppContext.tsx');
    const lanServer = read('electron/lanServer.js');

    expect(bootstrap).not.toMatch(/loadURL|location\.(?:assign|replace)|window\.location/);
    expect(lanServer).not.toMatch(/sendFile|index\.html|text\/html/);
    expect(appContext).toContain('applySalesWorkspace');
    expect(appContext).not.toMatch(/location\.(?:assign|replace)|window\.location|<Routes>/);
  });

  it('does not hide or replace the modern Owner Finances route in LAN mode', () => {
    const app = read('src/App.tsx');
    const layout = read('src/components/AppLayout.tsx');

    expect(app).toContain("hasSessionPermission(user, 'manage_finances')");
    expect(app).not.toMatch(/getActiveRepositoryMode\(\)\s*!==\s*['"]lan['"]/);
    expect(layout).toContain('hasSessionPermission(user, item.requiredPermission)');
    expect(layout).not.toMatch(/item\.path\s*!==\s*['"]\/finanzas['"]\s*\|\|\s*getActiveRepositoryMode/);
  });

  it('authorizes Inventory actions by permissions instead of LAN mode', () => {
    const inventory = read('src/pages/Inventory.tsx');

    expect(inventory).toContain("hasSessionPermission(user, 'manage_products')");
    expect(inventory).toContain("hasSessionPermission(user, 'manage_inventory')");
    expect(inventory).not.toMatch(/!isRemoteInventory\s*&&/);
    expect(inventory).not.toMatch(/isRemoteInventory\s*\?[^:]*ocult/i);
  });

  it('preserves the permission snapshot issued by the Principal Server', () => {
    const apiRepository = read('src/repositories/ApiRepository.ts');
    const auth = read('src/lib/auth.ts');
    const authCore = read('src/lib/authCore.ts');

    expect(apiRepository).toContain('permissions: Array.isArray(payload.permissions)');
    expect(auth).toContain('permissions: Array.isArray(remote.permissions)');
    expect(authCore).toContain('export function hasSessionPermission');
  });

  it('routes Owner Finances through the existing POST /repository/call contract', () => {
    const contract = read('src/lib/LanRepositoryContract.ts');
    const server = read('electron/lanServer.js');
    const bridge = read('src/components/LanAuthenticationBridge.tsx');
    const apiRepository = read('src/repositories/ApiRepository.ts');
    const service = read('src/services/OwnerFinanceRepositoryService.ts');

    const methods = [
      'fetchOwnerFinanceWorkspace',
      'createOwnerWithdrawal',
      'cancelOwnerWithdrawal',
      'createOwnerWithdrawalConcept',
      'updateOwnerWithdrawalConcept',
      'saveOwnerFinanceSettings',
    ];

    methods.forEach(method => {
      expect(contract).toContain(`${method}:`);
      expect(server).toContain(`${method}: ['manage_finances']`);
      expect(bridge).toContain(`case '${method}'`);
      expect(apiRepository).toContain(`'${method}'`);
    });

    expect(service).not.toContain('OWNER_FINANCE_REQUIRES_PRINCIPAL_SERVER');
    expect(apiRepository.match(/new URL\('repository\/call'/g) || []).toHaveLength(1);
  });
});
