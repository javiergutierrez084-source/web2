import { describe, expect, it, vi } from 'vitest';

const mocks = vi.hoisted(() => ({
  exportRowsToExcel: vi.fn(),
}));

vi.mock('@/lib/excelExport', () => ({
  exportRowsToExcel: mocks.exportRowsToExcel,
}));

import { exportProductMassUpdateReport, type ProductMassUpdatePlan } from '@/lib/productMassUpdate';

describe('reporte final de actualización masiva', () => {
  it('exporta productos modificados, sin cambios, no encontrados y con error', () => {
    const plan: ProductMassUpdatePlan = {
      previewRows: [],
      upserts: [],
      summary: {
        productsFound: 3,
        productsModified: 1,
        productsUnchanged: 1,
        productsNotFound: 1,
        errors: 1,
      },
      sourceResults: [
        { sourceRow: 2, productId: 'p1', product: 'P1 · Uno', outcome: 'modified', reason: 'Listo para actualizar.' },
        { sourceRow: 3, productId: 'p2', product: 'P2 · Dos', outcome: 'unchanged', reason: 'No contiene cambios aplicables.' },
        { sourceRow: 4, product: '(producto no encontrado)', outcome: 'not_found', reason: 'Producto no encontrado.' },
        { sourceRow: 5, productId: 'p3', product: 'P3 · Tres', outcome: 'error', reason: 'Proveedor inexistente.' },
      ],
    };

    exportProductMassUpdateReport(plan);

    expect(mocks.exportRowsToExcel).toHaveBeenCalledTimes(1);
    expect(mocks.exportRowsToExcel).toHaveBeenCalledWith(expect.objectContaining({
      filename: 'Reporte_Actualizacion_Masiva_Productos',
      sheetName: 'Resultado',
      rows: plan.sourceResults,
    }));
  });
});
