// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { render, screen } from '@testing-library/react';
import { beforeEach, describe, expect, it } from 'vitest';
import { OwnerFinanceGoalProgress } from '@/components/OwnerFinanceGoalProgress';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  calculateOwnerFinanceDashboard,
  calculateMonthlyGoalProgress,
} from '@/lib/OwnerFinanceService';
import { buildOwnerFinanceExportSummary } from '@/lib/OwnerFinanceExports';
import {
  cancelOwnerWithdrawalLocal,
  createOwnerWithdrawalLocal,
  fetchOwnerFinanceWorkspaceLocal,
  saveOwnerFinanceSettingsLocal,
} from '@/lib/OwnerFinanceLocalDataService';

const currentIso = () => new Date().toISOString();
const currentDay = () => currentIso().slice(0, 10);

const user = {
  id: 'owner-user',
  username: 'owner',
  display_name: 'Propietario',
  password_hash: '',
  role: 'master' as const,
  active: true,
  created_at: currentIso(),
  last_login: null,
};

const account = {
  id: 'account-owner',
  name: 'Caja Principal',
  kind: 'cash' as const,
  active: true,
  balance: 5_000,
  created_at: currentIso(),
  updated_at: currentIso(),
};

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.financial_accounts.put(account);
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
});

describe('Finanzas del Propietario V1 - meta mensual', () => {
  it('persiste la meta mensual y el periodo sin generar retiros automáticos', async () => {
    const movementsBefore = await localDb.financial_movements.count();
    const balanceBefore = (await localDb.financial_accounts.get(account.id))?.balance;

    const settings = await saveOwnerFinanceSettingsLocal({
      projectedWithdrawalPercentage: 40,
      monthlyProfitGoal: 10_000_000,
      financialPeriod: 'FORTNIGHTLY',
    });

    expect(settings).toMatchObject({
      projectedWithdrawalPercentage: 40,
      monthlyProfitGoal: 10_000_000,
      financialPeriod: 'FORTNIGHTLY',
      periodStatus: 'OPEN',
    });
    expect((await fetchOwnerFinanceWorkspaceLocal()).settings).toMatchObject(settings);
    expect(await localDb.financial_movements.count()).toBe(movementsBefore);
    expect((await localDb.financial_accounts.get(account.id))?.balance).toBe(balanceBefore);
  });

  it('calcula cumplimiento, alcanzado, restante y limita la barra al 100 %', () => {
    expect(calculateMonthlyGoalProgress(1_000, 450)).toEqual({
      monthlyGoalProgressPercentage: 45,
      monthlyGoalProgressBarPercentage: 45,
      monthlyGoalReachedValue: 450,
      monthlyGoalRemainingValue: 550,
      monthlyGoalReached: false,
    });

    expect(calculateMonthlyGoalProgress(1_000, 1_250)).toEqual({
      monthlyGoalProgressPercentage: 125,
      monthlyGoalProgressBarPercentage: 100,
      monthlyGoalReachedValue: 1_250,
      monthlyGoalRemainingValue: 0,
      monthlyGoalReached: true,
    });
  });

  it('renderiza la barra gráfica y el mensaje de meta alcanzada', () => {
    const dashboard = calculateOwnerFinanceDashboard({
      invoices: [{ id: 'sale', date: currentDay(), status: 'paid', total: 1_500, totalCost: 250 }],
      expenses: [],
      withdrawals: [],
      projectedWithdrawalPercentage: 30,
      monthlyProfitGoal: 1_000,
    });

    render(<OwnerFinanceGoalProgress dashboard={dashboard} />);

    const progress = screen.getByRole('progressbar', { name: 'Cumplimiento de la meta mensual' });
    expect(progress).toHaveAttribute('aria-valuenow', '100');
    expect(screen.getByTestId('owner-monthly-goal-progress-fill')).toHaveStyle({ width: '100%' });
    expect(screen.getByText('Meta alcanzada')).toBeInTheDocument();
    expect(screen.getByText('125.00 %')).toBeInTheDocument();
  });
});

describe('Finanzas del Propietario V1 - anulación de retiros', () => {
  it('crea el reverso, reintegra la caja y actualiza dashboard y reporte sin borrar historial', async () => {
    await localDb.invoices.add({
      id: 'invoice-owner-finance',
      number: 'FV-1',
      client_id: '',
      client_name: 'Cliente',
      subtotal: 1_000,
      discount: 0,
      tax: 0,
      total: 1_000,
      date: currentIso(),
      status: 'paid',
      payment_method: 'EFECTIVO',
      client_notes: '',
      internal_notes: '',
      cancellation_reason: '',
      cancelled_at: '',
      cancelled_by: '',
      tipo_documento: 'FACTURA',
      created_at: currentIso(),
    });
    await localDb.invoice_items.add({
      invoice_id: 'invoice-owner-finance',
      product_id: 'product-owner-finance',
      code: 'P-1',
      name: 'Producto',
      quantity: 1,
      weight_grams: 0,
      unit_price: 1_000,
      subtotal: 1_000,
      price_modified: false,
      original_price: 1_000,
      cost_price: 400,
    });
    await saveOwnerFinanceSettingsLocal({
      projectedWithdrawalPercentage: 30,
      monthlyProfitGoal: 1_000,
      financialPeriod: 'MONTHLY',
    });

    const initialWorkspace = await fetchOwnerFinanceWorkspaceLocal();
    const concept = initialWorkspace.concepts.find(item => item.active)!;
    const withdrawal = await createOwnerWithdrawalLocal({
      withdrawalDate: currentIso(),
      conceptId: concept.id,
      amount: 200,
      observations: 'Retiro que será anulado',
      accountId: account.id,
      paymentMethod: 'EFECTIVO',
    });

    const beforeCancellation = await fetchOwnerFinanceWorkspaceLocal();
    const reportBefore = buildOwnerFinanceExportSummary(beforeCancellation.dashboard);
    expect(beforeCancellation.dashboard).toMatchObject({
      profitMonth: 400,
      availableProfit: 400,
      withdrawnProfit: 200,
      availableBalance: 400,
      monthlyGoalProgressPercentage: 40,
    });
    expect(reportBefore).toMatchObject({
      monthlyProfitGoal: 1_000,
      generatedProfit: 400,
      compliancePercentage: 40,
      withdrawnProfit: 200,
      availableBalance: 400,
    });
    expect((await localDb.financial_accounts.get(account.id))?.balance).toBe(4_800);

    const cancelled = await cancelOwnerWithdrawalLocal(withdrawal.id, 'Registro duplicado');
    expect(cancelled.status).toBe('ANULADO');

    const afterCancellation = await fetchOwnerFinanceWorkspaceLocal();
    const reportAfter = buildOwnerFinanceExportSummary(afterCancellation.dashboard);
    expect(afterCancellation.dashboard).toMatchObject({
      profitMonth: 600,
      withdrawnProfit: 0,
      availableBalance: 600,
      monthlyGoalProgressPercentage: 60,
    });
    expect(reportAfter).toMatchObject({
      monthlyProfitGoal: 1_000,
      generatedProfit: 600,
      compliancePercentage: 60,
      withdrawnProfit: 0,
      availableBalance: 600,
    });
    expect((await localDb.financial_accounts.get(account.id))?.balance).toBe(5_000);

    const historicalWithdrawal = afterCancellation.withdrawals.find(item => item.id === withdrawal.id);
    expect(historicalWithdrawal).toMatchObject({
      status: 'ANULADO',
      cancellationReason: 'Registro duplicado',
      amount: 200,
    });
    expect(afterCancellation.withdrawals).toHaveLength(1);

    const originalMovement = await localDb.financial_movements.get(withdrawal.financialMovementId);
    const reversalMovement = await localDb.financial_movements
      .filter(movement => movement.related_movement_id === withdrawal.financialMovementId)
      .first();
    expect(originalMovement).toMatchObject({ status: 'POSTED', amount: 200 });
    expect(reversalMovement).toMatchObject({
      movement_code: 'REVERSAL',
      destination_account_id: account.id,
      amount: 200,
    });
    expect(await localDb.financial_movements.count()).toBe(2);
    await expect(cancelOwnerWithdrawalLocal(withdrawal.id, 'Segundo intento'))
      .rejects.toThrow('OWNER_WITHDRAWAL_ALREADY_CANCELLED');
    expect((await localDb.financial_accounts.get(account.id))?.balance).toBe(5_000);
    expect(await localDb.financial_movements.count()).toBe(2);
  });
});
