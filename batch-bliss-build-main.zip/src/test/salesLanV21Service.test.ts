import { beforeEach, describe, expect, it, vi } from 'vitest';
import type {
  Contact,
  FinancialAccount,
  FinancialMovement,
  FinancialSummary,
  Invoice,
  Product,
  Quotation,
} from '@/data/mockData';
import type { CompanyInfo, Layaway } from '@/domain/models';
import type { SalesWorkspace } from '@/lib/SalesRepositoryService';

const mocks = vi.hoisted(() => ({
  mode: 'lan' as 'lan' | 'local',
  repository: {} as Record<string, ReturnType<typeof vi.fn>>,
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getActiveRepositoryMode: () => mocks.mode,
  getDataRepository: () => mocks.repository,
}));

import { SalesRepositoryService } from '@/lib/SalesRepositoryService';

const company: CompanyInfo = {
  name: 'JoyaControl', nit: '1', phone: '', city: '', address: '', email: '', logoUrl: '',
};
const product: Product = {
  id: 'p1', code: 'A-1', name: 'Anillo', category: 'Anillos', purchasePrice: 50,
  salePrice: 100, weightGrams: 2, margin: 100, stock: 4, minStock: 1,
};
const contact: Contact = {
  id: 'c1', type: 'client', name: 'Ana', document: '123', phone: '', email: '', address: '',
};
const invoice: Invoice = {
  id: 'i1', number: 'FAC-001', clientId: contact.id, clientName: contact.name,
  items: [{ productId: product.id, code: product.code, name: product.name, quantity: 1, weightGrams: 2, unitPrice: 100, subtotal: 100 }],
  subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-20', status: 'paid',
};
const quotation: Quotation = {
  id: 'q1', number: 'COT-001', clientId: contact.id, clientName: contact.name,
  items: invoice.items, subtotal: 100, discount: 0, tax: 0, total: 100,
  date: '2026-07-20', validUntil: '2026-07-30', status: 'active',
};
const layaway: Layaway = {
  id: 'l1', invoiceId: invoice.id, invoice: { ...invoice, status: 'pending' }, payments: [], completed: false,
};
const account: FinancialAccount = {
  id: 'a1', name: 'Caja', kind: 'cash', active: true, balance: 100,
  createdAt: '2026-07-20T10:00:00.000Z', updatedAt: '2026-07-20T10:00:00.000Z',
};
const movement: FinancialMovement = {
  id: 'm1', type: 'sale_income', amount: 100, destinationAccountId: account.id,
  originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0,
  destinationBalanceAfter: 100, reference: invoice.number, documentType: 'invoice',
  documentId: invoice.id, observation: '', userId: 'u1', userName: 'Master',
  date: '2026-07-20', createdAt: '2026-07-20T10:00:00.000Z',
};
const summary: FinancialSummary = {
  cash: 100, banks: 0, totalFunds: 100, accountsPayable: 0, sales: 100,
  costOfSales: 50, grossProfit: 50, expenses: 0, netProfit: 50,
  availableProfit: 50, incomeToday: 100, expensesToday: 0,
};
const workspace: SalesWorkspace = {
  company,
  contacts: [contact],
  invoices: [invoice],
  layaways: [layaway],
  quotations: [quotation],
  financialAccounts: [account],
  financialMovements: [movement],
  financialSummary: summary,
};

beforeEach(() => {
  mocks.mode = 'lan';
  mocks.repository = {
    getSalesWorkspace: vi.fn().mockResolvedValue(workspace),
    getSalesClients: vi.fn().mockResolvedValue([contact]),
    searchSalesClients: vi.fn().mockResolvedValue([contact]),
    getSalesClientById: vi.fn().mockResolvedValue(contact),
    createSalesClient: vi.fn().mockResolvedValue(contact),
    updateSalesClient: vi.fn().mockResolvedValue(contact),
    deleteSalesClient: vi.fn().mockResolvedValue(undefined),
    querySales: vi.fn().mockResolvedValue([invoice]),
    getSaleById: vi.fn().mockResolvedValue(invoice),
    createSale: vi.fn().mockResolvedValue([product]),
    updateSaleStatus: vi.fn().mockResolvedValue(undefined),
    cancelSale: vi.fn().mockResolvedValue({
      invoiceId: invoice.id,
      cancelledAt: '2026-07-20T11:00:00.000Z',
      cancelledBy: 'Master',
      restoredProducts: [product],
    }),
    applySalesContactChanges: vi.fn().mockResolvedValue(undefined),
    createSalesQuotation: vi.fn().mockResolvedValue(quotation),
    updateSalesQuotationStatus: vi.fn().mockResolvedValue(undefined),
    createSalesLayaway: vi.fn().mockResolvedValue(layaway),
    updateSalesLayaway: vi.fn().mockResolvedValue({ layaway, updatedProducts: [product] }),
    deleteSalesLayaway: vi.fn().mockResolvedValue({ invoiceId: invoice.id, restoredProducts: [product] }),
    addSalesLayawayPayment: vi.fn().mockResolvedValue({
      payment: { id: 'pay1', amount: 40, date: '2026-07-20', method: 'Efectivo', accountId: account.id },
      invoiceId: invoice.id,
      completed: false,
    }),
    completeSalesLayaway: vi.fn().mockResolvedValue(invoice.id),
    invalidateSales: vi.fn(),

    ensureDefaultFinancialAccounts: vi.fn().mockResolvedValue([account]),
    fetchCompany: vi.fn().mockResolvedValue(company),
    fetchContacts: vi.fn().mockResolvedValue([contact]),
    fetchInvoices: vi.fn().mockResolvedValue([invoice]),
    fetchLayaways: vi.fn().mockResolvedValue([layaway]),
    fetchQuotations: vi.fn().mockResolvedValue([quotation]),
    fetchFinancialAccounts: vi.fn().mockResolvedValue([account]),
    fetchFinancialMovements: vi.fn().mockResolvedValue([movement]),
    fetchFinancialSummary: vi.fn().mockResolvedValue(summary),
    insertInvoiceWithFinancials: vi.fn().mockResolvedValue([product]),
  };
});

describe('SalesRepositoryService', () => {
  it('delegates the complete Sales workspace and commands to ApiRepository in LAN client mode', async () => {
    expect(await SalesRepositoryService.getSalesWorkspace()).toEqual(workspace);
    expect(await SalesRepositoryService.getClients()).toEqual([contact]);
    expect(await SalesRepositoryService.searchClients('Ana')).toEqual([contact]);
    expect(await SalesRepositoryService.getClientById(contact.id)).toEqual(contact);
    expect(await SalesRepositoryService.createClient(contact)).toEqual(contact);
    expect(await SalesRepositoryService.updateClient(contact)).toEqual(contact);
    await expect(SalesRepositoryService.deleteClient(contact.id)).resolves.toBeUndefined();
    expect(await SalesRepositoryService.querySales({ clientId: contact.id, limit: 10 })).toEqual([invoice]);
    expect(await SalesRepositoryService.getSaleById(invoice.id)).toEqual(invoice);
    expect(await SalesRepositoryService.createSale(invoice, [{ accountId: account.id, amount: 100 }])).toEqual([product]);
    await SalesRepositoryService.applyContactChanges({ upserts: [contact], deleteIds: [] });
    expect(await SalesRepositoryService.createQuotation({ ...quotation, id: undefined, number: undefined } as never)).toEqual(quotation);
    expect(await SalesRepositoryService.createLayaway(layaway)).toEqual(layaway);
    expect(await SalesRepositoryService.completeLayaway(layaway.id, '2026-07-20')).toBe(invoice.id);

    expect(mocks.repository.getSalesWorkspace).toHaveBeenCalledTimes(1);
    expect(mocks.repository.getSalesClients).toHaveBeenCalledTimes(2);
    expect(mocks.repository.searchSalesClients).toHaveBeenCalledWith('Ana');
    expect(mocks.repository.getSalesClientById).toHaveBeenCalledWith(contact.id);
    expect(mocks.repository.createSalesClient).toHaveBeenCalledWith(contact);
    expect(mocks.repository.updateSalesClient).toHaveBeenCalledWith(contact);
    expect(mocks.repository.deleteSalesClient).toHaveBeenCalledWith(contact.id);
    expect(mocks.repository.querySales).toHaveBeenCalledWith({ clientId: contact.id, limit: 10 });
    expect(mocks.repository.getSaleById).toHaveBeenCalledWith(invoice.id);
    expect(mocks.repository.createSale).toHaveBeenCalledWith(
      invoice,
      [{ accountId: account.id, amount: 100 }],
      {},
    );
    expect(mocks.repository.applySalesContactChanges).toHaveBeenCalledWith({ upserts: [contact], deleteIds: [] });
    expect(mocks.repository.createSalesLayaway).toHaveBeenCalledWith(layaway);
  });

  it('uses IDataRepository directly in Desktop and Principal Server modes', async () => {
    mocks.mode = 'local';

    const localWorkspace = await SalesRepositoryService.getSalesWorkspace();
    const results = await SalesRepositoryService.querySales({ text: 'fac-001', period: 'month' });
    const updatedProducts = await SalesRepositoryService.createSale(
      invoice,
      [{ accountId: account.id, amount: 100 }],
    );

    expect(localWorkspace).toEqual(workspace);
    expect(results).toEqual([invoice]);
    expect(updatedProducts).toEqual([product]);
    expect(mocks.repository.ensureDefaultFinancialAccounts).toHaveBeenCalledTimes(1);
    expect(mocks.repository.fetchInvoices).toHaveBeenCalledTimes(2);
    expect(mocks.repository.insertInvoiceWithFinancials).toHaveBeenCalledWith(
      invoice,
      [{ accountId: account.id, amount: 100 }],
      {},
    );
    expect(mocks.repository.getSalesWorkspace).not.toHaveBeenCalled();
  });
});
