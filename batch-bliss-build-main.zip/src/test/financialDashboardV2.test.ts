import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import type { Layaway } from '@/domain/models';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';
import {
  LAYAWAY_RESERVE_ACCOUNT_ID,
  MAIN_CASH_ACCOUNT_ID,
  buildFinancialPosition,
} from '@/lib/FinancialPositionService';

const account = (id: string, name: string, kind: FinancialAccount['kind'], balance: number): FinancialAccount => ({
  id, name, kind, balance, active: true, createdAt: '', updatedAt: '',
});

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(), type: 'adjustment', amount: 100,
  originBalanceBefore: 0, originBalanceAfter: 0,
  destinationBalanceBefore: 0, destinationBalanceAfter: 100,
  reference: '', documentType: 'layaway', documentId: 'lay-1', observation: '',
  userId: '', userName: '', date: '2026-07-21', createdAt: '',
  ...overrides,
});

const pendingLayaway: Layaway = {
  id: 'lay-1', invoiceId: 'invoice-lay-1', completed: false,
  invoice: {
    id: 'invoice-lay-1', number: 'SEP-1', clientId: 'client-1', clientName: 'Cliente',
    subtotal: 200, discount: 0, tax: 0, total: 200, date: '2026-07-21', status: 'pending',
    paymentMethod: '', items: [],
  },
  payments: [
    { id: 'p-1', amount: 100, date: '2026-07-21', method: 'Efectivo', accountId: MAIN_CASH_ACCOUNT_ID },
  ],
};

const accounts = [
  account(MAIN_CASH_ACCOUNT_ID, 'Caja Principal', 'cash', 1_000),
  account(LAYAWAY_RESERVE_ACCOUNT_ID, 'Caja Separados', 'cash', 300),
  account('bank-1', 'Bancolombia', 'bank', 500),
  account('wallet-1', 'Nequi', 'wallet', 200),
];

describe('Dashboard financiero y reserva de separados', () => {
  it('separa Caja Principal, Caja Separados, Bancos y Total Disponible', () => {
    const position = buildFinancialPosition({ accounts, movements: [], layaways: [pendingLayaway] });

    // El pago heredado estaba incluido en Caja Principal y debe mostrarse como reservado.
    expect(position.mainCash).toBe(900);
    expect(position.layawayReserve).toBe(400);
    expect(position.banks).toBe(700);
    expect(position.totalAvailable).toBe(1_600);
    expect(position.bankAccounts.map(item => item.name)).toEqual(['Bancolombia', 'Nequi']);
  });

  it('no descuenta dos veces los pagos que ya entraron a Caja Separados', () => {
    const position = buildFinancialPosition({
      accounts,
      movements: [movement({
        destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationBalanceBefore: 200,
        destinationBalanceAfter: 300,
      })],
      layaways: [pendingLayaway],
    });

    expect(position.mainCash).toBe(1_000);
    expect(position.layawayReserve).toBe(300);
    expect(position.totalAvailable).toBe(1_700);
  });

  it('el snapshot no cuenta abonos pendientes como ingreso de Caja Principal', () => {
    const snapshot = buildDashboardSnapshot({
      products: [], contacts: [], invoices: [], purchases: [], expenses: [],
      layaways: [pendingLayaway], cashSessions: [], accounts,
      movements: [
        movement({ id: 'opening-main', type: 'opening_balance', amount: 1_000, destinationAccountId: MAIN_CASH_ACCOUNT_ID, destinationBalanceBefore: 0, destinationBalanceAfter: 1_000, documentType: 'financial_account', documentId: MAIN_CASH_ACCOUNT_ID, movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: MAIN_CASH_ACCOUNT_ID }),
        movement({ id: 'opening-bank', type: 'opening_balance', amount: 500, destinationAccountId: 'bank-1', destinationBalanceBefore: 0, destinationBalanceAfter: 500, documentType: 'financial_account', documentId: 'bank-1', movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: 'bank-1' }),
        movement({ id: 'opening-wallet', type: 'opening_balance', amount: 200, destinationAccountId: 'wallet-1', destinationBalanceBefore: 0, destinationBalanceAfter: 200, documentType: 'financial_account', documentId: 'wallet-1', movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: 'wallet-1' }),
        movement({ id: 'opening-layaway', type: 'opening_balance', amount: 200, destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID, destinationBalanceBefore: 0, destinationBalanceAfter: 200, documentType: 'financial_account', documentId: LAYAWAY_RESERVE_ACCOUNT_ID, movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: LAYAWAY_RESERVE_ACCOUNT_ID }),
        movement({ destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID, destinationBalanceBefore: 200, destinationBalanceAfter: 300, movementCode: 'LAYAWAY_PAYMENT', referenceType: 'LAYAWAY', referenceId: 'lay-1' }),
      ],
      financialSummary: null, backupStatusAvailable: false,
      now: new Date('2026-07-21T12:00:00'),
    });

    expect('cash' in snapshot).toBe(false);
    expect(snapshot.financialPosition).toMatchObject({
      mainCash: 1_000,
      layawayReserve: 300,
      banks: 700,
      totalAvailable: 1_700,
      mainCashStatus: 'RECONCILED',
    });
  });
});
