import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, describe, expect, it } from 'vitest';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function post<T = Record<string, unknown>>(url: string, body: Record<string, unknown>) {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Connection: 'close' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { success?: boolean; error?: string };
  return { response, payload };
}

function serverOptions(userDataPath: string, port: number, sessionDurationDays = 30) {
  return {
    host: '127.0.0.1',
    port,
    serverName: 'Servidor sesiones persistentes',
    userDataPath,
    version: '2.1',
    sessionPolicy: {
      inactiveMs: 10,
      timeoutMs: 20,
      retentionMs: 25,
      sessionDurationDays,
    },
    authenticateUser: async (username: string, password: string) => username === 'master' && password === 'ok'
      ? { success: true, userId: 'u1', username, displayName: 'Maestro', role: 'master', permissions: ['view_reports', 'manage_products', 'create_sales'] }
      : { success: false },
    executeRepositoryCall: async (method: string) => ({ method, restored: true }),
  };
}

async function registerAndLogin(base: string, deviceInstanceId = 'persistent-device') {
  const registration = await post<{ clientId: string; sessionToken: string }>(`${base}/client/register`, {
    deviceInstanceId,
    name: 'PC Cliente',
    hostname: 'pc-cliente',
    ip: '192.168.20.12',
    version: '2.1',
    localTime: new Date().toISOString(),
    rememberDevice: true,
  });
  expect(registration.response.status).toBe(201);

  const login = await post<{
    authToken: string;
    createdAt: string;
    lastActivity: string;
    expiresAt: string;
    rememberDevice: boolean;
  }>(`${base}/login`, {
    username: 'master',
    password: 'ok',
    clientId: registration.payload.clientId,
    sessionToken: registration.payload.sessionToken,
    rememberDevice: true,
  });
  expect(login.response.status).toBe(200);
  return { ...registration.payload, ...login.payload, deviceInstanceId };
}

function agePersistedConnection(userDataPath: string, milliseconds: number): void {
  const runtimePath = path.join(userDataPath, 'lan-runtime-state.json');
  const payload = JSON.parse(fs.readFileSync(runtimePath, 'utf8')) as {
    clients: Array<Record<string, unknown>>;
    userSessions: Array<Record<string, unknown>>;
  };
  const old = new Date(Date.now() - milliseconds).toISOString();
  for (const client of payload.clients) {
    client.lastHeartbeat = old;
    client.lastActivity = old;
    client.status = 'connected';
    client.expiredAt = null;
  }
  fs.writeFileSync(runtimePath, JSON.stringify(payload), 'utf8');
}

describe('JOYACONTROL LAN V2.2 persistent authentication sessions', () => {
  afterEach(async () => {
    await stopLanServer();
  });

  it('stores createdAt, lastActivity, expiresAt and rememberDevice with a configurable 30-day default', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-fields-'));
    const port = 52000 + Math.floor(Math.random() * 500);
    const base = `http://127.0.0.1:${port}`;
    await startLanServer(serverOptions(userDataPath, port));

    const session = await registerAndLogin(base);
    expect(session.rememberDevice).toBe(true);
    expect(new Date(session.createdAt).getTime()).toBeLessThanOrEqual(new Date(session.lastActivity).getTime());
    const durationDays = (new Date(session.expiresAt).getTime() - new Date(session.createdAt).getTime()) / 86_400_000;
    expect(durationDays).toBeCloseTo(30, 5);
    expect(getLanServerState()).toMatchObject({ sessionDurationDays: 30 });

    const runtime = JSON.parse(fs.readFileSync(path.join(userDataPath, 'lan-runtime-state.json'), 'utf8')) as {
      clients: Array<Record<string, unknown>>;
      userSessions: Array<Record<string, unknown>>;
    };
    expect(runtime.clients[0]).toMatchObject({
      clientId: session.clientId,
      rememberDevice: true,
    });
    expect(runtime.clients[0].createdAt).toBeTruthy();
    expect(runtime.clients[0].expiresAt).toBeTruthy();
    expect(runtime.userSessions[0]).toMatchObject({
      authToken: session.authToken,
      rememberDevice: true,
    });
    expect(runtime.userSessions[0].createdAt).toBeTruthy();
    expect(runtime.userSessions[0].expiresAt).toBeTruthy();
  });

  it.each([
    ['10 seconds', 10_000],
    ['5 minutes', 5 * 60_000],
    ['1 hour', 60 * 60_000],
  ])('keeps authentication valid after a simulated %s network loss', async (_label, offlineMs) => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-offline-'));
    const port = 52500 + Math.floor(Math.random() * 500);
    const base = `http://127.0.0.1:${port}`;
    const options = serverOptions(userDataPath, port);
    await startLanServer(options);
    const session = await registerAndLogin(base, `device-${offlineMs}`);

    await stopLanServer();
    agePersistedConnection(userDataPath, offlineMs);
    await startLanServer(options);

    const reconnect = await post(`${base}/client/reconnect`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      deviceInstanceId: session.deviceInstanceId,
      ip: '192.168.20.80',
    });
    expect(reconnect.response.status).toBe(200);
    expect(reconnect.payload).toMatchObject({
      clientId: session.clientId,
      sessionToken: session.sessionToken,
    });

    const restore = await post(`${base}/auth/restore`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      authToken: session.authToken,
    });
    expect(restore.response.status).toBe(200);
    expect(restore.payload).toMatchObject({ authToken: session.authToken, userId: 'u1' });

    const ping = await post(`${base}/client/ping`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      timestamp: new Date().toISOString(),
    });
    expect(ping.response.status).toBe(200);
  });

  it('does not let a heartbeat timeout destroy an otherwise valid authentication session', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-heartbeat-'));
    const port = 53000 + Math.floor(Math.random() * 500);
    const base = `http://127.0.0.1:${port}`;
    await startLanServer(serverOptions(userDataPath, port));
    const session = await registerAndLogin(base);

    await new Promise(resolve => setTimeout(resolve, 35));
    const clients = await fetch(`${base}/clients`).then(response => response.json()) as { clients: Array<{ status: string }> };
    expect(clients.clients[0].status).toBe('disconnected');

    const ping = await post(`${base}/client/ping`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      timestamp: new Date().toISOString(),
    });
    expect(ping.response.status).toBe(200);

    const restore = await post(`${base}/auth/restore`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      authToken: session.authToken,
    });
    expect(restore.response.status).toBe(200);
  });

  it('persists the same client and authenticated session across a server restart', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-restart-'));
    const port = 53500 + Math.floor(Math.random() * 500);
    const base = `http://127.0.0.1:${port}`;
    const options = serverOptions(userDataPath, port);
    await startLanServer(options);
    const session = await registerAndLogin(base);

    await stopLanServer();
    await startLanServer(options);

    const reconnect = await post(`${base}/client/reconnect`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      deviceInstanceId: session.deviceInstanceId,
      ip: '192.168.20.18',
    });
    expect(reconnect.response.status).toBe(200);

    const restore = await post(`${base}/auth/restore`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      authToken: session.authToken,
    });
    expect(restore.response.status).toBe(200);
    expect(restore.payload).toMatchObject({ authToken: session.authToken });
  });


  it('keeps Dashboard, Inventory and Sales repository calls authenticated after server restart', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-modules-'));
    const port = 53750 + Math.floor(Math.random() * 200);
    const base = `http://127.0.0.1:${port}`;
    const options = serverOptions(userDataPath, port);
    await startLanServer(options);
    const session = await registerAndLogin(base, 'modules-device');

    await stopLanServer();
    await startLanServer(options);

    const reconnect = await post(`${base}/client/reconnect`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      deviceInstanceId: session.deviceInstanceId,
      ip: '192.168.20.55',
    });
    expect(reconnect.response.status).toBe(200);

    const restore = await post(`${base}/auth/restore`, {
      clientId: session.clientId,
      sessionToken: session.sessionToken,
      authToken: session.authToken,
    });
    expect(restore.response.status).toBe(200);

    for (const method of ['getDashboardMetrics', 'getProducts', 'getSalesWorkspace']) {
      const repositoryCall = await post<{ data?: { method?: string; restored?: boolean } }>(`${base}/repository/call`, {
        method,
        args: {},
        clientId: session.clientId,
        sessionToken: session.sessionToken,
        authToken: session.authToken,
      });
      expect(repositoryCall.response.status).toBe(200);
      expect(repositoryCall.payload.data).toEqual({ method, restored: true });
    }
  });

  it('destroys authentication on manual logout and only expires sessions at the real expiresAt boundary', async () => {
    const logoutDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-logout-'));
    const logoutPort = 54000 + Math.floor(Math.random() * 200);
    const logoutBase = `http://127.0.0.1:${logoutPort}`;
    await startLanServer(serverOptions(logoutDataPath, logoutPort));
    const logoutSession = await registerAndLogin(logoutBase);

    const logout = await post(`${logoutBase}/logout`, {
      clientId: logoutSession.clientId,
      sessionToken: logoutSession.sessionToken,
      authToken: logoutSession.authToken,
    });
    expect(logout.response.status).toBe(200);
    const restoreAfterLogout = await post(`${logoutBase}/auth/restore`, {
      clientId: logoutSession.clientId,
      sessionToken: logoutSession.sessionToken,
      authToken: logoutSession.authToken,
    });
    expect(restoreAfterLogout.response.status).toBe(401);
    expect(restoreAfterLogout.payload.error).toBe('LAN_INVALID_AUTH_TOKEN');

    await stopLanServer();
    const expiryDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-expiry-'));
    const expiryPort = 54250 + Math.floor(Math.random() * 200);
    const expiryBase = `http://127.0.0.1:${expiryPort}`;
    await startLanServer(serverOptions(expiryDataPath, expiryPort, 0.0000001));
    const expiringSession = await registerAndLogin(expiryBase, 'expiring-device');
    await new Promise(resolve => setTimeout(resolve, 20));

    const expiredReconnect = await post(`${expiryBase}/client/reconnect`, {
      clientId: expiringSession.clientId,
      sessionToken: expiringSession.sessionToken,
      deviceInstanceId: expiringSession.deviceInstanceId,
    });
    expect(expiredReconnect.response.status).toBe(401);
    expect(expiredReconnect.payload.error).toBe('LAN_SESSION_EXPIRED');
  });

  it('keeps two simultaneous remembered LAN clients without duplicating sessions', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan22-multiple-'));
    const port = 54500 + Math.floor(Math.random() * 200);
    const base = `http://127.0.0.1:${port}`;
    await startLanServer(serverOptions(userDataPath, port));

    const first = await registerAndLogin(base, 'device-one');
    const second = await registerAndLogin(base, 'device-two');
    expect(first.clientId).not.toBe(second.clientId);

    const clients = await fetch(`${base}/clients`).then(response => response.json()) as { clients: unknown[] };
    const users = await fetch(`${base}/users`).then(response => response.json()) as { users: unknown[] };
    expect(clients.clients).toHaveLength(2);
    expect(users.users).toHaveLength(2);
  });
});
