// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { getLanServerState, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return await new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}
const post = (url: string, body: object) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json', Connection: 'close' }, body: JSON.stringify(body) });
let userDataPath = '';
afterEach(async () => { await stopLanServer(); if (userDataPath) fs.rmSync(userDataPath, { recursive: true, force: true }); userDataPath = ''; });

describe('QA LAN estabilidad física simulada', () => {
  it('reconecta diez veces con el mismo clientId/sessionToken y un solo registro', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-physical-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Físico', userDataPath, version: '2.1', sessionPolicy: { inactiveMs: 20, timeoutMs: 40, retentionMs: 60_000 } });
    const base = `http://127.0.0.1:${port}`;
    const deviceInstanceId = 'device-office-stable';
    const registered = await post(`${base}/client/register`, { deviceInstanceId, name: 'PC Oficina', hostname: 'pc-oficina', ip: '192.168.1.20', version: '2.1', localTime: new Date().toISOString() });
    const session = await registered.json() as { clientId: string; sessionToken: string };
    for (let i = 0; i < 10; i += 1) {
      await new Promise(resolve => setTimeout(resolve, 45));
      const reconnect = await post(`${base}/client/reconnect`, { clientId: session.clientId, sessionToken: session.sessionToken, deviceInstanceId, ip: `192.168.1.${20 + i}` });
      expect(reconnect.status).toBe(200);
      const restored = await reconnect.json() as { clientId: string; sessionToken: string };
      expect(restored.clientId).toBe(session.clientId);
      expect(restored.sessionToken).toBe(session.sessionToken);
      const ping = await post(`${base}/client/ping`, { clientId: session.clientId, sessionToken: session.sessionToken, timestamp: new Date().toISOString() });
      expect(ping.status).toBe(200);
    }
    const clients = await (await fetch(`${base}/clients`)).json() as { clients: Array<{ clientId: string; activityCount: number }> };
    expect(clients.clients).toHaveLength(1);
    expect(clients.clients[0].clientId).toBe(session.clientId);
    expect(clients.clients[0].activityCount).toBe(10);
    expect(getLanServerState().heartbeatsReceived).toBe(10);
  });

  it('persiste la sesión del equipo al reiniciar el servidor', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-restart-'));
    const base = `http://127.0.0.1:${port}`;
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Reinicio', userDataPath, version: '2.1' });
    const registered = await post(`${base}/client/register`, { deviceInstanceId: 'device-restart', name: 'PC Oficina', hostname: 'pc-oficina', ip: '192.168.1.20', version: '2.1', localTime: new Date().toISOString() });
    const session = await registered.json() as { clientId: string; sessionToken: string };
    await post(`${base}/client/ping`, { ...session, timestamp: new Date().toISOString() });
    await stopLanServer();
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Reinicio', userDataPath, version: '2.1' });
    await new Promise(resolve => setTimeout(resolve, 25));
    const reconnect = await post(`${base}/client/reconnect`, { ...session, ip: '192.168.1.55' });
    expect(reconnect.status).toBe(200);
    const restored = await reconnect.json() as { clientId: string; sessionToken: string };
    expect(restored).toMatchObject(session);
    const clients = await (await fetch(`${base}/clients`)).json() as { clients: unknown[] };
    expect(clients.clients).toHaveLength(1);
  });

  it('deduplica el registro del mismo equipo por deviceInstanceId', async () => {
    const port = await freePort();
    userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan-dedupe-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor Dedupe', userDataPath, version: '2.1' });
    const base = `http://127.0.0.1:${port}`;
    const body = { deviceInstanceId: 'same-device', name: 'PC Oficina', hostname: 'pc-oficina', ip: '192.168.1.20', version: '2.1', localTime: new Date().toISOString() };
    const first = await (await post(`${base}/client/register`, body)).json() as { clientId: string; sessionToken: string };
    const second = await (await post(`${base}/client/register`, { ...body, ip: '192.168.1.99' })).json() as { clientId: string; sessionToken: string };
    expect(second).toMatchObject(first);
    const clients = await (await fetch(`${base}/clients`)).json() as { clients: unknown[] };
    expect(clients.clients).toHaveLength(1);
  });
});
