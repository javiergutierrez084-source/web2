// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import net from 'node:net';
import os from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { drainLanActivityEvents, startLanServer, stopLanServer } from '../../electron/lanServer.js';

async function freePort(): Promise<number> { return await new Promise((resolve, reject) => { const socket = net.createServer(); socket.listen(0, '127.0.0.1', () => { const address = socket.address(); if (!address || typeof address === 'string') return reject(new Error('NO_PORT')); socket.close(error => error ? reject(error) : resolve(address.port)); }); socket.on('error', reject); }); }
const post = (url: string, body: object) => fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

describe('LAN 1.4 user authentication', () => {
  let baseUrl = ''; let userDataPath = '';
  let repositoryCalls: Array<{ method: string; args: Record<string, unknown> }> = [];
  beforeEach(async () => {
    repositoryCalls = [];
    const port = await freePort(); userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joyacontrol-lan14-'));
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor QA', userDataPath, version: '2.1', allowMultipleUserSessions: false,
      authenticateUser: async (username: string, password: string) => username === 'maestro' && password === 'correcta'
        ? { success: true, userId: 'u1', username: 'maestro', displayName: 'Maestro', role: 'master', permissions: ['manage_settings'] }
        : { success: false, error: 'INVALID_CREDENTIALS' },
      executeRepositoryCall: async (method: string, args: Record<string, unknown>) => {
        repositoryCalls.push({ method, args });
        return null;
      },
    });
    baseUrl = `http://127.0.0.1:${port}`;
  });
  afterEach(async () => { await stopLanServer(); drainLanActivityEvents(); fs.rmSync(userDataPath, { recursive: true, force: true }); });
  async function register(index: number) { const response = await post(`${baseUrl}/client/register`, { name: `Equipo ${index}`, hostname: `eq-${index}`, ip: `192.168.1.${index}`, version: '2.1', localTime: new Date().toISOString() }); return await response.json(); }
  it('logs in, restores and logs out without disconnecting device heartbeat', async () => {
    const client = await register(1);
    const login = await post(`${baseUrl}/login`, { username: 'maestro', password: 'correcta', clientId: client.clientId, sessionToken: client.sessionToken });
    expect(login.status).toBe(200); const auth = await login.json(); expect(auth.authToken).toBeTruthy(); expect(auth.authToken).not.toBe(client.sessionToken);
    const restore = await post(`${baseUrl}/auth/restore`, { clientId: client.clientId, sessionToken: client.sessionToken, authToken: auth.authToken }); expect(restore.status).toBe(200);
    const logout = await post(`${baseUrl}/logout`, { clientId: client.clientId, sessionToken: client.sessionToken, authToken: auth.authToken }); expect(logout.status).toBe(200);
    const ping = await post(`${baseUrl}/client/ping`, { clientId: client.clientId, sessionToken: client.sessionToken, timestamp: new Date().toISOString() }); expect(ping.status).toBe(200);
    const users = await (await fetch(`${baseUrl}/users`)).json(); expect(users.users[0].status).toBe('disconnected');
  });
  it('rejects bad credentials and blocks duplicate login when policy is single-session', async () => {
    const c1 = await register(1); const c2 = await register(2);
    const bad = await post(`${baseUrl}/login`, { username: 'maestro', password: 'mala', clientId: c1.clientId, sessionToken: c1.sessionToken }); expect(bad.status).toBe(401);
    const first = await post(`${baseUrl}/login`, { username: 'maestro', password: 'correcta', clientId: c1.clientId, sessionToken: c1.sessionToken }); expect(first.status).toBe(200);
    const duplicate = await post(`${baseUrl}/login`, { username: 'maestro', password: 'correcta', clientId: c2.clientId, sessionToken: c2.sessionToken }); expect(duplicate.status).toBe(409);
    const blocked = await duplicate.json();
    expect(blocked.error).toBe('LAN_DUPLICATE_LOGIN_BLOCKED');
    expect(blocked.duplicateSession).toMatchObject({
      username: 'maestro',
      source: { clientId: c1.clientId, machineId: c1.machineId, deviceName: 'Equipo 1', hostname: 'eq-1' },
    });
    expect(blocked.duplicateSession.source).toHaveProperty('ip');
    expect(blocked.duplicateSession.source).toHaveProperty('lastHeartbeat');
    expect(blocked.duplicateSession.source).toHaveProperty('inactiveForMs');
    expect(drainLanActivityEvents().some(event => event.action === 'LAN_DUPLICATE_LOGIN_BLOCKED')).toBe(true);
  });

  it('transfers the single active user session, invalidates the old token and records SESSION_TRANSFER', async () => {
    const c1 = await register(1); const c2 = await register(2);
    const firstResponse = await post(`${baseUrl}/login`, {
      username: 'maestro', password: 'correcta', clientId: c1.clientId, sessionToken: c1.sessionToken,
    });
    const first = await firstResponse.json();

    const blockedResponse = await post(`${baseUrl}/login`, {
      username: 'maestro', password: 'correcta', clientId: c2.clientId, sessionToken: c2.sessionToken,
    });
    const blocked = await blockedResponse.json();

    const transferResponse = await post(`${baseUrl}/login`, {
      username: 'maestro',
      password: 'correcta',
      clientId: c2.clientId,
      sessionToken: c2.sessionToken,
      transferExistingSession: true,
      expectedSourceClientId: blocked.duplicateSession.source.clientId,
      expectedSourceMachineId: blocked.duplicateSession.source.machineId,
    });
    expect(transferResponse.status).toBe(200);
    const transferred = await transferResponse.json();
    expect(transferred.transferred).toBe(true);
    expect(transferred.authToken).toBeTruthy();
    expect(transferred.authToken).not.toBe(first.authToken);

    const oldRestore = await post(`${baseUrl}/auth/restore`, {
      clientId: c1.clientId,
      sessionToken: c1.sessionToken,
      authToken: first.authToken,
    });
    expect(oldRestore.status).toBe(401);
    expect((await oldRestore.json()).error).toBe('LAN_INVALID_AUTH_TOKEN');

    const newRestore = await post(`${baseUrl}/auth/restore`, {
      clientId: c2.clientId,
      sessionToken: c2.sessionToken,
      authToken: transferred.authToken,
    });
    expect(newRestore.status).toBe(200);

    const audit = repositoryCalls.find(call => call.method === 'logActivity');
    expect(audit?.args).toMatchObject({ action: 'SESSION_TRANSFER', entity: 'lan_auth_session' });
    const detail = JSON.parse(String(audit?.args.detail || '{}'));
    expect(detail).toMatchObject({
      user: { userId: 'u1', username: 'maestro' },
      sourceDevice: 'Equipo 1',
      destinationDevice: 'Equipo 2',
      sourceMachineId: c1.machineId,
      destinationMachineId: c2.machineId,
      sourceClientId: c1.clientId,
      destinationClientId: c2.clientId,
    });
    expect(detail.date).toBeTruthy();

    const users = await (await fetch(`${baseUrl}/users`)).json();
    expect(users.users.filter((item: { status: string }) => item.status === 'connected')).toHaveLength(1);
    expect(users.users[0].clientId).toBe(c2.clientId);
  });
});
