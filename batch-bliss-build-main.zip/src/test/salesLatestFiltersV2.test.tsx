// @vitest-environment jsdom
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Invoice } from '@/data/mockData';

const mocks = vi.hoisted(() => ({
  querySales: vi.fn(),
}));

const older: Invoice = {
  id: 'old', number: 'FAC-001', clientId: 'c1', clientName: 'Ana',
  subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-01', status: 'paid',
  paymentMethod: 'Efectivo', items: [],
};
const newer: Invoice = {
  ...older, id: 'new', number: 'FAC-002', clientName: 'Beatriz', date: '2026-07-21', total: 200,
};

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
    invoices: [older, newer],
    contacts: [
      { id: 'c1', type: 'client', name: 'Ana', document: '1', phone: '', email: '', address: '' },
    ],
    layaways: [], products: [],
    financialAccounts: [{ id: 'account-caja-principal', name: 'Caja Principal', kind: 'cash', active: true, balance: 0, createdAt: '', updatedAt: '' }],
    financialMovements: [],
    recordLayawayPayment: vi.fn(), completeLayaway: vi.fn(), updateLayaway: vi.fn(), deleteLayaway: vi.fn(), cancelInvoice: vi.fn(),
  }),
}));
vi.mock('@/contexts/AuthContext', () => ({ useAuth: () => ({ user: { username: 'admin', displayName: 'Admin' } }) }));
vi.mock('@/hooks/use-toast', () => ({ useToast: () => ({ toast: vi.fn() }) }));
vi.mock('@/lib/SalesRepositoryService', () => ({ SalesRepositoryService: { querySales: mocks.querySales } }));
vi.mock('@/components/InvoicePreview', () => ({ default: () => null }));
vi.mock('@/components/PdfDocumentActions', () => ({ default: () => null }));
vi.mock('@/components/DirectPdfActionButton', () => ({ default: () => null }));
vi.mock('@/components/ExcelExportButton', () => ({ default: () => null }));
vi.mock('@/components/ClientSearchCombobox', () => ({ default: () => null }));

import Sales from '@/pages/Sales';

describe('Ventas: últimas ventas y filtros Repository', () => {
  beforeEach(() => {
    mocks.querySales.mockReset().mockResolvedValue([newer, older]);
  });

  it('carga automáticamente por fecha descendente y envía búsqueda, estado y calendario al Repository', async () => {
    render(<MemoryRouter><Sales /></MemoryRouter>);

    await waitFor(() => expect(mocks.querySales).toHaveBeenCalledWith({
      text: undefined, status: undefined, dateFrom: undefined, dateTo: undefined,
    }));

    const rows = screen.getAllByRole('row');
    expect(rows[1].textContent).toContain('FAC-002');
    expect(rows[2].textContent).toContain('FAC-001');

    fireEvent.change(screen.getByPlaceholderText('Buscar por cliente o número...'), { target: { value: 'Beatriz' } });
    fireEvent.change(screen.getAllByRole('combobox')[0], { target: { value: 'paid' } });
    const dateInputs = document.querySelectorAll<HTMLInputElement>('input[type="date"]');
    fireEvent.change(dateInputs[0], { target: { value: '2026-07-10' } });
    fireEvent.change(dateInputs[1], { target: { value: '2026-07-31' } });

    await waitFor(() => expect(mocks.querySales).toHaveBeenLastCalledWith({
      text: 'Beatriz', status: 'paid', dateFrom: '2026-07-10', dateTo: '2026-07-31',
    }));
  });
});
