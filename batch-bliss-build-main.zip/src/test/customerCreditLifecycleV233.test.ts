// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  cancelInvoice,
  deleteLayaway,
  ensureDefaultFinancialAccounts,
  fetchFinancialAccounts,
  fetchFinancialMovements,
  fetchInvoices,
  insertInvoiceWithFinancials,
  insertLayaway,
} from '@/repositories/dexieDataSource';
import { buildCustomerCreditSummaries, getCustomerCreditBalance } from '@/lib/CustomerCreditService';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';
import type { Invoice } from '@/data/mockData';
import type { Layaway } from '@/domain/models';

const now = '2026-07-21T12:00:00.000Z';
const user = {
  id: 'credit-user', username: 'credit', display_name: 'Crédito', password_hash: '',
  role: 'master' as const, active: true, created_at: now, last_login: null,
};

const invoice = (id: string, total: number): Invoice => ({
  id,
  number: `FAC-${id}`,
  clientId: 'client-credit',
  clientName: 'Cliente Crédito',
  subtotal: total,
  discount: 0,
  tax: 0,
  total,
  date: '2026-07-21',
  status: 'paid',
  paymentMethod: 'Saldo a favor',
  items: [{
    productId: 'product-credit', code: 'CR-1', name: 'Producto Crédito', quantity: 1,
    weightGrams: 10, unitPrice: total, subtotal: total, costPrice: 50,
  }],
});

const creditLayaway = (): Layaway => ({
  id: 'layaway-credit-source',
  invoiceId: 'invoice-credit-source',
  completed: false,
  invoice: {
    ...invoice('invoice-credit-source', 850),
    number: 'SEP-0001',
    status: 'pending',
  },
  payments: [{
    id: 'payment-credit-source', amount: 850, date: '2026-07-21', method: 'Efectivo',
    accountId: MAIN_CASH_ACCOUNT_ID,
  }],
});

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.contacts.put({
    id: 'client-credit', type: 'client', name: 'Cliente Crédito', document: '100', phone: '', email: '', address: '', notes: '', created_at: now,
  });
  await localDb.products.put({
    id: 'product-credit', code: 'CR-1', name: 'Producto Crédito', category: 'General',
    purchase_price: 50, sale_price: 850, weight_grams: 10, margin: 100,
    stock: 10, min_stock: 1, description: '', supplier_ids: [], created_at: now,
    reference: 'CR-1', available_grams: 100, average_purchase_price: 50, last_purchase_date: '',
  });
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
  await ensureDefaultFinancialAccounts();
  const layaway = creditLayaway();
  await insertLayaway(layaway);
  await deleteLayaway(layaway.id, 'credit');
});

describe('JOYACONTROL LAN V2.3.3 - ciclo de saldo a favor', () => {
  it('reconstruye el saldo exclusivamente desde CUSTOMER_CREDIT y CUSTOMER_CREDIT_USED', async () => {
    const movements = await fetchFinancialMovements();
    const credit = movements.find(item => item.movementCode === 'CUSTOMER_CREDIT');
    expect(credit).toMatchObject({ amount: 850, customerId: 'client-credit', status: 'COMPLETED' });
    expect(getCustomerCreditBalance(movements, 'client-credit')).toBe(850);
    expect(buildCustomerCreditSummaries(movements)[0]).toMatchObject({ created: 850, used: 0, available: 850 });
  });

  it('permite uso parcial, uso total en múltiples ventas e impide exceder el disponible', async () => {
    await insertInvoiceWithFinancials(invoice('credit-sale-1', 600), [], {
      customerCredit: { customerId: 'client-credit', amount: 600 },
    });
    let movements = await fetchFinancialMovements();
    expect(getCustomerCreditBalance(movements, 'client-credit')).toBe(250);

    await insertInvoiceWithFinancials(
      invoice('credit-sale-2', 400),
      [{ accountId: MAIN_CASH_ACCOUNT_ID, amount: 150, paymentMethod: 'Efectivo' }],
      { customerCredit: { customerId: 'client-credit', amount: 250 } },
    );
    movements = await fetchFinancialMovements();
    const used = movements.filter(item => item.movementCode === 'CUSTOMER_CREDIT_USED');
    expect(used).toHaveLength(2);
    expect(used.reduce((sum, item) => sum + item.amount, 0)).toBe(850);
    expect(used.every(item => item.relatedMovementId && item.customerId === 'client-credit')).toBe(true);
    expect(getCustomerCreditBalance(movements, 'client-credit')).toBe(0);

    await expect(insertInvoiceWithFinancials(invoice('credit-sale-overuse', 100), [], {
      customerCredit: { customerId: 'client-credit', amount: 100 },
    })).rejects.toThrow('CUSTOMER_CREDIT_EXCEEDS_AVAILABLE');
    expect((await fetchInvoices()).some(item => item.id === 'credit-sale-overuse')).toBe(false);

    const accounts = await fetchFinancialAccounts();
    expect(accounts.find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(0);
    expect(accounts.find(item => item.id === MAIN_CASH_ACCOUNT_ID)?.balance).toBe(1_000);
  });

  it('restaura el saldo al anular una venta pagada con crédito sin duplicar movimientos', async () => {
    await insertInvoiceWithFinancials(invoice('credit-sale-cancel', 600), [], {
      customerCredit: { customerId: 'client-credit', amount: 600 },
    });
    expect(getCustomerCreditBalance(await fetchFinancialMovements(), 'client-credit')).toBe(250);

    await cancelInvoice('credit-sale-cancel', 'Cliente solicita anulación');
    const movements = await fetchFinancialMovements();
    expect(getCustomerCreditBalance(movements, 'client-credit')).toBe(850);
    expect(movements.filter(item => item.movementCode === 'CUSTOMER_CREDIT_USED')).toHaveLength(1);
    expect(movements.find(item => item.movementCode === 'CUSTOMER_CREDIT_USED')?.status).toBe('REVERSED');
    expect(movements.filter(item => item.movementCode === 'REVERSAL' && item.documentId === 'credit-sale-cancel')).toHaveLength(1);

    await expect(cancelInvoice('credit-sale-cancel', 'Segundo intento')).rejects.toThrow('INVOICE_ALREADY_CANCELLED');
    expect((await fetchFinancialMovements()).filter(item => item.movementCode === 'REVERSAL' && item.documentId === 'credit-sale-cancel')).toHaveLength(1);
  });
});
