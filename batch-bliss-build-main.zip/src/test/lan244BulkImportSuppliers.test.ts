// @vitest-environment jsdom
import * as XLSX from 'xlsx';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Contact } from '@/data/mockData';
import type { BulkImportProductRecord, CategoryRecord, ContactChangeSet } from '@/domain/models';
import { setSession } from '@/lib/authCore';
import {
  buildImportTemplateWorkbook,
  runBulkImport,
  type BulkImportRepository,
} from '@/lib/bulkImport';

class MemoryBulkImportRepository implements BulkImportRepository {
  contacts: Contact[];
  categories: CategoryRecord[];
  products: BulkImportProductRecord[] = [];

  fetchContacts = vi.fn(async (): Promise<Contact[]> => this.contacts.map(contact => ({ ...contact })));
  fetchCategories = vi.fn(async (): Promise<CategoryRecord[]> => this.categories.map(category => ({ ...category })));
  applyContactChanges = vi.fn(async (changes: ContactChangeSet<Contact>): Promise<void> => {
    const byId = new Map(this.contacts.map(contact => [contact.id, contact]));
    changes.upserts.forEach(contact => byId.set(contact.id, { ...contact }));
    changes.deleteIds.forEach(id => byId.delete(id));
    this.contacts = Array.from(byId.values());
  });
  bulkPutCategories = vi.fn(async (categories: CategoryRecord[]): Promise<void> => {
    const byId = new Map(this.categories.map(category => [category.id, category]));
    categories.forEach(category => byId.set(category.id, { ...category }));
    this.categories = Array.from(byId.values());
  });
  bulkPutProducts = vi.fn(async (products: BulkImportProductRecord[]): Promise<void> => {
    this.products.push(...products.map(product => ({ ...product, supplier_ids: [...product.supplier_ids] })));
  });

  constructor(contacts: Contact[] = [], categories: CategoryRecord[] = []) {
    this.contacts = contacts;
    this.categories = categories;
  }
}

const existingSupplier = (id: string, name: string): Contact => ({
  id,
  type: 'supplier',
  name,
  document: '',
  phone: '',
  email: '',
  address: '',
});

const baseRow = (code: string, supplier: string) => ({
  Codigo: code,
  Nombre: `Producto ${code}`,
  Categoria: 'Anillos',
  Proveedor: supplier,
  'Precio Compra': 100,
  'Precio Venta': 150,
  Peso: 1,
  Stock: 1,
  'Stock Minimo': 0,
});

function deterministicIds() {
  let value = 0;
  return () => `generated-${++value}`;
}

describe('JoyaControl LAN v2.4.4 - carga masiva con proveedores', () => {
  beforeEach(() => {
    sessionStorage.clear();
    setSession({ id: 'master-1', username: 'master', displayName: 'Maestro', role: 'master' });
  });

  it('reutiliza proveedores existentes ignorando mayúsculas, acentos y espacios', async () => {
    const repository = new MemoryBulkImportRepository([
      existingSupplier('supplier-1', 'Joyas La 70'),
    ]);

    const { summary, newProducts } = await runBulkImport(
      [baseRow('P-1', '  JOYAS   LA 70  '), baseRow('P-2', 'joyas la 70')],
      new Set(),
      undefined,
      { repository, idFactory: deterministicIds() },
    );

    expect(summary).toMatchObject({ productsImported: 2, providersCreated: 0, providersReused: 1 });
    expect(repository.fetchContacts).toHaveBeenCalledTimes(1);
    expect(repository.applyContactChanges).not.toHaveBeenCalled();
    expect(newProducts.map(product => product.supplier_ids)).toEqual([
      ['supplier-1'],
      ['supplier-1'],
    ]);
  });

  it('crea una sola vez un proveedor nuevo repetido y asocia todos los productos', async () => {
    const repository = new MemoryBulkImportRepository();

    const { summary, newProducts } = await runBulkImport(
      [
        baseRow('P-1', 'Oro Medellín'),
        baseRow('P-2', ' oro   medellín '),
        baseRow('P-3', 'ORO MEDELLIN'),
      ],
      new Set(),
      undefined,
      { repository, idFactory: deterministicIds() },
    );

    expect(summary.providersCreated).toBe(1);
    expect(summary.providersCreatedNames).toEqual(['Oro Medellín']);
    expect(repository.applyContactChanges).toHaveBeenCalledTimes(1);
    expect(repository.contacts.filter(contact => contact.type === 'supplier')).toHaveLength(1);
    const supplierIds = new Set(newProducts.flatMap(product => product.supplier_ids));
    expect(supplierIds.size).toBe(1);
  });

  it('importa mezcla de proveedores existentes, nuevos y productos sin proveedor', async () => {
    const repository = new MemoryBulkImportRepository([
      existingSupplier('supplier-existing', 'Proveedor Existente'),
    ]);

    const { summary, newProducts } = await runBulkImport(
      [
        baseRow('P-1', 'proveedor existente'),
        baseRow('P-2', 'Proveedor Nuevo'),
        baseRow('P-3', ''),
      ],
      new Set(),
      undefined,
      { repository, idFactory: deterministicIds() },
    );

    expect(summary).toMatchObject({
      productsImported: 3,
      productsUpdated: 0,
      productsOmitted: 0,
      providersCreated: 1,
      providersReused: 1,
    });
    expect(newProducts[0].supplier_ids).toEqual(['supplier-existing']);
    expect(newProducts[1].supplier_ids).toHaveLength(1);
    expect(newProducts[2].supplier_ids).toEqual([]);
  });

  it('procesa 500 productos y 100 proveedores distintos usando caché y sin duplicados', async () => {
    const existing = Array.from({ length: 50 }, (_, index) =>
      existingSupplier(`existing-${index}`, `Proveedor ${index}`),
    );
    const repository = new MemoryBulkImportRepository(existing);
    const rows = Array.from({ length: 500 }, (_, index) => {
      const supplierIndex = index % 100;
      const variant = index % 2 === 0
        ? `  PROVEEDOR   ${supplierIndex} `
        : `proveedor ${supplierIndex}`;
      return baseRow(`P-${String(index + 1).padStart(3, '0')}`, variant);
    });

    const { summary, newProducts } = await runBulkImport(
      rows,
      new Set(),
      undefined,
      { repository, idFactory: deterministicIds() },
    );

    expect(summary).toMatchObject({
      productsImported: 500,
      productsOmitted: 0,
      providersCreated: 50,
      providersReused: 50,
    });
    expect(repository.fetchContacts).toHaveBeenCalledTimes(1);
    expect(repository.applyContactChanges).toHaveBeenCalledTimes(1);
    expect(repository.bulkPutProducts).toHaveBeenCalledTimes(1);
    expect(repository.contacts.filter(contact => contact.type === 'supplier')).toHaveLength(100);
    expect(new Set(newProducts.flatMap(product => product.supplier_ids)).size).toBe(100);
    expect(newProducts.every(product => product.supplier_ids.length === 1)).toBe(true);
  });

  it('omite filas inválidas sin detener el resto del archivo', async () => {
    const repository = new MemoryBulkImportRepository();
    const invalid = { ...baseRow('BAD-1', 'Proveedor Uno'), 'Precio Venta': 0 };

    const { summary } = await runBulkImport(
      [invalid, baseRow('OK-1', 'Proveedor Dos')],
      new Set(),
      undefined,
      { repository, idFactory: deterministicIds() },
    );

    expect(summary.productsImported).toBe(1);
    expect(summary.productsOmitted).toBe(1);
    expect(summary.errors).toHaveLength(1);
    expect(repository.products).toHaveLength(1);
  });

  it('actualiza la plantilla con Proveedor, Ayuda, Ejemplos y Documentación', () => {
    const workbook = buildImportTemplateWorkbook();
    expect(workbook.SheetNames).toEqual(['Productos', 'Ayuda', 'Ejemplos', 'Documentación']);
    const products = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets.Productos);
    expect(products[0]).toHaveProperty('Proveedor', 'Oro Medellín');
    const help = XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets.Ayuda);
    expect(help.some(row => row.Campo === 'Proveedor')).toBe(true);
  });
});
