import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement, Invoice } from '@/data/mockData';
import {
  auditFinancialLedger,
  buildBankDetails,
  buildFinancialCompositions,
  buildFinancialLedgerRows,
  filterFinancialLedgerRows,
  traceFinancialMovement,
} from '@/lib/FinancialTraceabilityService';
import { MAIN_CASH_ACCOUNT_ID, LAYAWAY_RESERVE_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const accounts: FinancialAccount[] = [
  { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash', active: true, balance: 130, createdAt: '', updatedAt: '' },
  { id: LAYAWAY_RESERVE_ACCOUNT_ID, name: 'Caja Separados', kind: 'cash', active: true, balance: 0, createdAt: '', updatedAt: '' },
  { id: 'bank-1', name: 'Bancolombia', kind: 'bank', active: true, balance: 2000, createdAt: '', updatedAt: '' },
];

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 1,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'DOC',
  documentType: 'manual',
  documentId: 'doc',
  observation: 'Movimiento',
  userId: 'u1',
  userName: 'Admin',
  date: '2026-07-21',
  createdAt: '2026-07-21T10:00:00.000Z',
  movementCode: 'ADJUSTMENT',
  referenceType: 'MANUAL',
  referenceId: 'doc',
  status: 'POSTED',
  ...overrides,
});

const opening = movement({
  id: 'opening', amount: 500, destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  destinationBalanceBefore: 0, destinationBalanceAfter: 500,
  movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: MAIN_CASH_ACCOUNT_ID,
  documentType: 'financial_account', documentId: MAIN_CASH_ACCOUNT_ID, reference: 'Saldo inicial',
});
const sale = movement({
  id: 'sale-payment', type: 'sale_income', amount: 800, destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  destinationBalanceBefore: 500, destinationBalanceAfter: 1300,
  movementCode: 'SALE_PAYMENT', referenceType: 'SALE', referenceId: 'sale-1',
  documentType: 'invoice', documentId: 'sale-1', reference: 'FAC-00081', observation: 'Ana',
  createdAt: '2026-07-21T11:00:00.000Z',
});
const purchase = movement({
  id: 'purchase-payment', type: 'inventory_purchase', amount: 450, originAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 1300, originBalanceAfter: 850,
  movementCode: 'PURCHASE_PAYMENT', referenceType: 'PURCHASE', referenceId: 'purchase-1',
  documentType: 'purchase_invoice', documentId: 'purchase-1', reference: 'COM-0034', observation: 'Proveedor Oro',
  createdAt: '2026-07-21T12:00:00.000Z',
});
const expense = movement({
  id: 'expense-payment', type: 'expense', amount: 120, originAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 850, originBalanceAfter: 730,
  movementCode: 'EXPENSE', referenceType: 'EXPENSE', referenceId: 'expense-1',
  documentType: 'expense', documentId: 'expense-1', reference: 'GAS-0012', observation: 'Servicios',
  createdAt: '2026-07-21T13:00:00.000Z',
});
const transfer = movement({
  id: 'transfer-1', type: 'transfer', amount: 600, originAccountId: MAIN_CASH_ACCOUNT_ID, destinationAccountId: 'bank-1',
  originBalanceBefore: 730, originBalanceAfter: 130, destinationBalanceBefore: 1400, destinationBalanceAfter: 2000,
  movementCode: 'BANK_TRANSFER', referenceType: 'TRANSFER', referenceId: 'transfer-1',
  documentType: 'transfer', documentId: 'transfer-1', reference: 'Transferencia 1',
  createdAt: '2026-07-21T14:00:00.000Z',
});

const invoice: Invoice = {
  id: 'sale-1', number: 'FAC-00081', clientId: 'client-1', clientName: 'Ana', items: [],
  subtotal: 800, discount: 0, tax: 0, total: 800, date: '2026-07-21', status: 'paid', paymentMethod: 'Efectivo',
};

const input = {
  accounts,
  movements: [opening, sale, purchase, expense, transfer],
  contacts: [{ id: 'client-1', type: 'client' as const, name: 'Ana', document: '1', phone: '', email: '', address: '' }],
  invoices: [invoice],
  purchases: [{ id: 'purchase-1', number: 'COM-0034', supplierId: 'supplier-1', supplierName: 'Proveedor Oro', items: [], subtotal: 450, discount: 0, tax: 0, total: 450, date: '2026-07-21', status: 'paid' as const }],
  expenses: [{ id: 'expense-1', number: 'GAS-0012', supplierId: 'supplier-1', supplierName: 'Proveedor Oro', total: 120, description: 'Servicios', date: '2026-07-21', paymentMethod: 'Efectivo', status: 'paid' as const }],
  layaways: [],
};

describe('JOYACONTROL LAN V2.3.2 - trazabilidad financiera', () => {
  it('desglosa Caja Principal, Bancos y Total Disponible exclusivamente desde movimientos', () => {
    const compositions = buildFinancialCompositions(input);
    expect(compositions.mainCash.total).toBe(130);
    expect(compositions.banks.total).toBe(600);
    expect(compositions.totalAvailable.total).toBe(730);
    expect(compositions.mainCash.rows.map(row => row.document)).toEqual([
      'Transferencia 1', 'GAS-0012', 'COM-0034', 'FAC-00081', 'Saldo inicial',
    ]);
    expect(compositions.mainCash.rows.find(row => row.document === 'COM-0034')?.signedAmount).toBe(-450);
  });

  it('muestra el detalle consolidado de bancos con entradas, salidas y transferencias', () => {
    const banks = buildBankDetails(input);
    expect(banks).toHaveLength(1);
    expect(banks[0]).toMatchObject({ name: 'Bancolombia', balance: 600, entries: 600, exits: 0, transfers: 600 });
  });

  it('filtra por documento, cliente, proveedor, usuario, cuenta, código y rango', () => {
    const rows = buildFinancialLedgerRows(input);
    const result = filterFinancialLedgerRows(rows, {
      dateFrom: '2026-07-21', dateTo: '2026-07-21', client: 'Ana', invoice: '00081',
      user: 'Admin', accountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'SALE_PAYMENT', status: 'POSTED',
    }, accounts);
    expect(result.map(row => row.movementId)).toEqual(['sale-payment']);
  });

  it('rastrea venta, anulación y reverso mediante referenceId y relatedMovementId', () => {
    const cancellation = movement({
      id: 'sale-cancel', amount: 800, originAccountId: MAIN_CASH_ACCOUNT_ID,
      originBalanceBefore: 130, originBalanceAfter: -670,
      movementCode: 'SALE_CANCEL', referenceType: 'SALE', referenceId: 'sale-1',
      documentType: 'invoice_cancellation', documentId: 'sale-1', reference: 'Anulación FAC-00081',
      relatedMovementId: 'sale-payment', createdAt: '2026-07-22T10:00:00.000Z',
    });
    const reversal = movement({
      id: 'sale-reversal', amount: 800, destinationAccountId: MAIN_CASH_ACCOUNT_ID,
      destinationBalanceBefore: -670, destinationBalanceAfter: 130,
      movementCode: 'REVERSAL', referenceType: 'SALE', referenceId: 'sale-1',
      documentType: 'invoice_reversal', documentId: 'sale-1', reference: 'Reverso FAC-00081',
      relatedMovementId: 'sale-cancel', createdAt: '2026-07-23T10:00:00.000Z',
    });
    const rows = buildFinancialLedgerRows({ ...input, movements: [...input.movements, cancellation, reversal] });
    expect(traceFinancialMovement(rows, 'sale-cancel').map(row => row.movementId).sort()).toEqual([
      'sale-cancel', 'sale-payment', 'sale-reversal',
    ]);
  });


  it('reconstruye cadenas de compra, separado, conversión y devolución', () => {
    const purchasePayment = movement({
      id: 'purchase-chain-payment', amount: 300, originAccountId: MAIN_CASH_ACCOUNT_ID,
      movementCode: 'PURCHASE_PAYMENT', referenceType: 'PURCHASE', referenceId: 'purchase-chain',
      documentType: 'purchase_invoice', documentId: 'purchase-chain', reference: 'COM-0099',
    });
    const purchaseReversal = movement({
      id: 'purchase-chain-reversal', amount: 300, destinationAccountId: MAIN_CASH_ACCOUNT_ID,
      movementCode: 'REVERSAL', referenceType: 'PURCHASE', referenceId: 'purchase-chain',
      documentType: 'purchase_reversal', documentId: 'purchase-chain', reference: 'Reverso COM-0099',
      relatedMovementId: 'purchase-chain-payment',
    });
    const layawayPayment = movement({
      id: 'layaway-payment', amount: 200, destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      movementCode: 'LAYAWAY_PAYMENT', referenceType: 'LAYAWAY', referenceId: 'layaway-chain',
      documentType: 'layaway', documentId: 'layaway-chain', reference: 'SEP-0099',
    });
    const layawayCompletion = movement({
      id: 'layaway-completion', amount: 200, originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      destinationAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'LAYAWAY_COMPLETED',
      referenceType: 'LAYAWAY', referenceId: 'layaway-chain', documentType: 'layaway_completion',
      documentId: 'layaway-chain', reference: 'Conversión SEP-0099', relatedMovementId: 'layaway-payment',
    });
    const layawayRefund = movement({
      id: 'layaway-refund', amount: 200, originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      movementCode: 'LAYAWAY_REFUND', referenceType: 'LAYAWAY', referenceId: 'layaway-refund-chain',
      documentType: 'layaway_refund', documentId: 'layaway-refund-chain', reference: 'Devolución SEP-0100',
      relatedMovementId: 'layaway-refund-payment',
    });
    const layawayRefundPayment = movement({
      id: 'layaway-refund-payment', amount: 200, destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
      movementCode: 'LAYAWAY_PAYMENT', referenceType: 'LAYAWAY', referenceId: 'layaway-refund-chain',
      documentType: 'layaway', documentId: 'layaway-refund-chain', reference: 'SEP-0100',
    });
    const rows = buildFinancialLedgerRows({
      ...input,
      movements: [purchasePayment, purchaseReversal, layawayPayment, layawayCompletion, layawayRefundPayment, layawayRefund],
    });
    expect(traceFinancialMovement(rows, 'purchase-chain-payment').map(row => row.movementId).sort()).toEqual([
      'purchase-chain-payment', 'purchase-chain-reversal',
    ]);
    expect(traceFinancialMovement(rows, 'layaway-payment').map(row => row.movementId).sort()).toEqual([
      'layaway-completion', 'layaway-payment',
    ]);
    expect(traceFinancialMovement(rows, 'layaway-refund').map(row => row.movementId).sort()).toEqual([
      'layaway-refund', 'layaway-refund-payment',
    ]);
  });

  it('detecta duplicados, huérfanos, referencias ausentes, transferencias incompletas y diferencias de saldo', () => {
    const duplicate = { ...sale, id: 'sale-duplicate' };
    const orphan = movement({
      id: 'orphan-refund', movementCode: 'LAYAWAY_REFUND', referenceType: 'LAYAWAY', referenceId: 'layaway-1',
      documentType: 'layaway_refund', documentId: 'layaway-1', relatedMovementId: 'missing',
      originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
    });
    const incompleteTransfer = movement({
      id: 'bad-transfer', movementCode: 'BANK_TRANSFER', referenceType: 'TRANSFER', referenceId: 'bad-transfer',
      documentType: 'transfer', documentId: 'bad-transfer', originAccountId: MAIN_CASH_ACCOUNT_ID,
    });
    const missingReference = movement({ id: 'missing-ref', referenceType: undefined, referenceId: undefined, documentId: '', reference: '' });
    const audit = auditFinancialLedger({ ...input, movements: [...input.movements, duplicate, orphan, incompleteTransfer, missingReference] });
    const types = new Set(audit.issues.map(issue => issue.type));
    expect(types).toEqual(new Set([
      'DUPLICATE_MOVEMENT', 'ORPHAN_MOVEMENT', 'INCOMPLETE_REVERSAL',
      'INCOMPLETE_TRANSFER', 'MISSING_REFERENCE', 'MISSING_DOCUMENT', 'BALANCE_MISMATCH',
    ]));
  });
});
