import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';

const session = {
  id: 'user-lan-client',
  username: 'cliente',
  displayName: 'Cliente LAN',
  role: 'employee' as const,
};

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('LAN 2.2.6 ApiRepository activity log no-op', () => {
  it('finishes silently without HTTP, IPC, console output or LAN module errors', async () => {
    const fetchSpy = vi.fn();
    vi.stubGlobal('fetch', fetchSpy);
    const logSpy = vi.spyOn(console, 'log').mockImplementation(() => undefined);
    const warnSpy = vi.spyOn(console, 'warn').mockImplementation(() => undefined);
    const errorSpy = vi.spyOn(console, 'error').mockImplementation(() => undefined);

    const repository = new ApiRepository({ baseUrl: '' });

    await expect(repository.logActivity(
      session,
      'UPDATE',
      'lan_settings',
      'lan-communication',
      'Configuración LAN guardada',
    )).resolves.toBeUndefined();

    expect(fetchSpy).not.toHaveBeenCalled();
    expect(logSpy).not.toHaveBeenCalled();
    expect(warnSpy).not.toHaveBeenCalled();
    expect(errorSpy).not.toHaveBeenCalled();
  });
});
