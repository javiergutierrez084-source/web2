import { describe, expect, it } from 'vitest';
import type {
  Contact,
  ExpenseInvoice,
  InventoryAdjustment,
  Product,
  PurchaseInvoice,
} from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import {
  buildPurchaseDocumentRows,
  encodeExpenseDocumentNotes,
} from '@/lib/PurchaseDocumentsService';
import { createSupplierHistoryService } from '@/lib/SupplierHistoryService';

const supplier = (id: string, name: string): Contact => ({
  id,
  type: 'supplier',
  name,
  document: '',
  phone: '',
  email: '',
  address: '',
});

const product = (overrides: Partial<Product> = {}): Product => ({
  id: 'product-1',
  code: 'P-001',
  name: 'Producto Uno',
  category: 'General',
  purchasePrice: 100,
  salePrice: 150,
  weightGrams: 10,
  margin: 50,
  stock: 0,
  minStock: 0,
  supplierIds: [],
  ...overrides,
});

const purchase = (overrides: Partial<PurchaseInvoice> = {}): PurchaseInvoice => ({
  id: 'purchase-1',
  number: 'COM-001',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno',
  items: [{
    productId: 'product-1', code: 'P-001', name: 'Producto Uno', quantity: 2,
    weightGrams: 10, unitPrice: 100, subtotal: 200,
  }],
  subtotal: 200,
  discount: 0,
  tax: 0,
  total: 200,
  date: '2026-07-01',
  status: 'paid',
  ...overrides,
});

const payable = (overrides: Partial<SupplierInvoiceView> = {}): SupplierInvoiceView => ({
  id: 'payable-1',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno',
  invoiceNumber: 'COM-001',
  issueDate: '2026-07-01',
  dueDate: '2026-07-31',
  total: 200,
  initialValue: 200,
  pendingBalance: 200,
  sourceType: 'purchase_invoice',
  sourceId: 'purchase-1',
  status: 'pending',
  notes: '',
  payments: [],
  ...overrides,
});

const legacyExpense = (overrides: Partial<ExpenseInvoice> = {}): ExpenseInvoice => ({
  id: 'expense-1',
  number: 'GAS-001',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno',
  description: 'Transporte',
  total: 50,
  date: '2026-07-02',
  paymentMethod: 'Efectivo',
  status: 'paid',
  ...overrides,
});

const adjustment = (overrides: Partial<InventoryAdjustment> = {}): InventoryAdjustment => ({
  id: 'adjustment-1',
  productId: 'product-1',
  productCode: 'P-001',
  productName: 'Producto Uno',
  type: 'increase',
  quantity: 3,
  grams: 30,
  totalCost: 300,
  unitCost: 100,
  valuePerGram: 10,
  purchasePrice: 100,
  averagePriceBefore: 0,
  averagePriceAfter: 100,
  stockBefore: 0,
  stockAfter: 3,
  gramsBefore: 0,
  gramsAfter: 30,
  notes: 'Entrada histórica',
  date: '2026-06-15',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno',
  createdAt: '2026-06-15T12:00:00.000Z',
  ...overrides,
});

const service = (overrides: Partial<{
  contacts: Contact[];
  products: Product[];
  purchases: PurchaseInvoice[];
  supplierInvoices: SupplierInvoiceView[];
  legacyExpenses: ExpenseInvoice[];
  inventoryAdjustments: InventoryAdjustment[];
}> = {}) => {
  const contacts = overrides.contacts ?? [
    supplier('supplier-1', 'Proveedor Uno'),
    supplier('supplier-2', 'Proveedor Dos'),
  ];
  const products = overrides.products ?? [product({ supplierIds: ['supplier-1'] })];
  const purchases = overrides.purchases ?? [];
  const supplierInvoices = overrides.supplierInvoices ?? [];
  const legacyExpenses = overrides.legacyExpenses ?? [];

  return createSupplierHistoryService({
    contacts,
    products,
    documents: buildPurchaseDocumentRows({
      purchases,
      payables: supplierInvoices,
      legacyExpenses,
    }),
    supplierInvoices,
    inventoryAdjustments: overrides.inventoryAdjustments ?? [],
  });
};

describe('SupplierHistoryService con la fuente oficial de Compras', () => {
  it('devuelve ceros para un proveedor sin documentos comerciales', () => {
    const history = service().getSupplierHistory('supplier-1');
    expect(history).toMatchObject({
      totalInvertido: 0,
      totalGramos: 0,
      numeroEntradas: 0,
      ultimaCompra: '',
      compras: [],
      documentos: [],
      cuentasPorPagar: [],
    });
  });

  it('usa exactamente buildPurchaseDocumentRows y no duplica la cuenta por pagar enlazada', () => {
    const invoice = purchase({
      total: 1_250,
      date: '2026-07-10',
      items: [
        { productId: 'product-1', code: 'P-001', name: 'Producto Uno', quantity: 2, weightGrams: 10, unitPrice: 100, subtotal: 200 },
        { productId: 'product-2', code: 'P-002', name: 'Producto Dos', quantity: 3, weightGrams: 5, unitPrice: 50, subtotal: 150 },
      ],
    });
    const linkedPayable = payable({
      sourceId: invoice.id,
      invoiceNumber: invoice.number,
      issueDate: invoice.date,
      total: invoice.total,
    });

    const history = service({ purchases: [invoice], supplierInvoices: [linkedPayable] })
      .getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(1);
    expect(history.cuentasPorPagar).toHaveLength(1);
    expect(history.compras).toHaveLength(1);
    expect(history.totalInvertido).toBe(1_250);
    expect(history.totalGramos).toBe(35);
    expect(history.numeroEntradas).toBe(1);
    expect(history.ultimaCompra).toBe('2026-07-10');
  });

  it('coincide con los documentos visibles en Compras, incluidos gastos del proveedor', () => {
    const invoice = purchase({ total: 300, date: '2026-07-10' });
    const expensePayable = payable({
      id: 'expense-payable',
      sourceType: 'expense',
      sourceId: 'expense-concept-1',
      invoiceNumber: 'GAS-010',
      issueDate: '2026-07-12',
      dueDate: '2026-08-12',
      total: 80,
      initialValue: 80,
      pendingBalance: 80,
      notes: encodeExpenseDocumentNotes({
        conceptId: 'expense-concept-1',
        conceptName: 'Transporte',
      }),
    });
    const documents = buildPurchaseDocumentRows({
      purchases: [invoice],
      payables: [expensePayable],
      legacyExpenses: [],
    });
    const expectedTotal = documents
      .filter(document => document.supplierId === 'supplier-1' && document.status !== 'cancelled')
      .reduce((sum, document) => sum + document.total, 0);

    const history = service({ purchases: [invoice], supplierInvoices: [expensePayable] })
      .getSupplierHistory('supplier-1');

    expect(history.totalInvertido).toBe(expectedTotal);
    expect(history.totalInvertido).toBe(380);
    expect(history.totalGramos).toBe(20);
    expect(history.numeroEntradas).toBe(2);
    expect(history.ultimaCompra).toBe('2026-07-12');
  });

  it('incorpora una cuenta por pagar histórica no representada por PurchaseDocumentsService', () => {
    const historicalPayable = payable({
      id: 'legacy-payable',
      invoiceNumber: 'HIST-001',
      issueDate: '2025-12-20',
      total: 640,
      initialValue: 640,
      pendingBalance: 300,
      sourceType: 'legacy',
      sourceId: '',
      status: 'partial',
    });

    const history = service({ supplierInvoices: [historicalPayable] })
      .getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(0);
    expect(history.cuentasPorPagar).toHaveLength(1);
    expect(history.totalInvertido).toBe(640);
    expect(history.totalGramos).toBe(0);
    expect(history.numeroEntradas).toBe(1);
    expect(history.ultimaCompra).toBe('2025-12-20');
  });

  it('resuelve documentos por nombre cuando el ID histórico está vacío', () => {
    const invoice = purchase({ supplierId: '', supplierName: ' proveedor uno ' });
    const historicalPayable = payable({
      id: 'legacy-name',
      supplierId: '',
      supplierName: 'PROVEEDOR UNO',
      invoiceNumber: 'HIST-NOMBRE',
      issueDate: '2026-07-05',
      total: 120,
      sourceType: 'legacy',
      sourceId: '',
    });

    const history = service({ purchases: [invoice], supplierInvoices: [historicalPayable] })
      .getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(1);
    expect(history.cuentasPorPagar).toHaveLength(1);
    expect(history.totalInvertido).toBe(320);
    expect(history.numeroEntradas).toBe(2);
  });

  it('excluye documentos y cuentas por pagar anulados', () => {
    const history = service({
      purchases: [
        purchase({ id: 'valid', number: 'COM-VALIDA', total: 200 }),
        purchase({ id: 'cancelled', number: 'COM-ANULADA', total: 9_999, status: 'cancelled' }),
      ],
      supplierInvoices: [
        payable({ id: 'cancelled-payable', invoiceNumber: 'CP-ANULADA', total: 8_000, status: 'cancelled', sourceType: 'legacy', sourceId: '' }),
      ],
    }).getSupplierHistory('supplier-1');

    expect(history.totalInvertido).toBe(200);
    expect(history.numeroEntradas).toBe(1);
    expect(history.documentos.map(row => row.id)).toEqual(['valid']);
    expect(history.cuentasPorPagar).toHaveLength(0);
  });

  it('usa ajustes únicamente como respaldo cuando no hay documento comercial', () => {
    const historical = adjustment({ totalCost: 300, grams: 30, date: '2026-06-15' });
    const history = service({ inventoryAdjustments: [historical] })
      .getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(0);
    expect(history.ajustes).toHaveLength(1);
    expect(history.totalInvertido).toBe(300);
    expect(history.totalGramos).toBe(30);
    expect(history.numeroEntradas).toBe(1);
  });

  it('no duplica ajustes ya representados por un documento comercial', () => {
    const invoice = purchase({ date: '2026-07-01', total: 200 });
    const duplicatedAdjustment = adjustment({
      quantity: 2,
      grams: 20,
      totalCost: 200,
      date: '2026-07-01',
    });

    const history = service({
      purchases: [invoice],
      inventoryAdjustments: [duplicatedAdjustment],
    }).getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(1);
    expect(history.ajustes).toHaveLength(0);
    expect(history.compras).toHaveLength(1);
    expect(history.totalInvertido).toBe(200);
    expect(history.totalGramos).toBe(20);
  });

  it('mantiene productos asociados como catálogo sin convertirlos en compras', () => {
    const history = service({
      products: [product({ supplierIds: ['supplier-1', 'supplier-2'] })],
    }).getSupplierHistory('supplier-1');

    expect(history.productos).toHaveLength(1);
    expect(history.totalInvertido).toBe(0);
    expect(history.totalGramos).toBe(0);
    expect(history.numeroEntradas).toBe(0);
  });

  it('incluye un gasto heredado visible en el Centro de documentos', () => {
    const history = service({ legacyExpenses: [legacyExpense()] })
      .getSupplierHistory('supplier-1');

    expect(history.documentos).toHaveLength(1);
    expect(history.documentos[0].source).toBe('legacy_expense');
    expect(history.totalInvertido).toBe(50);
    expect(history.numeroEntradas).toBe(1);
    expect(history.totalGramos).toBe(0);
  });

  it('reconstruye documentos sin proveedor mediante Product.supplierIds y evita duplicados', () => {
    const uniqueProduct = product({
      id: 'product-unique',
      code: 'P-UNICO',
      name: 'Producto directo',
      weightGrams: 10,
      supplierIds: ['supplier-1'],
    });
    const sharedProduct = product({
      id: 'product-shared',
      code: 'P-COMPARTIDO',
      name: 'Producto histórico compartido',
      weightGrams: 5,
      supplierIds: ['supplier-1', 'supplier-2'],
    });
    const direct = purchase({
      id: 'direct-purchase',
      number: 'COM-DIRECTA',
      supplierId: 'supplier-1',
      supplierName: 'Proveedor Uno',
      date: '2026-07-20',
      total: 200,
      items: [{
        productId: uniqueProduct.id, code: uniqueProduct.code, name: uniqueProduct.name,
        quantity: 2, weightGrams: 10, unitPrice: 100, subtotal: 200,
      }],
    });
    const inferred = purchase({
      id: 'historical-without-supplier',
      number: 'COM-HISTORICA',
      supplierId: '',
      supplierName: '',
      date: '2026-07-10',
      total: 150,
      items: [{
        productId: sharedProduct.id, code: sharedProduct.code, name: sharedProduct.name,
        quantity: 3, weightGrams: 5, unitPrice: 50, subtotal: 150,
      }],
    });
    const assignedToOtherSupplier = purchase({
      id: 'other-supplier',
      number: 'COM-OTRO',
      supplierId: 'supplier-2',
      supplierName: 'Proveedor Dos',
      total: 9_999,
      items: inferred.items,
    });

    const history = service({
      products: [uniqueProduct, sharedProduct],
      purchases: [direct, inferred, { ...inferred }, assignedToOtherSupplier],
    }).getSupplierHistory('supplier-1');

    expect(history.trazabilidad).toEqual({
      productosAsociados: 2,
      documentosPorSupplierId: 1,
      documentosPorSupplierName: 0,
      documentosPorProductos: 1,
      documentosDuplicadosDescartados: 2,
    });
    expect(history.documentos.map(document => document.id)).toEqual([
      'direct-purchase',
      'historical-without-supplier',
    ]);
    expect(history.totalInvertido).toBe(350);
    expect(history.totalGramos).toBe(35);
    expect(history.numeroEntradas).toBe(2);
    expect(history.ultimaCompra).toBe('2026-07-20');
  });

  it('reconstruye gramos con el peso vigente del producto cuando la línea histórica no lo guardó', () => {
    const historicalProduct = product({
      id: 'current-product',
      code: 'COD-HIST',
      name: 'Producto vigente',
      weightGrams: 7.5,
      supplierIds: ['supplier-1'],
    });
    const historicalPurchase = purchase({
      id: 'old-purchase',
      supplierId: '',
      supplierName: '',
      total: 450,
      items: [{
        productId: '', code: 'COD-HIST', name: 'Nombre histórico', quantity: 4,
        weightGrams: 0, unitPrice: 112.5, subtotal: 450,
      }],
    });

    const history = service({
      products: [historicalProduct],
      purchases: [historicalPurchase],
    }).getSupplierHistory('supplier-1');

    expect(history.trazabilidad.documentosPorProductos).toBe(1);
    expect(history.totalGramos).toBe(30);
    expect(history.totalInvertido).toBe(450);
    expect(history.numeroEntradas).toBe(1);
  });

});
