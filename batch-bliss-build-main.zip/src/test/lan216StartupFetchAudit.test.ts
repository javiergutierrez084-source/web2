// @vitest-environment jsdom
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { restoreLanSession } from '@/lib/auth';

beforeEach(() => {
  localStorage.clear();
  sessionStorage.clear();
  vi.restoreAllMocks();
});

describe('LAN 2.1.6 startup fetch audit', () => {
  it('does not execute any fetch before Login on a fresh LAN client without authToken', async () => {
    saveLanConfig({
      ...createDefaultLanConfig(),
      mode: 'lan',
      role: 'client',
      clientServerIp: '127.0.0.1',
      clientServerPort: 47831,
      clientId: null,
      sessionToken: null,
      authToken: null,
    });
    const fetchSpy = vi.spyOn(globalThis, 'fetch');
    await expect(restoreLanSession()).resolves.toBeNull();
    expect(fetchSpy).not.toHaveBeenCalled();
  });

  it('keeps the LAN background service inside the authenticated tree', async () => {
    const source = await import('node:fs/promises').then(fs => fs.readFile(new URL('file://' + process.cwd() + '/src/App.tsx'), 'utf8'));
    const loginBranch = source.indexOf("if (state === 'login') return <LoginPage />;");
    const authenticatedTree = source.indexOf('<AppProvider>');
    const service = source.indexOf('<LanClientConnectionService />');
    expect(service).toBeGreaterThan(authenticatedTree);
    expect(source.slice(0, loginBranch)).not.toContain('<LanClientConnectionService />');
  });

  it('identifies the former first automatic request as GET /health', async () => {
    const source = await import('node:fs/promises').then(fs => fs.readFile(new URL('file://' + process.cwd() + '/src/lib/LanCommunicationConfig.ts'), 'utf8'));
    expect(source).toContain('lanFetch(buildHealthUrl(config)');
    expect(source.indexOf('lanFetch(buildHealthUrl(config)')).toBeLessThan(source.indexOf("lanFetch(`${buildLanBaseUrl(config)}/server-info`"));
  });
});
