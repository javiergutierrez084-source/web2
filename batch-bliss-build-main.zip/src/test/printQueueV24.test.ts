// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { PrintQueueService } from '../../electron/printQueueService.js';

const tempDirs: string[] = [];
const tempDir = () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-print-v24-'));
  tempDirs.push(dir);
  return dir;
};

const request = (id: string) => ({
  requestId: id,
  documentType: 'invoice',
  documentId: `invoice-${id}`,
  documentNumber: `FAC-${id}`,
  title: `Factura ${id}`,
  format: 'letter',
  contentType: 'application/pdf',
  contentBase64: Buffer.from(`PDF-${id}`).toString('base64'),
  requester: { userId: 'u1', username: 'master', displayName: 'Master', clientId: 'c1', deviceName: 'Cliente 1' },
  requestedAt: new Date().toISOString(),
});

const waitUntil = async (predicate: () => boolean, timeoutMs = 3000) => {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error('WAIT_TIMEOUT');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
};

afterEach(() => {
  for (const dir of tempDirs.splice(0)) fs.rmSync(dir, { recursive: true, force: true });
});

describe('JOYACONTROL LAN V2.4 transactional print queue', () => {
  it('serializes five simultaneous jobs, preserves documents and deduplicates retries', async () => {
    let active = 0;
    let maxActive = 0;
    const printed: string[] = [];
    const service = new PrintQueueService({
      userDataPath: tempDir(),
      adapter: {
        discoverPrinters: async () => [{ name: 'Printer-1', displayName: 'Printer 1', status: 0, isDefault: true, available: true, type: 'local' }],
        printJob: async (job: { requestId: string; contentBase64: string }) => {
          active += 1;
          maxActive = Math.max(maxActive, active);
          await new Promise(resolve => setTimeout(resolve, 15));
          printed.push(`${job.requestId}:${Buffer.from(job.contentBase64, 'base64').toString('utf8')}`);
          active -= 1;
        },
      },
    });
    service.start();

    const jobs = Array.from({ length: 5 }, (_, index) => service.submit(request(String(index + 1))));
    const duplicate = service.submit(request('1'));
    expect(duplicate.id).toBe(jobs[0].id);

    await waitUntil(() => service.jobs.filter((job: { status: string }) => job.status === 'completed').length === 5);
    expect(maxActive).toBe(1);
    expect(printed).toEqual(['1:PDF-1', '2:PDF-2', '3:PDF-3', '4:PDF-4', '5:PDF-5']);
    expect(service.jobs).toHaveLength(5);
    service.stop();
  });

  it('persists failed jobs, resumes after server restart and supports reprint without reconstruction', async () => {
    const dir = tempDir();
    let available = false;
    const printed: string[] = [];
    const adapter = {
      discoverPrinters: async () => [{ name: 'Printer-1', displayName: 'Printer 1', status: available ? 0 : 8, isDefault: true, available, type: 'local' }],
      printJob: async (job: { contentBase64: string }) => { printed.push(Buffer.from(job.contentBase64, 'base64').toString('utf8')); },
    };

    const first = new PrintQueueService({ userDataPath: dir, adapter });
    first.start();
    const original = first.submit(request('persisted'));
    await waitUntil(() => first.jobs[0]?.status === 'error');
    expect(first.jobs[0].lastError).toContain('PRINT_PRINTER_UNAVAILABLE');
    first.stop();

    available = true;
    const restarted = new PrintQueueService({ userDataPath: dir, adapter });
    restarted.start();
    restarted.retry(original.id);
    await waitUntil(() => restarted.jobs[0]?.status === 'completed');
    expect(printed).toEqual(['PDF-persisted']);

    const reprinted = restarted.reprint(original.id, 'reprint-request');
    await waitUntil(() => restarted.jobs.find((job: { id: string }) => job.id === reprinted.id)?.status === 'completed');
    expect(printed).toEqual(['PDF-persisted', 'PDF-persisted']);
    expect(reprinted.originalJobId).toBe(original.id);
    restarted.stop();
  });

  it('routes formats to configured printers and preserves cancelled failed jobs in history', async () => {
    let available = true;
    const selected: Array<[string, string]> = [];
    const service = new PrintQueueService({
      userDataPath: tempDir(),
      adapter: {
        discoverPrinters: async () => [
          { name: 'Laser', displayName: 'Laser', status: available ? 0 : 8, isDefault: true, available, type: 'local' },
          { name: 'Ticket', displayName: 'Ticket', status: 0, isDefault: false, available: true, type: 'local' },
          { name: 'Zebra', displayName: 'Zebra', status: 0, isDefault: false, available: true, type: 'local' },
        ],
        printJob: async (job: { format: string }, printer: { name: string }) => { selected.push([job.format, printer.name]); },
      },
    });
    service.start();
    service.saveConfiguration({
      defaultPrinterName: 'Laser',
      profilePrinters: { invoice: 'Laser', letter: 'Laser', a4: 'Laser', ticket: 'Ticket', label: 'Zebra', barcode: 'Zebra' },
      documentPrinters: {}, automaticRetry: true, retryDelayMs: 1000, updatedAt: new Date().toISOString(),
    });
    service.submit({ ...request('letter'), format: 'letter' });
    service.submit({ ...request('ticket'), format: 'ticket80', documentType: 'receipt' });
    service.submit({ ...request('a4'), format: 'a4', documentType: 'report' });
    service.submit({ ...request('label'), format: 'label', documentType: 'label' });
    service.submit({ ...request('barcode'), format: 'barcode', documentType: 'barcode' });
    await waitUntil(() => service.jobs.filter((job: { status: string }) => job.status === 'completed').length === 5);
    expect(Object.fromEntries(selected)).toEqual({ letter: 'Laser', ticket80: 'Ticket', a4: 'Laser', label: 'Zebra', barcode: 'Zebra' });

    available = false;
    const failed = service.submit(request('cancelled'));
    await waitUntil(() => service.jobs.find((job: { id: string }) => job.id === failed.id)?.status === 'error');
    const cancelled = service.cancel(failed.id);
    expect(cancelled.status).toBe('cancelled');
    expect((await service.getWorkspace()).jobs.find(job => job.id === failed.id)?.status).toBe('cancelled');
    service.stop();
  });

});
