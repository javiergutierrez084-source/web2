// @vitest-environment jsdom
import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { LanConnectionEventDetail, LanGlobalConnectionState } from '@/lib/LanConnectionManager';

const mocks = vi.hoisted(() => {
  const config = {
    mode: 'lan',
    role: 'client',
    autoReconnect: true,
    timeoutMs: 500,
    clientId: 'client-stable',
    sessionToken: 'session-stable',
    authToken: 'auth-stable' as string | null,
  };
  let serverAvailable = false;
  let heartbeatAvailable = true;
  let ip = '192.168.20.5';
  const aborts: string[] = [];

  const hangingUntilAbort = (signal?: AbortSignal): Promise<never> => new Promise((_, reject) => {
    if (!signal) return;
    const rejectAbort = () => {
      aborts.push(signal.reason instanceof Error ? signal.reason.message : 'ABORTED');
      reject(signal.reason instanceof Error ? signal.reason : new Error('ABORTED'));
    };
    if (signal.aborted) rejectAbort();
    else signal.addEventListener('abort', rejectAbort, { once: true });
  });

  return {
    config,
    aborts,
    get serverAvailable() { return serverAvailable; },
    setServerAvailable(value: boolean) { serverAvailable = value; },
    setHeartbeatAvailable(value: boolean) { heartbeatAvailable = value; },
    get ip() { return ip; },
    setIp(value: string) { ip = value; },
    ensure: vi.fn(async (_version?: string, signal?: AbortSignal) => {
      if (!serverAvailable) return hangingUntilAbort(signal);
      return { ...config };
    }),
    rediscover: vi.fn(async (_config: unknown, signal?: AbortSignal) => {
      if (!serverAvailable) return hangingUntilAbort(signal);
      return { ...config };
    }),
    restoreUser: vi.fn(async (_config: unknown, signal?: AbortSignal) => {
      if (!serverAvailable) return hangingUntilAbort(signal);
      return { success: true, userId: 'u1', username: 'master', role: 'master' };
    }),
    heartbeat: vi.fn(async (_config: unknown, _sequence?: number, signal?: AbortSignal) => {
      if (!serverAvailable || !heartbeatAvailable) return hangingUntilAbort(signal);
      return {
        latencyMs: 1,
        lastSeen: new Date().toISOString(),
        activityCount: 1,
        serverId: 'server-stable',
        events: [],
        latestEventSequence: 0,
      };
    }),
    refreshProducts: vi.fn(async () => undefined),
    refreshCategories: vi.fn(async () => undefined),
    invalidateCache: vi.fn(),
  };
});

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ ...mocks.config }),
  ensureLanClientSession: mocks.ensure,
  rediscoverTrustedLanServer: mocks.rediscover,
  restoreLanUser: mocks.restoreUser,
  sendLanHeartbeat: mocks.heartbeat,
  normalizeHeartbeatIntervalSeconds: (value: unknown) => Math.min(15, Math.max(10, Number(value) || 12)),
}));

vi.mock('@/lib/LanServerDescriptor', () => ({
  LanServerDescriptor: {
    changedEvent: 'joyacontrol-lan-server-descriptor-changed',
    hasAddress: () => true,
    getBaseUrl: () => `http://${mocks.ip}:47831`,
    toJSON: () => ({ ip: mocks.ip, serverId: 'server-stable', companyId: 'company-stable' }),
  },
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    refreshProducts: mocks.refreshProducts,
    refreshCategories: mocks.refreshCategories,
  }),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => ({ invalidateCache: mocks.invalidateCache }),
}));

import LanClientConnectionService from '@/components/LanClientConnectionService';
import { LanConnectionManager } from '@/lib/LanConnectionManager';

async function advance(ms: number): Promise<void> {
  await act(async () => {
    await vi.advanceTimersByTimeAsync(ms);
  });
}

beforeEach(() => {
  vi.useFakeTimers();
  mocks.setServerAvailable(false);
  mocks.setHeartbeatAvailable(true);
  mocks.setIp('192.168.20.5');
  mocks.aborts.length = 0;
  mocks.config.authToken = 'auth-stable';
  vi.clearAllMocks();
  LanConnectionManager.stop();
});

afterEach(() => {
  LanConnectionManager.stop();
  cleanup();
  vi.useRealTimers();
});

describe('LAN 2.2.5 bounded reconnection lifecycle', () => {
  it('emits SERVER_OFFLINE and renders the banner after bounded reconnect failures', async () => {
    const events: LanConnectionEventDetail[] = [];
    const unsubscribe = LanConnectionManager.subscribe(detail => events.push(detail));
    render(<LanClientConnectionService />);

    LanConnectionManager.start();
    await advance(40_000);

    expect(events.some(event => event.type === 'SERVER_RECONNECTING')).toBe(true);
    expect(events.some(event => event.type === 'SERVER_OFFLINE' && event.reason === 'LAN_RECONNECT_TIMEOUT')).toBe(true);
    expect(screen.getByText('Servidor LAN desconectado.')).toBeTruthy();
    expect(mocks.aborts.filter(reason => reason === 'LAN_RECONNECT_TIMEOUT').length).toBeGreaterThanOrEqual(3);
    unsubscribe();
  });

  it('recovers from OFFLINE with CLIENT_RECONNECTED and SERVER_ONLINE', async () => {
    const events: LanConnectionEventDetail[] = [];
    const unsubscribe = LanConnectionManager.subscribe(detail => events.push(detail));
    render(<LanClientConnectionService />);

    LanConnectionManager.start();
    await advance(40_000);
    expect(events.some(event => event.type === 'SERVER_OFFLINE')).toBe(true);

    mocks.setServerAvailable(true);
    await advance(40_000);

    expect(events.some(event => event.type === 'CLIENT_RECONNECTED')).toBe(true);
    expect(events.some(event => event.type === 'SERVER_ONLINE')).toBe(true);
    expect(LanConnectionManager.getConnectionState()).toBe('ONLINE');
    expect(mocks.invalidateCache).toHaveBeenCalled();
    expect(mocks.refreshProducts).toHaveBeenCalled();
    expect(mocks.refreshCategories).toHaveBeenCalled();
    unsubscribe();
  });

  it('counts heartbeat timeouts and emits SERVER_OFFLINE instead of looping forever', async () => {
    const events: LanConnectionEventDetail[] = [];
    const unsubscribe = LanConnectionManager.subscribe(detail => events.push(detail));
    render(<LanClientConnectionService />);

    mocks.setServerAvailable(true);
    mocks.setHeartbeatAvailable(false);
    LanConnectionManager.start();
    await advance(30_000);

    expect(events.some(event => event.type === 'SERVER_OFFLINE' && event.reason === 'LAN_HEARTBEAT_TIMEOUT')).toBe(true);
    expect(screen.getByText('Servidor LAN desconectado.')).toBeTruthy();
    unsubscribe();
  });

  it('does not remain indefinitely in RECONNECTING during ten simulated minutes', async () => {
    const transitions: Array<{ state: LanGlobalConnectionState; type: string; at: number }> = [];
    const unsubscribe = LanConnectionManager.subscribe(detail => {
      transitions.push({ state: detail.state, type: detail.type, at: Date.now() });
    });

    LanConnectionManager.start();
    await advance(10 * 60_000);

    const offlineEvents = transitions.filter(event => event.type === 'SERVER_OFFLINE');
    expect(offlineEvents.length).toBeGreaterThan(1);
    const lastReconnect = [...transitions].reverse().find(event => event.type === 'SERVER_RECONNECTING');
    if (lastReconnect && !transitions.some(event => event.type === 'SERVER_OFFLINE' && event.at >= lastReconnect.at)) {
      await advance(10_001);
    }
    expect(transitions.some(event => event.type === 'SERVER_OFFLINE' && (!lastReconnect || event.at >= lastReconnect.at))).toBe(true);
    expect(mocks.aborts.every(reason => reason === 'LAN_RECONNECT_TIMEOUT')).toBe(true);
    unsubscribe();
  });

  it('reconnects automatically when the server returns after several minutes', async () => {
    const events: LanConnectionEventDetail[] = [];
    const unsubscribe = LanConnectionManager.subscribe(detail => events.push(detail));

    LanConnectionManager.start();
    await advance(4 * 60_000);
    mocks.setServerAvailable(true);
    await advance(40_000);

    expect(LanConnectionManager.getConnectionState()).toBe('ONLINE');
    expect(events.some(event => event.type === 'CLIENT_RECONNECTED')).toBe(true);
    expect(events.some(event => event.type === 'SERVER_ONLINE')).toBe(true);
    unsubscribe();
  });
});
