import { beforeEach, describe, expect, it } from 'vitest';
import {
  clearOnlineServerSession,
  isOnlineServerSessionExpired,
  loadOnlineServerSession,
  ONLINE_SERVER_SESSION_STORAGE_KEY,
  saveOnlineServerSession,
  shouldClearOnlineServerSession,
} from '@/lib/OnlineServerSession';

const SESSION = {
  sessionId: 'a'.repeat(43),
  serverId: '11111111-1111-4111-8111-111111111111',
  username: 'admin',
  displayName: 'Administrador Principal',
  role: 'admin',
  createdAt: '2026-07-28T20:00:00.000Z',
  expiresAt: '2026-07-29T08:00:00.000Z',
  version: '3.0.0',
  url: 'https://midominio.com',
  port: 443,
  baseUrl: 'https://midominio.com',
  savedAt: '2026-07-28T20:00:01.000Z',
};

describe('sesión del Servidor Online', () => {
  beforeEach(() => localStorage.clear());

  it('guarda y restaura la sesión únicamente en localStorage', () => {
    const saved = saveOnlineServerSession(SESSION);
    expect(saved).toEqual(SESSION);
    expect(loadOnlineServerSession()).toEqual(SESSION);
    expect(localStorage.getItem(ONLINE_SERVER_SESSION_STORAGE_KEY)).toContain(SESSION.sessionId);
  });

  it('detecta expiración y permite borrar solo la sesión', () => {
    saveOnlineServerSession(SESSION);
    expect(isOnlineServerSessionExpired(SESSION, Date.parse('2026-07-29T07:59:59.000Z'))).toBe(false);
    expect(isOnlineServerSessionExpired(SESSION, Date.parse(SESSION.expiresAt))).toBe(true);

    clearOnlineServerSession();
    expect(loadOnlineServerSession()).toBeNull();
  });

  it('descarta datos corruptos sin utilizar Dexie', () => {
    localStorage.setItem(ONLINE_SERVER_SESSION_STORAGE_KEY, JSON.stringify({ ...SESSION, sessionId: 'corto' }));
    expect(loadOnlineServerSession()).toBeNull();
    expect(localStorage.getItem(ONLINE_SERVER_SESSION_STORAGE_KEY)).toBeNull();
  });

  it('identifica errores que obligan a volver al login', () => {
    expect(shouldClearOnlineServerSession('HTTPS_SESSION_INVALID')).toBe(true);
    expect(shouldClearOnlineServerSession('HTTPS_SESSION_EXPIRED')).toBe(true);
    expect(shouldClearOnlineServerSession('HTTPS_SERVER_NOT_FOUND')).toBe(false);
  });
});
