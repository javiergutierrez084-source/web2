import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import {
  calculateLedgerAccountBalances,
  resolveFinancialMovementCode,
  resolveFinancialReferenceType,
} from '@/lib/FinancialLedgerService';
import { buildFinancialPosition, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const account: FinancialAccount = {
  id: MAIN_CASH_ACCOUNT_ID,
  name: 'Caja Principal',
  kind: 'cash',
  active: true,
  balance: 9_999,
  createdAt: '2026-07-21T00:00:00.000Z',
  updatedAt: '2026-07-21T00:00:00.000Z',
};

const movement: FinancialMovement = {
  id: 'movement-1',
  type: 'sale_income',
  amount: 125,
  destinationAccountId: MAIN_CASH_ACCOUNT_ID,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 125,
  reference: 'FV-1',
  documentType: 'invoice',
  documentId: 'sale-1',
  observation: 'Venta',
  userId: 'user-1',
  userName: 'Usuario',
  date: '2026-07-21',
  createdAt: '2026-07-21T10:00:00.000Z',
};

describe('FinancialMovement como libro mayor central', () => {
  it('usa el historial de movimientos como fuente de verdad y no el saldo materializado', () => {
    const balances = calculateLedgerAccountBalances([account], [movement]);
    expect(balances.get(MAIN_CASH_ACCOUNT_ID)).toMatchObject({
      balance: 125,
      source: 'ledger',
      lastMovementId: movement.id,
    });

    const position = buildFinancialPosition({ accounts: [account], movements: [movement], layaways: [] });
    expect(position.mainCash).toBe(125);
    expect(position.totalAvailable).toBe(125);
  });

  it('normaliza el tipo y la referencia de registros históricos', () => {
    expect(resolveFinancialMovementCode(movement)).toBe('SALE_PAYMENT');
    expect(resolveFinancialReferenceType(movement)).toBe('SALE');
  });
});
