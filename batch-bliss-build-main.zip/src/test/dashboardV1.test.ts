import { describe, expect, it } from 'vitest';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';
import type {
  Contact,
  ExpenseInvoice,
  FinancialAccount,
  FinancialMovement,
  Invoice,
  Product,
  PurchaseInvoice,
} from '@/data/mockData';
import type { CashSession, Layaway } from '@/domain/models';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const products: Product[] = [
  { id: 'p1', code: 'P-1', name: 'Anillo', category: 'Anillos', purchasePrice: 40, averagePurchasePrice: 40, salePrice: 100, weightGrams: 2, stock: 5, minStock: 2, margin: 150 },
  { id: 'p2', code: 'P-2', name: 'Cadena', category: 'Cadenas', purchasePrice: 60, salePrice: 150, weightGrams: 4, stock: 0, minStock: 1, margin: 150 },
  { id: 'p3', code: 'P-3', name: 'Dije', category: 'Dijes', purchasePrice: 20, salePrice: 50, weightGrams: 1, stock: 1, minStock: 1, margin: 150 },
];

const paidInvoice: Invoice = {
  id: 'i1', number: 'FAC-1', clientId: 'c1', clientName: 'Ana', date: '2026-07-20', status: 'paid',
  subtotal: 200, discount: 0, tax: 0, total: 200,
  items: [{ productId: 'p1', code: 'P-1', name: 'Anillo', quantity: 2, weightGrams: 2, unitPrice: 100, subtotal: 200, costPrice: 40 }],
};

const contacts: Contact[] = [
  { id: 'c1', type: 'client', name: 'Ana', document: '1', phone: '', email: '', address: '' },
  { id: 's1', type: 'supplier', name: 'Proveedor', document: '2', phone: '', email: '', address: '' },
];

const purchases: PurchaseInvoice[] = [{
  id: 'po1', number: 'C-1', supplierId: 's1', supplierName: 'Proveedor', items: [], subtotal: 90,
  discount: 0, tax: 0, total: 90, date: '2026-07-20', status: 'paid',
}];

const expenses: ExpenseInvoice[] = [{
  id: 'e1', number: 'G-1', supplierId: 's1', supplierName: 'Proveedor', total: 10,
  description: 'Servicio', date: '2026-07-20', paymentMethod: 'Efectivo', status: 'paid',
}];

const layaways: Layaway[] = [{
  id: 'l1', invoiceId: 'li1', completed: false,
  invoice: { ...paidInvoice, id: 'li1', number: 'SEP-1', total: 300, items: [], clientId: 'c1' },
  payments: [{ id: 'lp1', amount: 100, date: '2026-07-20', method: 'Efectivo' }],
}];

const cashSessions: CashSession[] = [{
  id: 'cs1', date: '2026-07-20', openedAt: '08:00', openedBy: 'Admin', initialAmount: 50,
}];

const accounts: FinancialAccount[] = [
  { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash', active: true, balance: 350, createdAt: '', updatedAt: '' },
  { id: LAYAWAY_RESERVE_ACCOUNT_ID, name: 'Caja Separados', kind: 'cash', active: true, balance: 100, createdAt: '', updatedAt: '' },
];

const movements: FinancialMovement[] = [
  { id: 'opening-main', type: 'opening_balance', amount: 250, destinationAccountId: MAIN_CASH_ACCOUNT_ID, originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0, destinationBalanceAfter: 250, reference: 'Saldo inicial', documentType: 'financial_account', documentId: MAIN_CASH_ACCOUNT_ID, observation: '', userId: 'u1', userName: 'Admin', date: '2026-07-20', createdAt: '2026-07-20T08:00:00.000Z', movementCode: 'OPENING_BALANCE', referenceType: 'FINANCIAL_ACCOUNT', referenceId: MAIN_CASH_ACCOUNT_ID, status: 'POSTED' },
  { id: 'sale-payment', type: 'sale_income', amount: 200, destinationAccountId: MAIN_CASH_ACCOUNT_ID, originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 250, destinationBalanceAfter: 450, reference: 'FAC-1', documentType: 'invoice', documentId: 'i1', observation: 'Ana', userId: 'u1', userName: 'Admin', date: '2026-07-20', createdAt: '2026-07-20T09:00:00.000Z', movementCode: 'SALE_PAYMENT', referenceType: 'SALE', referenceId: 'i1', status: 'POSTED' },
  { id: 'purchase-payment', type: 'purchase_payment', amount: 90, originAccountId: MAIN_CASH_ACCOUNT_ID, originBalanceBefore: 450, originBalanceAfter: 360, destinationBalanceBefore: 0, destinationBalanceAfter: 0, reference: 'C-1', documentType: 'purchase', documentId: 'po1', observation: 'Proveedor', userId: 'u1', userName: 'Admin', date: '2026-07-20', createdAt: '2026-07-20T10:00:00.000Z', movementCode: 'PURCHASE_PAYMENT', referenceType: 'PURCHASE', referenceId: 'po1', status: 'POSTED' },
  { id: 'expense-payment', type: 'expense', amount: 10, originAccountId: MAIN_CASH_ACCOUNT_ID, originBalanceBefore: 360, originBalanceAfter: 350, destinationBalanceBefore: 0, destinationBalanceAfter: 0, reference: 'G-1', documentType: 'expense', documentId: 'e1', observation: 'Servicio', userId: 'u1', userName: 'Admin', date: '2026-07-20', createdAt: '2026-07-20T11:00:00.000Z', movementCode: 'EXPENSE', referenceType: 'EXPENSE', referenceId: 'e1', status: 'POSTED' },
  { id: 'layaway-payment', type: 'adjustment', amount: 100, destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID, originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0, destinationBalanceAfter: 100, reference: 'SEP-1', documentType: 'layaway', documentId: 'l1', observation: 'Ana', userId: 'u1', userName: 'Admin', date: '2026-07-20', createdAt: '2026-07-20T12:00:00.000Z', movementCode: 'LAYAWAY_PAYMENT', referenceType: 'LAYAWAY', referenceId: 'l1', status: 'POSTED' },
];

const input = {
  products,
  contacts,
  invoices: [paidInvoice],
  purchases,
  expenses,
  layaways,
  cashSessions,
  accounts,
  movements,
  financialSummary: null,
  lastSuccessfulBackupAt: null,
  now: new Date('2026-07-20T12:00:00'),
};

describe('JoyaControl Dashboard V1', () => {
  it('calcula ventas netas, caja, inventario, separados y clientes desde datos reales', () => {
    const result = buildDashboardSnapshot(input);

    expect(result.today).toEqual({ count: 1, value: 200 });
    expect(result.month).toEqual({ count: 1, value: 200 });
    expect('cash' in result).toBe(false);
    expect(result.financialPosition).toMatchObject({ mainCash: 350, layawayReserve: 100, banks: 0, totalAvailable: 350, mainCashStatus: 'RECONCILED' });
    expect(result.inventory).toMatchObject({ products: 3, activeProducts: 2, saleValue: 550, totalCost: 220 });
    expect(result.inventory.totalWeightGrams).toBe(11);
    expect(result.layaways).toEqual({ count: 1, pendingValue: 200, clients: 1 });
    expect(result.customers).toEqual({ registered: 1, newThisMonth: 1, active: 1 });
    expect(result.purchasesMonth).toBe(90);
  });

  it('construye la serie real de 30 días, top 10 y últimas ventas', () => {
    const result = buildDashboardSnapshot(input);

    expect(result.salesLast30Days).toHaveLength(30);
    expect(result.salesLast30Days.at(-1)).toMatchObject({ date: '2026-07-20', value: 200, count: 1 });
    expect(result.topProducts).toEqual([{ productId: 'p1', name: 'Anillo', quantity: 2, value: 200 }]);
    expect(result.recentSales.map(invoice => invoice.id)).toEqual(['i1']);
  });

  it('muestra únicamente alertas respaldadas por el estado real', () => {
    const result = buildDashboardSnapshot(input);
    const alertIds = result.alerts.map(alert => alert.id);

    expect(alertIds).toEqual([
      'products-out-of-stock',
      'products-low-stock',
      'layaways-pending',
      'cash-open',
      'backup-not-recent',
    ]);
  });

  it('no crea alerta local de respaldo cuando el Dashboard corre como Cliente LAN', () => {
    const result = buildDashboardSnapshot({ ...input, backupStatusAvailable: false });
    expect(result.alerts.some(alert => alert.id === 'backup-not-recent')).toBe(false);
  });
});
