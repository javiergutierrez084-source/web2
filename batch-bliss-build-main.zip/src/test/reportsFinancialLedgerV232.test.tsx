// @vitest-environment jsdom
import { fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { FinancialMovement } from '@/data/mockData';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 100,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'DOC-1',
  documentType: 'manual',
  documentId: 'doc-1',
  observation: 'Movimiento de prueba',
  userId: 'user-1',
  userName: 'Admin',
  date: new Date().toISOString().slice(0, 10),
  createdAt: new Date().toISOString(),
  status: 'POSTED',
  referenceType: 'MANUAL',
  referenceId: 'doc-1',
  ...overrides,
});

const appState = {
  company: { name: 'JoyaControl', nit: '', address: '', phone: '', email: '', logo: '' },
  contacts: [{ id: 'supplier-1', type: 'supplier' as const, name: 'Proveedor Uno', document: '900', phone: '', email: '', address: '' }],
  invoices: [],
  expenses: [],
  purchaseInvoices: [],
  products: [],
  layaways: [],
  financialAccounts: [
    { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja Principal', kind: 'cash' as const, active: true, balance: 350, createdAt: '', updatedAt: '' },
  ],
  financialMovements: [
    movement({ id: 'sale', type: 'sale_income', amount: 1_000, destinationAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'SALE_PAYMENT', referenceType: 'SALE', referenceId: 'sale-1', documentId: 'sale-1', reference: 'FAC-1' }),
    movement({ id: 'cancel', amount: 100, originAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'SALE_CANCEL', referenceType: 'SALE', referenceId: 'sale-1', documentId: 'sale-1', reference: 'FAC-1', relatedMovementId: 'sale' }),
    movement({ id: 'purchase', amount: 300, originAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'PURCHASE_PAYMENT', referenceType: 'PURCHASE', referenceId: 'purchase-1', documentId: 'purchase-1', reference: 'COM-1' }),
    movement({ id: 'expense', amount: 200, originAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'EXPENSE', referenceType: 'EXPENSE', referenceId: 'expense-1', documentId: 'expense-1', reference: 'GAS-1' }),
    movement({ id: 'supplier', amount: 50, originAccountId: MAIN_CASH_ACCOUNT_ID, movementCode: 'SUPPLIER_PAYMENT', referenceType: 'SUPPLIER_INVOICE', referenceId: 'supplier-invoice-1', documentId: 'supplier-invoice-1', reference: 'PROV-1', observation: 'Proveedor Uno' }),
  ],
};

vi.mock('@/contexts/AppContext', () => ({ useApp: () => appState }));

import Reports from '@/pages/Reports';

beforeEach(() => {
  window.URL.createObjectURL = vi.fn(() => 'blob:test');
  window.URL.revokeObjectURL = vi.fn();
});

describe('JOYACONTROL LAN V2.3.2 - Reportes desde Financial Ledger', () => {
  it('construye cuadre, resultado y pagos a proveedores desde FinancialMovement', () => {
    render(<MemoryRouter><Reports /></MemoryRouter>);

    fireEvent.click(screen.getByRole('button', { name: 'Cuadre Mensual' }));
    expect(screen.getByText('Cuadre Mensual - ' + new Date().toISOString().slice(0, 7))).toBeTruthy();
    expect(screen.getByText('Ventas').parentElement?.textContent).toContain('900');

    fireEvent.click(screen.getByRole('button', { name: 'Resultado Ledger' }));
    expect(screen.getByText('Resultado Financiero Trazable')).toBeTruthy();
    expect(screen.getAllByText('Resultado Ledger')).toHaveLength(2);

    fireEvent.click(screen.getByRole('button', { name: 'Pagos Proveedores' }));
    expect(screen.getByText('Historial explicado por movimientos SUPPLIER_PAYMENT.')).toBeTruthy();
    expect(screen.getByText('Proveedor Uno')).toBeTruthy();
  });
});
