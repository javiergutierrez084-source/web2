import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import OnlineServerPage from '@/pages/OnlineServerPage';
import {
  loadOnlineServerSelection,
  saveOnlineServerSelection,
} from '@/lib/OnlineServerConfig';
import {
  loadOnlineServerSession,
  saveOnlineServerSession,
} from '@/lib/OnlineServerSession';

const SERVER_ID = '11111111-1111-4111-8111-111111111111';
const SUCCESS_RESULT: HttpsServerConnectionSuccess = {
  ok: true,
  endpoint: {
    url: 'https://midominio.com',
    port: 443,
    baseUrl: 'https://midominio.com',
  },
  latencyMs: 42,
  tlsProtocol: 'TLSv1.3',
  health: {
    server: 'active',
    active: true,
    date: '2026-07-28T20:00:00.000Z',
    uptime: 30,
    protocol: 'HTTPS',
    version: '3.0.0',
  },
  serverInfo: {
    serverId: SERVER_ID,
    serverName: 'JoyaControl Principal',
    version: '3.0.0',
    hostname: 'joya-principal',
    online: true,
    uptime: 30,
  },
};

const LOGIN_RESULT: HttpsServerLoginSuccess = {
  ok: true,
  endpoint: SUCCESS_RESULT.endpoint,
  session: {
    sessionId: 'a'.repeat(43),
    serverId: SERVER_ID,
    usuario: 'admin',
    nombre: 'Administrador Principal',
    rol: 'admin',
    fecha: '2026-07-28T20:00:00.000Z',
    expiracion: '2099-07-29T08:00:00.000Z',
    version: '3.0.0',
  },
};


const REMOTE_CONTACTS = [
  {
    id: 'client-1',
    type: 'client' as const,
    name: 'Cliente Uno',
    document: '1001',
    phone: '3001001001',
    email: 'cliente@correo.test',
    address: 'Calle 1',
    notes: '',
    status: 'active' as const,
  },
  {
    id: 'supplier-1',
    type: 'supplier' as const,
    name: 'Proveedor Oro',
    document: '9001',
    phone: '3009001001',
    email: 'proveedor@correo.test',
    address: 'Carrera 2',
    notes: '',
    status: 'active' as const,
  },
];

const REMOTE_PRODUCTS = [
  {
    id: 'product-1',
    code: 'ANI-001',
    name: 'Anillo Oro',
    category: 'Anillos',
    reference: 'REF-001',
    description: '',
    weightGrams: 4.5,
    availableGrams: 13.5,
    salePrice: 950000,
    stock: 3,
    minStock: 1,
    status: 'available' as const,
  },
];

const REMOTE_INVENTORY = [
  {
    id: 'product-1',
    code: 'ANI-001',
    name: 'Anillo Oro',
    category: 'Anillos',
    stock: 3,
    availableGrams: 13.5,
    weightGrams: 4.5,
    minStock: 1,
    location: 'Vitrina A',
    lastMovement: { date: '2026-07-28T19:00:00.000Z', type: 'increase' as const },
    status: 'available' as const,
  },
];

const READ_DATA = {
  me: {
    id: 'user-admin-1',
    usuario: 'admin',
    nombre: 'Administrador Principal',
    rol: 'admin',
    permisos: ['view_reports', 'manage_settings'],
  },
  company: {
    nombreEmpresa: 'JoyaControl Principal',
    nit: '900123456-7',
    direccion: 'Calle Principal 10',
    ciudad: 'Bogotá',
    telefonos: ['3001234567'],
    correo: 'contacto@joyacontrol.test',
    logo: '',
    configuracionImpresion: null,
  },
  permissions: { permisos: ['view_reports', 'manage_settings'] },
  contacts: REMOTE_CONTACTS,
  contact: REMOTE_CONTACTS[0],
  contactsSearch: [REMOTE_CONTACTS[1]],
  products: REMOTE_PRODUCTS,
  product: REMOTE_PRODUCTS[0],
  productsSearch: REMOTE_PRODUCTS,
  inventory: REMOTE_INVENTORY,
  inventoryItem: REMOTE_INVENTORY[0],
};

const SESSION_RESULT: HttpsServerSessionSuccess = {
  ok: true,
  endpoint: SUCCESS_RESULT.endpoint,
  session: {
    usuario: 'admin',
    nombre: 'Administrador Principal',
    rol: 'admin',
    hostname: 'joya-principal',
    serverId: SERVER_ID,
    version: '3.0.0',
    estado: 'active',
    fecha: LOGIN_RESULT.session.fecha,
    expiracion: LOGIN_RESULT.session.expiracion,
  },
};

function saveServer() {
  return saveOnlineServerSelection({
    url: SUCCESS_RESULT.endpoint.url,
    port: SUCCESS_RESULT.endpoint.port,
    baseUrl: SUCCESS_RESULT.endpoint.baseUrl,
    serverId: SERVER_ID,
    serverName: SUCCESS_RESULT.serverInfo.serverName,
    version: SUCCESS_RESULT.serverInfo.version,
    hostname: SUCCESS_RESULT.serverInfo.hostname,
    savedAt: '2026-07-28T20:00:00.000Z',
  });
}

describe('pantalla Servidor Online', () => {
  beforeEach(() => {
    localStorage.clear();
    window.joyaControlHttps = {
      testConnection: vi.fn().mockResolvedValue(SUCCESS_RESULT),
      login: vi.fn().mockResolvedValue(LOGIN_RESULT),
      getSession: vi.fn().mockResolvedValue(SESSION_RESULT),
      logout: vi.fn().mockResolvedValue({
        ok: true,
        endpoint: SUCCESS_RESULT.endpoint,
        sessionClosed: true,
      }),
      read: vi.fn().mockImplementation(async ({ resource }) => ({
        ok: true,
        endpoint: SUCCESS_RESULT.endpoint,
        resource,
        data: READ_DATA[resource as keyof typeof READ_DATA],
        latencyMs: 18,
        communicatedAt: '2026-07-28T20:00:02.000Z',
        tlsProtocol: 'TLSv1.3',
      })),
      onAuthRequest: vi.fn(),
    } as typeof window.joyaControlHttps;
  });

  it('prueba, muestra, guarda y borra el servidor HTTPS seleccionado', async () => {
    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);

    fireEvent.change(screen.getByLabelText('URL del servidor'), { target: { value: 'https://midominio.com' } });
    fireEvent.change(screen.getByLabelText('Puerto'), { target: { value: '443' } });
    fireEvent.click(screen.getByRole('button', { name: 'Probar conexión' }));

    expect(await screen.findByText('JoyaControl Principal')).toBeInTheDocument();
    expect(screen.getByText('42 ms')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Guardar' }));
    await waitFor(() => expect(loadOnlineServerSelection()?.serverId).toBe(SERVER_ID));
    expect(screen.getByRole('heading', { name: 'Iniciar sesión' })).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: 'Borrar configuración' }));
    await waitFor(() => expect(loadOnlineServerSelection()).toBeNull());
    expect(loadOnlineServerSession()).toBeNull();
  });

  it('inicia sesión con un usuario existente y cierra solo la sesión', async () => {
    saveServer();
    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);

    fireEvent.change(screen.getByLabelText('Usuario'), { target: { value: 'admin' } });
    fireEvent.change(screen.getByLabelText('Contraseña'), { target: { value: 'correcta' } });
    fireEvent.click(screen.getByRole('button', { name: 'Conectar' }));

    expect(await screen.findByText('Conectado como: Administrador')).toBeInTheDocument();
    expect(screen.getByText('Administrador Principal')).toBeInTheDocument();
    expect(screen.getByText('@admin')).toBeInTheDocument();
    expect(await screen.findByText('900123456-7')).toBeInTheDocument();
    expect(screen.getByText('view_reports')).toBeInTheDocument();
    expect(screen.getByText('18 ms')).toBeInTheDocument();
    expect(await screen.findByText('Productos')).toBeInTheDocument();
    expect(screen.getAllByText('Anillo Oro').length).toBeGreaterThan(0);
    expect(screen.getByText('1 productos')).toBeInTheDocument();
    expect(screen.getByText('1 referencias')).toBeInTheDocument();
    expect(screen.getByText('3 existencias')).toBeInTheDocument();
    expect(loadOnlineServerSession()?.sessionId).toBe(LOGIN_RESULT.session.sessionId);

    fireEvent.click(screen.getByRole('button', { name: 'Cerrar sesión' }));
    await waitFor(() => expect(loadOnlineServerSession()).toBeNull());
    expect(loadOnlineServerSelection()?.serverId).toBe(SERVER_ID);
    expect(await screen.findByRole('heading', { name: 'Iniciar sesión' })).toBeInTheDocument();
  });

  it('restaura la sesión desde localStorage al reiniciar la aplicación', async () => {
    const server = saveServer();
    saveOnlineServerSession({
      sessionId: LOGIN_RESULT.session.sessionId,
      serverId: SERVER_ID,
      username: 'admin',
      displayName: 'Administrador Principal',
      role: 'admin',
      createdAt: LOGIN_RESULT.session.fecha,
      expiresAt: LOGIN_RESULT.session.expiracion,
      version: '3.0.0',
      url: server.url,
      port: server.port,
      baseUrl: server.baseUrl,
      savedAt: '2026-07-28T20:00:01.000Z',
    });

    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);

    expect(await screen.findByText('Conectado como: Administrador')).toBeInTheDocument();
    await waitFor(() => expect(window.joyaControlHttps?.getSession).toHaveBeenCalledWith(expect.objectContaining({
      sessionId: LOGIN_RESULT.session.sessionId,
      expectedServerId: SERVER_ID,
    })));
    expect(loadOnlineServerSession()?.displayName).toBe('Administrador Principal');
  });

  it('mantiene la sesión local pero no informa conexión cuando el servidor está apagado', async () => {
    const server = saveServer();
    saveOnlineServerSession({
      sessionId: LOGIN_RESULT.session.sessionId,
      serverId: SERVER_ID,
      username: 'admin',
      displayName: 'Administrador Principal',
      role: 'admin',
      createdAt: LOGIN_RESULT.session.fecha,
      expiresAt: LOGIN_RESULT.session.expiracion,
      version: '3.0.0',
      url: server.url,
      port: server.port,
      baseUrl: server.baseUrl,
      savedAt: '2026-07-28T20:00:01.000Z',
    });
    window.joyaControlHttps = {
      ...window.joyaControlHttps!,
      getSession: vi.fn().mockResolvedValue({
        ok: false,
        errorCode: 'HTTPS_SERVER_NOT_FOUND',
        errorMessage: 'Servidor apagado',
      }),
    };

    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);
    expect(await screen.findByText(/Servidor apagado o no encontrado/)).toBeInTheDocument();
    expect(screen.getByText('Conectado como: Administrador')).toBeInTheDocument();
    expect(screen.getByText('Servidor no disponible')).toBeInTheDocument();
    expect(loadOnlineServerSession()?.sessionId).toBe(LOGIN_RESULT.session.sessionId);
  });

  it('muestra un mensaje claro para contraseña incorrecta', async () => {
    saveServer();
    window.joyaControlHttps = {
      ...window.joyaControlHttps!,
      login: vi.fn().mockResolvedValue({
        ok: false,
        errorCode: 'HTTPS_PASSWORD_INCORRECT',
        errorMessage: 'Contraseña incorrecta',
      }),
    };

    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);
    fireEvent.change(screen.getByLabelText('Usuario'), { target: { value: 'admin' } });
    fireEvent.change(screen.getByLabelText('Contraseña'), { target: { value: 'mala' } });
    fireEvent.click(screen.getByRole('button', { name: 'Conectar' }));
    expect(await screen.findByText('Contraseña incorrecta.')).toBeInTheDocument();
  });

  it('muestra un mensaje claro cuando la versión es incompatible', async () => {
    window.joyaControlHttps = {
      ...window.joyaControlHttps!,
      testConnection: vi.fn().mockResolvedValue({
        ok: false,
        errorCode: 'HTTPS_VERSION_INCOMPATIBLE',
        errorMessage: 'Versión incompatible',
      }),
    };

    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);
    fireEvent.change(screen.getByLabelText('URL del servidor'), { target: { value: 'https://midominio.com' } });
    fireEvent.click(screen.getByRole('button', { name: 'Probar conexión' }));
    expect(await screen.findByText(/Versión incompatible/)).toBeInTheDocument();
  });

  it('muestra contactos remotos, búsqueda y detalle en modo solo lectura', async () => {
    const server = saveServer();
    saveOnlineServerSession({
      sessionId: LOGIN_RESULT.session.sessionId,
      serverId: SERVER_ID,
      username: 'admin',
      displayName: 'Administrador Principal',
      role: 'admin',
      createdAt: LOGIN_RESULT.session.fecha,
      expiresAt: LOGIN_RESULT.session.expiracion,
      version: '3.0.0',
      url: server.url,
      port: server.port,
      baseUrl: server.baseUrl,
      savedAt: '2026-07-28T20:00:01.000Z',
    });

    render(<MemoryRouter><OnlineServerPage /></MemoryRouter>);

    expect(await screen.findByRole('heading', { name: 'Contactos remotos' })).toBeInTheDocument();
    expect(await screen.findByText('1 clientes')).toBeInTheDocument();
    expect(screen.getByText('1 proveedores')).toBeInTheDocument();
    expect(await screen.findByText('Cliente Uno')).toBeInTheDocument();
    expect(screen.getByText('Proveedor Oro')).toBeInTheDocument();

    fireEvent.click(screen.getByRole('button', { name: /Cliente Uno/ }));
    expect(await screen.findByText('3001001001')).toBeInTheDocument();
    expect(screen.getByText('cliente@correo.test')).toBeInTheDocument();
    expect(screen.getByText('Activo')).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText('Buscar contactos remotos'), { target: { value: 'oro' } });
    fireEvent.click(screen.getByRole('button', { name: 'Buscar' }));
    await waitFor(() => expect(window.joyaControlHttps?.read).toHaveBeenCalledWith(expect.objectContaining({
      resource: 'contactsSearch',
      args: { query: 'oro' },
    })));
  });

});
