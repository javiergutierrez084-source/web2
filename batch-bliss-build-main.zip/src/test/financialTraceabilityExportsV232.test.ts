import { describe, expect, it } from 'vitest';
import { buildCsvContent } from '@/components/CsvDocumentActions';
import { buildTableDocumentData } from '@/lib/pdf';
import { buildExcelMatrix } from '@/lib/excelExport';

const company = { name: 'JoyaControl', nit: '', address: '', phone: '', email: '', logo: '' };

const document = buildTableDocumentData({
  company,
  title: 'Libro Mayor Financiero',
  filename: 'libro-mayor',
  columns: [{ header: 'Código' }, { header: 'Documento' }, { header: 'Valor' }],
  rows: [['SALE_PAYMENT', 'FAC-1', 800], ['SALE_CANCEL', 'FAC-1', -800]],
});

describe('JOYACONTROL LAN V2.3.2 - exportaciones de trazabilidad', () => {
  it('construye el documento PDF con todos los movimientos', () => {
    expect(document.kind).toBe('table');
    expect(document.rows).toHaveLength(2);
    expect(document.columns.map(column => column.header)).toEqual(['Código', 'Documento', 'Valor']);
  });

  it('construye matriz Excel y CSV sin perder códigos ni documentos', () => {
    const matrix = buildExcelMatrix(
      document.columns.map(column => ({ header: column.header, value: (row: Record<string, string>) => row[column.header] })),
      document.rows.map(row => Object.fromEntries(document.columns.map((column, index) => [column.header, row[index]]))),
    );
    const csv = buildCsvContent(document);
    expect(matrix[1]).toEqual(['SALE_PAYMENT', 'FAC-1', '800']);
    expect(csv).toContain('SALE_CANCEL;FAC-1;-800');
  });
});
