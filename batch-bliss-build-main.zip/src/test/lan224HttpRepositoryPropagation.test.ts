// @vitest-environment node
import { afterEach, describe, expect, it } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import {
  publishLanRepositoryEvent,
  startLanServer,
  stopLanServer,
} from '../../electron/lanServer.js';

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

const post = async <T>(url: string, body: object): Promise<T> => {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
};

afterEach(async () => {
  await stopLanServer();
});

describe('LAN 2.2.4 real HTTP Repository propagation', () => {
  it('propagates product and category create/edit/delete events through heartbeat and Repository', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan224-'));
    const products: Array<Record<string, unknown>> = [];
    const categories: Array<Record<string, unknown>> = [];

    try {
      await startLanServer({
        host: '127.0.0.1',
        port,
        serverName: 'Servidor LAN 2.2.4',
        userDataPath,
        version: '2.1',
        authenticateUser: async () => ({
          success: true,
          userId: 'master-1',
          username: 'master',
          displayName: 'Master',
          role: 'master',
          permissions: ['manage_products'],
        }),
        executeRepositoryCall: async (method: string) => {
          if (method === 'getProducts') return { items: structuredClone(products), total: products.length, page: 1, pageSize: products.length };
          if (method === 'getCategories') return { items: structuredClone(categories), total: categories.length, page: 1, pageSize: categories.length };
          if (method === 'searchProducts') return { items: structuredClone(products), total: products.length, page: 1, pageSize: products.length };
          if (method === 'getProductById') return null;
          throw new Error('METHOD_NOT_ALLOWED');
        },
      });

      const baseUrl = `http://127.0.0.1:${port}`;
      const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
        name: 'Cliente Integración',
        hostname: 'cliente-lan224',
        version: '2.1',
        localTime: new Date().toISOString(),
        deviceInstanceId: 'device-lan224-stable',
      });
      const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
        username: 'master',
        password: 'secret',
        clientId: registered.clientId,
        sessionToken: registered.sessionToken,
      });

      let sequence = 0;
      const ping = async (expectedType: 'PRODUCTS_UPDATED' | 'CATEGORIES_UPDATED') => {
        const payload = await post<{
          repositoryEvents: Array<{ type: string; sequence: number }>;
          latestEventSequence: number;
        }>(`${baseUrl}/client/ping`, {
          clientId: registered.clientId,
          sessionToken: registered.sessionToken,
          timestamp: new Date().toISOString(),
          lastEventSequence: sequence,
        });
        const matching = payload.repositoryEvents.filter(event => event.sequence > sequence);
        expect(matching.at(-1)?.type).toBe(expectedType);
        sequence = payload.latestEventSequence;
      };

      const repositoryCall = async <T>(method: 'getProducts' | 'getCategories') => {
        const payload = await post<{ data: T }>(`${baseUrl}/repository/call`, {
          method,
          args: {},
          clientId: registered.clientId,
          sessionToken: registered.sessionToken,
          authToken: login.authToken,
        });
        return payload.data;
      };

      // Product create.
      products.push({ id: 'product-1', code: 'P-001', name: 'Anillo', salePrice: 100, stock: 2, category: 'Anillos' });
      publishLanRepositoryEvent('PRODUCTS_UPDATED');
      await ping('PRODUCTS_UPDATED');
      expect((await repositoryCall<{ items: Array<{ name: string }> }>('getProducts')).items[0].name).toBe('Anillo');

      // Product edit.
      products[0] = { ...products[0], salePrice: 125 };
      publishLanRepositoryEvent('PRODUCTS_UPDATED');
      await ping('PRODUCTS_UPDATED');
      expect((await repositoryCall<{ items: Array<{ salePrice: number }> }>('getProducts')).items[0].salePrice).toBe(125);

      // Product delete.
      products.splice(0, products.length);
      publishLanRepositoryEvent('PRODUCTS_UPDATED');
      await ping('PRODUCTS_UPDATED');
      expect((await repositoryCall<{ items: unknown[] }>('getProducts')).items).toHaveLength(0);

      // Category create.
      categories.push({ id: 'category-1', name: 'Anillos', name_key: 'anillos', created_at: new Date().toISOString(), auto_created: false });
      publishLanRepositoryEvent('CATEGORIES_UPDATED');
      await ping('CATEGORIES_UPDATED');
      expect((await repositoryCall<{ items: Array<{ name: string }> }>('getCategories')).items[0].name).toBe('Anillos');

      // Category edit.
      categories[0] = { ...categories[0], name: 'Anillos Finos', name_key: 'anillos finos' };
      publishLanRepositoryEvent('CATEGORIES_UPDATED');
      await ping('CATEGORIES_UPDATED');
      expect((await repositoryCall<{ items: Array<{ name: string }> }>('getCategories')).items[0].name).toBe('Anillos Finos');

      // Category delete.
      categories.splice(0, categories.length);
      publishLanRepositoryEvent('CATEGORIES_UPDATED');
      await ping('CATEGORIES_UPDATED');
      expect((await repositoryCall<{ items: unknown[] }>('getCategories')).items).toHaveLength(0);
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });
});
