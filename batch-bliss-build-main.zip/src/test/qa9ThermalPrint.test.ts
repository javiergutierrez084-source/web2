import { describe, expect, it } from 'vitest';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { buildThermalInvoice80Html } from '@/lib/thermalInvoicePrint';
import type { InvoiceDocumentData } from '@/lib/pdf';

const invoice: InvoiceDocumentData = {
  kind: 'invoice',
  filename: 'FV-100',
  invoiceId: 'inv-100',
  number: 'FV-100',
  date: '17/07/2026',
  status: 'paid',
  type: 'sale',
  title: 'Factura de venta',
  company: {
    name: 'JoyaControl Joyas',
    nit: '900123456-7',
    city: 'Bogotá',
    address: 'Calle 1',
    phone: '3000000000',
    email: 'ventas@joyas.test',
    logoUrl: 'data:image/png;base64,AAAA',
  },
  entity: {
    id: 'client-1',
    label: 'Cliente',
    name: 'Cliente Uno',
    document: '123456',
    phone: '3110000000',
    address: '',
    email: '',
  },
  items: [
    { productId: 'p1', code: 'ARG-1', name: 'Argolla oro', quantity: 1, quantityLabel: '1 und', unitPrice: 150000, subtotal: 150000 },
    { productId: 'p2', code: 'CAD-1', name: 'Cadena larga de prueba', quantity: 2, quantityLabel: '2 und', unitPrice: 50000, subtotal: 100000 },
  ],
  subtotal: 250000,
  discount: 0,
  tax: 0,
  total: 250000,
  paymentMethod: 'Efectivo',
  notes: 'Entregar en estuche.',
  qrValue: 'FV-100|250000',
};

describe('QA #9 impresión térmica 80 mm', () => {
  it('usa ancho físico de 80 mm, margen de página cero y sin altura mínima', () => {
    const css = readFileSync(resolve(process.cwd(), 'src/styles/thermal80.css'), 'utf8');
    expect(css).toContain('size: 80mm auto');
    expect(css).toContain('margin: 0');
    expect(css).toContain('width: 80mm');
    expect(css).toContain('min-height: 0');
    expect(css).not.toContain('min-height: 420');
    expect(css).not.toContain('page-break-after: always');
  });

  it('incluye todos los productos, totales, QR y código de barras', () => {
    const html = buildThermalInvoice80Html(invoice);
    expect(html).toContain('Argolla oro');
    expect(html).toContain('Cadena larga de prueba');
    expect(html.replace(/\u00a0/g, ' ')).toContain('$ 250.000');
    expect(html).toContain('aria-label="Código QR"');
    expect(html).toContain('aria-label="Código de barras"');
    expect(html).toContain('Entregar en estuche.');
  });

  it('escapa datos del documento sin alterar sus valores financieros', () => {
    const html = buildThermalInvoice80Html({ ...invoice, notes: '<script>alert(1)</script>' });
    expect(html).not.toContain('<script>alert(1)</script>');
    expect(html).toContain('&lt;script&gt;alert(1)&lt;/script&gt;');
    expect(invoice.total).toBe(250000);
    expect(invoice.items).toHaveLength(2);
  });
});
