// @vitest-environment node
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { describe, expect, it } from 'vitest';

const source = (relativePath: string): string => readFileSync(resolve(process.cwd(), relativePath), 'utf8');

describe('JoyaControl v3.3.x - flujo único de factura de proveedor', () => {
  it('expone el formulario completo únicamente bajo Cuentas por pagar', () => {
    const app = source('src/App.tsx');
    expect(app).toContain('path="/cuentas-por-pagar/nueva"');
    expect(app).toContain('path="/cuentas-por-pagar/editar/:id"');
    expect(app).not.toContain('path="/compras/nueva"');
    expect(app).not.toContain('path="/compras/editar/:id"');
  });

  it('mantiene un único botón principal de creación en Cuentas por pagar', () => {
    const payables = source('src/pages/AccountsPayable.tsx');
    expect(payables).toContain("navigate('/cuentas-por-pagar/nueva')");
    expect(payables).toContain('Nueva factura de proveedor');
    expect(payables).not.toContain('insertSupplierInvoice');
    expect(payables).not.toContain('Nueva cuenta');
  });

  it('elimina accesos directos desde Compras y Dashboard', () => {
    const purchases = source('src/pages/Purchases.tsx');
    const dashboard = source('src/pages/Dashboard.tsx');
    expect(purchases).not.toContain("navigate('/compras/nueva')");
    expect(purchases).not.toContain('Factura proveedor');
    expect(dashboard).not.toContain("href: '/compras/nueva'");
  });

  it('reutiliza el formulario existente y vuelve a Cuentas por pagar', () => {
    const form = source('src/pages/NewPurchase.tsx');
    expect(form).toContain('Nueva factura de proveedor');
    expect(form).toContain("navigate('/cuentas-por-pagar')");
    expect(form).toContain('await createPurchase(purchase');
    expect(form).toContain('await synchronizePayableDueDate(purchase)');
  });

  it('conserva las mismas autorizaciones de gestión bajo las rutas nuevas', () => {
    const auth = source('src/lib/authCore.ts');
    expect(auth).toContain("'/cuentas-por-pagar/nueva': ['manage_purchases']");
    expect(auth).toContain("'/cuentas-por-pagar/editar': ['manage_purchases']");
    expect(auth).not.toContain("'/compras/nueva': ['manage_purchases']");
  });
});
