// @vitest-environment jsdom
import { act, cleanup, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { LanConnectionEventDetail, LanGlobalConnectionState } from '@/lib/LanConnectionManager';

const mocks = vi.hoisted(() => {
  const listeners = new Set<(detail: LanConnectionEventDetail) => void>();
  let state: LanGlobalConnectionState = 'ONLINE';

  return {
    listeners,
    getState: () => state,
    setState(next: LanGlobalConnectionState) { state = next; },
    emit(detail: LanConnectionEventDetail) {
      state = detail.state;
      listeners.forEach(listener => listener(detail));
    },
    refreshProducts: vi.fn(async () => undefined),
    refreshCategories: vi.fn(async () => undefined),
    invalidateProducts: vi.fn(),
    invalidateCategories: vi.fn(),
    invalidateCache: vi.fn(),
  };
});

vi.mock('@/lib/LanConnectionManager', () => ({
  LanConnectionManager: {
    getConnectionState: mocks.getState,
    subscribe: (listener: (detail: LanConnectionEventDetail) => void) => {
      mocks.listeners.add(listener);
      return () => mocks.listeners.delete(listener);
    },
  },
}));

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    refreshProducts: mocks.refreshProducts,
    refreshCategories: mocks.refreshCategories,
  }),
}));

vi.mock('@/lib/LanCommunicationConfig', async importOriginal => {
  const actual = await importOriginal<typeof import('@/lib/LanCommunicationConfig')>();
  return {
    ...actual,
    loadLanConfig: () => ({ mode: 'lan', role: 'client' }),
  };
});

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => ({
    invalidateProducts: mocks.invalidateProducts,
    invalidateCategories: mocks.invalidateCategories,
    invalidateCache: mocks.invalidateCache,
  }),
}));

import LanClientConnectionService from '@/components/LanClientConnectionService';
import { useLanConnectionViewState } from '@/hooks/useLanConnectionViewState';

const event = (
  type: LanConnectionEventDetail['type'],
  state: LanGlobalConnectionState,
): LanConnectionEventDetail => ({ type, state, at: new Date().toISOString() });

const StateProbe = () => {
  const [state] = useLanConnectionViewState();
  return <span data-testid="connection-state">{state}</span>;
};

afterEach(() => cleanup());

beforeEach(() => {
  mocks.listeners.clear();
  mocks.setState('ONLINE');
  vi.clearAllMocks();
});

describe('LAN 2.2.4A visual connection state', () => {
  it('reads the current manager snapshot when the panel-style consumer mounts', () => {
    mocks.setState('ONLINE');
    render(<StateProbe />);

    expect(screen.getByTestId('connection-state').textContent).toBe('connected');
    expect(mocks.listeners.size).toBe(1);
  });

  it('represents OFFLINE immediately and CLIENT_RECONNECTED as ONLINE without another heartbeat', () => {
    render(<StateProbe />);

    act(() => mocks.emit(event('SERVER_OFFLINE', 'OFFLINE')));
    expect(screen.getByTestId('connection-state').textContent).toBe('disconnected');

    act(() => mocks.emit(event('CLIENT_RECONNECTED', 'RECONNECTING')));
    expect(screen.getByTestId('connection-state').textContent).toBe('connected');

    // AUTH_RESTORED is not a connection transition and must not regress the UI.
    act(() => mocks.emit(event('AUTH_RESTORED', 'RECONNECTING')));
    expect(screen.getByTestId('connection-state').textContent).toBe('connected');
  });

  it('cleans the manager listener when the visual consumer unmounts', () => {
    const view = render(<StateProbe />);
    expect(mocks.listeners.size).toBe(1);

    view.unmount();
    expect(mocks.listeners.size).toBe(0);
  });

  it('shows the offline notice even when SERVER_OFFLINE happened before the service mounted', async () => {
    mocks.setState('OFFLINE');
    render(<LanClientConnectionService />);

    expect(await screen.findByText('Servidor LAN desconectado.')).toBeTruthy();
    expect(screen.getByText('Mostrando la última información sincronizada.')).toBeTruthy();
    expect(screen.getByText('Reintentando conexión...')).toBeTruthy();
  });
});
