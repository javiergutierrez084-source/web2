// @vitest-environment jsdom
import { cleanup, render, screen, waitFor } from '@testing-library/react';
import { afterEach, describe, expect, it, vi } from 'vitest';

const pdfMocks = vi.hoisted(() => ({
  renderPdfDocument: vi.fn().mockResolvedValue(new Blob(['pdf'], { type: 'application/pdf' })),
  createPdfFile: vi.fn().mockReturnValue({ blob: new Blob(['pdf']), url: 'blob:preview', filename: 'audit.pdf' }),
  revokePdfFile: vi.fn(),
  downloadPdfFile: vi.fn(),
  openPdfForPrint: vi.fn(),
}));

vi.mock('@/lib/pdf', () => ({
  DEFAULT_DOCUMENT_FORMATS: ['letter'],
  PDF_TEMPLATES: { letter: { label: 'Carta', description: 'Hoja' } },
  ...pdfMocks,
}));
vi.mock('@/lib/thermalInvoicePrint', () => ({ buildThermalInvoice80Html: vi.fn(), printThermalInvoice80: vi.fn() }));

import { PdfDocumentModal } from '@/components/PdfDocumentActions';

describe('auditoría funcional - visor PDF', () => {
  afterEach(() => cleanup());

  it('presenta Vista previa como estado y no como un botón sin acción', async () => {
    render(<PdfDocumentModal
      document={{ kind: 'table', id: 'audit-pdf', title: 'Auditoría', filename: 'Auditoria', company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' }, columns: [{ header: 'Campo' }], rows: [['Dato']], date: '2026-07-27' }}
      formats={['letter']}
      onClose={vi.fn()}
    />);

    await waitFor(() => expect(screen.getByRole('status', { name: 'Vista previa activa' })).not.toBeNull());
    expect(screen.queryByRole('button', { name: 'Vista previa' })).toBeNull();
    expect(screen.getByRole('button', { name: 'Descargar PDF' })).not.toBeNull();
    expect(screen.getByRole('button', { name: 'Imprimir' })).not.toBeNull();
  });
});
