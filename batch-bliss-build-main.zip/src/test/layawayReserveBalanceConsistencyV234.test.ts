import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';
import { buildFinancialCompositions } from '@/lib/FinancialTraceabilityService';
import { resolveFinancialAccountBalance } from '@/lib/FinancialLedgerService';
import {
  LAYAWAY_RESERVE_ACCOUNT_ID,
  MAIN_CASH_ACCOUNT_ID,
} from '@/lib/FinancialPositionService';

const date = '2026-07-21';

const account = (id: string, name: string, balance: number): FinancialAccount => ({
  id,
  name,
  kind: 'cash',
  active: true,
  balance,
  createdAt: `${date}T08:00:00.000Z`,
  updatedAt: `${date}T12:00:00.000Z`,
});

const movement = (
  id: string,
  createdAt: string,
  overrides: Partial<FinancialMovement>,
): FinancialMovement => ({
  id,
  type: 'adjustment',
  amount: 0,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: id,
  documentType: 'manual',
  documentId: id,
  observation: id,
  userId: 'user-1',
  userName: 'Administrador',
  date,
  createdAt,
  status: 'COMPLETED',
  ...overrides,
});

describe('JOYACONTROL LAN V2.3.3A - consistencia de Caja Separados', () => {
  it('Dashboard, Corrección Excepcional y Reportes usan el mismo saldo reconstruido', () => {
    const accounts = [
      account(MAIN_CASH_ACCOUNT_ID, 'Caja Principal', 300),
      account(LAYAWAY_RESERVE_ACCOUNT_ID, 'Caja Separados', 0),
    ];

    const movements: FinancialMovement[] = [
      movement('reversed-payment', `${date}T08:00:00.000Z`, {
        amount: 500,
        destinationAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationBalanceBefore: 0,
        destinationBalanceAfter: 500,
        movementCode: 'LAYAWAY_PAYMENT',
        documentType: 'layaway',
        referenceType: 'LAYAWAY',
        referenceId: 'layaway-reversed',
        status: 'REVERSED',
      }),
      movement('customer-credit', `${date}T09:00:00.000Z`, {
        amount: 500,
        movementCode: 'CUSTOMER_CREDIT',
        documentType: 'layaway_credit',
        referenceType: 'CUSTOMER',
        referenceId: 'customer-1',
        customerId: 'customer-1',
      }),
      movement('customer-credit-used', `${date}T10:00:00.000Z`, {
        type: 'transfer',
        amount: 300,
        originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationAccountId: MAIN_CASH_ACCOUNT_ID,
        originBalanceBefore: 500,
        originBalanceAfter: 200,
        destinationBalanceBefore: 0,
        destinationBalanceAfter: 300,
        movementCode: 'CUSTOMER_CREDIT_USED',
        documentType: 'customer_credit_used',
        relatedMovementId: 'customer-credit',
        referenceType: 'SALE',
        referenceId: 'invoice-1',
        customerId: 'customer-1',
      }),
      movement('layaway-refund', `${date}T11:00:00.000Z`, {
        amount: 200,
        originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        originBalanceBefore: 200,
        originBalanceAfter: 0,
        movementCode: 'LAYAWAY_REFUND',
        documentType: 'layaway_refund',
        referenceType: 'LAYAWAY',
        referenceId: 'layaway-1',
      }),
      movement('cancelled-credit-use', `${date}T12:00:00.000Z`, {
        type: 'transfer',
        amount: 50,
        originAccountId: LAYAWAY_RESERVE_ACCOUNT_ID,
        destinationAccountId: MAIN_CASH_ACCOUNT_ID,
        originBalanceBefore: 0,
        originBalanceAfter: -50,
        destinationBalanceBefore: 300,
        destinationBalanceAfter: 350,
        movementCode: 'CUSTOMER_CREDIT_USED',
        documentType: 'customer_credit_used',
        relatedMovementId: 'customer-credit',
        referenceType: 'SALE',
        referenceId: 'invoice-cancelled',
        customerId: 'customer-1',
        status: 'CANCELLED',
      }),
    ];

    // Corrección Excepcional now resolves its account option through this exact
    // shared ledger balance instead of reading a separate local calculation.
    const exceptionalCorrectionBalance = resolveFinancialAccountBalance(
      accounts,
      movements,
      LAYAWAY_RESERVE_ACCOUNT_ID,
    );

    const reportBalance = buildFinancialCompositions({
      accounts,
      movements,
      contacts: [],
      invoices: [],
      purchases: [],
      expenses: [],
      layaways: [],
    }).layawayReserve.total;

    const dashboardBalance = buildDashboardSnapshot({
      products: [],
      contacts: [],
      invoices: [],
      purchases: [],
      expenses: [],
      layaways: [],
      cashSessions: [],
      accounts,
      movements,
      financialSummary: null,
      backupStatusAvailable: false,
      now: new Date(`${date}T14:00:00.000Z`),
    }).financialPosition.layawayReserve;

    expect(exceptionalCorrectionBalance).toBe(0);
    expect(reportBalance).toBe(exceptionalCorrectionBalance);
    expect(dashboardBalance).toBe(exceptionalCorrectionBalance);
  });
});
