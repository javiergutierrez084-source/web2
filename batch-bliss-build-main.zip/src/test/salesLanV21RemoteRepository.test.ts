// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import Dexie from 'dexie';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';
import type {
  Contact,
  FinancialAccount,
  FinancialMovement,
  FinancialSummary,
  Invoice,
  Product,
  Quotation,
} from '@/data/mockData';
import type { CompanyInfo, Layaway } from '@/domain/models';
import type { SalesWorkspace } from '@/lib/SalesRepositoryService';


function privateLanIp(): string {
  for (const addresses of Object.values(os.networkInterfaces())) {
    for (const address of addresses || []) {
      if (address.family !== 'IPv4' || address.internal) continue;
      const parts = address.address.split('.').map(Number);
      if (parts[0] === 10 || (parts[0] === 192 && parts[1] === 168) || (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31)) {
        return address.address;
      }
    }
  }
  throw new Error('NO_PRIVATE_LAN_IP_FOR_TEST');
}

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function post<T>(baseUrl: string, route: string, body: object): Promise<T> {
  const response = await fetch(`${baseUrl}${route}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
}

const company: CompanyInfo = {
  name: 'JoyaControl', nit: '1', phone: '', city: '', address: '', email: '', logoUrl: '',
};
const product: Product = {
  id: 'p1', code: 'A-1', name: 'Anillo', category: 'Anillos', purchasePrice: 50,
  salePrice: 100, weightGrams: 2, margin: 100, stock: 4, minStock: 1,
};
const contact: Contact = {
  id: 'c1', type: 'client', name: 'Ana', document: '123', phone: '', email: '', address: '',
};
const invoice: Invoice = {
  id: 'i1', number: 'FAC-001', clientId: contact.id, clientName: contact.name,
  items: [{ productId: product.id, code: product.code, name: product.name, quantity: 1, weightGrams: 2, unitPrice: 100, subtotal: 100 }],
  subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-20', status: 'paid',
};
const quotation: Quotation = {
  id: 'q1', number: 'COT-001', clientId: contact.id, clientName: contact.name,
  items: invoice.items, subtotal: 100, discount: 0, tax: 0, total: 100,
  date: '2026-07-20', validUntil: '2026-07-30', status: 'active',
};
const layaway: Layaway = {
  id: 'l1', invoiceId: invoice.id, invoice: { ...invoice, status: 'pending' }, payments: [], completed: false,
};
const account: FinancialAccount = {
  id: 'a1', name: 'Caja', kind: 'cash', active: true, balance: 100,
  createdAt: '2026-07-20T10:00:00.000Z', updatedAt: '2026-07-20T10:00:00.000Z',
};
const movement: FinancialMovement = {
  id: 'm1', type: 'sale_income', amount: 100, destinationAccountId: account.id,
  originBalanceBefore: 0, originBalanceAfter: 0, destinationBalanceBefore: 0,
  destinationBalanceAfter: 100, reference: invoice.number, documentType: 'invoice',
  documentId: invoice.id, observation: '', userId: 'u1', userName: 'Master',
  date: '2026-07-20', createdAt: '2026-07-20T10:00:00.000Z',
};
const summary: FinancialSummary = {
  cash: 100, banks: 0, totalFunds: 100, accountsPayable: 0, sales: 100,
  costOfSales: 50, grossProfit: 50, expenses: 0, netProfit: 50,
  availableProfit: 50, incomeToday: 100, expensesToday: 0,
};
const workspace: SalesWorkspace = {
  company,
  contacts: [contact],
  invoices: [invoice],
  layaways: [layaway],
  quotations: [quotation],
  financialAccounts: [account],
  financialMovements: [movement],
  financialSummary: summary,
};

const responses: Record<string, unknown> = {
  getSalesWorkspace: workspace,
  querySales: [invoice],
  getSaleById: invoice,
  createSale: [product],
  updateSaleStatus: undefined,
  cancelSale: {
    invoiceId: invoice.id,
    cancelledAt: '2026-07-20T11:00:00.000Z',
    cancelledBy: 'Master',
    restoredProducts: [product],
  },
  applySalesContactChanges: undefined,
  createSalesQuotation: quotation,
  updateSalesQuotationStatus: undefined,
  createSalesLayaway: layaway,
  updateSalesLayaway: { layaway, updatedProducts: [product] },
  deleteSalesLayaway: { invoiceId: invoice.id, restoredProducts: [product] },
  addSalesLayawayPayment: {
    payment: { id: 'pay1', amount: 40, date: '2026-07-20', method: 'Efectivo', accountId: account.id },
    invoiceId: invoice.id,
    completed: false,
  },
  completeSalesLayaway: invoice.id,
};

afterEach(async () => {
  await stopLanServer();
  localStorage.clear();
  vi.restoreAllMocks();
});

describe('JoyaControl LAN V2.1 Sales Repository transport', () => {
  it('executes every Sales read/write through ApiRepository and the existing /repository/call route', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-sales-v21-'));
    const port = await freePort();
    const lanIp = privateLanIp();
    const baseUrl = `http://${lanIp}:${port}`;
    const provider = vi.fn(async (method: string) => {
      if (!(method in responses)) throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
      return responses[method];
    });

    try {
      await startLanServer({
        host: '0.0.0.0',
        port,
        serverName: 'Servidor Ventas LAN',
        userDataPath,
        version: '2.1',
        executeRepositoryCall: provider,
        authenticateUser: async () => ({
          success: true,
          userId: 'master-1',
          username: 'master',
          displayName: 'Master',
          role: 'master',
          permissions: ['create_sales', 'edit_sales', 'cancel_invoices', 'manage_contacts', 'manage_quotations', 'manage_layaways'],
        }),
      });

      const registered = await post<{ clientId: string; sessionToken: string }>(baseUrl, '/client/register', {
        name: 'Cliente Ventas', hostname: 'cliente-ventas', version: '2.1',
        localTime: new Date().toISOString(), deviceInstanceId: 'sales-device-1',
      });
      const login = await post<{ authToken: string }>(baseUrl, '/login', {
        username: 'master', password: 'secret',
        clientId: registered.clientId, sessionToken: registered.sessionToken,
      });
      saveLanConfig({
        ...createDefaultLanConfig(),
        mode: 'lan',
        role: 'client',
        clientServerIp: lanIp,
        clientServerPort: port,
        clientId: registered.clientId,
        sessionToken: registered.sessionToken,
        authToken: login.authToken,
      });

      const dexieOpen = vi.spyOn(Dexie.prototype, 'open');
      const repository = new ApiRepository({ baseUrl });

      expect(await repository.getSalesWorkspace()).toEqual(workspace);
      expect(await repository.querySales({ text: 'FAC', clientId: contact.id })).toEqual([invoice]);
      expect(await repository.getSaleById(invoice.id)).toEqual(invoice);
      expect(await repository.insertInvoiceWithFinancials(invoice, [{ accountId: account.id, amount: 100 }], {})).toEqual([product]);
      await expect(repository.updateInvoiceStatus(invoice.id, 'paid')).resolves.toBeUndefined();
      await expect(repository.cancelInvoice(invoice.id, 'Prueba')).resolves.toMatchObject({ invoiceId: invoice.id });
      await expect(repository.applyContactChanges({ upserts: [contact], deleteIds: [] })).resolves.toBeUndefined();
      await expect(repository.createQuotation({
        clientId: quotation.clientId,
        clientName: quotation.clientName,
        items: quotation.items,
        subtotal: quotation.subtotal,
        discount: quotation.discount,
        tax: quotation.tax,
        total: quotation.total,
        date: quotation.date,
        validUntil: quotation.validUntil,
        status: quotation.status,
      })).resolves.toEqual(quotation);
      await expect(repository.updateQuotationStatus(quotation.id, 'accepted')).resolves.toBeUndefined();
      await expect(repository.insertLayaway(layaway)).resolves.toEqual(layaway);
      await expect(repository.updateLayaway(layaway.id, layaway.invoice)).resolves.toMatchObject({ layaway });
      await expect(repository.deleteLayaway(layaway.id)).resolves.toMatchObject({ invoiceId: invoice.id });
      await expect(repository.deleteSalesLayaway(layaway.id, 'credit')).resolves.toMatchObject({ invoiceId: invoice.id });
      await expect(repository.addLayawayPayment(layaway.id, {
        amount: 40, date: '2026-07-20', method: 'Efectivo', accountId: account.id,
      })).resolves.toMatchObject({ invoiceId: invoice.id, completed: false });
      await expect(repository.completeLayawayDb(layaway.id, '2026-07-20')).resolves.toBe(invoice.id);

      const invokedMethods = provider.mock.calls.map(call => call[0]);
      expect(invokedMethods).toEqual([
        'getSalesWorkspace',
        'querySales',
        'getSaleById',
        'createSale',
        'updateSaleStatus',
        'cancelSale',
        'applySalesContactChanges',
        'createSalesQuotation',
        'updateSalesQuotationStatus',
        'createSalesLayaway',
        'updateSalesLayaway',
        'deleteSalesLayaway',
        'deleteSalesLayaway',
        'addSalesLayawayPayment',
        'completeSalesLayaway',
      ]);
      const deleteCalls = provider.mock.calls.filter(call => call[0] === 'deleteSalesLayaway');
      expect(deleteCalls[0]?.[1]).toMatchObject({ layawayId: layaway.id, resolution: 'refund' });
      expect(deleteCalls[1]?.[1]).toMatchObject({ layawayId: layaway.id, resolution: 'credit' });
      expect(dexieOpen).not.toHaveBeenCalled();
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  }, 30_000);
});
