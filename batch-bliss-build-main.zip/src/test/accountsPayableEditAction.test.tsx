// @vitest-environment jsdom
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { SupplierInvoiceView } from '@/domain/models';

const mocks = vi.hoisted(() => ({
  fetchSupplierInvoices: vi.fn(),
  updateSupplierInvoiceSafe: vi.fn(),
  addSupplierPaymentWithAccount: vi.fn(),
  deleteSupplierInvoiceSafe: vi.fn(),
  refreshFinancialData: vi.fn(),
  toast: vi.fn(),
}));

const invoice: SupplierInvoiceView = {
  id: 'payable-1',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Uno',
  invoiceNumber: 'FAC-001',
  issueDate: '2026-07-01',
  dueDate: '2026-07-31',
  total: 1_500_000,
  initialValue: 1_500_000,
  pendingBalance: 1_500_000,
  sourceType: 'supplier_invoice',
  sourceId: 'payable-1',
  status: 'pending',
  notes: 'Compra administrativa',
  payments: [],
};

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
    contacts: [{ id: 'supplier-1', type: 'supplier', name: 'Proveedor Uno', document: '900', phone: '', email: '', address: '', notes: '' }],
    financialAccounts: [{ id: 'account-caja-principal', name: 'Caja Principal', kind: 'cash', active: true, balance: 5_000_000 }],
    refreshFinancialData: mocks.refreshFinancialData,
    financialRefreshVersion: 0,
  }),
}));
vi.mock('@/hooks/use-toast', () => ({ useToast: () => ({ toast: mocks.toast }) }));
vi.mock('@/components/PdfDocumentActions', () => ({ default: () => null }));
vi.mock('@/components/ExcelDocumentActions', () => ({ default: () => null }));
vi.mock('@/lib/auth', () => ({ getSession: () => null, logActivity: vi.fn() }));
vi.mock('@/lib/database', () => ({
  fetchSupplierInvoices: mocks.fetchSupplierInvoices,
  updateSupplierInvoiceSafe: mocks.updateSupplierInvoiceSafe,
  addSupplierPaymentWithAccount: mocks.addSupplierPaymentWithAccount,
  deleteSupplierInvoiceSafe: mocks.deleteSupplierInvoiceSafe,
}));

import AccountsPayable from '@/pages/AccountsPayable';

describe('auditoría funcional - editar cuenta por pagar', () => {
  afterEach(() => cleanup());

  beforeEach(() => {
    vi.clearAllMocks();
    mocks.fetchSupplierInvoices.mockResolvedValue([invoice]);
    mocks.updateSupplierInvoiceSafe.mockResolvedValue(undefined);
    mocks.refreshFinancialData.mockResolvedValue(undefined);
  });

  it('abre el formulario completo, guarda mediante Repository y refresca la lista', async () => {
    render(<MemoryRouter><AccountsPayable /></MemoryRouter>);

    const editButton = await screen.findByRole('button', { name: 'Editar FAC-001' });
    fireEvent.click(editButton);

    expect(await screen.findByRole('heading', { name: 'Editar cuenta por pagar' })).not.toBeNull();
    expect(screen.getByDisplayValue('Proveedor Uno')).not.toBeNull();
    expect(screen.getByDisplayValue('FAC-001')).not.toBeNull();
    expect(screen.getByDisplayValue('2026-07-01')).not.toBeNull();
    expect(screen.getByDisplayValue('2026-07-31')).not.toBeNull();
    expect(screen.getByDisplayValue('1500000')).not.toBeNull();
    expect(screen.getByDisplayValue('Compra administrativa')).not.toBeNull();

    fireEvent.change(screen.getByDisplayValue('FAC-001'), { target: { value: 'FAC-001-EDITADA' } });
    fireEvent.change(screen.getByDisplayValue('Compra administrativa'), { target: { value: 'Concepto actualizado' } });
    fireEvent.click(screen.getByRole('button', { name: 'Guardar' }));

    await waitFor(() => expect(mocks.updateSupplierInvoiceSafe).toHaveBeenCalledWith(
      'payable-1',
      expect.objectContaining({
        supplierId: 'supplier-1',
        supplierName: 'Proveedor Uno',
        invoiceNumber: 'FAC-001-EDITADA',
        issueDate: '2026-07-01',
        dueDate: '2026-07-31',
        total: 1_500_000,
        notes: 'Concepto actualizado',
        status: 'pending',
      }),
    ));
    await waitFor(() => expect(mocks.refreshFinancialData).toHaveBeenCalledTimes(1));
    expect(mocks.fetchSupplierInvoices.mock.calls.length).toBeGreaterThanOrEqual(2);
  });
});
