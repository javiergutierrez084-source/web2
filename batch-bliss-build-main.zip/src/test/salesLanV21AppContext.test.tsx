// @vitest-environment jsdom
import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Invoice, Product } from '@/data/mockData';
import type { SalesWorkspace } from '@/lib/SalesRepositoryService';

const product: Product = {
  id: 'p1', code: 'A-1', name: 'Anillo', category: 'Anillos', purchasePrice: 50,
  salePrice: 100, weightGrams: 2, margin: 100, stock: 4, minStock: 1,
};
const originalInvoice: Invoice = {
  id: 'i1', number: 'FAC-001', clientId: 'c1', clientName: 'Ana', items: [],
  subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-20', status: 'paid',
};
const newInvoice: Invoice = {
  ...originalInvoice, id: 'i2', number: 'FAC-002', total: 150, subtotal: 150,
};
const synchronizedInvoice: Invoice = {
  ...originalInvoice, id: 'i3', number: 'FAC-003', total: 200, subtotal: 200,
};

const makeWorkspace = (invoices: Invoice[]): SalesWorkspace => ({
  company: { name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '' },
  contacts: [{ id: 'c1', type: 'client', name: 'Ana', document: '1', phone: '', email: '', address: '' }],
  invoices,
  layaways: [],
  quotations: [],
  financialAccounts: [],
  financialMovements: [],
  financialSummary: null,
});

const mocks = vi.hoisted(() => ({
  getWorkspace: vi.fn(),
  createSale: vi.fn(),
  invalidate: vi.fn(),
  fetchProducts: vi.fn(),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getActiveRepositoryMode: () => 'lan',
}));

vi.mock('@/lib/database', () => ({
  fetchProducts: mocks.fetchProducts,
}));

vi.mock('@/lib/categoryService', () => ({
  getAllCategoryNames: vi.fn(async () => ['Anillos']),
}));

vi.mock('@/lib/BackupManager', () => ({ BackupManager: { isBusy: vi.fn(() => false) } }));
vi.mock('@/lib/BackupScheduler', () => ({ BackupScheduler: { init: vi.fn() } }));

vi.mock('@/lib/SalesRepositoryService', () => ({
  SalesRepositoryService: {
    getSalesWorkspace: mocks.getWorkspace,
    createSale: mocks.createSale,
    invalidate: mocks.invalidate,
  },
}));

import { AppProvider, useApp } from '@/contexts/AppContext';

function Probe() {
  const { invoices, recordInvoice, isLoading } = useApp();
  return (
    <div>
      <span data-testid="loading">{String(isLoading)}</span>
      <span data-testid="invoice-numbers">{invoices.map(invoice => invoice.number).join(',')}</span>
      <button type="button" onClick={() => void recordInvoice(newInvoice, [], {})}>Crear venta</button>
    </div>
  );
}

beforeEach(() => {
  mocks.getWorkspace.mockReset();
  mocks.createSale.mockReset().mockResolvedValue([product]);
  mocks.invalidate.mockReset();
  mocks.fetchProducts.mockReset().mockResolvedValue([product]);
});

describe('Sales LAN V2.1 AppContext integration', () => {
  it('loads, writes and resynchronizes Sales through SalesRepositoryService without reloading the page', async () => {
    mocks.getWorkspace
      .mockResolvedValueOnce(makeWorkspace([originalInvoice]))
      .mockResolvedValueOnce(makeWorkspace([newInvoice, originalInvoice]))
      .mockResolvedValueOnce(makeWorkspace([synchronizedInvoice, newInvoice, originalInvoice]));

    render(<AppProvider><Probe /></AppProvider>);

    await waitFor(() => expect(screen.getByTestId('loading').textContent).toBe('false'));
    expect(screen.getByTestId('invoice-numbers').textContent).toContain('FAC-001');

    fireEvent.click(screen.getByRole('button', { name: 'Crear venta' }));
    await waitFor(() => expect(mocks.createSale).toHaveBeenCalledWith(newInvoice, [], {}));
    await waitFor(() => expect(screen.getByTestId('invoice-numbers').textContent).toBe('FAC-002,FAC-001'));

    window.dispatchEvent(new CustomEvent('joyacontrol:lan-repository-synchronized'));
    await waitFor(() => expect(mocks.invalidate).toHaveBeenCalledTimes(1));
    await waitFor(() => expect(screen.getByTestId('invoice-numbers').textContent).toBe('FAC-003,FAC-002,FAC-001'));

    expect(mocks.getWorkspace).toHaveBeenCalledTimes(3);
  });
});
