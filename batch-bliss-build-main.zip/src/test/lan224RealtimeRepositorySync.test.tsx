// @vitest-environment jsdom
import { act, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { LanConnectionEventDetail, LanGlobalConnectionState } from '@/lib/LanConnectionManager';

const mocks = vi.hoisted(() => {
  const listeners = new Set<(detail: LanConnectionEventDetail) => void>();
  let connectionState: LanGlobalConnectionState = 'ONLINE';
  const callOrder: string[] = [];

  return {
    listeners,
    callOrder,
    setConnectionState(state: LanGlobalConnectionState) { connectionState = state; },
    getConnectionState: () => connectionState,
    emit(detail: LanConnectionEventDetail) {
      connectionState = detail.state;
      listeners.forEach(listener => listener(detail));
    },
    invalidateProducts: vi.fn(() => callOrder.push('invalidateProducts')),
    invalidateCategories: vi.fn(() => callOrder.push('invalidateCategories')),
    invalidateCache: vi.fn(() => callOrder.push('invalidateCache')),
    refreshProducts: vi.fn(async () => { callOrder.push('refreshProducts'); }),
    refreshCategories: vi.fn(async () => { callOrder.push('refreshCategories'); }),
  };
});

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    refreshProducts: mocks.refreshProducts,
    refreshCategories: mocks.refreshCategories,
  }),
}));

vi.mock('@/lib/LanCommunicationConfig', () => ({
  loadLanConfig: () => ({ mode: 'lan', role: 'client' }),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => ({
    invalidateProducts: mocks.invalidateProducts,
    invalidateCategories: mocks.invalidateCategories,
    invalidateCache: mocks.invalidateCache,
  }),
}));

vi.mock('@/lib/LanConnectionManager', () => ({
  LanConnectionManager: {
    getConnectionState: mocks.getConnectionState,
    subscribe: (listener: (detail: LanConnectionEventDetail) => void) => {
      mocks.listeners.add(listener);
      return () => mocks.listeners.delete(listener);
    },
  },
}));

import LanClientConnectionService from '@/components/LanClientConnectionService';

const event = (
  type: LanConnectionEventDetail['type'],
  state: LanGlobalConnectionState = 'ONLINE',
): LanConnectionEventDetail => ({ type, state, at: new Date().toISOString() });

beforeEach(() => {
  mocks.listeners.clear();
  mocks.callOrder.length = 0;
  mocks.setConnectionState('ONLINE');
  vi.clearAllMocks();
});

describe('LAN 2.2.4 repository synchronization', () => {
  it('invalidates and reloads products automatically when PRODUCTS_UPDATED arrives', async () => {
    render(<LanClientConnectionService />);

    act(() => mocks.emit(event('PRODUCTS_UPDATED')));

    await waitFor(() => expect(mocks.refreshProducts).toHaveBeenCalledTimes(1));
    expect(mocks.invalidateProducts).toHaveBeenCalledTimes(1);
    expect(mocks.refreshCategories).not.toHaveBeenCalled();
    expect(mocks.callOrder).toEqual(['invalidateProducts', 'refreshProducts']);
  });

  it('invalidates and reloads categories automatically when CATEGORIES_UPDATED arrives', async () => {
    render(<LanClientConnectionService />);

    act(() => mocks.emit(event('CATEGORIES_UPDATED')));

    await waitFor(() => expect(mocks.refreshCategories).toHaveBeenCalledTimes(1));
    expect(mocks.invalidateCategories).toHaveBeenCalledTimes(1);
    expect(mocks.refreshProducts).not.toHaveBeenCalled();
    expect(mocks.callOrder).toEqual(['invalidateCategories', 'refreshCategories']);
  });

  it('keeps visible data untouched while offline and shows the required notice', async () => {
    render(<LanClientConnectionService />);

    act(() => mocks.emit(event('SERVER_OFFLINE', 'OFFLINE')));

    expect(await screen.findByText('Servidor LAN desconectado.')).toBeTruthy();
    expect(screen.getByText('Mostrando la última información sincronizada.')).toBeTruthy();
    expect(screen.getByText('Reintentando conexión...')).toBeTruthy();
    expect(mocks.refreshProducts).not.toHaveBeenCalled();
    expect(mocks.refreshCategories).not.toHaveBeenCalled();
  });

  it('invalidates all caches on reconnect and synchronizes both collections after SERVER_ONLINE', async () => {
    render(<LanClientConnectionService />);

    act(() => mocks.emit(event('SERVER_OFFLINE', 'OFFLINE')));
    act(() => mocks.emit(event('CLIENT_RECONNECTED', 'RECONNECTING')));

    expect(mocks.invalidateCache).toHaveBeenCalledTimes(1);
    expect(screen.getByText('Servidor reconectado.')).toBeTruthy();
    expect(screen.getByText('Sincronizando información...')).toBeTruthy();
    expect(mocks.refreshProducts).not.toHaveBeenCalled();

    act(() => mocks.emit(event('SERVER_ONLINE', 'ONLINE')));

    await waitFor(() => {
      expect(mocks.refreshProducts).toHaveBeenCalledTimes(1);
      expect(mocks.refreshCategories).toHaveBeenCalledTimes(1);
    });
    expect(mocks.invalidateProducts).toHaveBeenCalledTimes(1);
    expect(mocks.invalidateCategories).toHaveBeenCalledTimes(1);
  });
});
