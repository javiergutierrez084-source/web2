// @vitest-environment node
import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(process.cwd());
const panelSource = fs.readFileSync(path.join(root, 'src/components/LanCommunicationPanel.tsx'), 'utf8');
const configSource = fs.readFileSync(path.join(root, 'src/lib/LanCommunicationConfig.ts'), 'utf8');

describe('LAN device-maintenance interface', () => {
  it('shows the maintenance entry and requires React confirmations', () => {
    expect(panelSource).toContain('Mantenimiento de equipos LAN');
    expect(panelSource).toContain('AlertDialog');
    expect(panelSource).toContain('Esta acción no puede deshacerse');
    expect(panelSource).not.toMatch(/\bwindow\.confirm\s*\(/);
    expect(panelSource).not.toMatch(/\bconfirm\s*\(/);
  });

  it('disables the row delete action for connected equipment', () => {
    expect(panelSource).toContain("disabled={client.status === 'connected'}");
    expect(panelSource).toContain('No es posible eliminar un equipo conectado.');
  });

  it('uses the existing LAN HTTP service without Repository or commercial modules', () => {
    expect(configSource).toContain("lanEndpoint('/clients/maintenance')");
    expect(configSource).toContain('maintainLanDevices');
    expect(configSource).not.toContain('/repository/call');
  });
});
