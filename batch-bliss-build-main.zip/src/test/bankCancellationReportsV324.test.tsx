// @vitest-environment jsdom
import { fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { FinancialMovement } from '@/data/mockData';
import { localDateKey } from '@/lib/reportDateRange';

const today = localDateKey(new Date());
const previousDate = new Date();
previousDate.setDate(previousDate.getDate() - 1);
const yesterday = localDateKey(previousDate);

const movement = (overrides: Partial<FinancialMovement>): FinancialMovement => ({
  id: crypto.randomUUID(),
  type: 'adjustment',
  amount: 100,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'FAC-REG-1',
  documentType: 'manual',
  documentId: 'invoice-regression-1',
  observation: 'Regresión bancaria v3.2.4',
  userId: 'user-1',
  userName: 'Admin',
  date: today,
  createdAt: `${today}T12:00:00.000Z`,
  status: 'POSTED',
  referenceType: 'SALE',
  referenceId: 'invoice-regression-1',
  ...overrides,
});

const appState = {
  company: { name: 'JoyaControl', nit: '', address: '', phone: '', email: '', logo: '' },
  contacts: [],
  invoices: [],
  expenses: [],
  purchaseInvoices: [],
  products: [],
  layaways: [],
  financialAccounts: [
    { id: 'bank-1', name: 'Banco Principal', kind: 'bank' as const, active: true, balance: 1_000, createdAt: '', updatedAt: '' },
  ],
  financialMovements: [
    movement({
      id: 'opening-bank',
      type: 'opening_balance',
      amount: 1_000,
      movementCode: 'OPENING_BALANCE',
      documentType: 'financial_account',
      documentId: 'bank-1',
      referenceType: 'FINANCIAL_ACCOUNT',
      referenceId: 'bank-1',
      destinationAccountId: 'bank-1',
      destinationBalanceAfter: 1_000,
      date: yesterday,
      createdAt: `${yesterday}T08:00:00.000Z`,
    }),
    movement({
      id: 'sale-bank',
      type: 'sale_income',
      amount: 300,
      movementCode: 'SALE_PAYMENT',
      documentType: 'invoice',
      destinationAccountId: 'bank-1',
      destinationBalanceBefore: 1_000,
      destinationBalanceAfter: 1_300,
    }),
    movement({
      id: 'sale-bank-cancel',
      amount: 300,
      movementCode: 'SALE_CANCEL',
      documentType: 'invoice_cancellation',
      relatedMovementId: 'sale-bank',
      originAccountId: 'bank-1',
      destinationAccountId: undefined,
      originBalanceBefore: 1_300,
      originBalanceAfter: 1_000,
    }),
  ],
};

vi.mock('@/contexts/AppContext', () => ({ useApp: () => appState }));

import Reports from '@/pages/Reports';

beforeEach(() => {
  window.URL.createObjectURL = vi.fn(() => 'blob:test');
  window.URL.revokeObjectURL = vi.fn();
});

describe('JoyaControl v3.2.4 - anulación bancaria con filtros históricos', () => {
  it('mantiene el saldo actual desde todo el Ledger y filtra únicamente las filas históricas', () => {
    render(<MemoryRouter initialEntries={['/reportes?tab=accounts']}><Reports /></MemoryRouter>);

    fireEvent.click(screen.getByRole('button', { name: 'Hoy' }));

    const bankRow = screen.getByText('Banco Principal').closest('tr');
    expect(bankRow?.textContent).toContain('1.000');
    expect(screen.getByText('SALE_CANCEL')).toBeTruthy();
    expect(screen.queryByText('OPENING_BALANCE')).toBeNull();
  });
});
