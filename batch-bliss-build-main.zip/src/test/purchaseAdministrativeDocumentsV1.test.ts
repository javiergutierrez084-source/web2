import { describe, expect, it } from 'vitest';
import type { ExpenseInvoice, PurchaseInvoice } from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import {
  buildPurchaseDocumentRows,
  calculatePurchaseDashboardMetrics,
  duplicateExpenseNumber,
  encodeExpenseDocumentNotes,
  parseExpenseDocumentNotes,
} from '@/lib/PurchaseDocumentsService';

const purchase: PurchaseInvoice = {
  id: 'purchase-1',
  number: 'COM-0001',
  supplierId: 'supplier-1',
  supplierName: 'Proveedor Mercancía',
  items: [{ productId: 'product-1', code: 'P1', name: 'Anillo', quantity: 1, weightGrams: 5, unitPrice: 500, subtotal: 500 }],
  subtotal: 500,
  discount: 0,
  tax: 0,
  total: 500,
  date: '2026-07-27',
  status: 'pending',
  description: 'Compra de mercancía',
  paymentMethod: 'Efectivo',
};

const expensePayable: SupplierInvoiceView = {
  id: 'expense-1',
  supplierId: 'supplier-2',
  supplierName: 'Empresa de Energía',
  invoiceNumber: 'GAS-0001',
  issueDate: '2026-07-27',
  dueDate: '2026-08-10',
  total: 300,
  initialValue: 300,
  pendingBalance: 200,
  sourceType: 'legacy',
  sourceId: '',
  status: 'partial',
  notes: encodeExpenseDocumentNotes({ conceptId: 'energy', conceptName: 'Energía', description: 'Servicio del local' }),
  payments: [{ id: 'payment-1', amount: 100, date: '2026-07-27', method: 'Efectivo', accountId: 'cash', balanceBefore: 300, balanceAfter: 200, userName: 'Admin' }],
};

const purchasePayable: SupplierInvoiceView = {
  id: 'payable-1',
  supplierId: purchase.supplierId,
  supplierName: purchase.supplierName,
  invoiceNumber: purchase.number,
  issueDate: purchase.date,
  dueDate: '2026-08-27',
  total: purchase.total,
  initialValue: purchase.total,
  pendingBalance: purchase.total,
  sourceType: 'purchase_invoice',
  sourceId: purchase.id,
  status: 'pending',
  notes: purchase.description || '',
  payments: [],
};

const legacyExpense: ExpenseInvoice = {
  id: 'legacy-expense',
  number: 'GAS-LEGACY',
  supplierId: 'supplier-3',
  supplierName: 'Papelería Uno',
  total: 100,
  description: 'Papelería',
  date: '2026-07-26',
  paymentMethod: 'Efectivo',
  status: 'paid',
  accountId: 'cash',
};

describe('documentos administrativos de Compras', () => {
  it('codifica y recupera el concepto sin cambiar estructuras de tablas', () => {
    const notes = encodeExpenseDocumentNotes({ conceptId: 'rent', conceptName: 'Arriendo', description: 'Local principal' });
    expect(parseExpenseDocumentNotes(notes)).toEqual({
      version: 1,
      kind: 'expense',
      conceptId: 'rent',
      conceptName: 'Arriendo',
      description: 'Local principal',
    });
    expect(parseExpenseDocumentNotes('texto heredado')).toBeNull();
  });

  it('construye un historial único sin duplicar la cuenta vinculada a una compra', () => {
    const rows = buildPurchaseDocumentRows({
      purchases: [purchase],
      payables: [purchasePayable, expensePayable],
      legacyExpenses: [legacyExpense],
    });
    expect(rows).toHaveLength(3);
    expect(rows.filter(row => row.type === 'purchase')).toHaveLength(1);
    expect(rows.find(row => row.id === purchase.id)?.dueDate).toBe('2026-08-27');
    expect(rows.find(row => row.id === expensePayable.id)?.concept).toBe('Energía');
    expect(rows.find(row => row.id === expensePayable.id)?.status).toBe('partial');
  });

  it('calcula indicadores con los documentos ya cargados, sin consultas nuevas', () => {
    const rows = buildPurchaseDocumentRows({ purchases: [purchase], payables: [purchasePayable, expensePayable], legacyExpenses: [legacyExpense] });
    const metrics = calculatePurchaseDashboardMetrics(rows, new Date('2026-07-27T12:00:00.000Z'));
    expect(metrics.purchasesToday).toBe(500);
    expect(metrics.expensesToday).toBe(300);
    expect(metrics.purchasesMonth).toBe(500);
    expect(metrics.expensesMonth).toBe(400);
    expect(metrics.pendingInvoices).toBe(2);
    expect(metrics.topExpenseConcepts[0]).toEqual({ name: 'Energía', total: 300 });
    expect(metrics.topSuppliers[0]).toEqual({ name: 'Proveedor Mercancía', total: 500 });
  });

  it('duplica el número sin alterar el documento original', () => {
    expect(duplicateExpenseNumber('GAS-0001')).toBe('GAS-0001-COPIA');
    expect(duplicateExpenseNumber('GAS-0001-COPIA')).toBe('GAS-0001-COPIA');
  });
});
