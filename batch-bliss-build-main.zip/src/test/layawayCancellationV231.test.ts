// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  deleteLayaway,
  ensureDefaultFinancialAccounts,
  fetchFinancialAccounts,
  fetchFinancialMovements,
  insertLayaway,
} from '@/repositories/dexieDataSource';
import { buildFinancialPosition, LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';
import type { Layaway } from '@/domain/models';

const now = '2026-07-21T12:00:00.000Z';
const user = {
  id: 'finance-user', username: 'finance', display_name: 'Finanzas', password_hash: '',
  role: 'master' as const, active: true, created_at: now, last_login: null,
};

const createLayaway = (id: string): Layaway => ({
  id,
  invoiceId: `invoice-${id}`,
  completed: false,
  invoice: {
    id: `invoice-${id}`, number: `SEP-${id}`, clientId: 'client-1', clientName: 'Cliente Uno',
    subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-21', status: 'pending',
    paymentMethod: 'Mixto',
    items: [{
      productId: 'product-1', code: 'P1', name: 'Producto', quantity: 1, weightGrams: 10,
      unitPrice: 100, subtotal: 100, costPrice: 40,
    }],
  },
  payments: [{
    id: `payment-${id}`, amount: 40, date: '2026-07-21', method: 'Efectivo', accountId: MAIN_CASH_ACCOUNT_ID,
  }],
});

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.products.put({
    id: 'product-1', code: 'P1', name: 'Producto', category: 'General',
    purchase_price: 40, sale_price: 100, weight_grams: 10, margin: 150,
    stock: 10, min_stock: 1, description: '', supplier_ids: [], created_at: now,
    reference: 'P1', available_grams: 100, average_purchase_price: 40, last_purchase_date: '',
  });
  await localDb.contacts.put({
    id: 'client-1', type: 'client', name: 'Cliente Uno', document: '1', phone: '', email: '', address: '', notes: '', created_at: now,
  });
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
  await ensureDefaultFinancialAccounts();
});

describe('JOYACONTROL V2.3.1 - cancelación financiera de separados', () => {
  it('devuelve el dinero una sola vez, reduce Caja Separados y registra LAYAWAY_REFUND COMPLETED', async () => {
    const layaway = createLayaway('refund');
    await insertLayaway(layaway);

    const beforeAccounts = await fetchFinancialAccounts();
    const beforeMovements = await fetchFinancialMovements();
    const beforePosition = buildFinancialPosition({ accounts: beforeAccounts, movements: beforeMovements, layaways: [layaway] });
    expect(beforePosition.layawayReserve).toBe(40);
    expect(beforePosition.totalAvailable).toBe(beforePosition.mainCash + beforePosition.banks);

    const result = await deleteLayaway(layaway.id, 'refund');
    expect(result).toMatchObject({ resolution: 'refund', refundedAmount: 40, creditAmount: 0, clientId: 'client-1' });

    const movements = await fetchFinancialMovements();
    const refunds = movements.filter(item => item.movementCode === 'LAYAWAY_REFUND');
    expect(refunds).toHaveLength(1);
    expect(refunds[0]).toMatchObject({
      amount: 40,
      status: 'COMPLETED',
      referenceType: 'CUSTOMER',
      referenceId: 'client-1',
      documentType: 'layaway_refund',
    });
    expect(movements.find(item => item.movementCode === 'LAYAWAY_PAYMENT')?.status).toBe('REVERSED');
    const afterAccounts = await fetchFinancialAccounts();
    expect(afterAccounts.find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(0);
    const afterPosition = buildFinancialPosition({ accounts: afterAccounts, movements, layaways: [] });
    expect(afterPosition.layawayReserve).toBe(0);
    expect(afterPosition.totalAvailable).toBe(afterPosition.mainCash + afterPosition.banks);

    await expect(deleteLayaway(layaway.id, 'refund')).rejects.toThrow('LAYAWAY_NOT_FOUND');
    expect((await fetchFinancialMovements()).filter(item => item.movementCode === 'LAYAWAY_REFUND')).toHaveLength(1);
  });

  it('convierte el abono en saldo a favor sin mover Caja Separados ni crear una devolución', async () => {
    const layaway = createLayaway('credit');
    await insertLayaway(layaway);

    const before = (await fetchFinancialAccounts()).find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance;
    const result = await deleteLayaway(layaway.id, 'credit');
    const after = (await fetchFinancialAccounts()).find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance;

    expect(result).toMatchObject({ resolution: 'credit', refundedAmount: 0, creditAmount: 40, clientId: 'client-1' });
    expect(before).toBe(40);
    expect(after).toBe(40);

    const movements = await fetchFinancialMovements();
    expect(movements.filter(item => item.movementCode === 'LAYAWAY_REFUND')).toHaveLength(0);
    expect(movements.filter(item => item.movementCode === 'CUSTOMER_CREDIT')).toHaveLength(1);
    expect(movements.find(item => item.movementCode === 'CUSTOMER_CREDIT')).toMatchObject({
      amount: 40,
      status: 'COMPLETED',
      referenceType: 'CUSTOMER',
      referenceId: 'client-1',
      documentType: 'layaway_credit',
    });
    expect(movements.find(item => item.movementCode === 'LAYAWAY_PAYMENT')?.status).toBe('POSTED');
  });
});
