// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { setSession } from '@/lib/authCore';
import {
  addLayawayPayment,
  completeLayawayDb,
  deleteLayaway,
  ensureDefaultFinancialAccounts,
  fetchFinancialAccounts,
  fetchFinancialMovements,
  insertLayaway,
} from '@/repositories/dexieDataSource';
import { LAYAWAY_RESERVE_ACCOUNT_ID, MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';
import type { Layaway } from '@/domain/models';

const now = '2026-07-21T12:00:00.000Z';
const user = {
  id: 'finance-user', username: 'finance', display_name: 'Finanzas', password_hash: '',
  role: 'master' as const, active: true, created_at: now, last_login: null,
};

const layaway: Layaway = {
  id: 'layaway-financial-v2',
  invoiceId: 'invoice-financial-v2',
  completed: false,
  invoice: {
    id: 'invoice-financial-v2', number: 'SEP-2001', clientId: 'client-1', clientName: 'Cliente Uno',
    subtotal: 100, discount: 0, tax: 0, total: 100, date: '2026-07-21', status: 'pending',
    paymentMethod: 'Mixto',
    items: [{
      productId: 'product-1', code: 'P1', name: 'Producto', quantity: 1, weightGrams: 10,
      unitPrice: 100, subtotal: 100, costPrice: 40,
    }],
  },
  payments: [{
    id: 'initial', amount: 40, date: '2026-07-21', method: 'Efectivo', accountId: MAIN_CASH_ACCOUNT_ID,
  }],
};

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  await localDb.users.put(user);
  await localDb.products.put({
    id: 'product-1', code: 'P1', name: 'Producto', category: 'General',
    purchase_price: 40, sale_price: 100, weight_grams: 10, margin: 150,
    stock: 10, min_stock: 1, description: '', supplier_ids: [], created_at: now,
    reference: 'P1', available_grams: 100, average_purchase_price: 40, last_purchase_date: '',
  });
  await localDb.contacts.put({
    id: 'client-1', type: 'client', name: 'Cliente Uno', document: '1', phone: '', email: '', address: '', notes: '', created_at: now,
  });
  setSession({ id: user.id, username: user.username, displayName: user.display_name, role: user.role });
  await ensureDefaultFinancialAccounts();
});

describe('ciclo financiero de separados', () => {
  it('reserva abonos y los libera una sola vez al completar sin descontar inventario nuevamente', async () => {
    const created = await insertLayaway(layaway);
    expect(created.completed).toBe(false);
    expect(created.invoice.status).toBe('pending');

    let accounts = await fetchFinancialAccounts();
    expect(accounts.find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(40);
    expect(accounts.find(item => item.id === MAIN_CASH_ACCOUNT_ID)?.balance).toBe(0);
    expect((await localDb.products.get('product-1'))?.stock).toBe(9);

    const paymentResult = await addLayawayPayment(layaway.id, {
      amount: 60, date: '2026-07-21', method: 'Transferencia', accountId: 'account-bancolombia',
    });
    expect(paymentResult.completed).toBe(false);
    expect((await localDb.invoices.get(layaway.invoiceId))?.status).toBe('pending');

    accounts = await fetchFinancialAccounts();
    expect(accounts.find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(100);
    expect(accounts.find(item => item.id === MAIN_CASH_ACCOUNT_ID)?.balance).toBe(0);
    expect(accounts.find(item => item.id === 'account-bancolombia')?.balance).toBe(0);

    await completeLayawayDb(layaway.id, '2026-07-21');

    accounts = await fetchFinancialAccounts();
    expect(accounts.find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(0);
    expect(accounts.find(item => item.id === MAIN_CASH_ACCOUNT_ID)?.balance).toBe(40);
    expect(accounts.find(item => item.id === 'account-bancolombia')?.balance).toBe(60);
    expect((await localDb.invoices.get(layaway.invoiceId))?.status).toBe('paid');
    expect((await localDb.products.get('product-1'))?.stock).toBe(9);

    const movements = await fetchFinancialMovements();
    expect(movements.filter(item => item.documentType === 'layaway')).toHaveLength(2);
    expect(movements.filter(item => item.documentType === 'layaway_completion')).toHaveLength(2);
    expect(movements.filter(item => item.movementCode === 'LAYAWAY_PAYMENT')).toHaveLength(2);
    expect(movements.filter(item => item.movementCode === 'LAYAWAY_COMPLETED')).toHaveLength(2);
    expect(movements.filter(item => item.movementCode === 'LAYAWAY_COMPLETED').every(item => item.relatedMovementId)).toBe(true);

    // Idempotencia: una segunda confirmación no vuelve a mover dinero.
    await completeLayawayDb(layaway.id, '2026-07-21');
    expect((await fetchFinancialMovements()).filter(item => item.documentType === 'layaway_completion')).toHaveLength(2);
  });

  it('conserva el historial y registra LAYAWAY_REFUND al eliminar un separado', async () => {
    await insertLayaway(layaway);
    const original = (await fetchFinancialMovements()).find(item => item.movementCode === 'LAYAWAY_PAYMENT');
    expect(original).toBeTruthy();

    await deleteLayaway(layaway.id);

    const movements = await fetchFinancialMovements();
    const reversedOriginal = movements.find(item => item.id === original?.id);
    const refund = movements.find(item => item.movementCode === 'LAYAWAY_REFUND');
    expect(reversedOriginal?.status).toBe('REVERSED');
    expect(refund).toMatchObject({
      relatedMovementId: original?.id,
      referenceType: 'CUSTOMER',
      referenceId: layaway.invoice.clientId,
      amount: 40,
    });
    expect((await fetchFinancialAccounts()).find(item => item.id === LAYAWAY_RESERVE_ACCOUNT_ID)?.balance).toBe(0);
  });

});
