// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { hashPassword, setSession } from '@/lib/authCore';
import {
  addSupplierPaymentWithAccount,
  fetchSupplierInvoices,
  insertSupplierInvoice,
} from '@/repositories/dexieDataSource';
import {
  createExpenseConcept,
  fetchExpenseConcepts,
  setExpenseConceptActive,
  updateExpenseConcept,
} from '@/lib/ExpenseConceptService';
import { encodeExpenseDocumentNotes, parseExpenseDocumentNotes } from '@/lib/PurchaseDocumentsService';

const now = '2026-07-27T12:00:00.000Z';

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  const passwordHash = await hashPassword('purchase-documents');
  await localDb.users.put({
    id: 'user-1',
    username: 'admin',
    display_name: 'Administrador',
    password_hash: passwordHash,
    role: 'master',
    active: true,
    created_at: now,
    last_login: null,
  });
  setSession({ id: 'user-1', username: 'admin', displayName: 'Administrador', role: 'master' });
  await localDb.financial_accounts.put({
    id: 'account-caja-principal',
    name: 'Caja Principal',
    kind: 'cash',
    active: true,
    balance: 1_000_000,
    created_at: now,
    updated_at: now,
  });
  await localDb.products.put({
    id: 'product-1', code: 'P1', name: 'Anillo', category: 'Anillos', purchase_price: 1000,
    sale_price: 1500, weight_grams: 5, margin: 50, stock: 10, min_stock: 1,
    description: '', supplier_ids: [], reference: 'P1', available_grams: 50,
    average_purchase_price: 1000, last_purchase_date: '', created_at: now,
  });
});

describe('facturas administrativas de gasto', () => {
  it('crea la obligación y al pagar afecta Finanzas sin tocar Inventario ni Kardex', async () => {
    const productBefore = await localDb.products.get('product-1');
    const notes = encodeExpenseDocumentNotes({ conceptId: 'energy', conceptName: 'Energía', description: 'Servicio mensual' });
    const invoice = await insertSupplierInvoice({
      supplier_id: 'supplier-1',
      supplier_name: 'Empresa de Energía',
      invoice_number: 'GAS-0001',
      issue_date: '2026-07-27',
      due_date: '2026-08-10',
      total: 250_000,
      notes,
    });

    let payable = (await fetchSupplierInvoices()).find(item => item.id === invoice.id)!;
    expect(payable.status).toBe('pending');
    expect(payable.pendingBalance).toBe(250_000);
    expect(parseExpenseDocumentNotes(payable.notes)?.conceptName).toBe('Energía');
    expect(await localDb.financial_movements.count()).toBe(0);

    await addSupplierPaymentWithAccount(invoice.id, {
      amount: 250_000,
      date: '2026-07-27',
      method: 'Efectivo',
      accountId: 'account-caja-principal',
    });

    payable = (await fetchSupplierInvoices()).find(item => item.id === invoice.id)!;
    expect(payable.status).toBe('paid');
    expect(payable.pendingBalance).toBe(0);
    expect((await localDb.financial_accounts.get('account-caja-principal'))?.balance).toBe(750_000);
    expect(await localDb.financial_movements.where('document_id').equals(invoice.id).count()).toBe(1);
    expect(await localDb.inventory_adjustments.count()).toBe(0);
    expect(await localDb.products.get('product-1')).toEqual(productBefore);
  });
});

describe('catálogo de conceptos basado en infraestructura existente', () => {
  it('crea, edita y desactiva sin eliminar conceptos históricos', async () => {
    const created = await createExpenseConcept('Seguridad');
    const edited = await updateExpenseConcept(created, 'Seguridad privada');
    await setExpenseConceptActive(edited, false);

    const concepts = await fetchExpenseConcepts();
    const persisted = concepts.find(item => item.id === created.id);
    expect(persisted).toMatchObject({ name: 'Seguridad privada', active: false });
    expect(concepts.some(item => item.name === 'Arriendo')).toBe(true);
    expect(await localDb.activity_log.where('entity').equals('expense_concept').count()).toBe(3);
  });
});
