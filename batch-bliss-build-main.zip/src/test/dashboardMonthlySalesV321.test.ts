import { describe, expect, it } from 'vitest';
import type { Invoice } from '@/data/mockData';
import { buildDashboardSnapshot } from '@/lib/DashboardMetricsService';

const invoice = (
  id: string,
  total: number,
  date: string,
  status: Invoice['status'] = 'paid',
  tipoDocumento: Invoice['tipoDocumento'] = 'factura',
): Invoice => ({
  id,
  number: `FAC-${id}`,
  clientId: 'customer-1',
  clientName: 'Cliente',
  items: [],
  subtotal: total,
  discount: 0,
  tax: 0,
  total,
  date,
  status,
  tipoDocumento,
});

describe('JoyaControl v3.2.1 - regresión Ventas Totales del Mes', () => {
  it('incluye facturas válidas, separados convertidos e históricos sin Ledger', () => {
    const invoices: Invoice[] = [
      invoice('normal', 100_000, '2026-07-03'),
      invoice('layaway-completed', 300_000, '2026-07-18'),
      invoice('historical-no-movement', 200_000, '2026-07-20'),
      invoice('pending', 400_000, '2026-07-20', 'pending'),
      invoice('cancelled', 500_000, '2026-07-20', 'cancelled'),
      invoice('quotation', 600_000, '2026-07-20', 'paid', 'cotizacion'),
      invoice('previous-month', 700_000, '2026-06-30'),
    ];

    const snapshot = buildDashboardSnapshot({
      products: [], contacts: [], invoices, purchases: [], expenses: [], layaways: [],
      cashSessions: [], accounts: [],
      movements: [{
        id: 'layaway-completion', type: 'transfer', amount: 300_000,
        originBalanceBefore: 0, originBalanceAfter: 0,
        destinationBalanceBefore: 0, destinationBalanceAfter: 0,
        reference: 'SEP-1', documentType: 'layaway_completion', documentId: 'layaway-completed',
        observation: '', userId: 'user-1', userName: 'Admin', date: '2026-07-18',
        createdAt: '2026-07-18T12:00:00.000Z', movementCode: 'LAYAWAY_COMPLETED',
        referenceType: 'LAYAWAY', referenceId: 'layaway-completed', status: 'POSTED',
      }],
      financialSummary: null, backupStatusAvailable: false,
      now: new Date('2026-07-20T12:00:00'),
    });

    expect(snapshot.month).toEqual({ count: 3, value: 600_000 });
    expect(snapshot.today).toEqual({ count: 1, value: 200_000 });
    expect(snapshot.salesLast30Days.find(point => point.date === '2026-07-18')).toMatchObject({ value: 300_000, count: 1 });
    expect(snapshot.recentSales.map(sale => sale.id)).toEqual([
      'historical-no-movement', 'layaway-completed', 'normal', 'previous-month',
    ]);
  });
});
