// @vitest-environment node
import { afterEach, describe, expect, it, vi } from 'vitest';
import fs from 'node:fs';
import net from 'node:net';
import os from 'node:os';
import path from 'node:path';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';
import type { DashboardSnapshot } from '@/lib/DashboardMetricsService';

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const socket = net.createServer();
    socket.once('error', reject);
    socket.listen(0, '127.0.0.1', () => {
      const address = socket.address();
      if (!address || typeof address === 'string') return reject(new Error('NO_PORT'));
      socket.close(error => error ? reject(error) : resolve(address.port));
    });
  });
}

async function post<T>(url: string, body: object): Promise<T> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const payload = await response.json() as T & { error?: string };
  if (!response.ok) throw new Error(payload.error || `HTTP_${response.status}`);
  return payload;
}

afterEach(async () => {
  await stopLanServer();
});

describe('Dashboard LAN V2 summarized transport', () => {
  it('returns all Dashboard metrics in one /repository/call request for two simultaneous clients', async () => {
    const port = await freePort();
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-dashboard-v2-'));
    const metrics: DashboardSnapshot = {
      today: { count: 1, value: 150 },
      month: { count: 5, value: 900 },
          financialPosition: { mainCash: 700, layawayReserve: 100, banks: 300, totalAvailable: 1000, mainCashUpdatedAt: '2026-07-21T10:00:00.000Z', mainCashStatus: 'RECONCILED', banksUpdatedAt: '2026-07-21T10:00:00.000Z', totalAvailableUpdatedAt: '2026-07-21T10:00:00.000Z' },
      inventory: { products: 2, activeProducts: 2, saleValue: 1000, totalWeightGrams: 8, totalCost: 500 },
      layaways: { count: 1, pendingValue: 100, clients: 1 },
      customers: { registered: 3, newThisMonth: 1, active: 2 },
      purchasesMonth: 200,
      salesLast30Days: [{ date: '2026-07-20', label: '20 jul', value: 150, count: 1 }],
      topProducts: [{ productId: 'p1', name: 'Anillo', quantity: 1, value: 150 }],
      recentSales: [{ id: 'i1', number: 'FAC-1', clientName: 'Ana', date: '2026-07-20', total: 150 }],
      alerts: [],
    };
    const executeRepositoryCall = vi.fn(async (method: string) => {
      if (method === 'getDashboardMetrics') return metrics;
      throw new Error('METHOD_NOT_ALLOWED');
    });

    try {
      await startLanServer({
        host: '127.0.0.1',
        port,
        serverName: 'Dashboard LAN V2',
        userDataPath,
        version: '2.1',
        authenticateUser: async () => ({
          success: true,
          userId: 'master-1',
          username: 'master',
          displayName: 'Master',
          role: 'master',
          permissions: ['view_reports'],
        }),
        executeRepositoryCall,
      });

      const baseUrl = `http://127.0.0.1:${port}`;
      const connect = async (suffix: string) => {
        const registered = await post<{ clientId: string; sessionToken: string }>(`${baseUrl}/client/register`, {
          name: `Cliente ${suffix}`,
          hostname: `cliente-${suffix}`,
          version: '2.1',
          localTime: new Date().toISOString(),
          deviceInstanceId: `dashboard-device-${suffix}`,
        });
        const login = await post<{ authToken: string }>(`${baseUrl}/login`, {
          username: 'master',
          password: 'secret',
          clientId: registered.clientId,
          sessionToken: registered.sessionToken,
        });
        return { ...registered, ...login };
      };

      const [clientA, clientB] = await Promise.all([connect('a'), connect('b')]);
      const loadMetrics = (client: typeof clientA) => post<{ data: DashboardSnapshot }>(`${baseUrl}/repository/call`, {
        method: 'getDashboardMetrics',
        args: {},
        clientId: client.clientId,
        sessionToken: client.sessionToken,
        authToken: client.authToken,
      });

      const [responseA, responseB] = await Promise.all([loadMetrics(clientA), loadMetrics(clientB)]);

      expect(responseA.data).toEqual(metrics);
      expect(responseB.data).toEqual(metrics);
      expect(responseA.data.recentSales[0]).toEqual({
        id: 'i1', number: 'FAC-1', clientName: 'Ana', date: '2026-07-20', total: 150,
      });
      expect(executeRepositoryCall).toHaveBeenCalledTimes(2);
      expect(executeRepositoryCall.mock.calls.every(call => call[0] === 'getDashboardMetrics')).toBe(true);
    } finally {
      fs.rmSync(userDataPath, { recursive: true, force: true });
    }
  });
});
