// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { hashPassword, setSession } from '@/lib/authCore';
import {
  addSupplierPaymentWithAccount,
  createPurchaseWithInventory,
  deletePurchaseWithInventory,
  fetchSupplierInvoices,
  updatePurchaseWithInventory,
} from '@/repositories/dexieDataSource';
import type { PurchaseInvoice } from '@/data/mockData';

const now = '2026-07-17T12:00:00.000Z';
const cash = { id: 'account-caja-principal', name: 'Caja', kind: 'cash' as const, active: true, balance: 10_000_000, created_at: now, updated_at: now };

const purchase = (total = 2_500_000): PurchaseInvoice => ({
  id: 'purchase-1', number: 'COM-0001', supplierId: 'supplier-1', supplierName: 'Proveedor Uno',
  items: [{ productId: 'product-1', code: 'P1', name: 'Anillo', quantity: 2, weightGrams: 5, unitPrice: total / 2, subtotal: total }],
  subtotal: total, discount: 0, tax: 0, total, date: '2026-07-17', status: 'pending', paymentMethod: 'Efectivo', description: 'Compra inicial',
});

beforeEach(async () => {
  await localDb.delete();
  await localDb.open();
  const password_hash = await hashPassword('qa93');
  await localDb.users.put({ id: 'u1', username: 'qa93', display_name: 'QA 9.3', password_hash, role: 'master', active: true, created_at: now, last_login: null });
  setSession({ id: 'u1', username: 'qa93', displayName: 'QA 9.3', role: 'master' });
  await localDb.financial_accounts.put(cash);
  await localDb.products.put({ id: 'product-1', code: 'P1', name: 'Anillo', category: 'Anillos', purchase_price: 1_000_000, sale_price: 1_500_000,
    weight_grams: 5, margin: 50, stock: 10, min_stock: 1, description: '', supplier_ids: [], reference: 'P1', available_grams: 50,
    average_purchase_price: 1_000_000, last_purchase_date: '', created_at: now });
});

describe('QA #9.3 compra y cuenta vinculada', () => {
  it('actualiza la misma cuenta de 2.500.000 a 2.900.000 sin duplicarla', async () => {
    await createPurchaseWithInventory(purchase());
    const before = await localDb.supplier_invoices.toArray();
    expect(before).toHaveLength(1);
    const payableId = before[0].id;

    await updatePurchaseWithInventory({ ...purchase(2_900_000), supplierName: 'Proveedor Editado', description: 'Compra editada' });

    const after = await localDb.supplier_invoices.toArray();
    expect(after).toHaveLength(1);
    expect(after[0].id).toBe(payableId);
    expect(after[0].total).toBe(2_900_000);
    expect(after[0].pending_balance).toBe(2_900_000);
    expect(after[0].source_type).toBe('purchase_invoice');
    expect(after[0].source_id).toBe('purchase-1');
    expect(await localDb.activity_log.where('action').equals('PURCHASE_PAYABLE_UPDATED').count()).toBe(1);
  });

  it('bloquea edición y eliminación después de un pago parcial antes de mutar inventario', async () => {
    await createPurchaseWithInventory(purchase());
    const payable = (await fetchSupplierInvoices())[0];
    await addSupplierPaymentWithAccount(payable.id, { amount: 1_000_000, date: '2026-07-17', method: 'Efectivo', accountId: cash.id });
    const productBefore = await localDb.products.get('product-1');

    await expect(updatePurchaseWithInventory(purchase(2_900_000))).rejects.toThrow('PURCHASE_HAS_PARTIAL_PAYMENTS');
    await expect(deletePurchaseWithInventory('purchase-1')).rejects.toThrow('PAID_PURCHASE_REVERSAL_REQUIRED');
    expect(await localDb.products.get('product-1')).toEqual(productBefore);
  });
});

describe('QA #9.3 pagos parciales', () => {
  it('registra 1.000.000, 500.000 y 1.500.000 con saldos y eventos correctos', async () => {
    await createPurchaseWithInventory(purchase(3_000_000));
    const payable = (await fetchSupplierInvoices())[0];

    await addSupplierPaymentWithAccount(payable.id, { amount: 1_000_000, date: '2026-07-17', method: 'Efectivo', accountId: cash.id });
    let current = (await fetchSupplierInvoices())[0];
    expect(current.status).toBe('partial');
    expect(current.pendingBalance).toBe(2_000_000);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(9_000_000);

    await addSupplierPaymentWithAccount(payable.id, { amount: 500_000, date: '2026-07-18', method: 'Efectivo', accountId: cash.id });
    current = (await fetchSupplierInvoices())[0];
    expect(current.pendingBalance).toBe(1_500_000);

    await addSupplierPaymentWithAccount(payable.id, { amount: 1_500_000, date: '2026-07-19', method: 'Efectivo', accountId: cash.id });
    current = (await fetchSupplierInvoices())[0];
    expect(current.status).toBe('paid');
    expect(current.pendingBalance).toBe(0);
    expect(current.payments.map(payment => payment.balanceAfter)).toEqual([2_000_000, 1_500_000, 0]);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(7_000_000);
    expect(await localDb.financial_movements.where('document_id').equals(payable.id).count()).toBe(3);
    expect(await localDb.activity_log.where('action').equals('PAYABLE_PARTIAL_PAYMENT').count()).toBe(2);
    expect(await localDb.activity_log.where('action').equals('PAYABLE_FULL_PAYMENT').count()).toBe(1);
    expect((await localDb.purchase_invoices.get('purchase-1'))?.status).toBe('paid');
  });
});
