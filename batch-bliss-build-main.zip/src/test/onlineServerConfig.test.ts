import { beforeEach, describe, expect, it } from 'vitest';
import {
  clearOnlineServerSelection,
  loadOnlineServerSelection,
  ONLINE_SERVER_STORAGE_KEY,
  saveOnlineServerSelection,
} from '@/lib/OnlineServerConfig';

const FIRST_SERVER = {
  url: 'https://midominio.com',
  port: 443,
  baseUrl: 'https://midominio.com',
  serverId: '11111111-1111-4111-8111-111111111111',
  serverName: 'Servidor Principal',
  version: '3.0.0',
  hostname: 'principal-uno',
  savedAt: '2026-07-28T20:00:00.000Z',
};

describe('configuración del Servidor Online', () => {
  beforeEach(() => {
    localStorage.clear();
  });

  it('persiste el servidor HTTPS seleccionado entre cargas', () => {
    const saved = saveOnlineServerSelection(FIRST_SERVER);
    expect(saved.baseUrl).toBe('https://midominio.com');
    expect(loadOnlineServerSelection()).toEqual(saved);
  });

  it('permite cambiar el servidor seleccionado sin acumular configuraciones', () => {
    saveOnlineServerSelection(FIRST_SERVER);
    const second = saveOnlineServerSelection({
      ...FIRST_SERVER,
      url: 'https://203.0.113.20',
      port: 9443,
      baseUrl: 'https://203.0.113.20:9443',
      serverId: '22222222-2222-4222-8222-222222222222',
      serverName: 'Servidor Alterno',
      hostname: 'principal-dos',
    });

    expect(loadOnlineServerSelection()).toEqual(second);
    expect(JSON.parse(localStorage.getItem(ONLINE_SERVER_STORAGE_KEY) || '{}').serverId).toBe(second.serverId);
  });

  it('borra completamente la configuración seleccionada', () => {
    saveOnlineServerSelection(FIRST_SERVER);
    clearOnlineServerSelection();
    expect(loadOnlineServerSelection()).toBeNull();
    expect(localStorage.getItem(ONLINE_SERVER_STORAGE_KEY)).toBeNull();
  });

  it('descarta configuraciones no HTTPS o dañadas', () => {
    localStorage.setItem(ONLINE_SERVER_STORAGE_KEY, JSON.stringify({ ...FIRST_SERVER, url: 'http://inseguro.test' }));
    expect(loadOnlineServerSelection()).toBeNull();
    expect(localStorage.getItem(ONLINE_SERVER_STORAGE_KEY)).toBeNull();
  });
});
