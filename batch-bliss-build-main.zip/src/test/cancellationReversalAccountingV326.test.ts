import { describe, expect, it } from 'vitest';
import type { FinancialAccount, FinancialMovement } from '@/data/mockData';
import {
  calculateAccountIncomeForDate,
  getSaleAccountFlowsForDate,
} from '@/lib/FinancialLedgerService';
import { calculateBankDepositsForDate } from '@/lib/DashboardMetricsService';
import {
  buildFinancialCompositions,
  buildFinancialLedgerRows,
} from '@/lib/FinancialTraceabilityService';
import { MAIN_CASH_ACCOUNT_ID } from '@/lib/FinancialPositionService';

const DATE = '2026-08-03';
const BANK_ID = 'bank-test';
const accounts: FinancialAccount[] = [
  { id: MAIN_CASH_ACCOUNT_ID, name: 'Caja', kind: 'cash', active: true, balance: 0, createdAt: DATE, updatedAt: DATE },
  { id: BANK_ID, name: 'Banco', kind: 'bank', active: true, balance: 0, createdAt: DATE, updatedAt: DATE },
];

const movement = (input: Partial<FinancialMovement> & Pick<FinancialMovement, 'id' | 'amount'>): FinancialMovement => ({
  id: input.id,
  type: input.type || 'sale_income',
  amount: input.amount,
  originAccountId: input.originAccountId,
  destinationAccountId: input.destinationAccountId,
  originBalanceBefore: 0,
  originBalanceAfter: 0,
  destinationBalanceBefore: 0,
  destinationBalanceAfter: 0,
  reference: 'FV-TEST',
  documentType: input.documentType || 'invoice',
  documentId: 'invoice-cancelled',
  observation: '',
  userId: 'user',
  userName: 'Admin',
  date: input.date || DATE,
  createdAt: input.createdAt || `${DATE}T10:00:00.000Z`,
  movementCode: input.movementCode || 'SALE_PAYMENT',
  relatedMovementId: input.relatedMovementId,
  referenceType: 'SALE',
  referenceId: 'invoice-cancelled',
  status: input.status || 'POSTED',
  updatedAt: input.createdAt || `${DATE}T10:00:00.000Z`,
});

const mixedCancellation: FinancialMovement[] = [
  movement({ id: 'cash-sale', amount: 600_000, destinationAccountId: MAIN_CASH_ACCOUNT_ID, status: 'REVERSED' }),
  movement({ id: 'bank-sale', amount: 400_000, destinationAccountId: BANK_ID, status: 'REVERSED' }),
  movement({ id: 'cash-cancel', amount: 600_000, type: 'adjustment', originAccountId: MAIN_CASH_ACCOUNT_ID, documentType: 'invoice_cancellation', movementCode: 'SALE_CANCEL', relatedMovementId: 'cash-sale' }),
  movement({ id: 'bank-cancel', amount: 400_000, type: 'adjustment', originAccountId: BANK_ID, documentType: 'invoice_cancellation', movementCode: 'SALE_CANCEL', relatedMovementId: 'bank-sale' }),
];

describe('JoyaControl v3.2.6 direct sale cancellation accounting', () => {
  it('neutralizes Caja Hoy and Banco Hoy', () => {
    expect(calculateAccountIncomeForDate(mixedCancellation, MAIN_CASH_ACCOUNT_ID, DATE)).toBe(0);
    expect(getSaleAccountFlowsForDate(mixedCancellation, MAIN_CASH_ACCOUNT_ID, DATE)
      .reduce((sum, row) => sum + row.signedAmount, 0)).toBe(0);
    expect(calculateBankDepositsForDate(accounts, mixedCancellation, DATE)).toBe(0);
  });

  it('does not classify SALE_CANCEL as a commercial expense', () => {
    const rows = buildFinancialLedgerRows({ accounts, movements: mixedCancellation });
    expect(rows.reduce((sum, row) => sum + row.income, 0)).toBe(0);
    expect(rows.reduce((sum, row) => sum + row.expense, 0)).toBe(0);
    expect(rows.filter(row => row.code === 'SALE_CANCEL')).toHaveLength(2);
  });

  it('restores Caja, Bancos and Total Disponible', () => {
    const composition = buildFinancialCompositions({ accounts, movements: mixedCancellation });
    expect(composition.mainCash.total).toBe(0);
    expect(composition.banks.total).toBe(0);
    expect(composition.totalAvailable.total).toBe(0);
  });

  it('recognizes a bank deposit whose persisted date contains time', () => {
    const deposit = movement({
      id: 'deposit', amount: 250_000, type: 'adjustment', destinationAccountId: BANK_ID,
      documentType: 'manual_bank_deposit', movementCode: 'BANK_IN', date: `${DATE}T09:15:00.000Z`,
    });
    expect(calculateBankDepositsForDate(accounts, [deposit], DATE)).toBe(250_000);
  });
});
