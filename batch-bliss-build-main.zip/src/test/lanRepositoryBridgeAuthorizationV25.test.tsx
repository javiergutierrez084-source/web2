// @vitest-environment jsdom
import { act, render } from '@testing-library/react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { localDb } from '@/lib/localDb';
import { bulkPutProducts } from '@/repositories/dexieDataSource';
import { runWithAuthorizedLanRepositorySession } from '@/lib/LanRepositoryExecutionContext';

const session = {
  id: 'lan-user-1', username: 'admin', displayName: 'Administrador', role: 'admin' as const,
  permissions: ['manage_products', 'manage_inventory', 'manage_contacts', 'manage_purchases', 'manage_cash', 'view_reports'],
};

const mocks = vi.hoisted(() => {
  const repository = {
    loginUser: vi.fn(),
    fetchProducts: vi.fn(async () => []),
    fetchCategories: vi.fn(async () => []),
    fetchCompany: vi.fn(async () => ({ name: 'JoyaControl' })),
    saveCompany: vi.fn(async () => undefined),
    upsertProduct: vi.fn(async () => undefined),
    deleteProduct: vi.fn(async () => undefined),
    applyProductChanges: vi.fn(async () => undefined),
    fetchContacts: vi.fn(async () => []),
    upsertContact: vi.fn(async () => undefined),
    deleteContact: vi.fn(async () => undefined),
    applyContactChanges: vi.fn(async () => undefined),
    insertInvoice: vi.fn(async () => undefined),
    fetchPurchaseInvoices: vi.fn(async () => []),
    createPurchaseWithInventory: vi.fn(async () => undefined),
    updatePurchaseWithInventory: vi.fn(async () => undefined),
    deletePurchaseWithInventory: vi.fn(async () => undefined),
    markPurchaseAsPaid: vi.fn(async () => undefined),
    fetchExpenses: vi.fn(async () => []),
    insertExpense: vi.fn(async () => undefined),
    insertExpenseWithFinancials: vi.fn(async () => undefined),
    updateExpenseWithFinancialAdjustment: vi.fn(async () => undefined),
    fetchLayawayPayments: vi.fn(async () => ({})),
    fetchCashSessions: vi.fn(async () => []),
    insertCashSession: vi.fn(async () => undefined),
    closeCashSession: vi.fn(async () => undefined),
    fetchInventoryAdjustments: vi.fn(async () => []),
    applyInventoryAdjustment: vi.fn(async () => ({ adjustment: { id: 'a1' }, product: { id: 'p1' } })),
    fetchSupplierInvoices: vi.fn(async () => []),
    insertSupplierInvoice: vi.fn(async () => ({ invoice: {}, payments: [] })),
    addSupplierInvoicePayment: vi.fn(async () => ({ invoice: {}, payment: {} })),
    updateSupplierInvoiceStatus: vi.fn(async () => undefined),
    updateSupplierInvoiceSafe: vi.fn(async () => undefined),
    deleteSupplierInvoiceSafe: vi.fn(async () => undefined),
    fetchSupplierPaymentsForReports: vi.fn(async () => []),
    ensureDefaultFinancialAccounts: vi.fn(async () => []),
    fetchFinancialAccounts: vi.fn(async () => []),
    createFinancialAccount: vi.fn(async () => ({ id: 'account-1' })),
    transferBetweenAccounts: vi.fn(async () => []),
    fetchFinancialMovements: vi.fn(async () => []),
    createInventoryPayable: vi.fn(async () => undefined),
    postPaidInventoryPurchase: vi.fn(async () => undefined),
    addSupplierPaymentWithAccount: vi.fn(async () => undefined),
    fetchFinancialSummary: vi.fn(async () => ({ totalCash: 0 })),
    fetchActivityLog: vi.fn(async () => []),
    bulkPutCategories: vi.fn(async () => undefined),
    findCategoryByKey: vi.fn(async () => undefined),
    putCategory: vi.fn(async () => undefined),
    deleteCategory: vi.fn(async () => undefined),
    bulkPutProducts: vi.fn(async () => undefined),
  };
  return {
    repository,
    repositoryHandler: null as null | ((request: {
      method: string;
      args?: Record<string, unknown>;
    }) => Promise<unknown>),
    reload: vi.fn(async () => undefined),
    createSale: vi.fn(async () => []),
    cancelSale: vi.fn(async () => ({ invoiceId: 'i1', cancelledAt: '2026-07-24', cancelledBy: 'Admin', restoredProducts: [] })),
    deleteLayaway: vi.fn(async () => ({ invoiceId: 'i1', restoredProducts: [], resolution: 'refund' })),
  };
});

vi.mock('@/contexts/AppContext', () => ({
  useApp: () => ({
    products: [], contacts: [], invoices: [], purchaseInvoices: [], expenses: [], layaways: [],
    cashSessions: [], financialAccounts: [], financialMovements: [], financialSummary: null,
    reloadFromDatabase: mocks.reload,
  }),
}));

vi.mock('@/repositories/RepositoryRegistry', () => ({
  getDataRepository: () => mocks.repository,
}));

vi.mock('@/lib/DashboardRepositoryService', () => ({
  DashboardRepositoryService: { buildServerMetrics: vi.fn() },
}));

vi.mock('@/lib/SalesRepositoryService', () => ({
  SalesRepositoryService: {
    getSalesWorkspace: vi.fn(async () => ({ company: {}, contacts: [], invoices: [], layaways: [], quotations: [], financialAccounts: [], financialMovements: [], financialSummary: null })),
    getClients: vi.fn(async () => []), searchClients: vi.fn(async () => []), getClientById: vi.fn(async () => null),
    createClient: vi.fn(async client => client), updateClient: vi.fn(async client => client), deleteClient: vi.fn(async () => undefined),
    querySales: vi.fn(async () => []), getSaleById: vi.fn(async () => null),
    createSale: mocks.createSale, updateSaleStatus: vi.fn(async () => undefined), cancelSale: mocks.cancelSale,
    applyContactChanges: vi.fn(async () => undefined), createQuotation: vi.fn(async input => input),
    updateQuotationStatus: vi.fn(async () => undefined), createLayaway: vi.fn(async layaway => layaway),
    updateLayaway: vi.fn(async () => ({ layaway: {}, updatedProducts: [] })), deleteLayaway: mocks.deleteLayaway,
    addLayawayPayment: vi.fn(async () => ({ payment: {}, invoiceId: 'i1', completed: false })),
    completeLayaway: vi.fn(async () => 'i1'),
  },
}));

import LanAuthenticationBridge from '@/components/LanAuthenticationBridge';

const request = (method: string, args: Record<string, unknown> = {}) => {
  if (!mocks.repositoryHandler) throw new Error('REPOSITORY_HANDLER_NOT_READY');
  return mocks.repositoryHandler({
    method,
    args: { ...args, __joyaControlAuthorizedLanSession: session },
  });
};

beforeEach(() => {
  mocks.repositoryHandler = null;
  mocks.reload.mockClear();
  for (const value of Object.values(mocks.repository)) {
    if (typeof value === 'function') (value as ReturnType<typeof vi.fn>).mockClear?.();
  }
  mocks.createSale.mockClear();
  mocks.cancelSale.mockClear();
  mocks.deleteLayaway.mockClear();

  window.joyaControlLan = {
    onAuthRequest: () => () => undefined,
    onRepositoryRequest: handler => {
      mocks.repositoryHandler = handler as typeof mocks.repositoryHandler;
      return () => { mocks.repositoryHandler = null; };
    },
  } as typeof window.joyaControlLan;
});

describe('LAN 2.5 - puente IPC autorizado del Repository', () => {
  it('despacha escrituras de todos los módulos al Repository principal y refresca estado', async () => {
    const view = render(<LanAuthenticationBridge />);

    await act(async () => {
      await request('upsertProduct', { product: { id: 'p1' } });
      await request('applyProductChanges', { changes: { upserts: [{ id: 'p1' }], deleteIds: [] } });
      await request('deleteProduct', { id: 'p1' });
      await request('putCategory', { category: { id: 'c1' } });
      await request('deleteCategory', { id: 'c1' });
      await request('upsertContact', { contact: { id: 'supplier-1', type: 'supplier' } });
      await request('applyContactChanges', { changes: { upserts: [{ id: 'client-1', type: 'client' }], deleteIds: [] } });
      await request('createPurchaseWithInventory', { purchase: { id: 'purchase-1' }, accountId: 'account-1' });
      await request('updatePurchaseWithInventory', { purchase: { id: 'purchase-1' } });
      await request('deletePurchaseWithInventory', { id: 'purchase-1' });
      await request('markPurchaseAsPaid', { id: 'purchase-1', accountId: 'account-1' });
      await request('applyInventoryAdjustment', { input: { productId: 'p1' } });
      await request('createSale', { invoice: { id: 'invoice-1' }, allocations: [], options: {} });
      await request('cancelSale', { id: 'invoice-1', reason: 'QA' });
      await request('deleteSalesLayaway', { layawayId: 'layaway-1', resolution: 'refund' });
      await request('insertCashSession', { session: { id: 'cash-1' } });
      await request('closeCashSession', { id: 'cash-1', closedAt: '2026-07-24', closedBy: 'Admin', observations: '' });
      await request('insertExpenseWithFinancials', { expense: { id: 'expense-1' }, accountId: 'account-1' });
      await request('saveCompany', { company: { name: 'JoyaControl' } });
    });

    expect(mocks.repository.upsertProduct).toHaveBeenCalledTimes(1);
    expect(mocks.repository.applyProductChanges).toHaveBeenCalledTimes(1);
    expect(mocks.repository.deleteProduct).toHaveBeenCalledWith('p1');
    expect(mocks.repository.putCategory).toHaveBeenCalledTimes(1);
    expect(mocks.repository.deleteCategory).toHaveBeenCalledWith('c1');
    expect(mocks.repository.upsertContact).toHaveBeenCalledTimes(1);
    expect(mocks.repository.applyContactChanges).toHaveBeenCalledTimes(1);
    expect(mocks.repository.createPurchaseWithInventory).toHaveBeenCalledTimes(1);
    expect(mocks.repository.updatePurchaseWithInventory).toHaveBeenCalledTimes(1);
    expect(mocks.repository.deletePurchaseWithInventory).toHaveBeenCalledWith('purchase-1');
    expect(mocks.repository.markPurchaseAsPaid).toHaveBeenCalledWith('purchase-1', 'account-1');
    expect(mocks.repository.applyInventoryAdjustment).toHaveBeenCalledTimes(1);
    expect(mocks.createSale).toHaveBeenCalledTimes(1);
    expect(mocks.cancelSale).toHaveBeenCalledWith('invoice-1', 'QA');
    expect(mocks.deleteLayaway).toHaveBeenCalledWith('layaway-1', 'refund');
    expect(mocks.repository.insertCashSession).toHaveBeenCalledTimes(1);
    expect(mocks.repository.closeCashSession).toHaveBeenCalledTimes(1);
    expect(mocks.repository.insertExpenseWithFinancials).toHaveBeenCalledTimes(1);
    expect(mocks.repository.saveCompany).toHaveBeenCalledTimes(1);
    expect(mocks.reload).toHaveBeenCalledTimes(19);

    await expect(request('fetchInventoryAdjustments')).resolves.toEqual([]);
    await expect(request('fetchSupplierPaymentsForReports')).resolves.toEqual([]);
    await expect(request('fetchActivityLog', { limit: 100 })).resolves.toEqual([]);

    view.unmount();
  });

  it('no consulta el usuario local de Dexie dentro de una ejecución ya autorizada por el servidor', async () => {
    const localPermissionLookup = vi.spyOn(localDb.users, 'get');
    await runWithAuthorizedLanRepositorySession(session, () => bulkPutProducts([]));
    expect(localPermissionLookup).not.toHaveBeenCalled();
  });

  it('rechaza cualquier llamada IPC que no incluya el contexto autorizado del servidor', async () => {
    render(<LanAuthenticationBridge />);
    await expect(mocks.repositoryHandler?.({ method: 'getProducts', args: {} })).rejects.toThrow('LAN_AUTH_CONTEXT_REQUIRED');
    expect(mocks.repository.fetchProducts).not.toHaveBeenCalled();
  });
});
