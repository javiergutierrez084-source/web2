// @vitest-environment jsdom
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import Dexie from 'dexie';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ApiRepository } from '@/repositories/ApiRepository';
import { createDefaultLanConfig, saveLanConfig } from '@/lib/LanCommunicationConfig';
import { startLanServer, stopLanServer } from '../../electron/lanServer.js';

const products = [
  { id: 'p1', code: 'ORO-1', name: 'Anillo Oro', category: 'Anillos', purchasePrice: 100, salePrice: 180, weightGrams: 2, margin: 80, stock: 3, minStock: 1, description: '', supplierIds: [] },
  { id: 'p2', code: 'PLA-1', name: 'Cadena Plata', category: 'Cadenas', purchasePrice: 80, salePrice: 130, weightGrams: 4, margin: 62.5, stock: 5, minStock: 2, description: '', supplierIds: [] },
];

async function post(base: string, route: string, body: Record<string, unknown>) {
  return fetch(`${base}${route}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
}

describe('LAN 2.2.1 - productos remotos mediante Repository genérico', () => {
  afterEach(async () => { await stopLanServer(); localStorage.clear(); vi.restoreAllMocks(); });

  it('ejecuta UI -> ApiRepository -> HTTP -> provider Repository y nunca abre Dexie en el Cliente', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan221-'));
    const port = 53000 + Math.floor(Math.random() * 1000);
    const baseUrl = `http://127.0.0.1:${port}`;
    const provider = vi.fn(async (method: string, args: Record<string, unknown>) => {
      if (method === 'getProducts') return { items: products, total: 2, page: 1, pageSize: 2 };
      if (method === 'searchProducts') {
        const text = String(args.text || '').toLowerCase();
        const items = products.filter(product => product.name.toLowerCase().includes(text));
        return { items, total: items.length, page: 1, pageSize: items.length };
      }
      if (method === 'getProductById') return products.find(product => product.id === args.id) || null;
      if (method === 'getCategories') return { items: [], total: 0, page: 1, pageSize: 0 };
      if (method === 'upsertProduct') return undefined;
      throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
    });
    await startLanServer({
      host: '127.0.0.1', port, serverName: 'Servidor', userDataPath, version: '2.1', executeRepositoryCall: provider,
      authenticateUser: async () => ({ success: true, userId: 'u1', username: 'master', displayName: 'Maestro', role: 'master', permissions: ['manage_inventory', 'manage_products'] }),
    });
    const register = await (await post(baseUrl, '/client/register', { deviceInstanceId: 'dev1', name: 'Cliente', hostname: 'cliente', version: '2.1', localTime: new Date().toISOString() })).json() as { clientId: string; sessionToken: string };
    const login = await (await post(baseUrl, '/login', { username: 'master', password: 'ok', ...register })).json() as { authToken: string };
    saveLanConfig({ ...createDefaultLanConfig(), mode: 'lan', role: 'client', clientServerIp: '127.0.0.1', clientServerPort: port, clientId: register.clientId, sessionToken: register.sessionToken, authToken: login.authToken });

    const dexieOpen = vi.spyOn(Dexie.prototype, 'open');
    const repository = new ApiRepository({ baseUrl });
    expect(await repository.fetchProducts()).toEqual(products);
    expect((await repository.searchProducts('oro')).items).toEqual([products[0]]);
    expect(await repository.getProductById('p2')).toEqual(products[1]);
    expect(provider.mock.calls.some(call => call[0] === 'getProducts')).toBe(true);
    await repository.upsertProduct(products[0]);
    expect(provider.mock.calls.some(call => call[0] === 'upsertProduct')).toBe(true);
    expect(dexieOpen).not.toHaveBeenCalled();
  });

  it('valida tokens antes del provider y no ejecuta Repository sin autenticación', async () => {
    const userDataPath = fs.mkdtempSync(path.join(os.tmpdir(), 'joya-lan221-auth-'));
    const port = 54000 + Math.floor(Math.random() * 500);
    const baseUrl = `http://127.0.0.1:${port}`;
    const provider = vi.fn();
    await startLanServer({ host: '127.0.0.1', port, serverName: 'Servidor', userDataPath, version: '2.1', executeRepositoryCall: provider });
    const response = await post(baseUrl, '/repository/call', { method: 'getProducts', args: {} });
    expect(response.status).toBe(401);
    expect((await response.json()).error).toBe('LAN_SESSION_TOKEN_REQUIRED');
    expect(provider).not.toHaveBeenCalled();
  });
});
