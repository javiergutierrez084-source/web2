// @vitest-environment jsdom
import 'fake-indexeddb/auto';
import { beforeEach, describe, expect, it } from 'vitest';
import { localDb } from '@/lib/localDb';
import { hashPassword, setSession } from '@/lib/authCore';
import {
  createPurchaseWithInventory,
  deletePurchaseWithInventory,
  insertExpenseWithFinancials,
  markPurchaseAsPaid,
  updateExpenseWithFinancialAdjustment,
  updateSupplierInvoiceSafe,
  deleteSupplierInvoiceSafe,
} from '@/repositories/dexieDataSource';
import type { ExpenseInvoice, PurchaseInvoice } from '@/data/mockData';

const now = '2026-07-17T12:00:00.000Z';
const cash = { id: 'account-caja-principal', name: 'Caja', kind: 'cash' as const, active: true, balance: 100000, created_at: now, updated_at: now };

beforeEach(async () => {
  await localDb.delete(); await localDb.open();
  const password_hash = await hashPassword('qa92');
  await localDb.users.put({ id:'u1', username:'qa92', display_name:'QA 9.2', password_hash, role:'master', active:true, created_at:now, last_login:null });
  setSession({ id:'u1', username:'qa92', displayName:'QA 9.2', role:'master' });
  await localDb.financial_accounts.put(cash);
  await localDb.products.put({ id:'p1', code:'P1', name:'Anillo', category:'Anillos', purchase_price:1000, sale_price:1500,
    weight_grams:5, margin:50, stock:10, min_stock:1, description:'', supplier_ids:[], reference:'P1', available_grams:50,
    average_purchase_price:1000, last_purchase_date:'', created_at:now });
});

const expense = (status: 'pending'|'paid'): ExpenseInvoice => ({ id:'e1', number:'GAS-0001', supplierId:'s1', supplierName:'Proveedor', total:10000, description:'Arriendo', date:'2026-07-17', paymentMethod:'Efectivo', status, accountId: status==='paid'?cash.id:'' });
const purchase = (status: 'pending'|'paid'): PurchaseInvoice => ({ id:'c1', number:'COM-0001', supplierId:'s1', supplierName:'Proveedor', items:[{ productId:'p1', code:'P1', name:'Anillo', quantity:2, weightGrams:5, unitPrice:1200, subtotal:2400 }], subtotal:2400, discount:0, tax:0, total:2400, date:'2026-07-17', status, paymentMethod:'Efectivo', description:'Compra QA' });

describe('QA #9.2 gastos', () => {
  it('gasto pendiente no afecta Caja y al pagarlo crea una sola salida', async () => {
    await insertExpenseWithFinancials(expense('pending'), cash.id);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
    expect(await localDb.financial_movements.count()).toBe(0);
    await updateExpenseWithFinancialAdjustment({ ...expense('paid'), accountId: cash.id });
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(90000);
    expect(await localDb.financial_movements.where('document_id').equals('e1').count()).toBe(1);
    expect(await localDb.activity_log.where('action').equals('EXPENSE_MARKED_AS_PAID').count()).toBe(1);
  });
});

describe('QA #9.2 compras', () => {
  it('compra pendiente actualiza inventario y obligación, pero no Caja; al pagar disminuye Caja', async () => {
    await createPurchaseWithInventory(purchase('pending'));
    expect((await localDb.products.get('p1'))?.stock).toBe(12);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(100000);
    expect(await localDb.financial_movements.count()).toBe(0);
    expect(await localDb.supplier_invoices.count()).toBe(1);
    await markPurchaseAsPaid('c1', cash.id);
    expect((await localDb.financial_accounts.get(cash.id))?.balance).toBe(97600);
    expect(await localDb.supplier_invoices.count()).toBe(0);
    expect(await localDb.activity_log.where('action').equals('PURCHASE_MARKED_AS_PAID').count()).toBe(1);
  });

  it('elimina compra pendiente y revierte stock; bloquea compra pagada', async () => {
    await createPurchaseWithInventory(purchase('pending'));
    await deletePurchaseWithInventory('c1');
    expect((await localDb.products.get('p1'))?.stock).toBe(10);
    expect(await localDb.purchase_invoices.count()).toBe(0);
    await createPurchaseWithInventory(purchase('paid'), cash.id);
    await expect(deletePurchaseWithInventory('c1')).rejects.toThrow('PAID_PURCHASE_REVERSAL_REQUIRED');
  });
});

describe('QA #9.2 cuentas por pagar', () => {
  it('edita y elimina una cuenta sin pagos; bloquea eliminación con pago', async () => {
    await localDb.supplier_invoices.put({ id:'sp1', supplier_id:'s1', supplier_name:'Proveedor', invoice_number:'FP-1', issue_date:'2026-07-17', due_date:'2026-08-17', total:5000, initial_value:5000, pending_balance:5000, status:'pending', notes:'', created_at:now });
    await updateSupplierInvoiceSafe('sp1', { supplierId:'s1', supplierName:'Proveedor editado', invoiceNumber:'FP-1', issueDate:'2026-07-17', dueDate:'2026-09-01', total:5500, notes:'Editada', status:'pending' });
    expect((await localDb.supplier_invoices.get('sp1'))?.total).toBe(5500);
    await deleteSupplierInvoiceSafe('sp1');
    expect(await localDb.supplier_invoices.get('sp1')).toBeUndefined();

    await localDb.supplier_invoices.put({ id:'sp2', supplier_id:'s1', supplier_name:'Proveedor', invoice_number:'FP-2', issue_date:'2026-07-17', due_date:'2026-08-17', total:5000, initial_value:5000, pending_balance:0, status:'paid', notes:'', created_at:now });
    await localDb.supplier_invoice_payments.put({ id:'pay1', supplier_invoice_id:'sp2', amount:5000, date:'2026-07-17', method:'Efectivo', created_at:now });
    await expect(deleteSupplierInvoiceSafe('sp2')).rejects.toThrow('PAYABLE_HAS_PAYMENTS');
  });
});
