import type { Invoice, Product, Quotation } from '@/data/mockData';

export interface CompanyInfo {
  name: string;
  nit: string;
  phone: string;
  city: string;
  address: string;
  email: string;
  logoUrl: string;
}

export interface LayawayPayment {
  id: string;
  amount: number;
  date: string;
  method: string;
  accountId?: string;
}

export interface Layaway {
  id: string;
  invoiceId: string;
  invoice: Invoice;
  payments: LayawayPayment[];
  completed: boolean;
  completedDate?: string;
}

export interface CashSession {
  id: string;
  openedAt: string;
  openedBy: string;
  initialAmount: number;
  closedAt?: string;
  closedBy?: string;
  observations?: string;
  date: string;
}

export interface InvoiceCancellationResult {
  invoiceId: string;
  cancelledAt: string;
  cancelledBy: string;
  restoredProducts: Product[];
  removedLayawayId?: string;
  reopenedQuotationId?: string;
}

export interface LayawayPaymentResult {
  payment: LayawayPayment;
  invoiceId: string;
  completed: boolean;
  completedDate?: string;
}

export interface LayawayUpdateResult {
  layaway: Layaway;
  updatedProducts: Product[];
}

export type LayawayCancellationResolution = 'refund' | 'credit';

export interface LayawayDeleteResult {
  invoiceId: string;
  restoredProducts: Product[];
  resolution?: LayawayCancellationResolution;
  refundedAmount?: number;
  creditAmount?: number;
  clientId?: string;
}

export interface CustomerCreditApplication {
  customerId: string;
  amount: number;
}

export interface InvoiceFinancialTransactionOptions {
  quotationId?: string;
  manualTotal?: { calculatedTotal: number; finalTotal: number };
  customerCredit?: CustomerCreditApplication;
}

export type CreateQuotationInput = Omit<Quotation, 'id' | 'number'>;

export interface ProductChangeSet {
  upserts: Product[];
  deleteIds: string[];
}

export interface ContactChangeSet<TContact> {
  upserts: TContact[];
  deleteIds: string[];
}

export interface SupplierInvoicePaymentView {
  id: string;
  amount: number;
  date: string;
  method: string;
  accountId: string;
  balanceBefore: number;
  balanceAfter: number;
  userName: string;
}

export interface SupplierInvoiceView {
  id: string;
  supplierId: string;
  supplierName: string;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  total: number;
  initialValue: number;
  pendingBalance: number;
  sourceType: string;
  sourceId: string;
  status: string;
  notes: string;
  payments: SupplierInvoicePaymentView[];
}

export interface SupplierInvoiceCreateInput {
  supplier_id: string;
  supplier_name: string;
  invoice_number: string;
  issue_date: string;
  due_date: string;
  total: number;
  notes: string;
}

export interface SupplierInvoiceCreateResult extends SupplierInvoiceCreateInput {
  id: string;
  status: string;
  created_at: string;
}

export interface SupplierInvoiceUpdateInput {
  supplierId: string;
  supplierName: string;
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  total: number;
  notes: string;
  status: 'pending' | 'paid';
}

export interface SupplierInvoicePaymentInput {
  amount: number;
  date: string;
  method: string;
}

export interface SupplierInvoicePaymentResult extends SupplierInvoicePaymentInput {
  id: string;
  supplier_invoice_id: string;
  created_at: string;
}

export interface SupplierPaymentReportRow {
  id: string;
  amount: number;
  date: string;
  method: string;
  supplierName: string;
  invoiceNumber: string;
}

export type LayawayPaymentsById = Record<string, LayawayPayment[]>;

export type UserRole = 'master' | 'admin' | 'vendedor' | 'cajero';

export interface UserRecord {
  id: string;
  username: string;
  display_name: string;
  password_hash: string;
  role: UserRole;
  active: boolean;
  created_at: string;
  last_login: string | null;
}

export interface ActivityLogRecord {
  id?: number;
  user_id: string;
  user_name: string;
  action: string;
  entity: string;
  entity_id: string;
  detail: string;
  created_at: string;
}

export interface CategoryRecord {
  id: string;
  name: string;
  name_key: string;
  created_at: string;
  auto_created: boolean;
}

/** Serializable import payload retained for the existing Excel workflow. */
export interface BulkImportProductRecord {
  id: string;
  code: string;
  name: string;
  category: string;
  purchase_price: number;
  sale_price: number;
  weight_grams: number;
  margin: number;
  stock: number;
  min_stock: number;
  description: string;
  supplier_ids: string[];
  created_at: string;
  reference?: string;
  available_grams?: number;
  average_purchase_price?: number;
  last_purchase_date?: string;
}
