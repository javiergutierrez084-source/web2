import { useState } from 'react';
import { Diamond, User, Lock, Eye, EyeOff, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { createUser } from '@/lib/auth';
import { useToast } from '@/hooks/use-toast';
import { APP_VERSION_LABEL, APP_VERSION_TEXT } from '@/config/appVersion';

interface SetupWizardProps {
  onComplete: () => void;
}

const SetupWizard = ({ onComplete }: SetupWizardProps) => {
  const { toast } = useToast();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [form, setForm] = useState({
    displayName: '',
    username: '',
    password: '',
    confirmPassword: '',
  });

  const update = (field: string, value: string) =>
    setForm(prev => ({ ...prev, [field]: value }));

  const handleCreate = async () => {
    if (!form.displayName.trim()) {
      toast({ title: 'Error', description: 'Ingresa tu nombre completo', variant: 'destructive' });
      return;
    }
    if (form.username.length < 3) {
      toast({ title: 'Error', description: 'El usuario debe tener al menos 3 caracteres', variant: 'destructive' });
      return;
    }
    if (form.password.length < 4) {
      toast({ title: 'Error', description: 'La contraseña debe tener al menos 4 caracteres', variant: 'destructive' });
      return;
    }
    if (form.password !== form.confirmPassword) {
      toast({ title: 'Error', description: 'Las contraseñas no coinciden', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      await createUser(
        form.username,
        form.displayName,
        form.password,
        'master',
      );
      setStep(3);
    } catch (err: any) {
      toast({ title: 'Error', description: err.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background">
      <div className="w-full max-w-md px-6">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <div className="flex h-20 w-20 items-center justify-center rounded-2xl gold-gradient shadow-2xl mb-4">
            <Diamond className="h-10 w-10 text-primary-foreground" />
          </div>
          <h1 className="text-3xl font-bold gold-text">JoyaControl</h1>
          <p className="text-sm text-muted-foreground mt-1">{APP_VERSION_TEXT} · Solo Local</p>
        </div>

        {/* Step 1: Welcome */}
        {step === 1 && (
          <div className="rounded-2xl border border-border bg-card p-8 shadow-lg space-y-6 animate-fade-in">
            <div className="text-center space-y-2">
              <ShieldCheck className="h-12 w-12 text-primary mx-auto" />
              <h2 className="text-xl font-bold">Bienvenido a JoyaControl {APP_VERSION_LABEL}</h2>
              <p className="text-sm text-muted-foreground">
                Esta es la primera vez que abres la aplicación. Vamos a crear tu <strong>usuario maestro</strong> con acceso completo al sistema.
              </p>
            </div>
            <div className="rounded-lg bg-primary/5 border border-primary/20 p-4 text-sm text-muted-foreground space-y-1">
              <p>✅ Todos los datos se guardan localmente en tu dispositivo</p>
              <p>✅ Sin internet requerido para operar</p>
              <p>✅ Backup automático cada hora</p>
              <p>✅ Control de acceso por roles</p>
            </div>
            <Button onClick={() => setStep(2)} className="w-full gold-gradient text-primary-foreground font-semibold h-11">
              Crear usuario maestro
            </Button>
          </div>
        )}

        {/* Step 2: Create master user */}
        {step === 2 && (
          <div className="rounded-2xl border border-border bg-card p-8 shadow-lg space-y-5 animate-fade-in">
            <div className="space-y-1">
              <h2 className="text-xl font-bold">Crear usuario maestro</h2>
              <p className="text-sm text-muted-foreground">Este usuario tendrá acceso completo e irrestricto al sistema.</p>
            </div>

            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Nombre completo</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-9 bg-secondary/50"
                    placeholder="Ej: Javier Gutiérrez"
                    value={form.displayName}
                    onChange={e => update('displayName', e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Usuario (para iniciar sesión)</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-9 bg-secondary/50"
                    placeholder="Ej: javier o admin"
                    value={form.username}
                    onChange={e => update('username', e.target.value.toLowerCase().replace(/\s/g, ''))}
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type={showPass ? 'text' : 'password'}
                    className="pl-9 pr-9 bg-secondary/50"
                    placeholder="Mínimo 4 caracteres"
                    value={form.password}
                    onChange={e => update('password', e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPass(!showPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Confirmar contraseña</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    type={showConfirm ? 'text' : 'password'}
                    className="pl-9 pr-9 bg-secondary/50"
                    placeholder="Repite la contraseña"
                    value={form.confirmPassword}
                    onChange={e => update('confirmPassword', e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleCreate()}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm(!showConfirm)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  >
                    {showConfirm ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
            </div>

            <Button
              onClick={handleCreate}
              disabled={loading}
              className="w-full gold-gradient text-primary-foreground font-semibold h-11"
            >
              {loading ? 'Creando...' : 'Crear usuario maestro'}
            </Button>
          </div>
        )}

        {/* Step 3: Success */}
        {step === 3 && (
          <div className="rounded-2xl border border-border bg-card p-8 shadow-lg space-y-6 animate-fade-in text-center">
            <div className="space-y-3">
              <div className="text-6xl">🎉</div>
              <h2 className="text-xl font-bold">¡Usuario maestro creado!</h2>
              <p className="text-sm text-muted-foreground">
                Ya puedes ingresar al sistema con el usuario <strong>{form.username}</strong>. Recuerda guardar tu contraseña en un lugar seguro.
              </p>
            </div>
            <Button onClick={onComplete} className="w-full gold-gradient text-primary-foreground font-semibold h-11">
              Ir al inicio de sesión
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default SetupWizard;
