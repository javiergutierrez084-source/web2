import { useEffect, useRef } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { logActivity, hasRouteAccess } from '@/lib/auth';

export default function MasterOnlyRoute({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const location = useLocation();
  const logged = useRef(false);
  const allowed = hasRouteAccess(user, '/configuracion/lan');

  useEffect(() => {
    if (!allowed && user && !logged.current) {
      logged.current = true;
      void logActivity(user, 'UNAUTHORIZED_LAN_CONFIGURATION_ACCESS', 'lan_configuration', location.pathname,
        JSON.stringify({ route: location.pathname, requestedAt: new Date().toISOString() }));
    }
  }, [allowed, user, location.pathname]);

  if (!allowed) return <Navigate to="/acceso-denegado" replace />;
  return <>{children}</>;
}
