import { useEffect, useMemo, useRef, useState } from 'react';
import { Download, Eye, FileText, Loader2, Printer, Receipt, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { buildThermalInvoice80Html, printThermalInvoice80 } from '@/lib/thermalInvoicePrint';
import {
  DEFAULT_DOCUMENT_FORMATS,
  PDF_TEMPLATES,
  createPdfFile,
  downloadPdfFile,
  openPdfForPrint,
  renderPdfDocument,
  revokePdfFile,
  type GeneratedPdfFile,
  type PdfDocumentData,
  type PdfDocumentFormat,
} from '@/lib/pdf';

export type PdfDocumentAction = 'preview' | 'download' | 'print';

interface PdfDocumentModalProps {
  document: PdfDocumentData;
  onClose: () => void;
  formats?: PdfDocumentFormat[];
  initialFormat?: PdfDocumentFormat;
  initialAction?: PdfDocumentAction;
}

export const PdfDocumentModal = ({
  document,
  onClose,
  formats = DEFAULT_DOCUMENT_FORMATS,
  initialFormat = 'letter',
  initialAction = 'preview',
}: PdfDocumentModalProps) => {
  const availableFormats = formats.length > 0 ? formats : DEFAULT_DOCUMENT_FORMATS;
  const resolvedInitialFormat = availableFormats.includes(initialFormat) ? initialFormat : availableFormats[0];
  const [format, setFormat] = useState<PdfDocumentFormat>(resolvedInitialFormat);
  const [file, setFile] = useState<GeneratedPdfFile | null>(null);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState('');
  const initialActionHandled = useRef(false);

  useEffect(() => {
    let cancelled = false;
    let nextFile: GeneratedPdfFile | null = null;
    setBusy(true);
    setError('');
    setFile(current => {
      revokePdfFile(current);
      return null;
    });

    void renderPdfDocument(document, format)
      .then(blob => {
        if (cancelled) return;
        nextFile = createPdfFile(blob, `${document.filename}_${format}`);
        setFile(nextFile);
      })
      .catch(reason => {
        if (!cancelled) setError(reason instanceof Error ? reason.message : 'No se pudo generar el documento PDF.');
      })
      .finally(() => {
        if (!cancelled) setBusy(false);
      });

    return () => {
      cancelled = true;
      if (nextFile) revokePdfFile(nextFile);
    };
  }, [document, format]);

  useEffect(() => {
    if (!file || initialActionHandled.current || initialAction === 'preview') return;
    initialActionHandled.current = true;
    if (initialAction === 'download') downloadPdfFile(file);
    else openPdfForPrint(file);
  }, [file, initialAction]);

  const handleDownload = () => {
    if (file) downloadPdfFile(file);
  };

  const handlePrint = () => {
    if (!file) return;
    try {
      if (format === 'ticket80' && document.kind === 'invoice') {
        printThermalInvoice80(document);
        return;
      }
      openPdfForPrint(file);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No se pudo abrir el PDF para imprimir.');
    }
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center bg-background/90 p-3 backdrop-blur-sm" onClick={onClose}>
      <div className="flex h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl" onClick={event => event.stopPropagation()}>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
          <div className="min-w-0">
            <p className="min-w-0 break-words text-sm font-semibold">{document.title}</p>
            <p className="text-[10px] text-muted-foreground">La vista previa, la descarga y la impresión usan exactamente el mismo PDF.</p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div
              role="status"
              aria-label="Vista previa activa"
              className="inline-flex h-9 items-center gap-1.5 rounded-md bg-secondary px-3 text-sm font-medium text-secondary-foreground"
            >
              <Eye className="h-3.5 w-3.5" /> Vista previa
            </div>
            <Button size="sm" variant="outline" className="gap-1.5" onClick={handleDownload} disabled={busy || !file}>
              <Download className="h-3.5 w-3.5" /> Descargar PDF
            </Button>
            <Button size="sm" variant="outline" className="gap-1.5" onClick={handlePrint} disabled={busy || !file}>
              <Printer className="h-3.5 w-3.5" /> Imprimir
            </Button>
            <button type="button" onClick={onClose} className="rounded-lg p-1.5 transition-colors hover:bg-secondary" aria-label="Cerrar documento">
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {availableFormats.length > 1 && (
          <div className="flex flex-wrap gap-2 border-b border-border px-4 py-2">
            {availableFormats.map(option => {
              const definition = PDF_TEMPLATES[option];
              const Icon = option === 'letter' ? FileText : Receipt;
              return (
                <button
                  key={option}
                  type="button"
                  onClick={() => setFormat(option)}
                  className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-left transition-colors ${format === option ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-secondary'}`}
                >
                  <Icon className="h-4 w-4" />
                  <span><span className="block text-xs font-medium">{definition.label}</span><span className="block text-[10px] text-muted-foreground">{definition.description}</span></span>
                </button>
              );
            })}
          </div>
        )}

        {error && <div className="m-4 rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</div>}
        <div className="relative min-h-0 flex-1 bg-secondary/30">
          {busy && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-background/70">
              <div className="flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="h-4 w-4 animate-spin" /> Generando PDF...</div>
            </div>
          )}
          {file && format === 'ticket80' && document.kind === 'invoice' ? (
            <iframe
              title={`Vista previa térmica ${document.title}`}
              srcDoc={buildThermalInvoice80Html(document)}
              className="h-full w-full bg-white"
            />
          ) : file ? (
            <iframe title={`Vista previa PDF ${document.title}`} src={file.url} className="h-full w-full bg-white" />
          ) : null}
        </div>
      </div>
    </div>
  );
};

interface PdfDocumentActionsProps {
  document: PdfDocumentData | (() => PdfDocumentData);
  formats?: PdfDocumentFormat[];
  initialFormat?: PdfDocumentFormat;
  label?: string;
  compact?: boolean;
  className?: string;
  title?: string;
}

const PdfDocumentActions = ({
  document,
  formats = DEFAULT_DOCUMENT_FORMATS,
  initialFormat = 'letter',
  label = 'Documentos',
  compact = false,
  className = '',
  title,
}: PdfDocumentActionsProps) => {
  const [open, setOpen] = useState(false);
  const resolvedDocument = useMemo(
    () => open ? (typeof document === 'function' ? document() : document) : null,
    [document, open],
  );

  return (
    <>
      {compact ? (
        <button
          type="button"
          title={title || label}
          onClick={() => setOpen(true)}
          className={`rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground ${className}`}
        >
          <FileText className="h-4 w-4" />
        </button>
      ) : (
        <Button type="button" variant="outline" className={`gap-1.5 ${className}`} onClick={() => setOpen(true)}>
          <FileText className="h-3.5 w-3.5" /> {label}
        </Button>
      )}
      {open && resolvedDocument && (
        <PdfDocumentModal
          document={resolvedDocument}
          formats={formats}
          initialFormat={initialFormat}
          onClose={() => setOpen(false)}
        />
      )}
    </>
  );
};

export default PdfDocumentActions;
