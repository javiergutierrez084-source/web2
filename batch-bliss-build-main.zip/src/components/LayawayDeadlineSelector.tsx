import { memo, useMemo } from 'react';
import { CalendarClock } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  LAYAWAY_TERM_OPTIONS,
  addLayawayDays,
  isValidLayawayDate,
  type LayawayDeadlineMode,
} from '@/lib/LayawayAlertService';

interface LayawayDeadlineSelectorProps {
  createdDate: string;
  mode: LayawayDeadlineMode;
  termDays: number;
  customDueDate: string;
  disabled?: boolean;
  onModeChange: (mode: LayawayDeadlineMode) => void;
  onTermDaysChange: (days: number) => void;
  onCustomDueDateChange: (date: string) => void;
}

const LayawayDeadlineSelector = ({
  createdDate,
  mode,
  termDays,
  customDueDate,
  disabled = false,
  onModeChange,
  onTermDaysChange,
  onCustomDueDateChange,
}: LayawayDeadlineSelectorProps) => {
  const calculatedDueDate = useMemo(() => {
    if (mode === 'custom') return customDueDate;
    if (!isValidLayawayDate(createdDate)) return '';
    try {
      return addLayawayDays(createdDate, termDays);
    } catch {
      return '';
    }
  }, [createdDate, customDueDate, mode, termDays]);

  return (
    <section className="rounded-xl border border-border bg-secondary/15 p-4" aria-labelledby="layaway-term-title">
      <div className="flex items-start gap-3">
        <div className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-warning/10 text-warning">
          <CalendarClock className="h-4 w-4" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 id="layaway-term-title" className="text-sm font-semibold">Plazo del separado</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Este vencimiento queda asociado únicamente a este separado y no cambia al modificar la configuración global.
          </p>
        </div>
      </div>

      <div className="mt-4 grid gap-2 sm:grid-cols-3 lg:grid-cols-7">
        {LAYAWAY_TERM_OPTIONS.map(days => (
          <label
            key={days}
            className={`flex cursor-pointer items-center justify-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
              mode === 'term' && termDays === days
                ? 'border-primary bg-primary/10 text-primary'
                : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
            } ${disabled ? 'pointer-events-none opacity-60' : ''}`}
          >
            <input
              type="radio"
              name="layaway-term"
              value={days}
              checked={mode === 'term' && termDays === days}
              disabled={disabled}
              onChange={() => {
                onModeChange('term');
                onTermDaysChange(days);
              }}
              className="sr-only"
            />
            {days} días
          </label>
        ))}
        <label
          className={`flex cursor-pointer items-center justify-center rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
            mode === 'custom'
              ? 'border-primary bg-primary/10 text-primary'
              : 'border-border bg-card text-muted-foreground hover:border-primary/40 hover:text-foreground'
          } ${disabled ? 'pointer-events-none opacity-60' : ''}`}
        >
          <input
            type="radio"
            name="layaway-term"
            value="custom"
            checked={mode === 'custom'}
            disabled={disabled}
            onChange={() => onModeChange('custom')}
            className="sr-only"
          />
          Personalizado
        </label>
      </div>

      {mode === 'custom' && (
        <div className="mt-4 max-w-sm space-y-1.5">
          <label htmlFor="layaway-custom-due-date" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
            Fecha exacta de vencimiento
          </label>
          <Input
            id="layaway-custom-due-date"
            type="date"
            min={isValidLayawayDate(createdDate) ? createdDate : undefined}
            value={customDueDate}
            disabled={disabled}
            onChange={event => onCustomDueDateChange(event.target.value)}
            className="bg-card"
          />
        </div>
      )}

      <div className="mt-4 rounded-lg border border-border/70 bg-card/70 px-3 py-2 text-xs">
        <span className="text-muted-foreground">Fecha de vencimiento:</span>{' '}
        <strong>{calculatedDueDate || 'Selecciona un plazo válido'}</strong>
      </div>
    </section>
  );
};

export default memo(LayawayDeadlineSelector);
