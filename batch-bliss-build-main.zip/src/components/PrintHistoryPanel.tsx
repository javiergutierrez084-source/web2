import { useEffect, useMemo, useState } from 'react';
import { Ban, Printer, RefreshCw, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { PrintRepositoryService } from '@/lib/PrintRepositoryService';
import type { PrintJobStatus, PrintWorkspace } from '@/lib/PrintModels';

const statusLabels: Record<PrintJobStatus, string> = {
  pending: 'Pendiente', printing: 'Imprimiendo', completed: 'Completado', error: 'Error', cancelled: 'Cancelado',
};

export default function PrintHistoryPanel() {
  const { toast } = useToast();
  const [workspace, setWorkspace] = useState<PrintWorkspace | null>(null);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ text: '', status: 'all', printer: 'all', date: '', user: '', type: 'all' });

  const load = async () => {
    setLoading(true);
    try { setWorkspace(await PrintRepositoryService.getWorkspace()); }
    catch (error) { toast({ title: 'No fue posible consultar la cola', description: error instanceof Error ? error.message : 'PRINT_HISTORY_FAILED', variant: 'destructive' }); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    void load();
    const refresh = () => void load();
    window.addEventListener('joyacontrol:lan-repository-synchronized', refresh);
    window.addEventListener('focus', refresh);
    return () => {
      window.removeEventListener('joyacontrol:lan-repository-synchronized', refresh);
      window.removeEventListener('focus', refresh);
    };
  }, []);

  const jobs = useMemo(() => (workspace?.jobs || []).filter(job => {
    const text = filters.text.trim().toLowerCase();
    if (text && !`${job.documentNumber} ${job.title} ${job.requester.displayName}`.toLowerCase().includes(text)) return false;
    if (filters.status !== 'all' && job.status !== filters.status) return false;
    if (filters.printer !== 'all' && job.printerName !== filters.printer) return false;
    if (filters.type !== 'all' && job.documentType !== filters.type) return false;
    if (filters.user && !job.requester.displayName.toLowerCase().includes(filters.user.toLowerCase())) return false;
    if (filters.date && !job.requestedAt.startsWith(filters.date)) return false;
    return true;
  }), [workspace, filters]);

  const action = async (type: 'retry' | 'cancel' | 'reprint', jobId: string) => {
    try {
      if (type === 'retry') await PrintRepositoryService.retry(jobId);
      else if (type === 'cancel') await PrintRepositoryService.cancel(jobId);
      else await PrintRepositoryService.reprint(jobId);
      await load();
      toast({ title: type === 'reprint' ? 'Reimpresión encolada' : type === 'retry' ? 'Trabajo reintentado' : 'Trabajo cancelado' });
    } catch (error) {
      toast({ title: 'No fue posible actualizar el trabajo', description: error instanceof Error ? error.message : 'PRINT_ACTION_FAILED', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div><h2 className="flex items-center gap-2 font-semibold"><Printer className="h-4 w-4 text-primary" /> Historial de impresión</h2><p className="text-xs text-muted-foreground">Cola transaccional persistida en el Servidor Principal.</p></div>
        <Button variant="outline" size="sm" onClick={() => void load()} disabled={loading} className="gap-2"><RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Actualizar</Button>
      </div>

      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6">
        <Input placeholder="Documento o usuario" value={filters.text} onChange={event => setFilters(current => ({ ...current, text: event.target.value }))} />
        <Input type="date" value={filters.date} onChange={event => setFilters(current => ({ ...current, date: event.target.value }))} />
        <Input placeholder="Usuario" value={filters.user} onChange={event => setFilters(current => ({ ...current, user: event.target.value }))} />
        <Select value={filters.status} onValueChange={value => setFilters(current => ({ ...current, status: value }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos los estados</SelectItem>{Object.entries(statusLabels).map(([value, label]) => <SelectItem key={value} value={value}>{label}</SelectItem>)}</SelectContent></Select>
        <Select value={filters.printer} onValueChange={value => setFilters(current => ({ ...current, printer: value }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todas las impresoras</SelectItem>{(workspace?.printers || []).map(printer => <SelectItem key={printer.name} value={printer.name}>{printer.displayName || printer.name}</SelectItem>)}</SelectContent></Select>
        <Select value={filters.type} onValueChange={value => setFilters(current => ({ ...current, type: value }))}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">Todos los documentos</SelectItem>{['invoice','quotation','layaway','receipt','payment','expense','purchase','cash_close','report','label','barcode','other'].map(value => <SelectItem key={value} value={value}>{value}</SelectItem>)}</SelectContent></Select>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full min-w-[1050px] text-sm">
          <thead><tr className="border-b border-border bg-secondary/50"><th className="px-3 py-2 text-left">Fecha</th><th className="px-3 py-2 text-left">Documento</th><th className="px-3 py-2 text-left">Usuario / Cliente LAN</th><th className="px-3 py-2 text-left">Impresora</th><th className="px-3 py-2 text-center">Estado</th><th className="px-3 py-2 text-center">Intentos</th><th className="px-3 py-2 text-right">Tiempo</th><th className="px-3 py-2 text-center">Acciones</th></tr></thead>
          <tbody>{jobs.map(job => (
            <tr key={job.id} className="border-b border-border/50">
              <td className="px-3 py-2"><p>{new Date(job.requestedAt).toLocaleDateString('es-CO')}</p><p className="text-xs text-muted-foreground">{new Date(job.requestedAt).toLocaleTimeString('es-CO')}</p></td>
              <td className="px-3 py-2"><p className="font-medium">{job.documentNumber || job.title}</p><p className="text-xs text-muted-foreground">{job.documentType} · {job.format}</p></td>
              <td className="px-3 py-2"><p>{job.requester.displayName || job.requester.username}</p><p className="text-xs text-muted-foreground">{job.requester.deviceName} · {job.requester.clientId}</p></td>
              <td className="px-3 py-2">{job.printerName || 'Pendiente de asignación'}</td>
              <td className="px-3 py-2 text-center"><span className={`rounded-full px-2 py-1 text-xs ${job.status === 'completed' ? 'bg-success/15 text-success' : job.status === 'error' ? 'bg-destructive/15 text-destructive' : job.status === 'cancelled' ? 'bg-secondary text-muted-foreground' : 'bg-warning/15 text-warning'}`}>{statusLabels[job.status]}</span>{job.lastError && <p className="mt-1 max-w-[260px] break-words text-[10px] text-destructive" title={job.lastError}>{job.lastError}</p>}</td>
              <td className="px-3 py-2 text-center">{job.attempts}</td>
              <td className="px-3 py-2 text-right">{job.durationMs == null ? '—' : `${job.durationMs} ms`}</td>
              <td className="px-3 py-2"><div className="flex justify-center gap-1">{(job.status === 'error' || job.status === 'pending') && <Button size="sm" variant="outline" onClick={() => void action('retry', job.id)} title="Reintentar"><RefreshCw className="h-3.5 w-3.5" /></Button>}{job.status !== 'printing' && job.status !== 'completed' && job.status !== 'cancelled' && <Button size="sm" variant="outline" onClick={() => void action('cancel', job.id)} title="Cancelar"><Ban className="h-3.5 w-3.5" /></Button>}{job.status === 'completed' && <Button size="sm" variant="outline" onClick={() => void action('reprint', job.id)} title="Reimprimir"><RotateCcw className="h-3.5 w-3.5" /></Button>}</div></td>
            </tr>
          ))}</tbody>
        </table>
        {!loading && jobs.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">No existen trabajos de impresión para los filtros seleccionados.</p>}
      </div>
    </div>
  );
}
