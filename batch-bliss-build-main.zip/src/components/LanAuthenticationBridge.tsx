import { useEffect, useRef } from 'react';
import { useApp } from '@/contexts/AppContext';
import { getDataRepository } from '@/repositories/RepositoryRegistry';
import { getRolePermissions, getSession, type SessionUser } from '@/lib/authCore';
import { DashboardRepositoryService } from '@/lib/DashboardRepositoryService';
import type { DashboardSnapshotInput } from '@/lib/DashboardMetricsService';
import { SalesRepositoryService } from '@/lib/SalesRepositoryService';
import {
  cancelOwnerWithdrawalLocal,
  createOwnerWithdrawalConceptLocal,
  createOwnerWithdrawalLocal,
  fetchOwnerFinanceWorkspaceLocal,
  saveOwnerFinanceSettingsLocal,
  updateOwnerWithdrawalConceptLocal,
} from '@/lib/OwnerFinanceLocalDataService';
import {
  runWithAuthorizedLanRepositorySession,
  type AuthorizedLanRepositorySession,
} from '@/lib/LanRepositoryExecutionContext';
import {
  toPagedResult,
  type LanRepositoryArgs,
  type LanRepositoryMethod,
} from '@/lib/LanRepositoryContract';

let repositoryExecutionQueue: Promise<void> = Promise.resolve();
const AUTHORIZED_SESSION_ARGUMENT = '__joyaControlAuthorizedLanSession';

function enqueueRepositoryExecution<T>(operation: () => Promise<T>): Promise<T> {
  const execution = repositoryExecutionQueue.then(operation, operation);
  repositoryExecutionQueue = execution.then(() => undefined, () => undefined);
  return execution;
}

export default function LanAuthenticationBridge() {
  const {
    products,
    contacts,
    invoices,
    purchaseInvoices,
    expenses,
    layaways,
    cashSessions,
    financialAccounts,
    financialMovements,
    financialSummary,
    reloadFromDatabase,
  } = useApp();

  const dashboardSourceRef = useRef<DashboardSnapshotInput>({
    products: [],
    contacts: [],
    invoices: [],
    purchases: [],
    expenses: [],
    layaways: [],
    cashSessions: [],
    accounts: [],
    movements: [],
    financialSummary: null,
  });

  dashboardSourceRef.current = {
    products,
    contacts,
    invoices,
    purchases: purchaseInvoices,
    expenses,
    layaways,
    cashSessions,
    accounts: financialAccounts,
    movements: financialMovements,
    financialSummary,
  };

  useEffect(() => {
    const dispose = window.joyaControlLan?.onAuthRequest?.(async request => {
      try {
        const session = await getDataRepository().loginUser(request.username, request.password);
        return {
          success: true,
          userId: session.id,
          username: session.username,
          displayName: session.displayName,
          role: session.role,
          permissions: getRolePermissions(session.role),
        };
      } catch (error) {
        return { success: false, error: error instanceof Error ? error.message : 'LAN_AUTH_FAILED' };
      }
    });

    const refreshAfterWrite = async <T,>(operation: () => Promise<T>): Promise<T> => {
      const result = await operation();
      await reloadFromDatabase();
      return result;
    };

    const disposeRepository = window.joyaControlLan?.onRepositoryRequest?.(request => (
      // This value is injected by electron/lanServer.js only after the HTTP
      // session, client, token and permission checks have all succeeded.
      // The server overwrites any client-supplied value with the authoritative
      // login snapshot before forwarding the existing Repository request.
      enqueueRepositoryExecution(() => runWithAuthorizedLanRepositorySession(
        (request.args?.[AUTHORIZED_SESSION_ARGUMENT] || null) as AuthorizedLanRepositorySession | null,
        async () => {
          const repository = getDataRepository();
          const method = request.method as LanRepositoryMethod;
          const args = { ...(request.args || {}) } as Record<string, unknown>;
          delete args[AUTHORIZED_SESSION_ARGUMENT];

          switch (method) {
            case 'getProducts': {
              const items = await repository.fetchProducts();
              return toPagedResult(items);
            }
            case 'searchProducts': {
              const text = String(args.text || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
              const productsData = await repository.fetchProducts();
              const items = !text ? productsData : productsData.filter(product =>
                [product.code, product.name, product.reference || '', product.category]
                  .join(' ')
                  .normalize('NFD')
                  .replace(/[\u0300-\u036f]/g, '')
                  .toLowerCase()
                  .includes(text),
              );
              return toPagedResult(items);
            }
            case 'getProductById': {
              const productsData = await repository.fetchProducts();
              return productsData.find(product => product.id === String(args.id || '')) || null;
            }
            case 'getCategories':
              return toPagedResult(await repository.fetchCategories());
            case 'getDashboardMetrics':
              return DashboardRepositoryService.buildServerMetrics(dashboardSourceRef.current);
            case 'getSalesWorkspace':
              return SalesRepositoryService.getSalesWorkspace();
            case 'getSalesClients':
              return SalesRepositoryService.getClients();
            case 'searchSalesClients':
              return SalesRepositoryService.searchClients(String(args.text || ''));
            case 'getSalesClientById':
              return SalesRepositoryService.getClientById(String(args.id || ''));
            case 'createSalesClient':
              return refreshAfterWrite(() => SalesRepositoryService.createClient(
                args.client as LanRepositoryArgs['createSalesClient']['client'],
              ));
            case 'updateSalesClient':
              return refreshAfterWrite(() => SalesRepositoryService.updateClient(
                args.client as LanRepositoryArgs['updateSalesClient']['client'],
              ));
            case 'deleteSalesClient':
              return refreshAfterWrite(() => SalesRepositoryService.deleteClient(String(args.id || '')));
            case 'querySales':
              return SalesRepositoryService.querySales(
                (args.query || {}) as LanRepositoryArgs['querySales']['query'],
              );
            case 'getSaleById':
              return SalesRepositoryService.getSaleById(String(args.id || ''));
            case 'createSale':
              return refreshAfterWrite(() => SalesRepositoryService.createSale(
                args.invoice as LanRepositoryArgs['createSale']['invoice'],
                (args.allocations || []) as LanRepositoryArgs['createSale']['allocations'],
                (args.options || {}) as LanRepositoryArgs['createSale']['options'],
              ));
            case 'updateSaleStatus':
              return refreshAfterWrite(() => SalesRepositoryService.updateSaleStatus(
                String(args.id || ''),
                String(args.status || ''),
              ));
            case 'cancelSale':
              return refreshAfterWrite(() => SalesRepositoryService.cancelSale(
                String(args.id || ''),
                String(args.reason || ''),
              ));
            case 'applySalesContactChanges':
              return refreshAfterWrite(() => SalesRepositoryService.applyContactChanges(
                args.changes as LanRepositoryArgs['applySalesContactChanges']['changes'],
              ));
            case 'createSalesQuotation':
              return refreshAfterWrite(() => SalesRepositoryService.createQuotation(
                args.input as LanRepositoryArgs['createSalesQuotation']['input'],
              ));
            case 'updateSalesQuotationStatus':
              return refreshAfterWrite(() => SalesRepositoryService.updateQuotationStatus(
                String(args.id || ''),
                args.status as LanRepositoryArgs['updateSalesQuotationStatus']['status'],
              ));
            case 'createSalesLayaway':
              return refreshAfterWrite(() => SalesRepositoryService.createLayaway(
                args.layaway as LanRepositoryArgs['createSalesLayaway']['layaway'],
              ));
            case 'updateSalesLayaway':
              return refreshAfterWrite(() => SalesRepositoryService.updateLayaway(
                String(args.layawayId || ''),
                args.invoice as LanRepositoryArgs['updateSalesLayaway']['invoice'],
              ));
            case 'deleteSalesLayaway':
              return refreshAfterWrite(() => SalesRepositoryService.deleteLayaway(
                String(args.layawayId || ''),
                args.resolution === 'credit' ? 'credit' : 'refund',
              ));
            case 'addSalesLayawayPayment':
              return refreshAfterWrite(() => SalesRepositoryService.addLayawayPayment(
                String(args.layawayId || ''),
                args.payment as LanRepositoryArgs['addSalesLayawayPayment']['payment'],
              ));
            case 'completeSalesLayaway':
              return refreshAfterWrite(() => SalesRepositoryService.completeLayaway(
                String(args.layawayId || ''),
                String(args.completedDate || ''),
              ));

            case 'fetchCompany':
              return repository.fetchCompany();
            case 'logActivity': {
              const activitySession = (args.session || getSession()) as SessionUser | null;
              if (!activitySession) throw new Error('LAN_ACTIVITY_SESSION_NOT_AVAILABLE');
              return repository.logActivity(
                activitySession,
                String(args.action || ''),
                String(args.entity || ''),
                String(args.entityId || ''),
                typeof args.detail === 'string' ? args.detail : '',
              );
            }
            case 'saveCompany':
              return refreshAfterWrite(() => repository.saveCompany(
                args.company as LanRepositoryArgs['saveCompany']['company'],
              ));
            case 'upsertProduct':
              return refreshAfterWrite(() => repository.upsertProduct(
                args.product as LanRepositoryArgs['upsertProduct']['product'],
              ));
            case 'deleteProduct':
              return refreshAfterWrite(() => repository.deleteProduct(String(args.id || '')));
            case 'applyProductChanges':
              return refreshAfterWrite(() => repository.applyProductChanges(
                args.changes as LanRepositoryArgs['applyProductChanges']['changes'],
              ));
            case 'fetchContacts':
              return repository.fetchContacts();
            case 'insertInvoice':
              return refreshAfterWrite(() => repository.insertInvoice(
                args.invoice as LanRepositoryArgs['insertInvoice']['invoice'],
              ));
            case 'upsertContact':
              return refreshAfterWrite(() => repository.upsertContact(
                args.contact as LanRepositoryArgs['upsertContact']['contact'],
              ));
            case 'deleteContact':
              return refreshAfterWrite(() => repository.deleteContact(String(args.id || '')));
            case 'applyContactChanges':
              return refreshAfterWrite(() => repository.applyContactChanges(
                args.changes as LanRepositoryArgs['applyContactChanges']['changes'],
              ));
            case 'fetchPurchaseInvoices':
              return repository.fetchPurchaseInvoices();
            case 'createPurchaseWithInventory':
              return refreshAfterWrite(() => repository.createPurchaseWithInventory(
                args.purchase as LanRepositoryArgs['createPurchaseWithInventory']['purchase'],
                typeof args.accountId === 'string' ? args.accountId : undefined,
              ));
            case 'updatePurchaseWithInventory':
              return refreshAfterWrite(() => repository.updatePurchaseWithInventory(
                args.purchase as LanRepositoryArgs['updatePurchaseWithInventory']['purchase'],
              ));
            case 'deletePurchaseWithInventory':
              return refreshAfterWrite(() => repository.deletePurchaseWithInventory(String(args.id || '')));
            case 'markPurchaseAsPaid':
              return refreshAfterWrite(() => repository.markPurchaseAsPaid(
                String(args.id || ''),
                String(args.accountId || ''),
              ));
            case 'fetchExpenses':
              return repository.fetchExpenses();
            case 'insertExpense':
              return refreshAfterWrite(() => repository.insertExpense(
                args.expense as LanRepositoryArgs['insertExpense']['expense'],
              ));
            case 'insertExpenseWithFinancials':
              return refreshAfterWrite(() => repository.insertExpenseWithFinancials(
                args.expense as LanRepositoryArgs['insertExpenseWithFinancials']['expense'],
                String(args.accountId || ''),
              ));
            case 'updateExpenseWithFinancialAdjustment':
              return refreshAfterWrite(() => repository.updateExpenseWithFinancialAdjustment(
                args.expense as LanRepositoryArgs['updateExpenseWithFinancialAdjustment']['expense'],
              ));
            case 'fetchLayawayPayments':
              return repository.fetchLayawayPayments(
                Array.isArray(args.layawayIds) ? args.layawayIds.map(String) : undefined,
              );
            case 'fetchCashSessions':
              return repository.fetchCashSessions();
            case 'insertCashSession':
              return refreshAfterWrite(() => repository.insertCashSession(
                args.session as LanRepositoryArgs['insertCashSession']['session'],
              ));
            case 'closeCashSession':
              return refreshAfterWrite(() => repository.closeCashSession(
                String(args.id || ''),
                String(args.closedAt || ''),
                String(args.closedBy || ''),
                String(args.observations || ''),
              ));
            case 'fetchInventoryAdjustments':
              return repository.fetchInventoryAdjustments();
            case 'applyInventoryAdjustment':
              return refreshAfterWrite(() => repository.applyInventoryAdjustment(
                args.input as LanRepositoryArgs['applyInventoryAdjustment']['input'],
              ));
            case 'fetchSupplierInvoices':
              return repository.fetchSupplierInvoices();
            case 'insertSupplierInvoice':
              return refreshAfterWrite(() => repository.insertSupplierInvoice(
                args.input as LanRepositoryArgs['insertSupplierInvoice']['input'],
              ));
            case 'addSupplierInvoicePayment':
              return refreshAfterWrite(() => repository.addSupplierInvoicePayment(
                String(args.supplierInvoiceId || ''),
                args.payment as LanRepositoryArgs['addSupplierInvoicePayment']['payment'],
              ));
            case 'updateSupplierInvoiceStatus':
              return refreshAfterWrite(() => repository.updateSupplierInvoiceStatus(
                String(args.id || ''),
                String(args.status || ''),
              ));
            case 'updateSupplierInvoiceSafe':
              return refreshAfterWrite(() => repository.updateSupplierInvoiceSafe(
                String(args.id || ''),
                args.input as LanRepositoryArgs['updateSupplierInvoiceSafe']['input'],
              ));
            case 'deleteSupplierInvoiceSafe':
              return refreshAfterWrite(() => repository.deleteSupplierInvoiceSafe(String(args.id || '')));
            case 'fetchSupplierPaymentsForReports':
              return repository.fetchSupplierPaymentsForReports();
            case 'ensureDefaultFinancialAccounts':
              return refreshAfterWrite(() => repository.ensureDefaultFinancialAccounts());
            case 'fetchFinancialAccounts':
              return repository.fetchFinancialAccounts();
            case 'createFinancialAccount':
              return refreshAfterWrite(() => repository.createFinancialAccount(
                args.input as LanRepositoryArgs['createFinancialAccount']['input'],
              ));
            case 'transferBetweenAccounts':
              return refreshAfterWrite(() => repository.transferBetweenAccounts(
                args.input as LanRepositoryArgs['transferBetweenAccounts']['input'],
              ));
            case 'fetchFinancialMovements':
              return repository.fetchFinancialMovements(
                typeof args.limit === 'number' ? args.limit : undefined,
              );
            case 'createInventoryPayable':
              return refreshAfterWrite(() => repository.createInventoryPayable(
                args.input as LanRepositoryArgs['createInventoryPayable']['input'],
              ));
            case 'postPaidInventoryPurchase':
              return refreshAfterWrite(() => repository.postPaidInventoryPurchase(
                args.input as LanRepositoryArgs['postPaidInventoryPurchase']['input'],
              ));
            case 'addSupplierPaymentWithAccount':
              return refreshAfterWrite(() => repository.addSupplierPaymentWithAccount(
                String(args.supplierInvoiceId || ''),
                args.input as LanRepositoryArgs['addSupplierPaymentWithAccount']['input'],
              ));
            case 'fetchFinancialSummary':
              return repository.fetchFinancialSummary();
            case 'fetchOwnerFinanceWorkspace':
              return fetchOwnerFinanceWorkspaceLocal(
                args.filters as LanRepositoryArgs['fetchOwnerFinanceWorkspace']['filters'],
              );
            case 'createOwnerWithdrawal':
              return refreshAfterWrite(() => createOwnerWithdrawalLocal(
                args.input as LanRepositoryArgs['createOwnerWithdrawal']['input'],
              ));
            case 'cancelOwnerWithdrawal':
              return refreshAfterWrite(() => cancelOwnerWithdrawalLocal(
                String(args.withdrawalId || ''),
                String(args.reason || ''),
              ));
            case 'createOwnerWithdrawalConcept':
              return refreshAfterWrite(() => createOwnerWithdrawalConceptLocal(String(args.name || '')));
            case 'updateOwnerWithdrawalConcept':
              return refreshAfterWrite(() => updateOwnerWithdrawalConceptLocal(
                String(args.conceptId || ''),
                args.changes as LanRepositoryArgs['updateOwnerWithdrawalConcept']['changes'],
              ));
            case 'saveOwnerFinanceSettings':
              return refreshAfterWrite(() => saveOwnerFinanceSettingsLocal(
                args.settings as LanRepositoryArgs['saveOwnerFinanceSettings']['settings'],
              ));
            case 'fetchActivityLog':
              return repository.fetchActivityLog(typeof args.limit === 'number' ? args.limit : undefined);
            case 'bulkPutCategories':
              return refreshAfterWrite(() => repository.bulkPutCategories(
                args.categories as LanRepositoryArgs['bulkPutCategories']['categories'],
              ));
            case 'findCategoryByKey':
              return repository.findCategoryByKey(String(args.nameKey || ''));
            case 'putCategory':
              return refreshAfterWrite(() => repository.putCategory(
                args.category as LanRepositoryArgs['putCategory']['category'],
              ));
            case 'deleteCategory':
              return refreshAfterWrite(() => repository.deleteCategory(String(args.id || '')));
            case 'bulkPutProducts':
              return refreshAfterWrite(() => repository.bulkPutProducts(
                args.products as LanRepositoryArgs['bulkPutProducts']['products'],
              ));
            default:
              throw new Error('LAN_REPOSITORY_METHOD_NOT_ALLOWED');
          }
        },
      ))
    ));

    return () => { dispose?.(); disposeRepository?.(); };
  }, [reloadFromDatabase]);
  return null;
}
