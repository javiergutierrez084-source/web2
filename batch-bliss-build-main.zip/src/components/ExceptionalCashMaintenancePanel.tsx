import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, RefreshCw, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useApp } from '@/contexts/AppContext';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/data/mockData';
import { resolveFinancialAccountBalance } from '@/lib/FinancialLedgerService';
import {
  createExceptionalCashAdjustment,
  fetchExceptionalCashHistory,
  repairHistoricalInventoryFinancialMovements,
  type ExceptionalCashDirection,
  type ExceptionalCashHistoryEntry,
  type InventoryFinancialRepairReport,
} from '@/lib/ExceptionalCashMaintenance';

const emptyForm = {
  direction: 'positive' as ExceptionalCashDirection,
  amount: '',
  reason: '',
  observation: '',
  password: '',
  confirmed: false,
};

export default function ExceptionalCashMaintenancePanel() {
  const { financialAccounts, financialMovements, refreshFinancialData } = useApp();
  const { toast } = useToast();
  const cashAccounts = useMemo(() => {
    return financialAccounts
      .filter(account => account.kind === 'cash' && account.active)
      .map(account => ({
        ...account,
        balance: resolveFinancialAccountBalance(
          financialAccounts,
          financialMovements,
          account.id,
        ),
      }));
  }, [financialAccounts, financialMovements]);
  const [accountId, setAccountId] = useState('account-caja-principal');
  const [form, setForm] = useState(emptyForm);
  const [history, setHistory] = useState<ExceptionalCashHistoryEntry[]>([]);
  const [filters, setFilters] = useState({ from: '', to: '', userId: '', reason: '' });
  const [saving, setSaving] = useState(false);
  const [repairPassword, setRepairPassword] = useState('');
  const [repairConfirmed, setRepairConfirmed] = useState(false);
  const [repairing, setRepairing] = useState(false);
  const [repairReport, setRepairReport] = useState<InventoryFinancialRepairReport | null>(null);

  const loadHistory = async () => {
    try {
      setHistory(await fetchExceptionalCashHistory({
        from: filters.from || undefined,
        to: filters.to || undefined,
        userId: filters.userId || undefined,
        reason: filters.reason || undefined,
      }));
    } catch (error) {
      toast({ title: 'No fue posible cargar el historial', description: error instanceof Error ? error.message : 'Error desconocido', variant: 'destructive' });
    }
  };

  useEffect(() => { void loadHistory(); }, []); // carga inicial protegida por system_maintenance

  const users = useMemo(() => Array.from(new Map(history.map(row => [row.userId, row.userName])).entries()), [history]);

  const submitAdjustment = async () => {
    setSaving(true);
    try {
      await createExceptionalCashAdjustment({
        accountId,
        direction: form.direction,
        amount: Number(form.amount),
        reason: form.reason,
        observation: form.observation,
        password: form.password,
        confirmed: form.confirmed,
      });
      await refreshFinancialData();
      setForm(emptyForm);
      await loadHistory();
      toast({ title: 'Corrección excepcional registrada', description: 'Caja y trazabilidad fueron actualizadas dentro de una sola transacción.' });
    } catch (error) {
      toast({ title: 'No se aplicó la corrección', description: error instanceof Error ? error.message : 'Error desconocido', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const runRepair = async () => {
    setRepairing(true);
    try {
      const report = await repairHistoricalInventoryFinancialMovements(repairPassword, repairConfirmed);
      setRepairReport(report);
      setRepairPassword('');
      setRepairConfirmed(false);
      await refreshFinancialData();
      toast({ title: 'Revisión histórica completada', description: `${report.corrected} corregidos, ${report.ignored} ignorados, ${report.inconsistencies} inconsistencias.` });
    } catch (error) {
      toast({ title: 'No se ejecutó la reparación', description: error instanceof Error ? error.message : 'Error desconocido', variant: 'destructive' });
    } finally {
      setRepairing(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="rounded-xl border border-amber-500/40 bg-card p-6 space-y-4">
        <div className="flex items-start gap-3">
          <ShieldCheck className="h-5 w-5 text-amber-500 mt-0.5" />
          <div>
            <h2 className="font-semibold">Mantenimiento · Corrección excepcional de Caja</h2>
            <p className="text-xs text-muted-foreground">Uso exclusivo con permiso system_maintenance. No modifica ventas, gastos, inventario ni cuentas por pagar.</p>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <label className="space-y-1 text-xs">Cuenta de Caja
            <select value={accountId} onChange={event => setAccountId(event.target.value)} className="w-full rounded-md border border-border bg-secondary/50 px-3 py-2 text-sm">
              {cashAccounts.map(account => <option key={account.id} value={account.id}>{account.name} · {formatCurrency(account.balance)}</option>)}
            </select>
          </label>
          <label className="space-y-1 text-xs">Tipo
            <select value={form.direction} onChange={event => setForm(previous => ({ ...previous, direction: event.target.value as ExceptionalCashDirection }))} className="w-full rounded-md border border-border bg-secondary/50 px-3 py-2 text-sm">
              <option value="positive">Ajuste positivo</option>
              <option value="negative">Ajuste negativo</option>
            </select>
          </label>
          <label className="space-y-1 text-xs">Valor
            <Input type="number" min="0.01" step="0.01" value={form.amount} onChange={event => setForm(previous => ({ ...previous, amount: event.target.value }))} />
          </label>
          <label className="space-y-1 text-xs">Motivo
            <Input value={form.reason} onChange={event => setForm(previous => ({ ...previous, reason: event.target.value }))} />
          </label>
          <label className="space-y-1 text-xs sm:col-span-2">Observación
            <textarea value={form.observation} onChange={event => setForm(previous => ({ ...previous, observation: event.target.value }))} className="min-h-20 w-full rounded-md border border-border bg-secondary/50 px-3 py-2 text-sm" />
          </label>
          <label className="space-y-1 text-xs sm:col-span-2">Contraseña del usuario autenticado
            <Input type="password" value={form.password} onChange={event => setForm(previous => ({ ...previous, password: event.target.value }))} />
          </label>
        </div>
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={form.confirmed} onChange={event => setForm(previous => ({ ...previous, confirmed: event.target.checked }))} /> Confirmo que esta es una corrección excepcional auditada.</label>
        <Button onClick={submitAdjustment} disabled={saving || cashAccounts.length === 0}>{saving ? 'Aplicando…' : 'Aplicar corrección de Caja'}</Button>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <h3 className="font-semibold">Historial de correcciones excepcionales</h3>
        <div className="grid gap-2 sm:grid-cols-4">
          <Input type="date" value={filters.from} onChange={event => setFilters(previous => ({ ...previous, from: event.target.value }))} />
          <Input type="date" value={filters.to} onChange={event => setFilters(previous => ({ ...previous, to: event.target.value }))} />
          <select value={filters.userId} onChange={event => setFilters(previous => ({ ...previous, userId: event.target.value }))} className="rounded-md border border-border bg-secondary/50 px-3 py-2 text-sm"><option value="">Todos los usuarios</option>{users.map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select>
          <Input placeholder="Filtrar motivo" value={filters.reason} onChange={event => setFilters(previous => ({ ...previous, reason: event.target.value }))} />
        </div>
        <Button variant="outline" onClick={loadHistory}><RefreshCw className="h-4 w-4 mr-2" />Aplicar filtros</Button>
        <div className="overflow-x-auto">
          <table className="w-full text-xs"><thead><tr className="border-b border-border text-left"><th className="p-2">Fecha</th><th className="p-2">Usuario</th><th className="p-2">Tipo</th><th className="p-2">Motivo</th><th className="p-2 text-right">Valor</th><th className="p-2 text-right">Saldo</th></tr></thead><tbody>{history.map(row => <tr key={row.id} className="border-b border-border/50"><td className="p-2">{row.createdAt.replace('T', ' ').slice(0, 19)}</td><td className="p-2">{row.userName}</td><td className="p-2">{row.direction === 'positive' ? 'Positivo' : 'Negativo'}</td><td className="p-2" title={row.observation}>{row.reason}</td><td className="p-2 text-right">{formatCurrency(row.amount)}</td><td className="p-2 text-right">{formatCurrency(row.balanceBefore)} → {formatCurrency(row.balanceAfter)}</td></tr>)}</tbody></table>
          {history.length === 0 && <p className="py-4 text-center text-xs text-muted-foreground">Sin registros para los filtros seleccionados.</p>}
        </div>
      </div>

      <div className="rounded-xl border border-destructive/40 bg-card p-6 space-y-4">
        <div className="flex gap-3"><AlertTriangle className="h-5 w-5 text-destructive" /><div><h3 className="font-semibold">Reparar movimientos financieros históricos de ajustes</h3><p className="text-xs text-muted-foreground">Solo procesa relaciones inequívocas document_type=inventory_adjustment y document_id existente. Los casos dudosos se informan y no se modifican.</p></div></div>
        <Input type="password" placeholder="Contraseña del usuario autenticado" value={repairPassword} onChange={event => setRepairPassword(event.target.value)} />
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={repairConfirmed} onChange={event => setRepairConfirmed(event.target.checked)} /> Confirmo la ejecución de la reparación histórica.</label>
        <Button variant="destructive" onClick={runRepair} disabled={repairing}>{repairing ? 'Revisando…' : 'Ejecutar reparación histórica'}</Button>
        {repairReport && <div className="rounded-md bg-secondary/40 p-3 text-xs"><p>Corregidos: {repairReport.corrected} · Ignorados: {repairReport.ignored} · Inconsistencias: {repairReport.inconsistencies}</p></div>}
      </div>
    </div>
  );
}
