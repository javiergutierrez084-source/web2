import { useMemo } from 'react';
import { useApp } from '@/contexts/AppContext';
import { buildInvoiceDocumentData } from '@/lib/pdf';
import { PdfDocumentModal } from '@/components/PdfDocumentActions';
import type { Invoice, PurchaseInvoice } from '@/data/mockData';

interface InvoicePreviewProps {
  invoice: Invoice | PurchaseInvoice;
  type: 'sale' | 'purchase';
  onClose: () => void;
}

const InvoicePreview = ({ invoice, type, onClose }: InvoicePreviewProps) => {
  const { company, contacts, products } = useApp();
  const entityId = type === 'sale'
    ? (invoice as Invoice).clientId
    : (invoice as PurchaseInvoice).supplierId;
  const contact = contacts.find(item => item.id === entityId);
  const document = useMemo(
    () => buildInvoiceDocumentData({ invoice, type, company, contact, products }),
    [company, contact, invoice, products, type],
  );
  return (
    <PdfDocumentModal
      document={document}
      formats={['letter', 'ticket80', 'ticket50']}
      initialFormat="letter"
      onClose={onClose}
    />
  );
};

export default InvoicePreview;
