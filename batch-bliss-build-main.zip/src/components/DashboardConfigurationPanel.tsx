import { useEffect, useMemo, useState } from 'react';
import { GripVertical, RotateCcw, Save, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  DASHBOARD_WIDGET_CATALOG,
  createDefaultDashboardPreferences,
  dashboardWidgetsByCategory,
  type DashboardPreferences,
  type DashboardWidgetKey,
} from '@/lib/DashboardPreferencesService';

interface DashboardConfigurationPanelProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  preferences: DashboardPreferences;
  onSave: (preferences: DashboardPreferences) => void;
}

const moveItem = (items: DashboardWidgetKey[], source: DashboardWidgetKey, target: DashboardWidgetKey): DashboardWidgetKey[] => {
  if (source === target) return items;
  const next = [...items];
  const sourceIndex = next.indexOf(source);
  const targetIndex = next.indexOf(target);
  if (sourceIndex < 0 || targetIndex < 0) return items;
  next.splice(sourceIndex, 1);
  next.splice(targetIndex, 0, source);
  return next;
};

const DashboardConfigurationPanel = ({
  open,
  onOpenChange,
  preferences,
  onSave,
}: DashboardConfigurationPanelProps) => {
  const [draft, setDraft] = useState(preferences);
  const [draggedKey, setDraggedKey] = useState<DashboardWidgetKey | null>(null);

  useEffect(() => {
    if (open) setDraft(preferences);
  }, [open, preferences]);

  const grouped = useMemo(() => dashboardWidgetsByCategory(), []);
  const widgetByKey = useMemo(
    () => new Map(DASHBOARD_WIDGET_CATALOG.map(widget => [widget.key, widget])),
    [],
  );
  const activeOrder = useMemo(
    () => draft.order.filter(key => draft.visible[key]),
    [draft.order, draft.visible],
  );

  const setVisible = (key: DashboardWidgetKey, checked: boolean) => {
    setDraft(current => ({
      ...current,
      visible: { ...current.visible, [key]: checked },
    }));
  };

  const save = () => {
    onSave({ ...draft, updatedAt: new Date().toISOString() });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[calc(100vh-1rem)] max-w-6xl flex-col gap-0 overflow-hidden p-0 sm:max-h-[92vh]">
        <DialogHeader className="shrink-0 border-b border-border px-5 py-4 sm:px-6 sm:py-5">
          <DialogTitle className="flex items-center gap-2">
            <Settings2 className="h-5 w-5 text-primary" /> Configurar Dashboard
          </DialogTitle>
          <DialogDescription>
            Marca los indicadores que deseas ver. Arrastra los elementos activos para cambiar su orden.
          </DialogDescription>
        </DialogHeader>

        <div className="grid min-h-0 flex-1 overflow-hidden lg:grid-cols-[minmax(0,1.55fr)_minmax(280px,0.75fr)]">
          <ScrollArea className="h-full min-h-0 border-b border-border lg:border-b-0 lg:border-r">
            <div className="space-y-6 p-5 sm:p-6">
              {grouped.map(group => (
                <section key={group.category}>
                  <h3 className="mb-3 text-xs font-bold uppercase tracking-[0.15em] text-muted-foreground">{group.category}</h3>
                  <div className="grid gap-2 sm:grid-cols-2 xl:grid-cols-3">
                    {group.widgets.map(widget => (
                      <label
                        key={widget.key}
                        className="flex cursor-pointer items-start gap-3 rounded-lg border border-border bg-secondary/20 p-3 transition-colors hover:border-primary/30 hover:bg-primary/5"
                      >
                        <Checkbox
                          checked={draft.visible[widget.key]}
                          onCheckedChange={checked => setVisible(widget.key, checked === true)}
                          aria-label={widget.label}
                        />
                        <span className="min-w-0 text-sm font-medium leading-tight">{widget.label}</span>
                      </label>
                    ))}
                  </div>
                </section>
              ))}
            </div>
          </ScrollArea>

          <div className="flex min-h-0 flex-col bg-secondary/10 p-4 sm:p-5">
            <div className="mb-3 shrink-0">
              <h3 className="text-sm font-semibold">Orden de widgets activos</h3>
              <p className="text-xs text-muted-foreground">{activeOrder.length} seleccionados</p>
            </div>
            <ScrollArea className="min-h-0 flex-1 pr-3">
              <div className="space-y-2 pb-2">
                {activeOrder.map(key => {
                  const widget = widgetByKey.get(key);
                  if (!widget) return null;
                  return (
                    <div
                      key={key}
                      draggable
                      onDragStart={() => setDraggedKey(key)}
                      onDragEnd={() => setDraggedKey(null)}
                      onDragOver={event => event.preventDefault()}
                      onDrop={() => {
                        if (!draggedKey) return;
                        setDraft(current => ({ ...current, order: moveItem(current.order, draggedKey, key) }));
                        setDraggedKey(null);
                      }}
                      className="flex cursor-grab items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm shadow-sm active:cursor-grabbing"
                    >
                      <GripVertical className="h-4 w-4 shrink-0 text-muted-foreground" />
                      <span className="min-w-0 flex-1 break-words font-medium">{widget.label}</span>
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{widget.category}</span>
                    </div>
                  );
                })}
              </div>
            </ScrollArea>
          </div>
        </div>

        <DialogFooter className="z-10 shrink-0 border-t border-border bg-background/95 px-4 py-3 backdrop-blur sm:px-6 sm:py-4">
          <Button
            type="button"
            variant="ghost"
            className="gap-1.5 sm:mr-auto"
            onClick={() => setDraft(createDefaultDashboardPreferences())}
          >
            <RotateCcw className="h-4 w-4" /> Restablecer
          </Button>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button type="button" className="gap-2 gold-gradient font-semibold text-primary-foreground" onClick={save}>
            <Save className="h-4 w-4" /> Guardar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default DashboardConfigurationPanel;
