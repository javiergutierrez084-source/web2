import { AlertTriangle, CalendarDays, CircleDollarSign, FileClock, ReceiptText, ShoppingCart } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { formatCurrency } from '@/data/mockData';
import type { PurchaseDashboardMetrics } from '@/lib/PurchaseDocumentsService';

interface PurchaseFinanceDashboardProps {
  metrics: PurchaseDashboardMetrics;
}

const PurchaseFinanceDashboard = ({ metrics }: PurchaseFinanceDashboardProps) => {
  const cards = [
    { label: 'Compras del día', value: formatCurrency(metrics.purchasesToday), icon: ShoppingCart },
    { label: 'Gastos del día', value: formatCurrency(metrics.expensesToday), icon: ReceiptText },
    { label: 'Compras del mes', value: formatCurrency(metrics.purchasesMonth), icon: CalendarDays },
    { label: 'Gastos del mes', value: formatCurrency(metrics.expensesMonth), icon: CircleDollarSign },
    { label: 'Facturas pendientes', value: String(metrics.pendingInvoices), icon: FileClock },
    { label: 'Facturas vencidas', value: String(metrics.overdueInvoices), icon: AlertTriangle },
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        {cards.map(({ label, value, icon: Icon }) => (
          <Card key={label}>
            <CardContent className="flex items-center justify-between p-4">
              <div><p className="text-xs text-muted-foreground">{label}</p><p className="mt-1 text-xl font-bold">{value}</p></div>
              <Icon className="h-5 w-5 text-primary" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="text-base">Top conceptos de gasto</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {metrics.topExpenseConcepts.map((item, index) => (
              <div key={item.name} className="flex items-center justify-between rounded-lg bg-secondary/40 px-3 py-2 text-sm">
                <span>{index + 1}. {item.name}</span><strong>{formatCurrency(item.total)}</strong>
              </div>
            ))}
            {metrics.topExpenseConcepts.length === 0 && <p className="text-sm text-muted-foreground">Aún no hay gastos registrados.</p>}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle className="text-base">Top proveedores</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {metrics.topSuppliers.map((item, index) => (
              <div key={item.name} className="flex items-center justify-between rounded-lg bg-secondary/40 px-3 py-2 text-sm">
                <span>{index + 1}. {item.name}</span><strong>{formatCurrency(item.total)}</strong>
              </div>
            ))}
            {metrics.topSuppliers.length === 0 && <p className="text-sm text-muted-foreground">Aún no hay documentos registrados.</p>}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PurchaseFinanceDashboard;
