import { useEffect, useMemo, useState } from 'react';
import { Activity, AlertTriangle, Clipboard, Download, KeyRound, Network, Play, RotateCcw, Search, Server, ShieldCheck, Square, TestTube2, Trash2, Wifi, WifiOff, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { hasSessionPermission, logActivity } from '@/lib/auth';
import {
  discoverLanServers,
  disconnectLanClient,
  fetchLanClients,
  fetchLanUsers,
  loadLanConfig,
  maintainLanDevices,
  reconnectOrRegisterLanClient,
  probeLanServer,
  resetLanConfig,
  saveLanConfig,
  serializeLanDiagnostic,
  validateLanConfig,
  validateAndRememberLanServer,
  type LanCommunicationConfig,
  type LanDiagnostics,
  type LanConnectedDevice,
  type LanConnectedUser,
  type LanDiscoveredServer,
  type LanDeviceMaintenanceAction,
} from '@/lib/LanCommunicationConfig';
import { LanServerDescriptor, type LanServerDescriptorData } from '@/lib/LanServerDescriptor';
import { LAN_CONFIG_CHANGED_EVENT, LAN_RUNTIME_DIAGNOSTICS_EVENT, type LanRuntimeDiagnostics } from '@/components/LanClientConnectionService';
import { useLanConnectionState } from '@/contexts/LanConnectionStateContext';

const APP_VERSION = '2.1';
const formatDate = (value: string | null) => value ? new Date(value).toLocaleString('es-CO') : 'No disponible';

interface DeviceMaintenanceIntent {
  action: LanDeviceMaintenanceAction;
  count: number;
  clientId?: string;
  days?: 30 | 60 | 90 | 180;
  title: string;
  description: string;
}

const lastDeviceActivityMs = (client: LanConnectedDevice): number => Math.max(
  new Date(client.lastActivity || 0).getTime() || 0,
  new Date(client.lastHeartbeat || 0).getTime() || 0,
  new Date(client.connectedAt || 0).getTime() || 0,
  new Date(client.registeredAt || 0).getTime() || 0,
);

const LanCommunicationPanel = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const { connectionState: clientConnectionState } = useLanConnectionState();
  const [config, setConfig] = useState<LanCommunicationConfig>(() => loadLanConfig());
  const [descriptor, setDescriptor] = useState<LanServerDescriptorData>(() => LanServerDescriptor.load());
  const [diagnostics, setDiagnostics] = useState<LanDiagnostics | null>(null);
  const [busy, setBusy] = useState(false);
  const [serverState, setServerState] = useState<{ running: boolean; serverId?: string; startedAt?: string | null; connectedClients?: number; activeClients?: number; inactiveClients?: number; requestsHandled?: number; heartbeatsReceived?: number; averageResponseTimeMs?: number; protocolVersion?: string; ip?: string | null; baseUrl?: string | null; lastLanIp?: string | null; ipSource?: LanServerDescriptorData['ipSource']; ipUpdatedAt?: string | null; networkAvailable?: boolean }>({ running: false });
  const [clients, setClients] = useState<LanConnectedDevice[]>([]);
  const [connectedUsers, setConnectedUsers] = useState<LanConnectedUser[]>([]);
  const [discoveredServers, setDiscoveredServers] = useState<LanDiscoveredServer[]>([]);
  const [runtimeDiagnostics, setRuntimeDiagnostics] = useState<LanRuntimeDiagnostics>({ lastHeartbeatSent: null, lastHeartbeatReceived: null, timerState: 'stopped', reconnectAttempts: 0, lastPingAgeMs: null, autoReconnect: config.autoReconnect, lastDisconnectReason: null, lastReconnect: null, reconnectCount: 0, watcherState: 'stopped', lastIpChange: null, timeWithoutServerMs: 0 });
  const [maintenanceOpen, setMaintenanceOpen] = useState(false);
  const [maintenanceDays, setMaintenanceDays] = useState<30 | 60 | 90 | 180>(30);
  const [maintenanceIntent, setMaintenanceIntent] = useState<DeviceMaintenanceIntent | null>(null);
  const [maintenanceBusy, setMaintenanceBusy] = useState(false);

  useEffect(() => {
    const refreshConfig = () => { setConfig(loadLanConfig()); setDescriptor(LanServerDescriptor.load()); };
    const updateRuntimeDiagnostics = (event: Event) => {
      const detail = (event as CustomEvent<LanRuntimeDiagnostics>).detail;
      if (detail) setRuntimeDiagnostics(detail);
    };
    window.addEventListener(LAN_CONFIG_CHANGED_EVENT, refreshConfig);
    window.addEventListener(LAN_RUNTIME_DIAGNOSTICS_EVENT, updateRuntimeDiagnostics);
    window.addEventListener(LanServerDescriptor.changedEvent, refreshConfig);
    return () => {
      window.removeEventListener(LAN_CONFIG_CHANGED_EVENT, refreshConfig);
      window.removeEventListener(LAN_RUNTIME_DIAGNOSTICS_EVENT, updateRuntimeDiagnostics);
      window.removeEventListener(LanServerDescriptor.changedEvent, refreshConfig);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const refreshServer = async () => {
      const state = await window.joyaControlLan?.getServerStatus?.();
      if (cancelled || !state) return;
      setServerState(state);
      if (state.running !== config.serverStarted) {
        const next = { ...loadLanConfig(), serverStarted: state.running };
        saveLanConfig(next);
      }
      if (state.running && config.role === 'server') {
        const liveDiagnostics = await probeLanServer({ ...config, role: 'server' });
        if (!cancelled && liveDiagnostics.ok) setDiagnostics(liveDiagnostics);
      }
    };
    void refreshServer();
    const unsubscribe = window.joyaControlLan?.onServerStateChanged?.(payload => {
      if (cancelled) return;
      setServerState(current => ({ ...current, ...payload.state }));
      void LanServerDescriptor.refresh().then(nextDescriptor => { if (!cancelled) setDescriptor(nextDescriptor); });
      void refreshServer();
    });
    const timer = window.setInterval(() => void refreshServer(), 1000);
    return () => { cancelled = true; unsubscribe?.(); window.clearInterval(timer); };
  }, [config.role, config.serverStarted, descriptor.ip, descriptor.port]);

  useEffect(() => {
    let cancelled = false;
    const refresh = async () => {
      if (config.mode !== 'lan') return;
      try {
        const [nextClients, nextUsers] = await Promise.all([fetchLanClients(config), fetchLanUsers(config)]);
        if (!cancelled) { setClients(nextClients); setConnectedUsers(nextUsers); }
      } catch {
        // Preserve the last confirmed server snapshot during a transient network gap.
        // The next successful poll or IPC state event replaces it immediately.
      }
      const events = await window.joyaControlLan?.getActivityEvents?.() ?? [];
      if (user) {
        for (const event of events) {
          await logActivity(user, event.action, 'lan_client', event.id, JSON.stringify({ ...event.details, eventDate: event.createdAt }));
        }
      }
    };
    void refresh();
    const onInfrastructureState = () => void refresh();
    window.addEventListener('joyacontrol-lan-infrastructure-event', onInfrastructureState);
    const unsubscribe = window.joyaControlLan?.onServerStateChanged?.(() => void refresh());
    const unsubscribeEvents = window.joyaControlLan?.onLanEvent?.(() => void refresh());
    const timer = window.setInterval(() => void refresh(), 1000);
    return () => { cancelled = true; unsubscribe?.(); unsubscribeEvents?.(); window.removeEventListener('joyacontrol-lan-infrastructure-event', onInfrastructureState); window.clearInterval(timer); };
  }, [config.mode, config.role, descriptor.baseUrl, user]);

  const errors = useMemo(() => validateLanConfig(config, descriptor), [config, descriptor]);
  const update = <K extends keyof LanCommunicationConfig>(key: K, value: LanCommunicationConfig[K]) => setConfig(current => ({ ...current, [key]: value }));
  const updateDescriptor = <K extends keyof LanServerDescriptorData>(key: K, value: LanServerDescriptorData[K]) => setDescriptor(current => ({ ...current, [key]: value }));

  const persist = async (next = config) => {
    try {
      const serverMode = next.role === 'server';
      const manualClientIp = !serverMode && descriptor.ip ? descriptor.ip : '';
      const savedDescriptor = await LanServerDescriptor.save({
        ...descriptor,
        allowMultipleUserSessions: next.allowMultipleUserSessions,
        addressMode: serverMode ? 'automatic' : 'remote',
        ...(serverMode ? {} : {
          enabled: false,
          lastLanIp: manualClientIp,
          ipSource: manualClientIp ? 'manual' : 'unavailable',
          ipUpdatedAt: manualClientIp ? new Date().toISOString() : descriptor.ipUpdatedAt,
          networkAvailable: Boolean(manualClientIp),
        }),
      });
      setDescriptor(savedDescriptor);
      saveLanConfig(next);
      setConfig(next);
      if (user) void logActivity(user, 'LAN_CONFIGURATION_UPDATED', 'lan_configuration', user.id, JSON.stringify({ mode: next.mode, role: next.role, serverId: savedDescriptor.serverId, address: savedDescriptor.baseUrl }));
      toast({ title: 'Configuración LAN guardada', description: 'La comunicación utiliza exclusivamente el descriptor único del servidor.' });
    } catch (error) {
      toast({ title: 'No fue posible guardar', description: error instanceof Error ? error.message : 'Configuración LAN inválida.', variant: 'destructive' });
    }
  };

  const startServer = async () => {
    if (config.role !== 'server') { toast({ title: 'Rol inválido', description: 'Configure este equipo como Servidor principal.', variant: 'destructive' }); return; }
    if (errors.length) { toast({ title: 'Configuración inválida', description: errors[0], variant: 'destructive' }); return; }
    if (!window.joyaControlLan) { toast({ title: 'Disponible solo en Electron', description: 'El servidor local requiere la aplicación Desktop.', variant: 'destructive' }); return; }
    setBusy(true);
    try {
      await LanServerDescriptor.save({ ...descriptor, addressMode: 'automatic', allowMultipleUserSessions: config.allowMultipleUserSessions });
      const state = await window.joyaControlLan.startServer({ allowMultipleUserSessions: config.allowMultipleUserSessions });
      setServerState(state);
      const activeDescriptor = await LanServerDescriptor.refresh();
      setDescriptor(activeDescriptor);
      const next = { ...config, mode: 'lan' as const, serverStarted: true }; saveLanConfig(next); setConfig(next);
      if (user) await logActivity(user, 'LAN_SERVER_STARTED', 'lan_server', state.serverId || activeDescriptor.serverName, JSON.stringify({ serverId: activeDescriptor.serverId, address: activeDescriptor.baseUrl }));
      toast({
        title: 'Servidor LAN iniciado',
        description: activeDescriptor.networkAvailable && activeDescriptor.baseUrl
          ? `${activeDescriptor.serverName} está escuchando en ${activeDescriptor.baseUrl}.`
          : `${activeDescriptor.serverName} está iniciado. Sin conexión de red; la IPv4 LAN se detectará automáticamente.`,
      });
    } catch (error) { toast({ title: 'No fue posible iniciar', description: error instanceof Error ? error.message : 'Error desconocido', variant: 'destructive' }); } finally { setBusy(false); }
  };

  const stopServer = async () => {
    if (!window.joyaControlLan) return;
    setBusy(true);
    try {
      const state = await window.joyaControlLan.stopServer(); setServerState(state);
      const next = { ...config, serverStarted: false }; saveLanConfig(next); setConfig(next);
      if (user) await logActivity(user, 'LAN_SERVER_STOPPED', 'lan_server', serverState.serverId || descriptor.serverName, JSON.stringify({ serverId: descriptor.serverId, address: descriptor.baseUrl }));
      toast({ title: 'Servidor LAN detenido' });
    } finally { setBusy(false); }
  };

  const searchServers = async () => {
    setBusy(true);
    try {
      const savedDescriptor = await LanServerDescriptor.save(descriptor);
      setDescriptor(savedDescriptor);
      const found = await discoverLanServers(config);
      setDiscoveredServers(found);
      toast({ title: found.length ? 'Servidores encontrados' : 'Sin servidores', description: found.length ? `Se detectaron ${found.length} servidor(es) JoyaControl.` : 'No se encontraron servidores compatibles en la red local.' });
    } catch (error) {
      toast({ title: 'No fue posible buscar', description: error instanceof Error ? error.message : 'Error de descubrimiento.', variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const selectAndConnectServer = async (server: LanDiscoveredServer) => {
    const candidate = { ...config, mode: 'lan' as const, role: 'client' as const };
    setConfig(candidate);
    setBusy(true);
    try {
      const selectedDescriptor = await LanServerDescriptor.rememberServer(server);
      setDescriptor(selectedDescriptor);
      const validated = await validateAndRememberLanServer(candidate, APP_VERSION, 'LAN-1');
      const identity = await window.joyaControlLan?.getSystemIdentity?.() ?? { hostname: candidate.deviceName, ip: '' };
      const registration = await reconnectOrRegisterLanClient(validated.config, identity, APP_VERSION);
      const next = { ...validated.config, clientId: registration.clientId, sessionToken: registration.sessionToken, lastConnection: new Date().toISOString() };
      saveLanConfig(next);
      setConfig(next);
      setDiagnostics(validated.diagnostics);
      toast({ title: 'Servidor conectado', description: `${server.serverName} (${server.ip}) quedó guardado como servidor preferido.` });
    } catch (error) {
      toast({ title: 'Servidor incompatible', description: error instanceof Error ? error.message : 'No fue posible conectar.', variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const testConnection = async (markConnected = false) => {
    if (errors.length) {
      toast({ title: 'Configuración inválida', description: errors[0], variant: 'destructive' });
      return;
    }
    setBusy(true);
    try {
      const savedDescriptor = await LanServerDescriptor.save(descriptor);
      setDescriptor(savedDescriptor);
      let validatedConfig = config;
      let result: LanDiagnostics;
      if (config.role === 'server') {
        // A Principal Server diagnoses its own local HTTP service. It never follows
        // a separately persisted client address or attempts client registration.
        result = await probeLanServer({ ...config, role: 'server' });
        const state = await window.joyaControlLan?.getServerStatus?.();
        if (state) setServerState(state);
        if (result.ok) {
          try {
            const [nextClients, nextUsers] = await Promise.all([fetchLanClients({ ...config, role: 'server' }), fetchLanUsers({ ...config, role: 'server' })]);
            setClients(nextClients);
            setConnectedUsers(nextUsers);
          } catch { /* health remains the source of truth for local diagnosis */ }
        }
      } else {
        try {
          const validated = await validateAndRememberLanServer(config, APP_VERSION, 'LAN-1');
          validatedConfig = validated.config;
          result = validated.diagnostics;
        } catch (error) {
          result = await probeLanServer(config);
          result = { ...result, ok: false, error: error instanceof Error ? error.message : 'LAN_INCOMPATIBLE_SERVER' };
        }
      }
      setDiagnostics(result);
      if (result.ok) {
        let next = { ...validatedConfig, mode: 'lan' as const, lastConnection: new Date().toISOString() };
        if (markConnected && config.role === 'client') {
          try {
            const identity = await window.joyaControlLan?.getSystemIdentity?.() ?? { hostname: config.deviceName, ip: '' };
            const registration = await reconnectOrRegisterLanClient(next, identity, APP_VERSION);
            next = { ...next, clientId: registration.clientId, sessionToken: registration.sessionToken };
          } catch (error) {
            toast({ title: 'Registro rechazado', description: error instanceof Error ? error.message : 'No fue posible registrar el cliente.', variant: 'destructive' });
            return;
          }
        }
        saveLanConfig(next);
        setConfig(next);
        const activeDescriptor = LanServerDescriptor.toJSON();
        toast({ title: config.role === 'server' ? 'Servidor LAN local activo' : 'Servidor disponible', description: config.role === 'server' ? `${activeDescriptor.baseUrl} · ${result.serverName || activeDescriptor.serverName} · ${result.serverId || activeDescriptor.serverId || 'ServerId disponible'}.` : `Respuesta recibida desde ${activeDescriptor.baseUrl}/health.` });
      } else {
        toast({ title: config.role === 'server' ? 'Servidor LAN local detenido' : 'Sin conexión', description: config.role === 'server' ? `No hay un servicio LAN respondiendo en ${savedDescriptor.baseUrl || 'la dirección detectada'}. Inicie el servidor desde esta configuración.` : 'No existe todavía un servicio LAN respondiendo en el descriptor configurado.', variant: 'destructive' });
      }
    } catch (error) {
      toast({ title: 'No fue posible probar la conexión', description: error instanceof Error ? error.message : 'Error de comunicación LAN.', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const disconnectClient = async () => {
    try {
      await disconnectLanClient(config);
      const next = { ...config, mode: 'local' as const, clientId: null, sessionToken: null };
      saveLanConfig(next);
      setConfig(next);
      toast({ title: 'Cliente desconectado' });
    } catch (error) {
      toast({ title: 'No fue posible desconectar', description: error instanceof Error ? error.message : 'Error desconocido', variant: 'destructive' });
    }
  };

  const downloadDiagnostic = () => {
    const blob = new Blob([serializeLanDiagnostic(config, diagnostics, APP_VERSION)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `joyacontrol-diagnostico-lan-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const copyConfiguration = async () => {
    await navigator.clipboard.writeText(JSON.stringify({ descriptor, config: { ...config, sharedKey: '[PROTEGIDA]', sessionToken: config.sessionToken ? '[PROTEGIDO]' : null, authToken: config.authToken ? '[PROTEGIDO]' : null } }, null, 2));
    toast({ title: 'Configuración copiada', description: 'La clave compartida fue ocultada por seguridad.' });
  };

  const reset = async () => {
    const nextDescriptor = await LanServerDescriptor.reset();
    setDescriptor(nextDescriptor);
    const next = resetLanConfig();
    setConfig(next);
    setDiagnostics(null);
    toast({ title: 'Configuración restablecida', description: 'El equipo volvió al modo Local.' });
  };

  const refreshRegisteredDevices = async () => {
    const [nextClients, nextUsers] = await Promise.all([fetchLanClients(config), fetchLanUsers(config)]);
    setClients(nextClients);
    setConnectedUsers(nextUsers);
  };

  const confirmDeviceMaintenance = (intent: DeviceMaintenanceIntent) => {
    if (!user || user.role !== 'master' || !hasSessionPermission(user, 'manage_settings')) {
      toast({ title: 'Acceso restringido', description: 'El mantenimiento de equipos requiere un usuario Maestro.', variant: 'destructive' });
      return;
    }
    setMaintenanceIntent(intent);
  };

  const executeDeviceMaintenance = async () => {
    if (!maintenanceIntent || !user) return;
    setMaintenanceBusy(true);
    try {
      const result = await maintainLanDevices(config, {
        action: maintenanceIntent.action,
        clientId: maintenanceIntent.clientId,
        days: maintenanceIntent.days,
        actor: {
          userId: user.id,
          username: user.username,
          displayName: user.displayName,
          role: user.role,
        },
      });
      await refreshRegisteredDevices();
      window.dispatchEvent(new CustomEvent('joyacontrol-lan-infrastructure-event', {
        detail: { type: 'LAN_DEVICE_REGISTRY_MAINTENANCE', removedCount: result.removedCount },
      }));
      toast({
        title: result.removedCount ? 'Mantenimiento completado' : 'Sin registros para eliminar',
        description: result.removedCount
          ? `Se eliminaron ${result.removedCount} equipo${result.removedCount === 1 ? '' : 's'} registrado${result.removedCount === 1 ? '' : 's'}.`
          : 'No se encontraron equipos que cumplieran los criterios seleccionados.',
      });
      setMaintenanceIntent(null);
      setMaintenanceOpen(false);
    } catch (error) {
      const code = error instanceof Error ? error.message : 'LAN_DEVICE_MAINTENANCE_FAILED';
      toast({
        title: code === 'LAN_CONNECTED_DEVICE_CANNOT_BE_REMOVED' ? 'Equipo conectado' : 'No fue posible realizar el mantenimiento',
        description: code === 'LAN_CONNECTED_DEVICE_CANNOT_BE_REMOVED'
          ? 'No es posible eliminar un equipo conectado.'
          : code,
        variant: 'destructive',
      });
    } finally {
      setMaintenanceBusy(false);
    }
  };

  const connectionState = config.mode !== 'lan'
    ? 'disconnected'
    : config.role === 'server'
      ? (serverState.running ? 'connected' : 'disconnected')
      : clientConnectionState;
  const statusLabel = connectionState === 'connected' ? '🟢 Conectado' : connectionState === 'connecting' ? '🟡 Buscando' : '🔴 Desconectado';
  const currentServerIp = descriptor.networkAvailable && descriptor.ip ? descriptor.ip : 'Sin conexión de red';
  const serverIpOrigin = descriptor.networkAvailable && descriptor.ipSource === 'automatic'
    ? 'Detectada automáticamente'
    : descriptor.ipSource === 'persisted'
      ? 'Última IP LAN válida'
      : 'Sin conexión de red';
  const connectedClients = useMemo(
    () => clients.filter(client => client.status === 'connected'),
    [clients],
  );
  const disconnectedMaintenanceClients = useMemo(
    () => clients.filter(client => client.status === 'disconnected' || client.status === 'expired'),
    [clients],
  );
  const oldMaintenanceClients = useMemo(() => {
    const threshold = Date.now() - maintenanceDays * 24 * 60 * 60 * 1000;
    return clients.filter(client => client.status !== 'connected' && lastDeviceActivityMs(client) <= threshold);
  }, [clients, maintenanceDays]);
  const canMaintainDevices = Boolean(
    user?.role === 'master'
    && hasSessionPermission(user, 'manage_settings')
    && config.mode === 'lan'
    && config.role === 'server'
    && serverState.running,
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><Network className="h-5 w-5 text-primary" />Comunicación LAN</CardTitle>
        <CardDescription>La identidad y la dirección del Servidor Principal se resuelven exclusivamente mediante LanServerDescriptor. Discovery, heartbeat, reconexión y Repository comparten la misma fuente.</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="status" className="space-y-5">
          <TabsList className="flex h-auto flex-wrap justify-start">
            <TabsTrigger value="status">Estado</TabsTrigger><TabsTrigger value="server">Servidor</TabsTrigger><TabsTrigger value="client">Cliente</TabsTrigger><TabsTrigger value="diagnostic">Diagnóstico</TabsTrigger><TabsTrigger value="security">Seguridad</TabsTrigger><TabsTrigger value="devices">Equipos</TabsTrigger><TabsTrigger value="users">Usuarios conectados</TabsTrigger><TabsTrigger value="advanced">Avanzada</TabsTrigger><TabsTrigger value="tools">Herramientas</TabsTrigger>
          </TabsList>

          <TabsContent value="status" className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
              <Info label="Modo actual" value={config.mode === 'local' ? 'Local' : 'LAN'} />
              <Info label="Estado" value={statusLabel} />
              <Info label="Equipo actual" value={config.deviceName} />
              <Info label="Machine ID" value={config.machineId} />
              <Info label="Versión" value={APP_VERSION} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Modo de operación"><Select value={config.mode} onValueChange={value => update('mode', value as LanCommunicationConfig['mode'])}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="local">Local</SelectItem><SelectItem value="lan">LAN</SelectItem></SelectContent></Select></Field>
              <Field label="Tipo de equipo"><Select value={config.role} onValueChange={value => update('role', value as LanCommunicationConfig['role'])}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="server">Servidor principal</SelectItem><SelectItem value="client">Cliente LAN</SelectItem></SelectContent></Select></Field>
            </div>
            {errors.length > 0 && <div className="rounded-lg border border-destructive/30 bg-destructive/10 p-3 text-sm text-destructive">{errors.join(' ')}</div>}
            <Button onClick={() => void persist()} disabled={errors.length > 0}>Guardar configuración LAN</Button>
          </TabsContent>

          <TabsContent value="server" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Nombre del servidor"><Input value={descriptor.serverName} onChange={event => updateDescriptor('serverName', event.target.value)} /></Field>
              <Info label="Servidor Principal" value={descriptor.serverName} />
              <Info label="IP actual" value={currentServerIp} />
              <Info label="Origen" value={serverIpOrigin} />
              <Info label="Última actualización" value={formatDate(descriptor.ipUpdatedAt ?? null)} />
              <Info label="Última IPv4 LAN válida" value={descriptor.lastLanIp || 'No disponible'} />
              <Field label="Puerto"><Input type="number" value={descriptor.port} onChange={event => updateDescriptor('port', Number(event.target.value))} /></Field>
              <Info label="Estado del servicio" value={serverState.running ? 'En ejecución' : 'Detenido'} />
              <Info label="Descriptor activo" value={descriptor.networkAvailable && descriptor.baseUrl ? descriptor.baseUrl : 'Sin conexión de red'} />
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => void startServer()} disabled={busy || serverState.running}><Play className="mr-2 h-4 w-4" />Iniciar servidor</Button>
              <Button variant="outline" onClick={() => void stopServer()} disabled={busy || !serverState.running}><Square className="mr-2 h-4 w-4" />Detener servidor</Button>
              <Button onClick={() => void testConnection()} disabled={busy}><TestTube2 className="mr-2 h-4 w-4" />Probar servidor</Button>
            </div>
          </TabsContent>

          <TabsContent value="client" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="IP del servidor"><Input value={descriptor.ip} onChange={event => updateDescriptor('ip', event.target.value)} /></Field>
              <Field label="Puerto"><Input type="number" value={descriptor.port} onChange={event => updateDescriptor('port', Number(event.target.value))} /></Field>
              <Field label="Nombre del equipo"><Input value={config.deviceName} onChange={event => update('deviceName', event.target.value)} /></Field>
              <Field label="Machine ID"><Input value={config.machineId} readOnly /></Field>
              <Field label="Reconexión automática"><Select value={config.autoReconnect ? 'yes' : 'no'} onValueChange={value => update('autoReconnect', value === 'yes')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="yes">Activada</SelectItem><SelectItem value="no">Desactivada</SelectItem></SelectContent></Select></Field>
              <Field label="Heartbeat (10–15 segundos)"><Input type="number" min={10} max={15} value={config.heartbeatIntervalSeconds} onChange={event => update('heartbeatIntervalSeconds', Number(event.target.value))} /></Field>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button variant="outline" onClick={() => void searchServers()} disabled={busy}><Search className="mr-2 h-4 w-4" />Buscar servidor</Button>
              <Button onClick={() => void testConnection(true)} disabled={busy}><Wifi className="mr-2 h-4 w-4" />Conectar</Button>
              <Button variant="outline" onClick={() => void disconnectClient()}><WifiOff className="mr-2 h-4 w-4" />Desconectar</Button>
              <Button variant="outline" onClick={() => void testConnection()} disabled={busy}><TestTube2 className="mr-2 h-4 w-4" />Probar conexión</Button>
            </div>
            {discoveredServers.length > 0 && <div className="space-y-2 rounded-lg border p-3"><p className="text-sm font-medium">Servidores JoyaControl encontrados</p>{discoveredServers.map(server => { const companyMismatch = Boolean(descriptor.companyId && server.companyId !== descriptor.companyId); return <div key={server.serverId} className="flex flex-col gap-2 rounded-md border p-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-medium">{server.serverName}</p><p className="text-xs text-muted-foreground">{server.ip}:{server.port} · v{server.version} · {server.protocolVersion} · {server.latencyMs} ms</p><p className="text-xs text-muted-foreground">Empresa: {server.company} · ID: {server.companyId}</p>{companyMismatch && <p className="text-xs text-destructive">Servidor de otra empresa.</p>}</div><Button size="sm" disabled={companyMismatch || busy} onClick={() => void selectAndConnectServer(server)}>Seleccionar y conectar</Button></div>; })}</div>}
          </TabsContent>

          <TabsContent value="diagnostic" className="space-y-4">
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              <Info label="Ping" value={diagnostics?.ping ?? 'No ejecutado'} />
              <Info label="Latencia" value={diagnostics?.latencyMs == null ? 'No disponible' : `${diagnostics.latencyMs} ms`} />
              <Info label="Estado del servidor" value={diagnostics?.serverStatus ?? 'No disponible'} />
              <Info label="Versión servidor" value={diagnostics?.version ?? 'No disponible'} />
              <Info label="Hora del servidor" value={formatDate(diagnostics?.serverTime ?? null)} />
              <Info label="Hora local" value={formatDate(diagnostics?.localTime ?? new Date().toISOString())} />
              <Info label="Diferencia de reloj" value={diagnostics?.clockDifferenceMs == null ? 'No disponible' : `${diagnostics.clockDifferenceMs} ms`} />
              <Info label="Última conexión" value={formatDate(config.lastConnection)} />
              <Info label="Server ID" value={diagnostics?.serverId ?? serverState.serverId ?? descriptor.serverId ?? 'No disponible'} />
              <Info label="Empresa confiable" value={descriptor.companyId || 'Se establecerá en la primera conexión'} />
              <Info label="Machine ID local" value={config.machineId} />
              <Info label="Equipos registrados" value={String(clients.length)} />
              <Info label="Equipos conectados" value={String(diagnostics?.activeClients ?? serverState.activeClients ?? connectedClients.length)} />
              <Info label="Clientes inactivos" value={String(diagnostics?.inactiveClients ?? serverState.inactiveClients ?? clients.filter(client => client.status === 'inactive').length)} />
              <Info label="Tiempo activo" value={diagnostics?.uptimeSeconds == null ? 'No disponible' : `${diagnostics.uptimeSeconds} s`} />
              <Info label="Memoria utilizada" value={diagnostics?.memoryUsedBytes == null ? 'No disponible' : `${(diagnostics.memoryUsedBytes / 1024 / 1024).toFixed(1)} MB`} />
              <Info label="Tiempo promedio de respuesta" value={`${diagnostics?.averageResponseTimeMs ?? serverState.averageResponseTimeMs ?? 0} ms`} />
              <Info label="Heartbeats recibidos" value={String(diagnostics?.heartbeatsReceived ?? serverState.heartbeatsReceived ?? 0)} />
              <Info label="Solicitudes atendidas" value={String(diagnostics?.requestsHandled ?? serverState.requestsHandled ?? 0)} />
              <Info label="Protocolo LAN" value={diagnostics?.protocolVersion ?? serverState.protocolVersion ?? descriptor.protocolVersion} />
              <Info label="Último heartbeat enviado" value={formatDate(runtimeDiagnostics.lastHeartbeatSent)} />
              <Info label="Último heartbeat recibido" value={formatDate(runtimeDiagnostics.lastHeartbeatReceived)} />
              <Info label="Estado del temporizador" value={runtimeDiagnostics.timerState} />
              <Info label="Intentos de reconexión" value={String(runtimeDiagnostics.reconnectAttempts)} />
              <Info label="Tiempo desde último ping" value={runtimeDiagnostics.lastPingAgeMs == null ? 'No disponible' : `${Math.round(runtimeDiagnostics.lastPingAgeMs / 1000)} s`} />
              <Info label="Auto-reconexión" value={runtimeDiagnostics.autoReconnect ? 'Activa' : 'Inactiva'} />
              <Info label="Última desconexión" value={runtimeDiagnostics.lastDisconnectReason ?? 'Ninguna'} />
              <Info label="Última reconexión" value={formatDate(runtimeDiagnostics.lastReconnect)} />
              <Info label="Cantidad de reconexiones" value={String(runtimeDiagnostics.reconnectCount)} />
              <Info label="Estado del watcher" value={runtimeDiagnostics.watcherState} />
              <Info label="Último cambio de IP" value={formatDate(runtimeDiagnostics.lastIpChange)} />
              <Info label="Tiempo sin servidor" value={`${Math.round(runtimeDiagnostics.timeWithoutServerMs / 1000)} s`} />
              <Info label="Usuarios conectados" value={String(connectedUsers.filter(item => item.status === 'connected').length)} />
              <Info label="Sesiones activas" value={String(connectedUsers.filter(item => item.status === 'connected').length)} />
              <Info label="Tiempo promedio de sesión" value={connectedUsers.length ? `${Math.round(connectedUsers.reduce((sum, item) => sum + (Date.now() - new Date(item.loginAt).getTime()) / 1000, 0) / connectedUsers.length)} s` : '0 s'} />
              <Info label="Última sincronización" value="No disponible" />
            </div>
            <Button onClick={() => void testConnection()} disabled={busy}><Activity className="mr-2 h-4 w-4" />Ejecutar diagnóstico</Button>
          </TabsContent>

          <TabsContent value="security" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Clave compartida"><Input type="password" value={config.sharedKey} onChange={event => update('sharedKey', event.target.value)} /></Field>
              <Field label="Permitir múltiples sesiones del mismo usuario"><Select value={config.allowMultipleUserSessions ? 'yes' : 'no'} onValueChange={value => update('allowMultipleUserSessions', value === 'yes')}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="yes">Sí</SelectItem><SelectItem value="no">No</SelectItem></SelectContent></Select></Field>
              <Info label="Estado de autenticación" value="Autenticación LAN disponible" />
              <Info label="Cifrado" value="Preparado para futuras versiones" />
              <Field label="Token de sesión"><Input value={connectionState === 'connected' ? 'Token temporal administrado por el futuro servidor' : 'No disponible'} readOnly /></Field>
            </div>
            <p className="text-xs text-muted-foreground flex gap-2"><ShieldCheck className="h-4 w-4" />La clave se almacena solo en este equipo. No se implementa autenticación distribuida en esta fase.</p>
          </TabsContent>

          <TabsContent value="devices" className="space-y-5">
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div className="grid flex-1 gap-3 sm:grid-cols-2">
                <Info label="Equipos registrados" value={String(clients.length)} />
                <Info label="Equipos conectados" value={String(connectedClients.length)} />
              </div>
              {canMaintainDevices && (
                <Button variant="outline" onClick={() => setMaintenanceOpen(true)}>
                  <Wrench className="mr-2 h-4 w-4" />Mantenimiento
                </Button>
              )}
            </div>
            <DeviceTable title="Equipos conectados" clients={connectedClients} emptyMessage="No existen equipos conectados en este momento." />
            <DeviceTable
              title="Equipos registrados"
              clients={clients}
              emptyMessage="No existen equipos registrados."
              canMaintain={canMaintainDevices}
              onRemove={client => confirmDeviceMaintenance({
                action: 'remove-client',
                clientId: client.clientId,
                count: 1,
                title: `Eliminar ${client.name}`,
                description: client.status === 'connected'
                  ? 'No es posible eliminar un equipo conectado.'
                  : `Se eliminará el registro del equipo ${client.name} (${client.machineId}).`,
              })}
            />
          </TabsContent>


          <TabsContent value="users" className="space-y-4">
            <div className="overflow-x-auto rounded-lg border"><table className="w-full min-w-[900px] text-sm"><thead className="bg-secondary/50"><tr><th className="p-3 text-left">Usuario</th><th className="p-3 text-left">Rol</th><th className="p-3 text-left">Equipo</th><th className="p-3 text-left">IP</th><th className="p-3 text-left">Inicio de sesión</th><th className="p-3 text-left">Última actividad</th><th className="p-3 text-left">Estado</th></tr></thead><tbody>{connectedUsers.length === 0 ? <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No existen usuarios LAN autenticados.</td></tr> : connectedUsers.map(item => <tr key={`${item.userId}-${item.clientId}`} className="border-t"><td className="p-3">{item.username}</td><td className="p-3">{item.role}</td><td className="p-3">{item.deviceName}</td><td className="p-3">{item.ip}</td><td className="p-3">{formatDate(item.loginAt)}</td><td className="p-3">{formatDate(item.lastActivity)}</td><td className="p-3">{item.status}</td></tr>)}</tbody></table></div>
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              <Field label="Puerto TCP"><Input type="number" value={descriptor.port} onChange={event => updateDescriptor('port', Number(event.target.value))} /></Field>
              <Field label="Tiempo de espera (ms)"><Input type="number" value={config.timeoutMs} onChange={event => update('timeoutMs', Number(event.target.value))} /></Field>
              <Field label="Reintentos automáticos"><Input type="number" value={config.automaticRetries} onChange={event => update('automaticRetries', Number(event.target.value))} /></Field>
              <Field label="Heartbeat (segundos)"><Input type="number" min={10} max={15} value={config.heartbeatIntervalSeconds} onChange={event => update('heartbeatIntervalSeconds', Number(event.target.value))} /></Field>
              <Field label="Intervalo de sincronización legado"><Input type="number" value={config.syncIntervalSeconds} disabled /></Field>
              <Field label="Nivel de registro"><Select value={config.logLevel} onValueChange={value => update('logLevel', value as LanCommunicationConfig['logLevel'])}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="debug">Debug</SelectItem><SelectItem value="info">Información</SelectItem><SelectItem value="error">Error</SelectItem></SelectContent></Select></Field>
            </div>
          </TabsContent>

          <TabsContent value="tools" className="space-y-3">
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => void testConnection()} disabled={busy}><TestTube2 className="mr-2 h-4 w-4" />Probar comunicación</Button>
              <Button variant="outline" onClick={downloadDiagnostic}><Download className="mr-2 h-4 w-4" />Exportar diagnóstico</Button>
              <Button variant="outline" onClick={() => void copyConfiguration()}><Clipboard className="mr-2 h-4 w-4" />Copiar configuración</Button>
              <Button variant="destructive" onClick={() => void reset()}><RotateCcw className="mr-2 h-4 w-4" />Restablecer configuración LAN</Button>
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-2"><KeyRound className="h-4 w-4" />Las herramientas no modifican datos comerciales, DexieRepository ni RepositoryRegistry.</p>
          </TabsContent>
        </Tabs>

        <Dialog open={maintenanceOpen} onOpenChange={setMaintenanceOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Mantenimiento de equipos LAN</DialogTitle>
              <DialogDescription>
                Limpia únicamente registros administrativos. No elimina usuarios, permisos, configuración LAN ni información comercial.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4">
              <div className="rounded-lg border p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <p className="font-medium">Eliminar equipos desconectados</p>
                    <p className="text-sm text-muted-foreground">
                      Se eliminarán únicamente equipos desconectados o expirados. No afecta clientes conectados ni inactivos.
                    </p>
                  </div>
                  <Button
                    variant="destructive"
                    disabled={disconnectedMaintenanceClients.length === 0 || maintenanceBusy}
                    onClick={() => confirmDeviceMaintenance({
                      action: 'remove-disconnected',
                      count: disconnectedMaintenanceClients.length,
                      title: 'Eliminar todos los equipos desconectados',
                      description: 'Se eliminarán únicamente equipos desconectados. No afecta clientes actualmente conectados.',
                    })}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Eliminar todos ({disconnectedMaintenanceClients.length})
                  </Button>
                </div>
              </div>

              <div className="rounded-lg border p-4">
                <div className="flex flex-col gap-3 lg:flex-row lg:items-end lg:justify-between">
                  <div className="space-y-2">
                    <div>
                      <p className="font-medium">Eliminar equipos inactivos antiguos</p>
                      <p className="text-sm text-muted-foreground">Compara la última actividad y el último heartbeat. Nunca elimina equipos conectados.</p>
                    </div>
                    <Select value={String(maintenanceDays)} onValueChange={value => setMaintenanceDays(Number(value) as 30 | 60 | 90 | 180)}>
                      <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="30">30 días</SelectItem>
                        <SelectItem value="60">60 días</SelectItem>
                        <SelectItem value="90">90 días</SelectItem>
                        <SelectItem value="180">180 días</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    variant="destructive"
                    disabled={oldMaintenanceClients.length === 0 || maintenanceBusy}
                    onClick={() => confirmDeviceMaintenance({
                      action: 'remove-older-than',
                      days: maintenanceDays,
                      count: oldMaintenanceClients.length,
                      title: `Eliminar equipos sin actividad por más de ${maintenanceDays} días`,
                      description: `Se eliminarán registros no conectados cuya última actividad o heartbeat supere ${maintenanceDays} días.`,
                    })}
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Eliminar ({oldMaintenanceClients.length})
                  </Button>
                </div>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setMaintenanceOpen(false)} disabled={maintenanceBusy}>Cerrar</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <AlertDialog open={Boolean(maintenanceIntent)} onOpenChange={open => { if (!open && !maintenanceBusy) setMaintenanceIntent(null); }}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5 text-destructive" />{maintenanceIntent?.title}</AlertDialogTitle>
              <AlertDialogDescription className="space-y-3">
                <span className="block">{maintenanceIntent?.description}</span>
                <span className="block font-medium text-foreground">
                  Se eliminarán {maintenanceIntent?.count ?? 0} equipo{maintenanceIntent?.count === 1 ? '' : 's'} registrado{maintenanceIntent?.count === 1 ? '' : 's'}.
                </span>
                <span className="block">Esta acción no puede deshacerse. ¿Desea continuar?</span>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel disabled={maintenanceBusy}>Cancelar</AlertDialogCancel>
              <AlertDialogAction
                disabled={maintenanceBusy}
                className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={event => { event.preventDefault(); void executeDeviceMaintenance(); }}
              >
                {maintenanceBusy ? 'Eliminando…' : 'Confirmar eliminación'}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
};

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => <div className="space-y-1.5"><Label>{label}</Label>{children}</div>;
const ClientStatus = ({ status }: { status: LanConnectedDevice['status'] }) => {
  const values = {
    connected: { label: 'Conectado', dot: 'bg-green-500' },
    inactive: { label: 'Inactivo', dot: 'bg-yellow-500' },
    disconnected: { label: 'Desconectado', dot: 'bg-red-500' },
    expired: { label: 'Expirado', dot: 'bg-gray-400' },
  } as const;
  const value = values[status];
  return <span className="inline-flex items-center gap-2"><span aria-hidden="true" className={`h-2.5 w-2.5 rounded-full ${value.dot}`} /><span>{value.label}</span></span>;
};
const DeviceTable = ({
  title,
  clients,
  emptyMessage,
  canMaintain = false,
  onRemove,
}: {
  title: string;
  clients: LanConnectedDevice[];
  emptyMessage: string;
  canMaintain?: boolean;
  onRemove?: (client: LanConnectedDevice) => void;
}) => (
  <section className="space-y-2">
    <h3 className="text-sm font-semibold">{title}</h3>
    <div className="overflow-x-auto rounded-lg border">
      <table className="w-full min-w-[1560px] text-sm">
        <thead className="bg-secondary/50">
          <tr>
            <th className="p-3 text-left">Machine ID</th>
            <th className="p-3 text-left">Nombre</th>
            <th className="p-3 text-left">IP</th>
            <th className="p-3 text-left">Hostname / SO</th>
            <th className="p-3 text-left">Hora conexión</th>
            <th className="p-3 text-left">Última actividad</th>
            <th className="p-3 text-left">Último heartbeat</th>
            <th className="p-3 text-left">Latencia</th>
            <th className="p-3 text-left">Estado</th>
            <th className="p-3 text-left">Versión</th>
            {canMaintain && <th className="p-3 text-center">Acciones</th>}
          </tr>
        </thead>
        <tbody>
          {clients.length === 0 ? (
            <tr><td colSpan={canMaintain ? 11 : 10} className="p-8 text-center text-muted-foreground">{emptyMessage}</td></tr>
          ) : clients.map(client => (
            <tr key={client.clientId} className="border-t">
              <td className="p-3 font-mono text-xs">{client.machineId}</td>
              <td className="p-3">{client.name}</td>
              <td className="p-3">{client.ip}</td>
              <td className="p-3"><div>{client.hostname}</div><div className="text-xs text-muted-foreground">{client.operatingSystem}</div></td>
              <td className="p-3">{formatDate(client.connectedAt)}</td>
              <td className="p-3">{formatDate(client.lastActivity)}</td>
              <td className="p-3">{formatDate(client.lastHeartbeat)}</td>
              <td className="p-3">{client.currentLatencyMs == null ? 'No disponible' : `${client.currentLatencyMs} ms`}<div className="text-xs text-muted-foreground">Promedio: {client.averageLatencyMs == null ? 'N/D' : `${client.averageLatencyMs} ms`}</div></td>
              <td className="p-3"><ClientStatus status={client.status} /></td>
              <td className="p-3">{client.version}</td>
              {canMaintain && (
                <td className="p-3 text-center">
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    disabled={client.status === 'connected'}
                    title={client.status === 'connected' ? 'No es posible eliminar un equipo conectado.' : `Eliminar ${client.name}`}
                    aria-label={client.status === 'connected' ? `No es posible eliminar el equipo conectado ${client.name}` : `Eliminar equipo ${client.name}`}
                    onClick={() => onRemove?.(client)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </section>
);
const Info = ({ label, value }: { label: string; value: string }) => <div className="rounded-lg border bg-secondary/20 p-3"><p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p><p className="mt-1 font-medium break-words">{value}</p></div>;

export default LanCommunicationPanel;
