import { useEffect, useMemo, useRef } from 'react';
import { useApp } from '@/contexts/AppContext';
import { loadLanConfig } from '@/lib/LanCommunicationConfig';

const productFingerprint = (products: ReturnType<typeof useApp>['products']): string => JSON.stringify(
  [...products]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(product => ({
      id: product.id,
      code: product.code,
      name: product.name,
      category: product.category,
      purchasePrice: product.purchasePrice,
      salePrice: product.salePrice,
      weightGrams: product.weightGrams,
      margin: product.margin,
      stock: product.stock,
      minStock: product.minStock,
      description: product.description || '',
      reference: product.reference || '',
      availableGrams: product.availableGrams ?? null,
      averagePurchasePrice: product.averagePurchasePrice ?? null,
      lastPurchaseDate: product.lastPurchaseDate || '',
      supplierIds: [...(product.supplierIds || [])].sort(),
    })),
);

const categoryFingerprint = (categories: string[]): string => JSON.stringify(
  [...categories].sort((a, b) => a.localeCompare(b, 'es')),
);

const dashboardFingerprint = (data: Pick<ReturnType<typeof useApp>,
  | 'contacts'
  | 'invoices'
  | 'purchaseInvoices'
  | 'expenses'
  | 'layaways'
  | 'cashSessions'
  | 'financialAccounts'
  | 'financialMovements'
  | 'financialSummary'
>): string => JSON.stringify({
  contacts: [...(data.contacts || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(contact => ({ id: contact.id, type: contact.type, name: contact.name, document: contact.document })),
  invoices: [...(data.invoices || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(invoice => ({
      id: invoice.id,
      number: invoice.number,
      clientId: invoice.clientId,
      clientName: invoice.clientName,
      date: invoice.date,
      status: invoice.status,
      total: invoice.total,
      items: invoice.items.map(item => ({
        productId: item.productId,
        name: item.name,
        quantity: item.quantity,
        subtotal: item.subtotal,
        costPrice: item.costPrice ?? null,
      })),
    })),
  purchases: [...(data.purchaseInvoices || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(purchase => ({ id: purchase.id, date: purchase.date, status: purchase.status, total: purchase.total })),
  expenses: [...(data.expenses || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(expense => ({ id: expense.id, date: expense.date, status: expense.status, total: expense.total })),
  layaways: [...(data.layaways || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(layaway => ({
      id: layaway.id,
      completed: layaway.completed,
      invoiceId: layaway.invoiceId,
      invoiceStatus: layaway.invoice.status,
      clientId: layaway.invoice.clientId,
      total: layaway.invoice.total,
      payments: layaway.payments.map(payment => ({ id: payment.id, amount: payment.amount, date: payment.date })),
    })),
  cashSessions: [...(data.cashSessions || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(session => ({ id: session.id, date: session.date, openedAt: session.openedAt, closedAt: session.closedAt || '', openedBy: session.openedBy })),
  accounts: [...(data.financialAccounts || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(account => ({ id: account.id, kind: account.kind, balance: account.balance, active: account.active })),
  movements: [...(data.financialMovements || [])]
    .sort((a, b) => a.id.localeCompare(b.id))
    .map(movement => ({
      id: movement.id,
      type: movement.type,
      amount: movement.amount,
      date: movement.date,
      documentType: movement.documentType,
      documentId: movement.documentId,
      originAccountId: movement.originAccountId,
      destinationAccountId: movement.destinationAccountId,
      observation: movement.observation,
    })),
  summary: data.financialSummary,
});

export default function LanRepositoryChangePublisher() {
  const {
    products,
    categories,
    contacts,
    invoices,
    purchaseInvoices,
    expenses,
    layaways,
    cashSessions,
    financialAccounts,
    financialMovements,
    financialSummary,
    isLoading,
  } = useApp();
  const initialized = useRef(false);
  const previousProducts = useRef('');
  const previousCategories = useRef('');
  const previousDashboard = useRef('');
  const productsSnapshot = useMemo(() => productFingerprint(products), [products]);
  const categoriesSnapshot = useMemo(() => categoryFingerprint(categories), [categories]);
  const dashboardSnapshot = useMemo(() => dashboardFingerprint({
    contacts,
    invoices,
    purchaseInvoices,
    expenses,
    layaways,
    cashSessions,
    financialAccounts,
    financialMovements,
    financialSummary,
  }), [
    contacts,
    invoices,
    purchaseInvoices,
    expenses,
    layaways,
    cashSessions,
    financialAccounts,
    financialMovements,
    financialSummary,
  ]);

  useEffect(() => {
    // The first completed database load establishes the baseline. It is not a
    // commercial mutation and must not generate a repository-change event.
    if (isLoading) return;

    if (!initialized.current) {
      initialized.current = true;
      previousProducts.current = productsSnapshot;
      previousCategories.current = categoriesSnapshot;
      previousDashboard.current = dashboardSnapshot;
      return;
    }

    const config = loadLanConfig();
    if (config.mode === 'lan' && config.role === 'server') {
      const productsOrDashboardChanged = productsSnapshot !== previousProducts.current
        || dashboardSnapshot !== previousDashboard.current;
      if (productsOrDashboardChanged) {
        // Reuse the established Repository event channel. LAN clients reload
        // products and then request one summarized Dashboard snapshot.
        void window.joyaControlLan?.notifyRepositoryChanged?.('PRODUCTS_UPDATED');
      }
      if (categoriesSnapshot !== previousCategories.current) {
        void window.joyaControlLan?.notifyRepositoryChanged?.('CATEGORIES_UPDATED');
      }
    }

    previousProducts.current = productsSnapshot;
    previousCategories.current = categoriesSnapshot;
    previousDashboard.current = dashboardSnapshot;
  }, [categoriesSnapshot, dashboardSnapshot, isLoading, productsSnapshot]);

  return null;
}
