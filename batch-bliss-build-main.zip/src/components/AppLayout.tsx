import { useState, type ReactNode } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard, ShoppingCart, Receipt, Users, Package, Settings,
  Diamond, ChevronLeft, ChevronRight, BarChart3, FileCheck, Wallet,
  CreditCard, DatabaseBackup, LogOut, UserCog, Activity, WalletCards,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuth } from '@/contexts/AuthContext';
import { hasRouteAccess, hasSessionPermission, type Permission } from '@/lib/auth';
import { useWorkMode } from '@/contexts/WorkModeContext';

interface LayoutProps { children: ReactNode; }

const ROLE_BADGE: Record<string, string> = {
  master: 'bg-yellow-500/20 text-yellow-600',
  admin: 'bg-blue-500/20 text-blue-600',
  vendedor: 'bg-green-500/20 text-green-600',
  cajero: 'bg-purple-500/20 text-purple-600',
};
const ROLE_LABEL: Record<string, string> = {
  master: '👑 Maestro', admin: '🛡️ Admin', vendedor: '🛍️ Vendedor', cajero: '💰 Cajero',
};

const allNavItems: Array<{ path: string; label: string; icon: typeof LayoutDashboard; requiredPermission?: Permission }> = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/ventas', label: 'Ventas', icon: Receipt },
  { path: '/compras', label: 'Compras', icon: ShoppingCart },
  { path: '/contactos', label: 'Contactos', icon: Users },
  { path: '/inventario', label: 'Inventario', icon: Package },
  { path: '/cotizaciones', label: 'Cotizaciones', icon: FileCheck },
  { path: '/cuentas-por-pagar', label: 'Ctas. por Pagar', icon: CreditCard },
  { path: '/caja', label: 'Caja', icon: Wallet },
  { path: '/reportes', label: 'Reportes', icon: BarChart3 },
  { path: '/finanzas', label: 'Finanzas del Propietario', icon: WalletCards, requiredPermission: 'manage_finances' },
  { path: '/usuarios', label: 'Usuarios', icon: UserCog },
  { path: '/actividad', label: 'Actividad', icon: Activity },
  { path: '/respaldos', label: 'Respaldos', icon: DatabaseBackup },
  { path: '/configuracion', label: 'Configuración', icon: Settings },
];

const AppLayout = ({ children }: LayoutProps) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const { effectiveMode } = useWorkMode();
  const [collapsed, setCollapsed] = useState(false);

  const role = user?.role ?? 'cajero';
  const navItems = allNavItems.filter(item => (
    hasRouteAccess(user, item.path)
    && (!item.requiredPermission || hasSessionPermission(user, item.requiredPermission))
  ));

  const handleLogout = async () => {
    const result = await window.joyaControlApp?.requestLogout?.({ mode: effectiveMode });
    if (result?.cancelled) return;
    if (!window.joyaControlApp?.requestLogout) await logout();
    navigate('/');
  };

  return (
    <div className="flex h-screen min-w-0 overflow-hidden">
      <aside className={cn(
        "flex flex-col border-r border-border bg-sidebar transition-all duration-300",
        collapsed ? "w-[68px]" : "w-[240px]"
      )}>
        {/* Logo */}
        <div className="flex h-16 items-center gap-3 border-b border-border px-4">
          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg gold-gradient">
            <Diamond className="h-5 w-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="min-w-0 animate-fade-in">
              <h1 className="text-lg font-bold gold-text leading-none">JoyaControl</h1>
              <p className="text-[10px] text-muted-foreground leading-none mt-0.5">Sistema de Joyería</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 space-y-1 p-3 overflow-y-auto">
          {navItems.map(item => {
            const isActive = location.pathname === item.path ||
              (item.path !== '/' && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all duration-200",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                )}
              >
                <item.icon className={cn("h-5 w-5 shrink-0", isActive && "text-primary")} />
                {!collapsed && <span className="min-w-0 break-words animate-fade-in">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* User info + logout */}
        {!collapsed && user && (
          <div className="border-t border-border p-3 space-y-2">
            <div className="flex items-center gap-2 px-2">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                {user.displayName.charAt(0).toUpperCase()}
              </div>
              <div className="min-w-0">
                <p className="break-words text-sm font-medium leading-tight">{user.displayName}</p>
                <span className={cn("text-[10px] px-1.5 py-0.5 rounded-full font-medium", ROLE_BADGE[role])}>
                  {ROLE_LABEL[role]}
                </span>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-2 px-3 py-2 text-sm text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors"
            >
              <LogOut className="h-4 w-4" />
              Cerrar sesión
            </button>
          </div>
        )}

        {/* Collapsed: just logout icon */}
        {collapsed && (
          <div className="border-t border-border p-3 flex flex-col items-center gap-2">
            <button onClick={handleLogout} className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors">
              <LogOut className="h-4 w-4" />
            </button>
          </div>
        )}

        {/* Collapse toggle */}
        <div className="border-t border-border p-3">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center p-2 text-muted-foreground hover:text-foreground transition-colors rounded-lg hover:bg-sidebar-accent"
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full min-w-0 max-w-[1600px] p-4 animate-fade-in sm:p-6 lg:p-8">{children}</div>
      </main>
    </div>
  );
};

export default AppLayout;
