import { useEffect, useState } from 'react';
import { useApp } from '@/contexts/AppContext';
import { loadLanConfig } from '@/lib/LanCommunicationConfig';
import { LanConnectionManager, type LanConnectionEventDetail } from '@/lib/LanConnectionManager';
import { getDataRepository } from '@/repositories/RepositoryRegistry';

export const LAN_CONNECTION_STATE_EVENT = 'joyacontrol-lan-connection-state';
export const LAN_CONFIG_CHANGED_EVENT = 'joyacontrol-lan-config-changed';
export const LAN_RUNTIME_DIAGNOSTICS_EVENT = 'joyacontrol-lan-runtime-diagnostics';

export interface LanRuntimeDiagnostics {
  lastHeartbeatSent: string | null;
  lastHeartbeatReceived: string | null;
  timerState: 'stopped' | 'running' | 'retrying';
  reconnectAttempts: number;
  lastPingAgeMs: number | null;
  autoReconnect: boolean;
  lastDisconnectReason: string | null;
  lastReconnect: string | null;
  reconnectCount: number;
  watcherState: 'stopped' | 'watching' | 'recovering';
  lastIpChange: string | null;
  timeWithoutServerMs: number;
}

type LanNotice = 'offline' | 'syncing' | null;
type SynchronizationTarget = { products: boolean; categories: boolean; reconnected: boolean };

interface InvalidatableLanRepository {
  invalidateProducts?: () => void;
  invalidateCategories?: () => void;
  invalidateCache?: () => void;
}

function publishConnectionState(detail: Pick<LanConnectionEventDetail, 'state' | 'reason'>): void {
  const state = detail.state === 'ONLINE'
    ? 'connected'
    : detail.state === 'OFFLINE'
      ? 'disconnected'
      : 'connecting';

  window.dispatchEvent(new CustomEvent(LAN_CONNECTION_STATE_EVENT, {
    detail: { state, error: detail.reason },
  }));
}

const isLanClient = (): boolean => {
  const config = loadLanConfig();
  return config.mode === 'lan' && config.role === 'client';
};

/**
 * Authenticated UI bridge. LanBootstrapProvider owns the LAN lifecycle; this
 * component owns Repository invalidation, React-state synchronization and the
 * non-destructive connection notice shown to LAN clients.
 */
export default function LanClientConnectionService() {
  const { refreshProducts, refreshCategories } = useApp();
  const [notice, setNotice] = useState<LanNotice>(null);

  useEffect(() => {
    let disposed = false;
    let synchronizing = false;
    let retryTimer: number | null = null;
    let hideTimer: number | null = null;
    let disconnected = false;
    let reconnectPending = false;
    let pending: SynchronizationTarget = { products: false, categories: false, reconnected: false };

    const clearRetryTimer = () => {
      if (retryTimer != null) window.clearTimeout(retryTimer);
      retryTimer = null;
    };

    const clearHideTimer = () => {
      if (hideTimer != null) window.clearTimeout(hideTimer);
      hideTimer = null;
    };

    const repository = (): InvalidatableLanRepository => getDataRepository() as unknown as InvalidatableLanRepository;

    const mergePending = (target: SynchronizationTarget) => {
      pending = {
        products: pending.products || target.products,
        categories: pending.categories || target.categories,
        reconnected: pending.reconnected || target.reconnected,
      };
    };

    const hasPendingSynchronization = () => pending.products || pending.categories;

    const scheduleRetry = (drain: () => Promise<void>) => {
      if (disposed || retryTimer != null) return;
      retryTimer = window.setTimeout(() => {
        retryTimer = null;
        void drain();
      }, 2000);
    };

    const drainSynchronization = async (): Promise<void> => {
      if (
        disposed ||
        synchronizing ||
        !hasPendingSynchronization() ||
        !isLanClient() ||
        LanConnectionManager.getConnectionState() !== 'ONLINE'
      ) return;

      synchronizing = true;
      clearRetryTimer();
      const current = pending;
      pending = { products: false, categories: false, reconnected: false };

      let failed = false;
      try {
        const activeRepository = repository();
        if (current.products) activeRepository.invalidateProducts?.();
        if (current.categories) activeRepository.invalidateCategories?.();

        await Promise.all([
          current.products ? refreshProducts() : Promise.resolve(),
          current.categories ? refreshCategories() : Promise.resolve(),
        ]);

        if (disposed) return;
        window.dispatchEvent(new CustomEvent('joyacontrol:lan-repository-synchronized', {
          detail: {
            products: current.products,
            categories: current.categories,
            reconnected: current.reconnected,
            at: new Date().toISOString(),
          },
        }));

        if (!hasPendingSynchronization()) {
          clearHideTimer();
          hideTimer = window.setTimeout(() => {
            if (!disposed && !disconnected && LanConnectionManager.getConnectionState() === 'ONLINE') setNotice(null);
          }, current.reconnected ? 1800 : 600);
        }
      } catch (error) {
        failed = true;
        // React keeps the last successful arrays because refreshProducts and
        // refreshCategories only commit state after a successful remote read.
        mergePending(current);
        clearHideTimer();
        setNotice('offline');
        scheduleRetry(drainSynchronization);
        console.error('[LAN] No fue posible sincronizar el Repository remoto.', error);
      } finally {
        synchronizing = false;
        if (!disposed && hasPendingSynchronization() && !failed) {
          if (LanConnectionManager.getConnectionState() === 'ONLINE') void drainSynchronization();
          else scheduleRetry(drainSynchronization);
        }
      }
    };

    const requestSynchronization = (target: SynchronizationTarget) => {
      mergePending(target);
      if (target.reconnected) {
        clearHideTimer();
        setNotice('syncing');
      }
      void drainSynchronization();
    };

    publishConnectionState({ state: LanConnectionManager.getConnectionState() });

    const unsubscribe = LanConnectionManager.subscribe(detail => {
      publishConnectionState(detail);
      if (!isLanClient()) return;

      switch (detail.type) {
        case 'PRODUCTS_UPDATED':
          requestSynchronization({ products: true, categories: false, reconnected: false });
          break;
        case 'CATEGORIES_UPDATED':
          requestSynchronization({ products: false, categories: true, reconnected: false });
          break;
        case 'CLIENT_RECONNECTED':
          reconnectPending = true;
          repository().invalidateCache?.();
          clearHideTimer();
          setNotice('syncing');
          break;
        case 'SERVER_OFFLINE':
          disconnected = true;
          clearHideTimer();
          setNotice('offline');
          break;
        case 'SERVER_RECONNECTING':
          if (disconnected) setNotice('offline');
          break;
        case 'SERVER_ONLINE':
          if (disconnected || reconnectPending) {
            disconnected = false;
            reconnectPending = false;
            requestSynchronization({ products: true, categories: true, reconnected: true });
          }
          break;
        default:
          break;
      }
    });

    return () => {
      disposed = true;
      clearRetryTimer();
      clearHideTimer();
      unsubscribe();
    };
  }, [refreshCategories, refreshProducts]);

  if (!isLanClient() || notice === null) return null;

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed left-1/2 top-4 z-[100] w-[min(92vw,520px)] -translate-x-1/2 rounded-xl border px-4 py-3 shadow-xl backdrop-blur ${
        notice === 'offline'
          ? 'border-amber-500/40 bg-background/95 text-foreground'
          : 'border-primary/40 bg-background/95 text-foreground'
      }`}
    >
      <p className="text-sm font-semibold">
        {notice === 'offline' ? 'Servidor LAN desconectado.' : 'Servidor reconectado.'}
      </p>
      {notice === 'offline' ? (
        <div className="mt-1 text-xs text-muted-foreground">
          <p>Mostrando la última información sincronizada.</p>
          <p>Reintentando conexión...</p>
        </div>
      ) : (
        <p className="mt-1 text-xs text-muted-foreground">Sincronizando información...</p>
      )}
    </div>
  );
}
