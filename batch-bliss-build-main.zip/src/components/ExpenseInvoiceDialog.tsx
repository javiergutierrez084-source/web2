import { useEffect, useMemo, useState } from 'react';
import { AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency, paymentMethods, type Contact, type FinancialAccount } from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import type { ExpenseConcept } from '@/lib/ExpenseConceptService';
import { encodeExpenseDocumentNotes, parseExpenseDocumentNotes } from '@/lib/PurchaseDocumentsService';
import {
  addSupplierPaymentWithAccount,
  insertSupplierInvoice,
  updateSupplierInvoiceSafe,
} from '@/lib/database';
import { getSession, logActivity } from '@/lib/auth';

interface ExpenseInvoiceDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  suppliers: Contact[];
  concepts: ExpenseConcept[];
  financialAccounts: FinancialAccount[];
  initial?: SupplierInvoiceView | null;
  duplicateFrom?: SupplierInvoiceView | null;
  onSaved: () => Promise<void> | void;
}

const today = () => new Date().toISOString().slice(0, 10);
const defaultDueDate = () => new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10);

const ExpenseInvoiceDialog = ({
  open,
  onOpenChange,
  suppliers,
  concepts,
  financialAccounts,
  initial,
  duplicateFrom,
  onSaved,
}: ExpenseInvoiceDialogProps) => {
  const { toast } = useToast();
  const source = initial || duplicateFrom || null;
  const sourceMetadata = parseExpenseDocumentNotes(source?.notes);
  const [supplierId, setSupplierId] = useState('');
  const [number, setNumber] = useState('');
  const [conceptId, setConceptId] = useState('');
  const [description, setDescription] = useState('');
  const [issueDate, setIssueDate] = useState(today());
  const [dueDate, setDueDate] = useState(defaultDueDate());
  const [total, setTotal] = useState('');
  const [status, setStatus] = useState<'pending' | 'paid'>('pending');
  const [paymentMethod, setPaymentMethod] = useState('Efectivo');
  const [accountId, setAccountId] = useState('account-caja-principal');
  const [busy, setBusy] = useState(false);

  const activeConcepts = useMemo(() => concepts.filter(item => item.active || item.id === sourceMetadata?.conceptId), [concepts, sourceMetadata?.conceptId]);

  useEffect(() => {
    if (!open) return;
    const metadata = parseExpenseDocumentNotes(source?.notes);
    setSupplierId(source?.supplierId || '');
    setNumber(initial ? source?.invoiceNumber || '' : duplicateFrom ? `${source?.invoiceNumber || 'GAS'}-COPIA` : `GAS-${Date.now().toString().slice(-6)}`);
    setConceptId(metadata?.conceptId || activeConcepts[0]?.id || '');
    setDescription(metadata?.description || '');
    setIssueDate(initial ? source?.issueDate || today() : today());
    setDueDate(source?.dueDate || defaultDueDate());
    setTotal(source ? String(source.total) : '');
    setStatus('pending');
    setPaymentMethod('Efectivo');
    setAccountId('account-caja-principal');
  }, [open, initial, duplicateFrom, source, activeConcepts]);

  const save = async () => {
    const supplier = suppliers.find(item => item.id === supplierId);
    const concept = concepts.find(item => item.id === conceptId);
    const numericTotal = Number(total);
    if (!supplier || !number.trim() || !concept || !Number.isFinite(numericTotal) || numericTotal <= 0) {
      toast({ title: 'Completa proveedor, número, concepto y valor', variant: 'destructive' });
      return;
    }
    if (status === 'paid' && !accountId) {
      toast({ title: 'Selecciona la cuenta de pago', variant: 'destructive' });
      return;
    }

    setBusy(true);
    try {
      const notes = encodeExpenseDocumentNotes({
        conceptId: concept.id,
        conceptName: concept.name,
        description,
      });
      if (initial) {
        await updateSupplierInvoiceSafe(initial.id, {
          supplierId: supplier.id,
          supplierName: supplier.name,
          invoiceNumber: number.trim(),
          issueDate,
          dueDate: dueDate || issueDate,
          total: numericTotal,
          notes,
          status: initial.payments.length > 0 || initial.status === 'paid' ? 'paid' : 'pending',
        });
        const session = getSession();
        if (session) await logActivity(session, 'EXPENSE_DOCUMENT_UPDATED', 'supplier_invoice', initial.id, JSON.stringify({ concept: concept.name, total: numericTotal }));
      } else {
        const created = await insertSupplierInvoice({
          supplier_id: supplier.id,
          supplier_name: supplier.name,
          invoice_number: number.trim(),
          issue_date: issueDate,
          due_date: dueDate || issueDate,
          total: numericTotal,
          notes,
        });
        if (status === 'paid') {
          await addSupplierPaymentWithAccount(created.id, {
            amount: numericTotal,
            date: issueDate,
            method: paymentMethod,
            accountId,
          });
        }
        const session = getSession();
        if (session) await logActivity(session, 'EXPENSE_DOCUMENT_CREATED', 'supplier_invoice', created.id, JSON.stringify({ concept: concept.name, total: numericTotal, status }));
      }
      await onSaved();
      onOpenChange(false);
      toast({ title: initial ? 'Factura de gasto actualizada' : 'Factura de gasto registrada' });
    } catch (error) {
      const code = error instanceof Error ? error.message : '';
      toast({
        title: 'No se pudo guardar la factura de gasto',
        description: code === 'INSUFFICIENT_ACCOUNT_BALANCE'
          ? 'La cuenta seleccionada no tiene saldo suficiente.'
          : code === 'PAID_PAYABLE_VALUE_LOCKED'
            ? 'Una factura pagada no permite cambiar su valor.'
            : code,
        variant: 'destructive',
      });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{initial ? 'Editar factura de gasto' : duplicateFrom ? 'Duplicar factura de gasto' : 'Nueva factura de gasto'}</DialogTitle>
          <DialogDescription>Este documento no modifica Inventario ni Kardex. Su obligación y pagos se gestionan en Cuentas por Pagar.</DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Proveedor</label>
            <select value={supplierId} onChange={event => setSupplierId(event.target.value)} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm">
              <option value="">Seleccionar...</option>
              {suppliers.map(supplier => <option key={supplier.id} value={supplier.id}>{supplier.name}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Número</label>
            <Input value={number} onChange={event => setNumber(event.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Concepto</label>
            <select value={conceptId} onChange={event => setConceptId(event.target.value)} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm">
              <option value="">Seleccionar...</option>
              {activeConcepts.map(concept => <option key={concept.id} value={concept.id}>{concept.name}</option>)}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Valor</label>
            <Input type="number" min={0} value={total} onChange={event => setTotal(event.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Fecha</label>
            <Input type="date" value={issueDate} onChange={event => setIssueDate(event.target.value)} />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-muted-foreground">Vencimiento</label>
            <Input type="date" value={dueDate} onChange={event => setDueDate(event.target.value)} />
          </div>
          {!initial && (
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-muted-foreground">Estado inicial</label>
              <select value={status} onChange={event => setStatus(event.target.value as 'pending' | 'paid')} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm">
                <option value="pending">Pendiente</option>
                <option value="paid">Pagada</option>
              </select>
            </div>
          )}
          {!initial && status === 'paid' && (
            <>
              <div className="space-y-1.5">
                <label className="text-xs font-medium text-muted-foreground">Método</label>
                <select value={paymentMethod} onChange={event => setPaymentMethod(event.target.value)} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm">
                  {paymentMethods.map(method => <option key={method}>{method}</option>)}
                </select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-xs font-medium text-muted-foreground">Cuenta</label>
                <select value={accountId} onChange={event => setAccountId(event.target.value)} className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm">
                  {financialAccounts.filter(account => account.active).map(account => (
                    <option key={account.id} value={account.id}>{account.name} · {formatCurrency(account.balance)}</option>
                  ))}
                </select>
              </div>
            </>
          )}
          <div className="space-y-1.5 sm:col-span-2">
            <label className="text-xs font-medium text-muted-foreground">Observaciones</label>
            <Textarea value={description} onChange={event => setDescription(event.target.value)} rows={3} />
          </div>
        </div>

        {!initial && status === 'pending' && (
          <div className="flex gap-2 rounded-lg border border-warning/30 bg-warning/10 p-3 text-sm text-warning">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            La factura se registrará en Cuentas por Pagar y no descontará Caja o Bancos hasta registrar un abono.
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
          <Button onClick={() => void save()} disabled={busy}>{busy ? 'Guardando...' : 'Guardar factura'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ExpenseInvoiceDialog;
