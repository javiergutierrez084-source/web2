import { useState } from 'react';
import { Download, Loader2, Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  createPdfFile,
  downloadPdfFile,
  openPdfForPrint,
  renderPdfDocument,
  revokePdfFile,
  type GeneratedPdfFile,
  type PdfDocumentData,
} from '@/lib/pdf';

interface DirectPdfActionButtonProps {
  document: PdfDocumentData | (() => PdfDocumentData);
  action?: 'download' | 'print';
  label?: string;
  compact?: boolean;
  title?: string;
}

const DirectPdfActionButton = ({
  document,
  action = 'download',
  label = action === 'download' ? 'Descargar PDF' : 'Imprimir',
  compact = false,
  title,
}: DirectPdfActionButtonProps) => {
  const [busy, setBusy] = useState(false);

  const handleAction = async (): Promise<void> => {
    if (busy) return;
    setBusy(true);
    let file: GeneratedPdfFile | null = null;
    try {
      const resolved = typeof document === 'function' ? document() : document;
      const blob = await renderPdfDocument(resolved, 'letter');
      file = createPdfFile(blob, resolved.filename);
      if (action === 'download') downloadPdfFile(file);
      else openPdfForPrint(file);
    } finally {
      if (file) window.setTimeout(() => revokePdfFile(file), 1500);
      setBusy(false);
    }
  };

  const Icon = busy ? Loader2 : action === 'download' ? Download : Printer;
  if (compact) {
    return (
      <button type="button" onClick={() => void handleAction()} disabled={busy} title={title || label}
        className="rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:opacity-50">
        <Icon className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} />
      </button>
    );
  }
  return (
    <Button type="button" variant="outline" size="sm" className="gap-2" onClick={() => void handleAction()} disabled={busy}>
      <Icon className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} /> {label}
    </Button>
  );
};

export default DirectPdfActionButton;
