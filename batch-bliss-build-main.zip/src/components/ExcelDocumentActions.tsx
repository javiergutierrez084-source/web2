import { FileSpreadsheet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { TableDocumentData } from '@/lib/pdf';
import { exportRowsToExcel } from '@/lib/excelExport';

interface ExcelDocumentActionsProps {
  document: TableDocumentData | (() => TableDocumentData);
  label?: string;
}

const ExcelDocumentActions = ({ document, label = 'Excel' }: ExcelDocumentActionsProps) => {
  const handleExport = () => {
    const resolved = typeof document === 'function' ? document() : document;
    const rows = resolved.rows.map(row => Object.fromEntries(resolved.columns.map((column, index) => [column.header, row[index] ?? ''])));
    exportRowsToExcel({
      filename: resolved.filename,
      sheetName: resolved.title,
      rows,
      columns: resolved.columns.map(column => ({
        header: column.header,
        value: (row: Record<string, string>) => row[column.header],
        width: column.width,
      })),
    });
  };

  return (
    <Button type="button" variant="outline" size="sm" className="gap-2" onClick={handleExport}>
      <FileSpreadsheet className="h-4 w-4" />
      {label}
    </Button>
  );
};

export default ExcelDocumentActions;
