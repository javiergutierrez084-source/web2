import { useMemo } from 'react';
import { useApp } from '@/contexts/AppContext';
import { buildQuotationDocumentData } from '@/lib/pdf';
import { PdfDocumentModal } from '@/components/PdfDocumentActions';
import type { Quotation } from '@/data/mockData';

interface QuotationPreviewProps {
  quotation: Quotation;
  onClose: () => void;
}

const QuotationPreview = ({ quotation, onClose }: QuotationPreviewProps) => {
  const { company, contacts, products } = useApp();
  const contact = contacts.find(item => item.id === quotation.clientId);
  const document = useMemo(
    () => buildQuotationDocumentData({ quotation, company, contact, products }),
    [company, contact, products, quotation],
  );

  return (
    <PdfDocumentModal
      document={document}
      formats={['letter', 'ticket80', 'ticket50']}
      initialFormat="letter"
      onClose={onClose}
    />
  );
};

export default QuotationPreview;
