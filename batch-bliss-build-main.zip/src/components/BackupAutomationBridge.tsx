import { useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useApp } from '@/contexts/AppContext';
import { useWorkMode } from '@/contexts/WorkModeContext';
import { BackupScheduler } from '@/lib/BackupScheduler';
import {
  PROFESSIONAL_BACKUP_STATUS_EVENT,
  ProfessionalBackupService,
} from '@/lib/ProfessionalBackupService';

const CLOSE_BACKUP_POLL_INTERVAL_MS = 750;

type CloseProgressReporter = (progress: { phase: 'backup' | 'finalizing' }) => void;

async function waitForActiveBackupToFinish(reportProgress: CloseProgressReporter): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    let settled = false;
    let checking = false;

    const cleanup = () => {
      window.clearInterval(pollTimer);
      window.removeEventListener(PROFESSIONAL_BACKUP_STATUS_EVENT, handleStatusChange);
    };

    const checkStatus = async () => {
      if (settled || checking) return;
      checking = true;
      try {
        const status = await ProfessionalBackupService.getStatus();
        if (!status.running && status.queued === 0) {
          settled = true;
          cleanup();
          resolve();
        }
      } catch (error) {
        settled = true;
        cleanup();
        reject(error);
      } finally {
        checking = false;
      }
    };

    const handleStatusChange = () => { void checkStatus(); };
    const pollTimer = window.setInterval(() => {
      reportProgress({ phase: 'backup' });
      void checkStatus();
    }, CLOSE_BACKUP_POLL_INTERVAL_MS);

    window.addEventListener(PROFESSIONAL_BACKUP_STATUS_EVENT, handleStatusChange);
    reportProgress({ phase: 'backup' });
    void checkStatus();
  });
}

const BackupAutomationBridge = () => {
  const { effectiveMode } = useWorkMode();
  const { user } = useAuth();
  const { cashSessions, isLoading } = useApp();
  const previousCashClosures = useRef<Map<string, string | undefined>>(new Map());
  const cashSnapshotReady = useRef(false);

  useEffect(() => {
    if (effectiveMode !== 'server' || !user) {
      BackupScheduler.dispose();
      return undefined;
    }

    void BackupScheduler.init().then(() => (
      ProfessionalBackupService.runDatabaseUpdateBackupIfNeeded()
    )).catch(error => {
      console.error('[Backup] No fue posible iniciar el sistema automático:', error);
    });

    return () => BackupScheduler.dispose();
  }, [effectiveMode, user]);

  useEffect(() => {
    const dispose = window.joyaControlBackup?.onBeforeQuit?.(async (_request, reportProgress) => {
      try {
        const status = await ProfessionalBackupService.getStatus();
        if (!status.running && status.queued === 0) {
          return { completed: true, waitedForBackup: false };
        }

        reportProgress({ phase: 'backup' });
        await waitForActiveBackupToFinish(reportProgress);
        reportProgress({ phase: 'finalizing' });
        return { completed: true, waitedForBackup: true };
      } catch (error) {
        return {
          completed: false,
          reason: error instanceof Error ? error.message : 'BACKUP_BEFORE_QUIT_FAILED',
        };
      }
    });
    return dispose;
  }, []);

  useEffect(() => {
    if (isLoading) return;
    const current = new Map(cashSessions.map(session => [session.id, session.closedAt]));
    if (!cashSnapshotReady.current) {
      previousCashClosures.current = current;
      cashSnapshotReady.current = true;
      return;
    }

    if (effectiveMode === 'server' && user) {
      for (const session of cashSessions) {
        const previousClosedAt = previousCashClosures.current.get(session.id);
        const sessionWasAlreadyObserved = previousCashClosures.current.has(session.id);
        if (sessionWasAlreadyObserved && !previousClosedAt && session.closedAt) {
          void ProfessionalBackupService.createAutomaticBackup('cash-close').catch(error => {
            console.error('[Backup] Falló el respaldo posterior al cierre de caja:', error);
          });
        }
      }
    }
    previousCashClosures.current = current;
  }, [cashSessions, effectiveMode, isLoading, user]);

  return null;
};

export default BackupAutomationBridge;
