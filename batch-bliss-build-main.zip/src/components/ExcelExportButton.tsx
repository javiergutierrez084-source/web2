import { FileSpreadsheet } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { exportRowsToExcel, type ExcelColumn } from '@/lib/excelExport';

interface ExcelExportButtonProps<T> {
  filename: string;
  sheetName: string;
  columns: ExcelColumn<T>[];
  rows: T[];
  label?: string;
  compact?: boolean;
}

const ExcelExportButton = <T,>({ filename, sheetName, columns, rows, label = 'Excel', compact = false }: ExcelExportButtonProps<T>) => (
  <Button
    type="button"
    variant="outline"
    size={compact ? 'icon' : 'sm'}
    className={compact ? 'h-8 w-8' : 'gap-2'}
    title="Descargar Excel"
    aria-label="Descargar Excel"
    onClick={() => exportRowsToExcel({ filename, sheetName, columns, rows })}
  >
    <FileSpreadsheet className="h-4 w-4" />
    {!compact && label}
  </Button>
);

export default ExcelExportButton;
