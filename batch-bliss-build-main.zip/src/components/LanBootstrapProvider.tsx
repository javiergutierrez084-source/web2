import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import SplashScreen from '@/components/SplashScreen';
import { restoreLanSession } from '@/lib/auth';
import {
  loadLanConfig,
  rediscoverTrustedLanServer,
  validateAndRememberLanServer,
  type LanCommunicationConfig,
} from '@/lib/LanCommunicationConfig';
import { LanConnectionManager } from '@/lib/LanConnectionManager';
import { LanServerDescriptor } from '@/lib/LanServerDescriptor';

export type LanBootstrapState = 'LAN_BOOTSTRAPPING' | 'LAN_READY' | 'LAN_FAILED';

interface LanBootstrapContextValue {
  state: LanBootstrapState;
  error: string | null;
  retry: () => void;
}

const APP_VERSION = '2.1';
const PROTOCOL_VERSION = 'LAN-1';
const MINIMUM_SPLASH_MS = 3_000;
export const LAN_BOOTSTRAP_STATE_EVENT = 'joyacontrol-lan-bootstrap-state';

const LanBootstrapContext = createContext<LanBootstrapContextValue | null>(null);

function wait(milliseconds: number): Promise<void> {
  return new Promise(resolve => window.setTimeout(resolve, milliseconds));
}

async function waitForMinimumSplash(startedAt: number): Promise<void> {
  const remaining = MINIMUM_SPLASH_MS - (Date.now() - startedAt);
  if (remaining > 0) await wait(remaining);
}

async function prepareLanClient(config: LanCommunicationConfig): Promise<void> {
  let activeConfig = config;

  if (!LanServerDescriptor.hasAddress()) {
    activeConfig = await rediscoverTrustedLanServer(activeConfig);
  }

  try {
    await validateAndRememberLanServer(activeConfig, APP_VERSION, PROTOCOL_VERSION);
  } catch (firstError) {
    if (!activeConfig.autoReconnect) throw firstError;
    activeConfig = await rediscoverTrustedLanServer(activeConfig);
    await validateAndRememberLanServer(activeConfig, APP_VERSION, PROTOCOL_VERSION);
  }

  if (!LanServerDescriptor.hasAddress()) {
    throw new Error('LAN_SERVER_DESCRIPTOR_ADDRESS_NOT_AVAILABLE');
  }
}

export function useLanBootstrap(): LanBootstrapContextValue {
  const context = useContext(LanBootstrapContext);
  if (!context) throw new Error('useLanBootstrap must be inside LanBootstrapProvider');
  return context;
}

export default function LanBootstrapProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<LanBootstrapState>('LAN_BOOTSTRAPPING');
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);

  const publishState = useCallback((nextState: LanBootstrapState, nextError: string | null = null) => {
    setState(nextState);
    setError(nextError);
    window.dispatchEvent(new CustomEvent(LAN_BOOTSTRAP_STATE_EVENT, {
      detail: { state: nextState, error: nextError },
    }));
  }, []);

  const retry = useCallback(() => setAttempt(current => current + 1), []);

  useEffect(() => {
    let cancelled = false;
    const startedAt = Date.now();

    LanConnectionManager.stop();
    publishState('LAN_BOOTSTRAPPING');

    const bootstrap = async () => {
      try {
        const config = loadLanConfig();

        LanServerDescriptor.load();
        await LanServerDescriptor.refresh();

        if (config.mode === 'lan' && config.role === 'client') {
          await prepareLanClient(config);
        }

        await restoreLanSession();

        if (cancelled) return;

        LanConnectionManager.start();
        await waitForMinimumSplash(startedAt);

        if (!cancelled) publishState('LAN_READY');
      } catch (bootstrapError) {
        LanConnectionManager.stop();
        await waitForMinimumSplash(startedAt);
        if (cancelled) return;
        publishState(
          'LAN_FAILED',
          bootstrapError instanceof Error ? bootstrapError.message : 'LAN_BOOTSTRAP_FAILED',
        );
      }
    };

    void bootstrap();

    return () => {
      cancelled = true;
      LanConnectionManager.stop();
    };
  }, [attempt, publishState]);

  const contextValue = useMemo(() => ({ state, error, retry }), [state, error, retry]);

  if (state === 'LAN_BOOTSTRAPPING') {
    return (
      <LanBootstrapContext.Provider value={contextValue}>
        <SplashScreen persistent />
      </LanBootstrapContext.Provider>
    );
  }

  if (state === 'LAN_FAILED') {
    return (
      <LanBootstrapContext.Provider value={contextValue}>
        <div className="min-h-screen flex items-center justify-center bg-background p-6">
          <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-xl">
            <h1 className="text-xl font-bold">No fue posible iniciar la conexión LAN</h1>
            <p className="mt-3 text-sm text-muted-foreground">
              {error || 'La infraestructura LAN no está disponible.'}
            </p>
            <button
              type="button"
              onClick={retry}
              className="mt-6 inline-flex h-10 items-center justify-center rounded-md bg-primary px-5 text-sm font-medium text-primary-foreground"
            >
              Reintentar
            </button>
          </div>
        </div>
      </LanBootstrapContext.Provider>
    );
  }

  return (
    <LanBootstrapContext.Provider value={contextValue}>
      {children}
    </LanBootstrapContext.Provider>
  );
}
