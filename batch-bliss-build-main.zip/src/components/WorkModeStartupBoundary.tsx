import type { ReactNode } from 'react';
import { HardDrive, Loader2, Network, Radar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useWorkMode } from '@/contexts/WorkModeContext';

export default function WorkModeStartupBoundary({ children }: { children: ReactNode }) {
  const {
    phase,
    detectedServer,
    error,
    confirmAutomaticServer,
    retryResolution,
    useLocalFallback,
  } = useWorkMode();

  if (phase === 'ready') return <>{children}</>;

  if (phase === 'awaiting-confirmation' && detectedServer) {
    return (
      <AlertDialog open>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Network className="h-5 w-5 text-primary" />
              Servidor Principal detectado
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <span className="block">Se encontró <strong>{detectedServer.serverName}</strong>.</span>
              <span className="block font-mono text-xs">{detectedServer.ip}:{detectedServer.port}</span>
              <span className="block">¿Desea conectarse como Cliente LAN?</span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => void confirmAutomaticServer(false)}>
              Usar modo Local
            </AlertDialogCancel>
            <AlertDialogAction onClick={() => void confirmAutomaticServer(true)}>
              Conectar al servidor
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    );
  }

  if (phase === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-6">
        <div className="w-full max-w-md rounded-2xl border border-border bg-card p-8 text-center shadow-xl">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-destructive/10">
            <Network className="h-7 w-7 text-destructive" />
          </div>
          <h1 className="mt-5 text-xl font-bold">No fue posible preparar el Cliente LAN</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {error || 'No se encontró un Servidor Principal disponible.'}
          </p>
          <div className="mt-6 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button variant="outline" onClick={useLocalFallback}>
              <HardDrive className="mr-2 h-4 w-4" />
              Usar modo Local
            </Button>
            <Button onClick={retryResolution}>
              <Radar className="mr-2 h-4 w-4" />
              Buscar nuevamente
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-8 text-center shadow-xl">
        <Loader2 className="mx-auto h-9 w-9 animate-spin text-primary" />
        <h1 className="mt-5 text-lg font-bold">
          {phase === 'detecting' ? 'Buscando Servidor Principal' : 'Preparando JoyaControl'}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {phase === 'detecting'
            ? 'Comprobando los equipos disponibles en la red local.'
            : 'Seleccionando el origen de datos configurado.'}
        </p>
      </div>
    </div>
  );
}
