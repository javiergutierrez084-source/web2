import type { OwnerFinanceDashboard } from '@/lib/OwnerFinanceService';

const currency = new Intl.NumberFormat('es-CO', {
  style: 'currency',
  currency: 'COP',
  maximumFractionDigits: 0,
});

interface OwnerFinanceGoalProgressProps {
  dashboard: OwnerFinanceDashboard;
}

export function OwnerFinanceGoalProgress({ dashboard }: OwnerFinanceGoalProgressProps) {
  const hasGoal = dashboard.monthlyProfitGoal > 0;

  return (
    <section className="space-y-4 rounded-xl border bg-card p-4 shadow-sm" aria-label="Progreso de la meta mensual">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="font-semibold">Progreso de la meta mensual</h2>
          <p className="text-xs text-muted-foreground">
            La meta es informativa y no modifica los cálculos financieros.
          </p>
        </div>
        {dashboard.monthlyGoalReached && (
          <span className="w-fit rounded-full bg-emerald-100 px-3 py-1 text-xs font-semibold text-emerald-800">
            Meta alcanzada
          </span>
        )}
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div>
          <p className="text-xs text-muted-foreground">Cumplimiento</p>
          <p className="font-semibold">{dashboard.monthlyGoalProgressPercentage.toFixed(2)} %</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Valor alcanzado</p>
          <p className="font-semibold">{currency.format(dashboard.monthlyGoalReachedValue)}</p>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">Valor restante</p>
          <p className="font-semibold">{currency.format(dashboard.monthlyGoalRemainingValue)}</p>
        </div>
      </div>

      <div
        className="h-3 overflow-hidden rounded-full bg-secondary"
        role="progressbar"
        aria-label="Cumplimiento de la meta mensual"
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={dashboard.monthlyGoalProgressBarPercentage}
        data-testid="owner-monthly-goal-progress"
      >
        <div
          className={`h-full rounded-full transition-[width] duration-300 ${dashboard.monthlyGoalReached ? 'bg-emerald-600' : 'bg-primary'}`}
          style={{ width: `${dashboard.monthlyGoalProgressBarPercentage}%` }}
          data-testid="owner-monthly-goal-progress-fill"
        />
      </div>

      {!hasGoal && (
        <p className="text-xs text-muted-foreground">
          Configura una meta mensual para visualizar su cumplimiento.
        </p>
      )}
    </section>
  );
}
