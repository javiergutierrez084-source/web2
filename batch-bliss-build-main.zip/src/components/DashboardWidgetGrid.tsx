import { memo, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState, type ComponentType, type ReactNode } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  ArrowRight,
  Banknote,
  BarChart3,
  Boxes,
  CalendarClock,
  CircleDollarSign,
  Clock3,
  CreditCard,
  DollarSign,
  Gauge,
  Landmark,
  Package,
  ReceiptText,
  ShoppingBag,
  ShoppingCart,
  TrendingDown,
  TrendingUp,
  UserRoundCheck,
  Users,
  Wallet,
} from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip as ChartTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { formatCurrency } from '@/data/mockData';
import { formatShortDate, formatWeight } from '@/lib/utils';
import type { DashboardSnapshot } from '@/lib/DashboardMetricsService';
import type { DashboardPreferences, DashboardWidgetKey } from '@/lib/DashboardPreferencesService';
import type { DashboardChartDatum, DashboardVisualMetrics } from '@/lib/DashboardVisualMetricsService';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface DashboardWidgetGridProps {
  preferences: DashboardPreferences;
  snapshot: DashboardSnapshot;
  metrics: DashboardVisualMetrics;
  layawayBankFunds: number;
}

type IconComponent = ComponentType<{ className?: string }>;

type WidgetKind = 'kpi' | 'chart' | 'alert';

interface WidgetDefinition {
  node: ReactNode;
  kind?: WidgetKind;
}

const MASONRY_GAP = 12;

const estimatedHeightByKind: Record<WidgetKind, number> = {
  kpi: 150,
  alert: 220,
  chart: 280,
};

interface MasonryPosition {
  left: number;
  top: number;
  width: number;
}

interface MasonryWidgetProps {
  widgetKey: DashboardWidgetKey;
  position: MasonryPosition;
  children: ReactNode;
  onHeightChange: (key: DashboardWidgetKey, height: number) => void;
}

const MasonryWidget = memo(({ widgetKey, position, children, onHeightChange }: MasonryWidgetProps) => {
  const contentRef = useRef<HTMLDivElement>(null);

  const measure = useCallback(() => {
    const element = contentRef.current;
    if (!element) return;
    onHeightChange(widgetKey, Math.ceil(element.getBoundingClientRect().height));
  }, [onHeightChange, widgetKey]);

  useLayoutEffect(() => {
    measure();
    const element = contentRef.current;
    if (!element || typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(measure);
    observer.observe(element);
    return () => observer.disconnect();
  }, [measure]);

  return (
    <div
      className="absolute min-w-0 transition-transform duration-200 ease-out"
      style={{
        width: `${position.width}px`,
        transform: `translate3d(${position.left}px, ${position.top}px, 0)`,
      }}
    >
      <div ref={contentRef} className="min-w-0">{children}</div>
    </div>
  );
});

MasonryWidget.displayName = 'MasonryWidget';

const columnsForViewport = (viewportWidth: number): number => {
  if (viewportWidth >= 2400) return 6;
  if (viewportWidth >= 1900) return 5;
  if (viewportWidth >= 1536) return 4;
  if (viewportWidth >= 1280) return 3;
  if (viewportWidth >= 640) return 2;
  return 1;
};

const tooltipStyle = {
  backgroundColor: 'hsl(220 18% 13%)',
  border: '1px solid hsl(220 14% 18%)',
  borderRadius: '10px',
  color: 'hsl(40 20% 92%)',
  fontSize: '12px',
};

const formatLedgerTimestamp = (value: string | null): string => {
  if (!value) return 'Sin movimientos';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return new Intl.DateTimeFormat('es-CO', { dateStyle: 'short', timeStyle: 'short' }).format(parsed);
};

const WidgetCard = ({
  title,
  value,
  icon: Icon,
  rows = [],
  accent = false,
  actionHref,
  actionLabel = 'Ver detalle',
  children,
}: {
  title: string;
  value: string;
  icon: IconComponent;
  rows?: Array<{ label: string; value: string }>;
  accent?: boolean;
  actionHref?: string;
  actionLabel?: string;
  children?: ReactNode;
}) => (
  <Card className={cn(
    'min-h-[150px] overflow-hidden border-border/80 bg-card/95 transition-all duration-200 hover:-translate-y-0.5 hover:border-primary/30 hover:shadow-lg hover:shadow-primary/5',
    accent && 'border-primary/30 bg-gradient-to-br from-primary/10 via-card to-card',
  )}>
    <CardContent className="flex min-h-[150px] flex-col p-3.5 sm:p-4">
      <div className="mb-2.5 flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">{title}</p>
          <p className={cn('mt-1 break-words text-2xl font-bold tracking-tight', accent && 'gold-text')}>{value}</p>
        </div>
        <div className={cn(
          'flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border border-border bg-secondary/70',
          accent && 'gold-gradient border-transparent shadow-md shadow-primary/10',
        )}>
          <Icon className={cn('h-[18px] w-[18px] text-muted-foreground', accent && 'text-primary-foreground')} />
        </div>
      </div>
      {(rows.length > 0 || children || actionHref) && (
        <div className="mt-auto space-y-1.5 border-t border-border/70 pt-2.5">
          {rows.map(row => (
            <div key={row.label} className="flex items-start justify-between gap-2 text-xs">
              <span className="text-muted-foreground">{row.label}</span>
              <span className="max-w-[60%] break-words text-right font-semibold text-foreground">{row.value}</span>
            </div>
          ))}
          {children}
          {actionHref && (
            <Button asChild variant="ghost" size="sm" className="mt-0.5 h-7 w-full justify-between px-0 text-xs text-primary hover:bg-transparent">
              <Link to={actionHref}>{actionLabel}<ArrowRight className="h-3.5 w-3.5" /></Link>
            </Button>
          )}
        </div>
      )}
    </CardContent>
  </Card>
);

const ChartCard = ({
  title,
  description,
  data,
  secondaryLabel,
  kind = 'bar',
}: {
  title: string;
  description: string;
  data: DashboardChartDatum[];
  secondaryLabel?: string;
  kind?: 'bar' | 'line';
}) => (
  <Card className="min-h-[260px] overflow-hidden border-border/80 bg-card/95">
    <CardHeader className="px-4 pb-1.5 pt-4">
      <CardTitle className="flex items-center gap-2 text-base"><BarChart3 className="h-4 w-4 text-primary" />{title}</CardTitle>
      <p className="text-xs text-muted-foreground">{description}</p>
    </CardHeader>
    <CardContent className="px-2 pb-3 pt-0 sm:px-4">
      {data.length === 0 ? (
        <div className="flex h-[190px] items-center justify-center rounded-xl border border-dashed border-border text-sm text-muted-foreground">Sin información para mostrar.</div>
      ) : (
        <div className="h-[200px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            {kind === 'line' ? (
              <LineChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 14% 18%)" vertical={false} />
                <XAxis dataKey="label" minTickGap={24} tick={{ fill: 'hsl(220 10% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis width={64} tick={{ fill: 'hsl(220 10% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={value => `$${Math.round(Number(value) / 1000)}k`} />
                <ChartTooltip contentStyle={tooltipStyle} formatter={value => formatCurrency(Number(value) || 0)} />
                <Line type="monotone" dataKey="value" stroke="hsl(43 96% 56%)" strokeWidth={2.5} dot={false} activeDot={{ r: 5 }} />
              </LineChart>
            ) : (
              <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(220 14% 18%)" vertical={false} />
                <XAxis dataKey="label" minTickGap={20} tick={{ fill: 'hsl(220 10% 50%)', fontSize: 9 }} axisLine={false} tickLine={false} />
                <YAxis width={64} tick={{ fill: 'hsl(220 10% 50%)', fontSize: 10 }} axisLine={false} tickLine={false} tickFormatter={value => `$${Math.round(Number(value) / 1000)}k`} />
                <ChartTooltip contentStyle={tooltipStyle} formatter={(value, name) => [formatCurrency(Number(value) || 0), name === 'secondary' ? secondaryLabel || 'Comparativo' : title]} />
                <Bar dataKey="value" fill="hsl(43 96% 56%)" radius={[5, 5, 0, 0]} />
                {secondaryLabel && <Bar dataKey="secondary" fill="hsl(210 80% 55%)" radius={[5, 5, 0, 0]} />}
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      )}
    </CardContent>
  </Card>
);

function DashboardWidgetGrid({
  preferences,
  snapshot,
  metrics,
  layawayBankFunds,
}: DashboardWidgetGridProps) {
  const definitions = useMemo<Partial<Record<DashboardWidgetKey, WidgetDefinition>>>(() => ({
    'sales.today': { node: <WidgetCard title="Ventas Hoy" value={formatCurrency(snapshot.today.value)} icon={CircleDollarSign} accent rows={[{ label: 'Facturas', value: snapshot.today.count.toLocaleString('es-CO') }]} /> },
    'sales.week': { node: <WidgetCard title="Ventas Semana" value={formatCurrency(metrics.salesWeek.value)} icon={TrendingUp} rows={[{ label: 'Facturas', value: metrics.salesWeek.count.toLocaleString('es-CO') }]} /> },
    'sales.month': { node: <WidgetCard title="Ventas Mes" value={formatCurrency(snapshot.month.value)} icon={TrendingUp} rows={[{ label: 'Facturas', value: snapshot.month.count.toLocaleString('es-CO') }]} /> },
    'sales.ticketAverage': { node: <WidgetCard title="Ticket promedio" value={formatCurrency(metrics.ticketAverage)} icon={ReceiptText} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },
    'sales.invoices': { node: <WidgetCard title="Facturas emitidas" value={metrics.invoicesMonth.toLocaleString('es-CO')} icon={ReceiptText} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },
    'sales.productsSold': { node: <WidgetCard title="Productos vendidos" value={metrics.productsSoldMonth.toLocaleString('es-CO', { maximumFractionDigits: 3 })} icon={ShoppingBag} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },

    'profit.today': { node: <WidgetCard title="Utilidad Hoy" value={formatCurrency(metrics.profitToday)} icon={DollarSign} rows={[{ label: 'Ventas menos costos y gastos', value: 'Hoy' }]} /> },
    'profit.week': { node: <WidgetCard title="Utilidad Semana" value={formatCurrency(metrics.profitWeek)} icon={DollarSign} rows={[{ label: 'Periodo', value: 'Semana actual' }]} /> },
    'profit.month': { node: <WidgetCard title="Utilidad Mes" value={formatCurrency(metrics.profitMonth)} icon={DollarSign} accent rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },

    'cash.main': { node: <WidgetCard title="Caja Principal" value={formatCurrency(snapshot.financialPosition.mainCash)} icon={Wallet} rows={[{ label: 'Última actualización', value: formatLedgerTimestamp(snapshot.financialPosition.mainCashUpdatedAt) }, { label: 'Estado', value: snapshot.financialPosition.mainCashStatus === 'RECONCILED' ? 'Conciliado' : snapshot.financialPosition.mainCashStatus === 'MISMATCH' ? 'Revisar conciliación' : 'Sin movimientos' }]} actionHref="/reportes?tab=traceability&composition=mainCash" /> },
    'cash.banksToday': { node: <WidgetCard title="Bancos Hoy" value={formatCurrency(snapshot.financialPosition.banksToday || 0)} icon={Landmark} rows={[{ label: 'Saldo acumulado', value: formatCurrency(snapshot.financialPosition.banks) }]} actionHref="/reportes?tab=traceability&composition=banks">{layawayBankFunds > 0 && <div className="rounded-lg border border-warning/30 bg-warning/5 p-2"><div className="flex justify-between gap-2 text-xs"><span className="font-medium">Fondos de separados</span><span className="font-bold text-warning">{formatCurrency(layawayBankFunds)}</span></div><p className="mt-1 text-[10px] text-muted-foreground">No corresponde a ventas realizadas.</p></div>}</WidgetCard> },
    'cash.totalAvailable': { node: <WidgetCard title="Total Disponible" value={formatCurrency(snapshot.financialPosition.totalAvailable)} icon={Banknote} accent rows={[{ label: 'Caja Principal', value: formatCurrency(snapshot.financialPosition.mainCash) }, { label: 'Bancos', value: formatCurrency(snapshot.financialPosition.banks) }]} actionHref="/reportes?tab=traceability&composition=totalAvailable" /> },
    'cash.layawayReserve': { node: <WidgetCard title="Caja Separados" value={formatCurrency(snapshot.financialPosition.layawayReserve)} icon={ShoppingBag} rows={[{ label: 'Estado', value: 'Dinero reservado' }, { label: 'Disponible', value: 'No incluido' }]} actionHref="/reportes?tab=traceability&composition=layawayReserve" /> },

    'inventory.lowStock': { node: <WidgetCard title="Productos con poco stock" value={metrics.lowStock.toLocaleString('es-CO')} icon={AlertTriangle} rows={[{ label: 'Umbral', value: 'Stock mínimo configurado' }]} actionHref="/inventario" /> },
    'inventory.outOfStock': { node: <WidgetCard title="Productos agotados" value={metrics.outOfStock.toLocaleString('es-CO')} icon={Boxes} rows={[{ label: 'Disponibilidad', value: 'Sin existencias' }]} actionHref="/inventario" /> },
    'inventory.topProducts': { node: <WidgetCard title="Producto más vendido" value={snapshot.topProducts[0]?.name || 'Sin ventas'} icon={Package} rows={[{ label: 'Cantidad', value: snapshot.topProducts[0]?.quantity.toLocaleString('es-CO', { maximumFractionDigits: 3 }) || '0' }, { label: 'Valor', value: formatCurrency(snapshot.topProducts[0]?.value || 0) }]} /> },
    'inventory.leastProducts': { node: <WidgetCard title="Producto menos vendido" value={metrics.leastSoldProduct?.name || 'Sin ventas'} icon={TrendingDown} rows={[{ label: 'Cantidad', value: metrics.leastSoldProduct?.quantity.toLocaleString('es-CO', { maximumFractionDigits: 3 }) || '0' }]} /> },
    'inventory.value': { node: <WidgetCard title="Valor del inventario" value={formatCurrency(snapshot.inventory.saleValue)} icon={Package} rows={[{ label: 'Costo total', value: formatCurrency(snapshot.inventory.totalCost) }, { label: 'Productos activos', value: snapshot.inventory.activeProducts.toLocaleString('es-CO') }]} /> },
    'inventory.grams': { node: <WidgetCard title="Gramos disponibles" value={`${formatWeight(snapshot.inventory.totalWeightGrams)} g`} icon={Gauge} rows={[{ label: 'Productos', value: snapshot.inventory.products.toLocaleString('es-CO') }]} /> },

    'customers.new': { node: <WidgetCard title="Clientes nuevos" value={snapshot.customers.newThisMonth.toLocaleString('es-CO')} icon={UserRoundCheck} rows={[{ label: 'Registrados', value: snapshot.customers.registered.toLocaleString('es-CO') }]} /> },
    'customers.frequent': { node: <WidgetCard title="Clientes frecuentes" value={metrics.frequentCustomers.toLocaleString('es-CO')} icon={Users} rows={[{ label: 'Criterio', value: 'Dos o más compras' }]} /> },
    'customers.top': { node: <WidgetCard title="Cliente con mayor compra" value={metrics.topCustomer?.name || 'Sin ventas'} icon={Users} rows={[{ label: 'Valor comprado', value: formatCurrency(metrics.topCustomer?.value || 0) }]} /> },

    'suppliers.payables': { node: <WidgetCard title="Cuentas por pagar" value={formatCurrency(metrics.accountsPayable)} icon={CreditCard} rows={[{ label: 'Saldo pendiente', value: 'Facturas activas' }]} actionHref="/cuentas-por-pagar" /> },
    'suppliers.overdue': { node: <WidgetCard title="Facturas vencidas" value={metrics.overdueSupplierInvoices.toLocaleString('es-CO')} icon={AlertTriangle} rows={[{ label: 'Proveedor', value: 'Pendientes vencidas' }]} actionHref="/cuentas-por-pagar" /> },

    'purchases.month': { node: <WidgetCard title="Compras del mes" value={formatCurrency(snapshot.purchasesMonth)} icon={ShoppingCart} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },
    'purchases.expensesMonth': { node: <WidgetCard title="Gastos del mes" value={formatCurrency(metrics.expensesMonth)} icon={TrendingDown} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },

    'layaways.active': { node: <WidgetCard title="Separados activos" value={metrics.layaways.active.toLocaleString('es-CO')} icon={ShoppingBag} rows={[{ label: 'Clientes', value: snapshot.layaways.clients.toLocaleString('es-CO') }]} actionHref="/ventas?tab=layaways&filter=active" /> },
    'layaways.valueRetained': { node: <WidgetCard title="Valor retenido en separados" value={formatCurrency(metrics.layaways.retainedValue)} icon={Wallet} rows={[{ label: 'Saldo pendiente', value: formatCurrency(snapshot.layaways.pendingValue) }]} actionHref="/ventas?tab=layaways&filter=active" /> },
    'layaways.paymentsReceived': { node: <WidgetCard title="Abonos recibidos" value={formatCurrency(metrics.layaways.paymentsReceived)} icon={Banknote} rows={[{ label: 'Separados activos', value: metrics.layaways.active.toLocaleString('es-CO') }]} /> },
    'layaways.upcoming': { node: <WidgetCard title="Separados por vencer" value={metrics.layaways.upcoming.toLocaleString('es-CO')} icon={CalendarClock} rows={[{ label: 'Próximo vencimiento', value: metrics.layaways.nearestDueDate ? formatShortDate(metrics.layaways.nearestDueDate) : 'Sin vencimientos' }]} actionHref="/ventas?tab=layaways&filter=upcoming" /> },
    'layaways.overdue': { node: <WidgetCard title="Separados vencidos" value={metrics.layaways.overdue.toLocaleString('es-CO')} icon={AlertTriangle} rows={[{ label: 'Estado', value: metrics.layaways.overdue > 0 ? 'Requiere revisión' : 'Sin vencidos' }]} actionHref="/ventas?tab=layaways&filter=overdue" /> },
    'layaways.noRecentPayments': { node: <WidgetCard title="Sin abonos recientes" value={metrics.layaways.noRecentPayments.toLocaleString('es-CO')} icon={Clock3} rows={[{ label: 'Umbral', value: 'Más de 30 días' }]} actionHref="/ventas?tab=layaways&filter=noRecentPayments" /> },
    'layaways.alerts': {
      node: (
        <Card className="min-h-[220px] border-warning/25 bg-card/95">
          <CardHeader className="px-4 pb-2 pt-4">
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4 text-warning" /> Alertas de separados
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-2 px-4 pb-4 pt-0 sm:grid-cols-2">
            <Link to="/ventas?tab=layaways&filter=upcoming" className="rounded-lg border border-border bg-secondary/20 p-2.5">
              <span className="block text-xs text-muted-foreground">Separados próximos a vencer</span>
              <strong className="text-xl">{metrics.layaways.upcoming}</strong>
            </Link>
            <Link to="/ventas?tab=layaways&filter=overdue" className="rounded-lg border border-destructive/20 bg-destructive/5 p-2.5">
              <span className="block text-xs text-muted-foreground">Separados vencidos</span>
              <strong className="text-xl text-destructive">{metrics.layaways.overdue}</strong>
            </Link>
            <div className="rounded-lg border border-border bg-secondary/20 p-2.5">
              <span className="block text-xs text-muted-foreground">Valor retenido</span>
              <strong className="break-words text-lg">{formatCurrency(metrics.layaways.retainedValue)}</strong>
            </div>
            <Link to="/ventas?tab=layaways&filter=active" className="rounded-lg border border-border bg-secondary/20 p-2.5">
              <span className="block text-xs text-muted-foreground">Cantidad de separados</span>
              <strong className="text-xl">{metrics.layaways.active}</strong>
            </Link>
            {metrics.layaways.nearestDueDate && (
              <div className="rounded-lg border border-warning/20 bg-warning/5 p-2.5 text-xs sm:col-span-2">
                <span className="text-muted-foreground">Próxima fecha de vencimiento:</span>{' '}
                <strong>{formatShortDate(metrics.layaways.nearestDueDate)}</strong>
              </div>
            )}
          </CardContent>
        </Card>
      ),
      kind: 'alert',
    },

    'finance.cashFlow': { node: <WidgetCard title="Flujo de caja" value={formatCurrency(metrics.cashFlowToday)} icon={TrendingUp} rows={[{ label: 'Ingresos menos egresos', value: 'Hoy' }]} /> },
    'finance.incomeExpense': { node: <WidgetCard title="Balance ingresos/egresos" value={formatCurrency(metrics.incomeExpenseBalanceMonth)} icon={BarChart3} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },
    'finance.profitability': { node: <WidgetCard title="Rentabilidad" value={`${metrics.profitabilityMonth.toLocaleString('es-CO', { maximumFractionDigits: 2 })}%`} icon={Gauge} rows={[{ label: 'Periodo', value: 'Mes actual' }]} /> },
    'finance.availableCapital': { node: <WidgetCard title="Capital disponible" value={formatCurrency(metrics.capitalAvailable)} icon={Banknote} accent rows={[{ label: 'Origen', value: 'Caja + bancos' }]} /> },

    'charts.salesDay': { node: <ChartCard title="Ventas por día" description="Últimos 30 días" data={snapshot.salesLast30Days.map(row => ({ label: row.label, value: row.value, count: row.count }))} kind="line" />, kind: 'chart' },
    'charts.salesMonth': { node: <ChartCard title="Ventas por mes" description="Últimos 12 meses" data={metrics.charts.salesMonth} />, kind: 'chart' },
    'charts.profitMonth': { node: <ChartCard title="Utilidad por mes" description="Ventas menos costos y gastos" data={metrics.charts.profitMonth} />, kind: 'chart' },
    'charts.paymentMethods': { node: <ChartCard title="Formas de pago" description="Distribución por valor vendido" data={metrics.charts.paymentMethods} />, kind: 'chart' },
    'charts.clientsTop': { node: <ChartCard title="Clientes Top 10" description="Clientes con mayor valor comprado" data={metrics.charts.clientsTop} />, kind: 'chart' },
    'charts.productsTop': { node: <ChartCard title="Productos Top 10" description="Productos con mayor valor vendido" data={metrics.charts.productsTop} />, kind: 'chart' },
    'charts.categoriesTop': { node: <ChartCard title="Categorías más vendidas" description="Valor vendido por categoría" data={metrics.charts.categoriesTop} />, kind: 'chart' },
    'charts.purchasesVsSales': { node: <ChartCard title="Compras vs ventas" description="Comparativo mensual" data={metrics.charts.purchasesVsSales} secondaryLabel="Compras" />, kind: 'chart' },
    'charts.incomeVsExpenses': { node: <ChartCard title="Ingresos vs egresos" description="Comparativo mensual" data={metrics.charts.incomeVsExpenses} secondaryLabel="Egresos" />, kind: 'chart' },
    'charts.cashEvolution': { node: <ChartCard title="Evolución de caja" description="Saldo de Caja Principal durante 30 días" data={metrics.charts.cashEvolution} kind="line" />, kind: 'chart' },
  }), [layawayBankFunds, metrics, snapshot]);

  const active = useMemo(
    () => preferences.order.filter(key => preferences.visible[key] && definitions[key]),
    [definitions, preferences.order, preferences.visible],
  );
  const containerRef = useRef<HTMLElement>(null);
  const [containerWidth, setContainerWidth] = useState(0);
  const [viewportWidth, setViewportWidth] = useState(() => typeof window === 'undefined' ? 1280 : window.innerWidth);
  const [widgetHeights, setWidgetHeights] = useState<Partial<Record<DashboardWidgetKey, number>>>({});

  useLayoutEffect(() => {
    const element = containerRef.current;
    if (!element) return;
    const updateWidth = () => setContainerWidth(Math.max(0, Math.floor(element.getBoundingClientRect().width)));
    updateWidth();
    if (typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(updateWidth);
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const updateViewport = () => setViewportWidth(window.innerWidth);
    window.addEventListener('resize', updateViewport, { passive: true });
    return () => window.removeEventListener('resize', updateViewport);
  }, []);

  const handleHeightChange = useCallback((key: DashboardWidgetKey, height: number) => {
    setWidgetHeights(current => {
      if (Math.abs((current[key] || 0) - height) < 2) return current;
      return { ...current, [key]: height };
    });
  }, []);

  const masonryLayout = useMemo(() => {
    const columnCount = columnsForViewport(viewportWidth);
    if (containerWidth <= 0) return { height: 0, positions: {} as Partial<Record<DashboardWidgetKey, MasonryPosition>> };
    const columnWidth = Math.max(0, (containerWidth - MASONRY_GAP * (columnCount - 1)) / columnCount);
    const columnHeights = Array.from({ length: columnCount }, () => 0);
    const positions: Partial<Record<DashboardWidgetKey, MasonryPosition>> = {};

    active.forEach(key => {
      const definition = definitions[key];
      if (!definition) return;
      let targetColumn = 0;
      for (let index = 1; index < columnHeights.length; index += 1) {
        if (columnHeights[index] < columnHeights[targetColumn]) targetColumn = index;
      }
      const top = columnHeights[targetColumn];
      positions[key] = {
        left: targetColumn * (columnWidth + MASONRY_GAP),
        top,
        width: columnWidth,
      };
      const kind = definition.kind || 'kpi';
      columnHeights[targetColumn] = top + (widgetHeights[key] || estimatedHeightByKind[kind]) + MASONRY_GAP;
    });

    return {
      positions,
      height: Math.max(0, ...columnHeights) - (active.length > 0 ? MASONRY_GAP : 0),
    };
  }, [active, containerWidth, definitions, viewportWidth, widgetHeights]);
  if (active.length === 0) {
    return <Card className="border-dashed"><CardContent className="flex min-h-32 flex-col items-center justify-center p-4 text-center"><Gauge className="mb-2 h-7 w-7 text-muted-foreground" /><p className="font-semibold">No hay widgets activos</p><p className="mt-1 text-sm text-muted-foreground">Usa “Configurar Dashboard” para seleccionar indicadores.</p></CardContent></Card>;
  }

  return (
    <section
      ref={containerRef}
      className="relative w-full overflow-x-clip"
      style={{ height: `${masonryLayout.height}px` }}
      aria-label="Dashboard personalizable"
    >
      {active.map(key => {
        const definition = definitions[key];
        const position = masonryLayout.positions[key];
        if (!definition || !position) return null;
        return (
          <MasonryWidget
            key={key}
            widgetKey={key}
            position={position}
            onHeightChange={handleHeightChange}
          >
            {definition.node}
          </MasonryWidget>
        );
      })}
    </section>
  );
}

export default memo(DashboardWidgetGrid);
