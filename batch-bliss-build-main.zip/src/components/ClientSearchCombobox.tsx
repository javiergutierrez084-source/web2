import {
  useDeferredValue,
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
} from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import type { Contact } from '@/data/mockData';

interface ClientSearchComboboxProps {
  clients: Contact[];
  value: string;
  onChange: (clientId: string) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
}

interface IndexedClient {
  client: Contact;
  searchText: string;
}

const MAX_VISIBLE_RESULTS = 30;

const normalizeSearch = (value: string): string =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es')
    .trim();

const ClientSearchCombobox = ({
  clients,
  value,
  onChange,
  placeholder = 'Buscar por nombre, documento o teléfono...',
  disabled = false,
  className = '',
}: ClientSearchComboboxProps) => {
  const selectedClient = useMemo(
    () => clients.find(client => client.id === value),
    [clients, value],
  );
  const [query, setQuery] = useState(selectedClient?.name || '');
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const deferredQuery = useDeferredValue(query);
  const rootRef = useRef<HTMLDivElement>(null);
  const resultRefs = useRef<Array<HTMLButtonElement | null>>([]);

  const indexedClients = useMemo<IndexedClient[]>(
    () => clients.map(client => ({
      client,
      searchText: normalizeSearch([
        client.name,
        client.document,
        client.phone,
      ].filter(Boolean).join(' ')),
    })),
    [clients],
  );

  const results = useMemo(() => {
    const normalized = normalizeSearch(deferredQuery);
    if (!normalized) return indexedClients.slice(0, MAX_VISIBLE_RESULTS);

    const terms = normalized.split(/\s+/).filter(Boolean);
    const matches: IndexedClient[] = [];
    for (const indexed of indexedClients) {
      if (terms.every(term => indexed.searchText.includes(term))) {
        matches.push(indexed);
        if (matches.length >= MAX_VISIBLE_RESULTS) break;
      }
    }
    return matches;
  }, [deferredQuery, indexedClients]);

  useEffect(() => {
    if (!open) setQuery(selectedClient?.name || '');
  }, [open, selectedClient]);

  useEffect(() => {
    setActiveIndex(previous => Math.min(previous, Math.max(0, results.length - 1)));
  }, [results.length]);

  useEffect(() => {
    if (!open) return;
    resultRefs.current[activeIndex]?.scrollIntoView({ block: 'nearest' });
  }, [activeIndex, open]);

  useEffect(() => {
    const handlePointerDown = (event: MouseEvent) => {
      if (!rootRef.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handlePointerDown);
    return () => document.removeEventListener('mousedown', handlePointerDown);
  }, []);

  const selectClient = (client: Contact) => {
    onChange(client.id);
    setQuery(client.name);
    setOpen(false);
    setActiveIndex(0);
  };

  const handleKeyDown = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'ArrowDown') {
      event.preventDefault();
      if (!open) {
        setOpen(true);
        setActiveIndex(0);
      } else {
        setActiveIndex(index => Math.min(index + 1, Math.max(0, results.length - 1)));
      }
      return;
    }
    if (event.key === 'ArrowUp') {
      event.preventDefault();
      if (!open) {
        setOpen(true);
        setActiveIndex(Math.max(0, results.length - 1));
      } else {
        setActiveIndex(index => Math.max(0, index - 1));
      }
      return;
    }
    if (event.key === 'Enter' && open && results[activeIndex]) {
      event.preventDefault();
      selectClient(results[activeIndex].client);
      return;
    }
    if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
      setQuery(selectedClient?.name || '');
    }
  };

  const clearSelection = () => {
    onChange('');
    setQuery('');
    setOpen(true);
    setActiveIndex(0);
  };

  return (
    <div ref={rootRef} className={`relative min-w-0 ${className}`}>
      <Search className="pointer-events-none absolute left-3 top-1/2 z-10 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      <Input
        role="combobox"
        aria-autocomplete="list"
        aria-expanded={open}
        aria-controls="client-search-results"
        disabled={disabled}
        value={query}
        onFocus={event => {
          setOpen(true);
          event.currentTarget.select();
        }}
        onChange={event => {
          setQuery(event.target.value);
          setOpen(true);
          setActiveIndex(0);
          if (value) onChange('');
        }}
        onKeyDown={handleKeyDown}
        placeholder={placeholder}
        className="h-10 w-full min-w-0 bg-secondary/50 pl-9 pr-16 text-foreground placeholder:text-muted-foreground"
      />
      <div className="absolute right-2 top-1/2 z-10 flex -translate-y-1/2 items-center gap-1">
        {value && (
          <button
            type="button"
            onClick={clearSelection}
            className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
            aria-label="Quitar cliente seleccionado"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        )}
        <button
          type="button"
          onClick={() => setOpen(current => !current)}
          className="rounded p-1 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          aria-label="Mostrar clientes"
        >
          <ChevronDown className={`h-4 w-4 transition-transform ${open ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {open && !disabled && (
        <div
          id="client-search-results"
          role="listbox"
          className="absolute z-50 mt-1 max-h-72 w-full min-w-[280px] overflow-y-auto rounded-lg border border-border bg-popover p-1 shadow-xl"
        >
          {results.length === 0 ? (
            <div className="px-3 py-4 text-center text-sm text-muted-foreground">
              No se encontraron clientes
            </div>
          ) : (
            results.map(({ client }, index) => (
              <button
                key={client.id}
                ref={element => { resultRefs.current[index] = element; }}
                type="button"
                role="option"
                aria-selected={client.id === value}
                onMouseEnter={() => setActiveIndex(index)}
                onMouseDown={event => event.preventDefault()}
                onClick={() => selectClient(client)}
                className={`flex w-full min-w-0 items-center justify-between gap-3 rounded-md px-3 py-2 text-left transition-colors ${
                  index === activeIndex ? 'bg-secondary text-foreground' : 'text-popover-foreground hover:bg-secondary/70'
                }`}
              >
                <div className="min-w-0">
                  <p className="break-words text-sm font-medium">{client.name}</p>
                  <p className="break-words text-[11px] text-muted-foreground">
                    {client.document || 'Sin documento'}
                    {client.phone ? ` · ${client.phone}` : ''}
                  </p>
                </div>
                {client.id === value && <Check className="h-4 w-4 shrink-0 text-primary" />}
              </button>
            ))
          )}
          {results.length === MAX_VISIBLE_RESULTS && indexedClients.length > MAX_VISIBLE_RESULTS && (
            <p className="border-t border-border px-3 py-2 text-[10px] text-muted-foreground">
              Mostrando hasta {MAX_VISIBLE_RESULTS} resultados. Escribe más datos para precisar la búsqueda.
            </p>
          )}
        </div>
      )}
    </div>
  );
};

export default ClientSearchCombobox;
