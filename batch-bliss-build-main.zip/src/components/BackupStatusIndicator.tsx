import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle, HardDrive } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkMode } from '@/contexts/WorkModeContext';
import { useToast } from '@/hooks/use-toast';
import { logActivity } from '@/lib/auth';
import { BackupManager } from '@/lib/BackupManager';
import { BackupScheduler } from '@/lib/BackupScheduler';
import {
  PROFESSIONAL_BACKUP_STATUS_EVENT,
  ProfessionalBackupService,
  type ProfessionalBackupStatus,
} from '@/lib/ProfessionalBackupService';
import { BackupType, type BackupSettings } from '@/types/backup';

type BackupStatusIndicatorVariant = 'dashboard' | 'settings' | 'backup-page';

function timeAgo(value: string | null): string {
  if (!value) return 'Sin ejecuciones';
  const timestamp = Date.parse(value);
  if (!Number.isFinite(timestamp)) return value;
  const minutes = Math.max(0, Math.floor((Date.now() - timestamp) / 60_000));
  if (minutes < 1) return 'Hace menos de 1 minuto';
  if (minutes < 60) return `Hace ${minutes} minuto${minutes === 1 ? '' : 's'}`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `Hace ${hours} hora${hours === 1 ? '' : 's'}`;
  const days = Math.floor(hours / 24);
  return `Hace ${days} día${days === 1 ? '' : 's'}`;
}

function nextBackupIn(nextRunAt: number | null, now: number, running: boolean): string {
  if (!running || nextRunAt === null) return 'Programador detenido';
  const totalSeconds = Math.max(0, Math.ceil((nextRunAt - now) / 1000));
  if (totalSeconds <= 0) return 'Ejecutando...';
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  if (minutes === 0) return `${seconds} s`;
  return `${minutes} min ${String(seconds).padStart(2, '0')} s`;
}

function StatusLine({ label, ok, text }: { label: string; ok: boolean; text: string }) {
  return (
    <div className="flex items-center justify-between gap-3 text-xs">
      <span className="flex items-center gap-2 text-muted-foreground">
        {ok ? <CheckCircle className="h-3.5 w-3.5 text-success" /> : <AlertTriangle className="h-3.5 w-3.5 text-destructive" />}
        {label}
      </span>
      <span className="text-right font-medium text-foreground">{text}</span>
    </div>
  );
}

export default function BackupStatusIndicator({ variant = 'dashboard' }: { variant?: BackupStatusIndicatorVariant }) {
  const { effectiveMode } = useWorkMode();
  const { user } = useAuth();
  const { toast } = useToast();
  const [status, setStatus] = useState<ProfessionalBackupStatus | null>(null);
  const [settings, setSettings] = useState<BackupSettings | null>(null);
  const [lastAutomaticAt, setLastAutomaticAt] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [now, setNow] = useState(Date.now());
  const isPrincipalServer = effectiveMode === 'server';

  const load = useCallback(async () => {
    const [nextStatus, nextSettings, history] = await Promise.all([
      ProfessionalBackupService.getStatus(),
      BackupManager.loadSettings(),
      BackupManager.listHistory(100).catch(() => []),
    ]);
    setStatus(nextStatus);
    setSettings(nextSettings);
    setLastAutomaticAt(history.find(item => item.type === BackupType.AUTOMATIC)?.date ?? null);
    setNow(Date.now());
  }, []);

  useEffect(() => {
    let cancelled = false;
    const refresh = () => {
      void load().catch(error => {
        if (!cancelled) console.error('[Backup] No fue posible actualizar el indicador:', error);
      });
    };
    refresh();
    const statusTimer = window.setInterval(refresh, 30_000);
    const clockTimer = window.setInterval(() => setNow(Date.now()), 1_000);
    window.addEventListener(PROFESSIONAL_BACKUP_STATUS_EVENT, refresh);
    return () => {
      cancelled = true;
      window.clearInterval(statusTimer);
      window.clearInterval(clockTimer);
      window.removeEventListener(PROFESSIONAL_BACKUP_STATUS_EVENT, refresh);
    };
  }, [load]);

  // Self-heal installations where the persisted switch says ON but the
  // renderer was opened before the global automation bridge armed the timer.
  // onSettingsChanged() always replaces the existing timer, so this cannot
  // create a second scheduler instance.
  useEffect(() => {
    if (!isPrincipalServer || !settings?.backupEnabled || BackupScheduler.isArmed()) return;
    let cancelled = false;
    void BackupScheduler.onSettingsChanged()
      .then(() => {
        if (!cancelled) setNow(Date.now());
      })
      .catch(error => {
        if (!cancelled) console.error('[Backup] No fue posible iniciar el programador automático:', error);
      });
    return () => { cancelled = true; };
  }, [isPrincipalServer, settings?.backupEnabled]);

  const setAutomaticBackupEnabled = useCallback(async (enabled: boolean) => {
    if (!settings || saving) return;
    const previous = settings;
    const updated: BackupSettings = {
      ...settings,
      backupEnabled: enabled,
      backupInterval: '15m',
    };
    setSettings(updated);
    setSaving(true);
    try {
      await BackupManager.saveSettings(updated);
      await BackupScheduler.onSettingsChanged();
      if (user) {
        await logActivity(
          user,
          enabled ? 'BACKUP_AUTOMATIC_ENABLED' : 'BACKUP_AUTOMATIC_DISABLED',
          'BACKUP',
          'automatic-scheduler',
          JSON.stringify({ enabled, interval: '15m' }),
        ).catch(error => {
          console.warn('[Backup] No fue posible registrar el cambio en Activity Log:', error);
        });
      }
      window.dispatchEvent(new CustomEvent(PROFESSIONAL_BACKUP_STATUS_EVENT));
      await load();
    } catch (error) {
      setSettings(previous);
      const message = error instanceof Error ? error.message : String(error);
      console.error('[Backup] No fue posible cambiar el programador automático:', error);
      toast({ title: 'No fue posible cambiar el backup automático', description: message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }, [load, saving, settings, toast, user]);

  const settingsLoaded = settings !== null;
  const automaticEnabled = settings?.backupEnabled ?? false;
  const schedulerArmed = isPrincipalServer && BackupScheduler.isArmed();
  const schedulerRunning = automaticEnabled && schedulerArmed;
  const internalOk = status?.internal.status === 'success' || status?.internal.status === 'active';
  const externalOk = status?.external.status === 'success' || status?.external.status === 'ready';
  const externalText = status?.external.status === 'error'
    ? timeAgo(status.external.lastSuccessAt)
    : status?.external.configuredFolder
      ? timeAgo(status.external.lastSuccessAt)
      : 'Carpeta no configurada';
  const nextRunAt = schedulerRunning ? BackupScheduler.getNextRunAt() : null;
  const stateText = !settingsLoaded
    ? 'Cargando...'
    : schedulerRunning
      ? '🟢 Activo'
      : '🔴 Detenido';
  const stateOk = settingsLoaded && schedulerRunning;
  const nextExecutionText = nextBackupIn(nextRunAt, now, schedulerRunning);

  const visualClass = schedulerRunning
    ? 'border-emerald-500/40 bg-emerald-500/5'
    : 'border-red-500/40 bg-red-500/5';
  const statusDotClass = schedulerRunning
    ? 'bg-emerald-500 shadow-[0_0_0_4px_rgba(16,185,129,0.15)]'
    : 'bg-red-500 shadow-[0_0_0_4px_rgba(239,68,68,0.15)]';

  if (variant === 'dashboard') {
    return (
      <Link to="/respaldos" className="block rounded-xl border border-border bg-card/80 px-3 py-2 transition-colors hover:border-primary/35">
        <div className="mb-1 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          <span className={`h-2.5 w-2.5 rounded-full ${statusDotClass}`} /> Backup automático
        </div>
        <div className="space-y-1">
          <StatusLine label="Última ejecución" ok={internalOk} text={timeAgo(lastAutomaticAt)} />
          <StatusLine label="Próxima ejecución" ok={schedulerRunning && nextRunAt !== null} text={nextExecutionText} />
          <StatusLine label="Estado" ok={stateOk} text={stateText} />
        </div>
      </Link>
    );
  }

  const isBackupPage = variant === 'backup-page';

  return (
    <Card className={isBackupPage ? visualClass : undefined}>
      <CardHeader>
        <CardTitle className="flex flex-wrap items-center justify-between gap-4">
          <span className="flex items-center gap-3">
            <span className={`h-3 w-3 rounded-full ${statusDotClass}`} />
            <span>{isBackupPage ? 'BACKUP AUTOMÁTICO' : 'Backup Automático'}</span>
          </span>
          <div className="flex items-center gap-3">
            <span className={`text-sm font-bold ${schedulerRunning ? 'text-emerald-600' : 'text-red-600'}`}>
              {schedulerRunning ? 'ON' : 'OFF'}
            </span>
            <Switch
              checked={schedulerRunning}
              onCheckedChange={value => void setAutomaticBackupEnabled(value)}
              disabled={!isPrincipalServer || !settings || saving}
              aria-label="Activar o desactivar backup automático"
              className={isBackupPage ? 'scale-125 origin-right' : undefined}
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <StatusLine label="Estado" ok={stateOk} text={stateText} />
        <StatusLine label="Programador" ok={schedulerRunning} text={schedulerRunning ? 'Funcionando' : 'Programador detenido'} />
        <StatusLine label="Intervalo" ok={schedulerRunning} text="15 minutos" />
        <StatusLine label="Última ejecución" ok={lastAutomaticAt !== null} text={timeAgo(lastAutomaticAt)} />
        <StatusLine label="Próxima ejecución" ok={schedulerRunning && nextRunAt !== null} text={nextExecutionText} />
        {!isBackupPage && <StatusLine label="Backup externo" ok={externalOk} text={externalText} />}
        {!isBackupPage && status?.external.configuredFolder && (
          <div className="flex items-start gap-2 rounded-lg bg-muted p-3 text-xs text-muted-foreground">
            <HardDrive className="mt-0.5 h-4 w-4 shrink-0" />
            <span className="break-all">{status.external.configuredFolder}</span>
          </div>
        )}
        {!isPrincipalServer && (
          <p className="rounded-lg border border-amber-500/30 bg-amber-500/5 p-3 text-xs text-muted-foreground">
            Las copias automáticas se ejecutan exclusivamente en el Servidor Principal. El interruptor permanece visible y se habilita en ese equipo.
          </p>
        )}
        <p className="text-xs text-muted-foreground">
          Al desactivar se detiene únicamente el temporizador. Los respaldos manuales, OPFS, SHA-256, la cola, la retención, la carpeta externa y el historial se conservan.
        </p>
        {!isBackupPage && <Button asChild variant="outline" size="sm"><Link to="/respaldos">Administrar copias</Link></Button>}
      </CardContent>
    </Card>
  );
}
