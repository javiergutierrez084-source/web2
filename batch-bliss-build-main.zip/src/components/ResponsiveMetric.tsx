import { memo } from 'react';
import { formatCurrency } from '@/data/mockData';
import { cn } from '@/lib/utils';

type MetricFormat = 'currency' | 'number' | 'grams' | 'text';
type MetricSize = 'sm' | 'md' | 'lg' | 'xl';
type MetricAlign = 'left' | 'center' | 'right';

interface ResponsiveMetricProps {
  value: number | string;
  format?: MetricFormat;
  size?: MetricSize;
  className?: string;
  wrapperClassName?: string;
  compactFrom?: number;
  maximumFractionDigits?: number;
  align?: MetricAlign;
}

const compactFormatter = new Intl.NumberFormat('es-CO', {
  maximumFractionDigits: 1,
  minimumFractionDigits: 0,
});

const ALIGN_CLASSES: Record<MetricAlign, string> = {
  left: 'text-left',
  center: 'text-center',
  right: 'text-right',
};

const SIZE_CLASSES: Record<MetricSize, string> = {
  sm: 'text-[clamp(0.875rem,10cqi,1.125rem)]',
  md: 'text-[clamp(0.95rem,11cqi,1.25rem)]',
  lg: 'text-[clamp(1rem,12cqi,1.5rem)]',
  xl: 'text-[clamp(1rem,12cqi,1.875rem)]',
};

const compactMagnitude = (value: number): { amount: number; suffix: string } => {
  const absolute = Math.abs(value);
  if (absolute >= 1_000_000_000_000) return { amount: absolute / 1_000_000_000_000, suffix: ' B' };
  if (absolute >= 1_000_000_000) return { amount: absolute / 1_000_000_000, suffix: ' mil M' };
  return { amount: absolute / 1_000_000, suffix: ' M' };
};

const formatCompactNumber = (value: number, prefix = '', suffix = ''): string => {
  const compact = compactMagnitude(value);
  const sign = value < 0 ? '-' : '';
  return `${sign}${prefix}${compactFormatter.format(compact.amount)}${compact.suffix}${suffix}`;
};

const buildMetricText = (
  value: number | string,
  format: MetricFormat,
  compactFrom: number,
  maximumFractionDigits: number,
): { display: string; full: string } => {
  if (typeof value === 'string' || format === 'text') {
    const text = String(value);
    return { display: text, full: text };
  }

  if (!Number.isFinite(value)) return { display: '—', full: '—' };

  if (format === 'currency') {
    const full = formatCurrency(value);
    const display = Math.abs(value) >= compactFrom
      ? formatCompactNumber(value, '$')
      : full;
    return { display, full };
  }

  const full = new Intl.NumberFormat('es-CO', {
    maximumFractionDigits,
  }).format(value);

  if (format === 'grams') {
    const display = Math.abs(value) >= compactFrom
      ? formatCompactNumber(value, '', ' g')
      : `${full} g`;
    return { display, full: `${full} g` };
  }

  const display = Math.abs(value) >= compactFrom
    ? formatCompactNumber(value)
    : full;
  return { display, full };
};

const ResponsiveMetric = memo(({
  value,
  format = 'number',
  size = 'xl',
  className,
  wrapperClassName,
  compactFrom = 1_000_000,
  maximumFractionDigits = 2,
  align = 'center',
}: ResponsiveMetricProps) => {
  const { display, full } = buildMetricText(
    value,
    format,
    compactFrom,
    maximumFractionDigits,
  );

  return (
    <div
      className={cn(
        'w-full min-w-0 max-w-full [container-type:inline-size]',
        wrapperClassName,
      )}
    >
      <span
        className={cn(
          'block w-full max-w-full break-words whitespace-normal font-bold leading-tight tracking-tight',
          SIZE_CLASSES[size],
          ALIGN_CLASSES[align],
          className,
        )}
        title={full}
        aria-label={full}
      >
        {display}
      </span>
    </div>
  );
});

ResponsiveMetric.displayName = 'ResponsiveMetric';

export default ResponsiveMetric;
