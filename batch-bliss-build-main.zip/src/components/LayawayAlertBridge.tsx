import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ToastAction } from '@/components/ui/toast';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { buildLayawayAlertSummary, ensureLayawayDeadlines } from '@/lib/LayawayAlertService';

const LayawayAlertBridge = () => {
  const { layaways, isLoading } = useApp();
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const notifiedRef = useRef(false);

  useEffect(() => {
    if (isLoading) return;
    ensureLayawayDeadlines(layaways);
  }, [isLoading, layaways]);

  useEffect(() => {
    if (isLoading || notifiedRef.current) return;
    const sessionKey = `joyacontrol_layaway_alert_notice_v34:${user?.id || 'default'}`;
    if (window.sessionStorage.getItem(sessionKey)) {
      notifiedRef.current = true;
      return;
    }

    const registry = ensureLayawayDeadlines(layaways);
    const summary = buildLayawayAlertSummary(layaways, registry);
    if (summary.overdue <= 0 && summary.upcoming <= 0) return;

    notifiedRef.current = true;
    window.sessionStorage.setItem(sessionKey, '1');
    const title = summary.overdue > 0
      ? `⚠ Existen ${summary.overdue} separado${summary.overdue === 1 ? '' : 's'} vencido${summary.overdue === 1 ? '' : 's'}`
      : `⚠ Hay ${summary.upcoming} separado${summary.upcoming === 1 ? '' : 's'} próximo${summary.upcoming === 1 ? '' : 's'} a vencer`;
    const description = summary.overdue > 0 && summary.upcoming > 0
      ? `Además, ${summary.upcoming} separado${summary.upcoming === 1 ? '' : 's'} vence${summary.upcoming === 1 ? '' : 'n'} en los próximos 15 días.`
      : 'Revisa el estado y los últimos abonos registrados.';

    toast({
      title,
      description,
      action: (
        <ToastAction
          altText="Ir a separados"
          onClick={() => navigate(`/ventas?tab=layaways&filter=${summary.overdue > 0 ? 'overdue' : 'upcoming'}`)}
        >
          Ver
        </ToastAction>
      ),
    });
  }, [isLoading, layaways, navigate, toast, user?.id]);

  return null;
};

export default LayawayAlertBridge;
