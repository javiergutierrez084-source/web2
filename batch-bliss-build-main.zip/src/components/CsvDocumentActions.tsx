import { FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { TableDocumentData } from '@/lib/pdf';

interface CsvDocumentActionsProps {
  document: TableDocumentData | (() => TableDocumentData);
  label?: string;
}

const escapeCsv = (value: string): string => {
  const normalized = String(value ?? '');
  return /[",\n\r;]/.test(normalized)
    ? `"${normalized.replace(/"/g, '""')}"`
    : normalized;
};

export function buildCsvContent(document: TableDocumentData): string {
  const delimiter = ';';
  const lines = [
    document.columns.map(column => escapeCsv(column.header)).join(delimiter),
    ...document.rows.map(row => row.map(value => escapeCsv(value)).join(delimiter)),
  ];
  return `\uFEFF${lines.join('\r\n')}`;
}

const sanitizeFilename = (value: string): string => value
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .replace(/[^a-zA-Z0-9._-]+/g, '_')
  .replace(/^_+|_+$/g, '');

const CsvDocumentActions = ({ document, label = 'CSV' }: CsvDocumentActionsProps) => {
  const handleExport = () => {
    const resolved = typeof document === 'function' ? document() : document;
    const blob = new Blob([buildCsvContent(resolved)], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = window.document.createElement('a');
    anchor.href = url;
    anchor.download = `${sanitizeFilename(resolved.filename) || 'exportacion'}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  return (
    <Button type="button" variant="outline" size="sm" className="gap-2" onClick={handleExport}>
      <FileText className="h-4 w-4" />
      {label}
    </Button>
  );
};

export default CsvDocumentActions;
