import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useWorkMode } from '@/contexts/WorkModeContext';
import { ProfessionalBackupService } from '@/lib/ProfessionalBackupService';

const SecureCloseBridge = () => {
  const { user, logout } = useAuth();
  const { effectiveMode } = useWorkMode();

  useEffect(() => {
    window.joyaControlApp?.reportSessionState?.({
      authenticated: Boolean(user),
      mode: effectiveMode,
    });
  }, [effectiveMode, user]);

  useEffect(() => window.joyaControlApp?.onPrepareClose?.(async request => {
    const backupStatus = effectiveMode === 'server'
      ? await ProfessionalBackupService.getStatus().catch(() => ({ running: false, queued: 0 }))
      : { running: false, queued: 0 };

    if (request.logout && user) await logout();

    return {
      completed: true,
      authenticated: Boolean(request.logout ? false : user),
      mode: effectiveMode,
      backupActive: effectiveMode === 'server' && (backupStatus.running || backupStatus.queued > 0),
    };
  }), [effectiveMode, logout, user]);

  return null;
};

export default SecureCloseBridge;
