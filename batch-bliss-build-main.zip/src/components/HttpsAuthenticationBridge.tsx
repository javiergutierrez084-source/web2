import { useEffect } from 'react';
import { getDataRepository } from '@/repositories/RepositoryRegistry';

export default function HttpsAuthenticationBridge() {
  useEffect(() => {
    const dispose = window.joyaControlHttps?.onAuthRequest?.(async request => {
      try {
        const session = await getDataRepository().loginUser(request.username, request.password);
        return {
          success: true,
          userId: session.id,
          username: session.username,
          displayName: session.displayName,
          role: session.role,
        };
      } catch (error) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'HTTPS_AUTH_FAILED',
        };
      }
    });

    return () => dispose?.();
  }, []);

  return null;
}
