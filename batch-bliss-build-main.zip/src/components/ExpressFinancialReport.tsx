import { useMemo } from 'react';
import {
  AlertTriangle,
  Banknote,
  Building2,
  ChevronDown,
  CircleDollarSign,
  FileChartColumnIncreasing,
  HandCoins,
  Landmark,
  ReceiptText,
  ShieldCheck,
  WalletCards,
} from 'lucide-react';
import type {
  ExpenseInvoice,
  FinancialAccount,
  FinancialMovement,
  Invoice,
  PurchaseInvoice,
} from '@/data/mockData';
import { formatCurrency } from '@/data/mockData';
import type { CompanyInfo, Layaway, SupplierInvoiceView } from '@/domain/models';
import { buildTableDocumentData } from '@/lib/pdf';
import PdfDocumentActions from '@/components/PdfDocumentActions';
import ExcelDocumentActions from '@/components/ExcelDocumentActions';
import CsvDocumentActions from '@/components/CsvDocumentActions';
import { Button } from '@/components/ui/button';
import {
  buildExpressFinancialReport,
  type ExpressReportDetailRow,
} from '@/lib/ExpressFinancialReportService';
import {
  buildReportDateRange,
  describeReportDateRange,
  type ReportDateRange,
} from '@/lib/reportDateRange';

interface ExpressFinancialReportProps {
  company: CompanyInfo;
  accounts: FinancialAccount[];
  movements: FinancialMovement[];
  invoices: Invoice[];
  purchases: PurchaseInvoice[];
  expenses: ExpenseInvoice[];
  layaways: Layaway[];
  supplierInvoices: SupplierInvoiceView[];
  range: ReportDateRange;
  onRangeChange: (range: ReportDateRange) => void;
}

interface DetailSectionProps {
  title: string;
  total: number;
  rows: ExpressReportDetailRow[];
  emptyLabel?: string;
}

const moneyTone = (value: number): string => value < 0 ? 'text-destructive' : 'text-foreground';

const DetailSection = ({ title, total, rows, emptyLabel = 'Sin movimientos en el período.' }: DetailSectionProps) => (
  <details className="group rounded-xl border border-border bg-card">
    <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3">
      <span className="min-w-0">
        <span className="block text-sm font-semibold">{title}</span>
        <span className="block text-xs text-muted-foreground">{rows.length} movimiento{rows.length === 1 ? '' : 's'} trazable{rows.length === 1 ? '' : 's'}</span>
      </span>
      <span className="flex shrink-0 items-center gap-2">
        <span className={`font-semibold ${moneyTone(total)}`}>{formatCurrency(total)}</span>
        <ChevronDown className="h-4 w-4 transition-transform group-open:rotate-180" />
      </span>
    </summary>
    <div className="border-t border-border px-4 py-3">
      {rows.length === 0 ? (
        <p className="text-sm text-muted-foreground">{emptyLabel}</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[680px] text-sm">
            <thead>
              <tr className="text-left text-xs text-muted-foreground">
                <th className="pb-2 pr-3">Fecha</th>
                <th className="pb-2 pr-3">Documento</th>
                <th className="pb-2 pr-3">Detalle</th>
                <th className="pb-2 pr-3">Cuenta</th>
                <th className="pb-2 text-right">Valor</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(row => (
                <tr key={row.id} className="border-t border-border/60">
                  <td className="py-2 pr-3 whitespace-nowrap">{row.date}</td>
                  <td className="py-2 pr-3 font-mono text-xs">{row.document}</td>
                  <td className="py-2 pr-3">{row.description}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{row.account}</td>
                  <td className={`py-2 text-right font-semibold ${moneyTone(row.signedValue)}`}>{formatCurrency(row.signedValue)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  </details>
);

const Metric = ({ label, value, note }: { label: string; value: number; note?: string }) => (
  <div className="rounded-xl border border-border bg-card p-4">
    <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">{label}</p>
    <p className="mt-1 text-2xl font-bold">{formatCurrency(value)}</p>
    {note && <p className="mt-1 text-xs text-muted-foreground">{note}</p>}
  </div>
);

const ExpressFinancialReport = ({
  company,
  accounts,
  movements,
  invoices,
  purchases,
  expenses,
  layaways,
  supplierInvoices,
  range,
  onRangeChange,
}: ExpressFinancialReportProps) => {
  const report = useMemo(() => buildExpressFinancialReport({
    accounts,
    movements,
    invoices,
    purchases,
    expenses,
    layaways,
    supplierInvoices,
    range,
  }), [accounts, movements, invoices, purchases, expenses, layaways, supplierInvoices, range]);

  const rangeLabel = describeReportDateRange(range);
  const reconciliationMovementsNet = report.details.reconciliationMovements.reduce((sum, row) => sum + row.signedValue, 0);
  const reconciliationTone = report.reconciliation.reconciled
    ? 'border-success/30 bg-success/5 text-success'
    : 'border-destructive/40 bg-destructive/5 text-destructive';

  const exportDocument = useMemo(() => buildTableDocumentData({
    company,
    title: 'Informe Express - Situación Financiera Consolidada',
    subtitle: `${rangeLabel} · Total Disponible oficial: ${formatCurrency(report.current.totalAvailable)}`,
    columns: [
      { header: 'Sección' },
      { header: 'Fecha' },
      { header: 'Documento' },
      { header: 'Detalle' },
      { header: 'Cuenta' },
      { header: 'Valor', align: 'right' },
    ],
    rows: [
      ...report.details.sales.map(row => ['Ventas válidas', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.supplierPayments.map(row => ['Pagos proveedores', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.expenses.map(row => ['Gastos', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.ownerWithdrawals.map(row => ['Retiros propietario', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.otherIncome.map(row => ['Otros ingresos', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.otherOutflows.map(row => ['Otros egresos', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.layawayReleased.map(row => ['Fondos liberados de separados', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
      ...report.details.reconciliationMovements.map(row => ['Movimientos de conciliación', row.date, row.document, row.description, row.account, formatCurrency(row.signedValue)]),
    ],
    summaryLines: [
      { label: 'Caja Principal actual', value: formatCurrency(report.current.mainCash) },
      { label: 'Bancos actuales', value: formatCurrency(report.current.banks) },
      { label: 'TOTAL DISPONIBLE ACTUAL', value: formatCurrency(report.current.totalAvailable), bold: true },
      { label: 'Ventas válidas del período', value: formatCurrency(report.period.validSales) },
      { label: 'Salidas del período', value: formatCurrency(report.period.totalOutflows) },
      { label: 'Retiros del propietario', value: formatCurrency(report.period.ownerWithdrawals) },
      { label: 'Fondos reservados en separados', value: formatCurrency(report.layaways.totalReserved) },
      { label: 'Cuentas por pagar pendientes', value: formatCurrency(report.period.accountsPayablePending) },
      { label: 'Total disponible conciliado', value: formatCurrency(report.reconciliation.reconciledCurrentAvailable), bold: true },
      { label: 'Diferencia de conciliación', value: formatCurrency(report.reconciliation.difference) },
    ],
  }), [company, rangeLabel, report]);

  const useCurrentSituation = () => onRangeChange(buildReportDateRange('all'));
  const useCurrentMonth = () => onRangeChange(buildReportDateRange('currentMonth'));
  const usePreviousMonth = () => onRangeChange(buildReportDateRange('previousMonth'));

  return (
    <div className="space-y-5">
      <section className="rounded-2xl border border-primary/25 bg-primary/5 p-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <FileChartColumnIncreasing className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">INFORME EXPRESS</h2>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Período: {rangeLabel}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <PdfDocumentActions document={exportDocument} formats={['letter']} label="PDF / Imprimir" />
            <ExcelDocumentActions document={exportDocument} label="Excel" />
            <CsvDocumentActions document={exportDocument} label="CSV" />
          </div>
        </div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button type="button" size="sm" variant={range.preset === 'all' ? 'default' : 'outline'} onClick={useCurrentSituation}>Situación actual</Button>
          <Button type="button" size="sm" variant={range.preset === 'currentMonth' ? 'default' : 'outline'} onClick={useCurrentMonth}>Mes actual</Button>
          <Button type="button" size="sm" variant={range.preset === 'previousMonth' ? 'default' : 'outline'} onClick={usePreviousMonth}>Mes anterior</Button>
          <Button type="button" size="sm" variant={range.preset === 'custom' ? 'default' : 'outline'} onClick={() => onRangeChange({ ...range, preset: 'custom' })}>Mes personalizado</Button>
        </div>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-6">
        <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 sm:col-span-2">
          <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">TOTAL DISPONIBLE ACTUAL</p>
          <p className="mt-1 text-3xl font-bold gold-text">{formatCurrency(report.current.totalAvailable)}</p>
          <p className="mt-1 text-xs text-muted-foreground">Misma fuente oficial usada por Dashboard → Total Disponible.</p>
        </div>
        <Metric label="Ventas del período" value={report.period.validSales} note={`${report.period.validSalesCount} factura${report.period.validSalesCount === 1 ? '' : 's'} válida${report.period.validSalesCount === 1 ? '' : 's'}`} />
        <Metric label="Total egresos" value={report.period.totalOutflows} />
        <Metric label="Retiros propietario" value={report.period.ownerWithdrawals} />
        <Metric label="Fondos en separados" value={report.layaways.totalReserved} note="Reservado; no disponible" />
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><WalletCards className="h-4 w-4 text-primary" /> Composición del Total Disponible</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Caja Principal</span><span className="font-semibold">{formatCurrency(report.current.mainCash)}</span></div>
            <div className="flex justify-between gap-4"><span>Bancos</span><span className="font-semibold">{formatCurrency(report.current.banks)}</span></div>
            <div className="border-t border-border pt-3 flex justify-between gap-4 text-base"><strong>TOTAL DISPONIBLE</strong><strong>{formatCurrency(report.current.totalAvailable)}</strong></div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Caja Separados no se suma al Total Disponible.</p>
        </div>

        <div className={`rounded-xl border p-5 ${reconciliationTone}`}>
          <h3 className="flex items-center gap-2 font-semibold"><ShieldCheck className="h-4 w-4" /> Conciliación con Dashboard</h3>
          <p className="mt-2 text-2xl font-bold">{report.reconciliation.reconciled ? 'Conciliado' : 'ERROR DE CONCILIACIÓN'}</p>
          <div className="mt-3 space-y-1 text-sm">
            <div className="flex justify-between gap-4"><span>Dashboard / fuente oficial</span><strong>{formatCurrency(report.reconciliation.officialCurrentAvailable)}</strong></div>
            <div className="flex justify-between gap-4"><span>Informe conciliado</span><strong>{formatCurrency(report.reconciliation.reconciledCurrentAvailable)}</strong></div>
            <div className="flex justify-between gap-4"><span>Diferencia</span><strong>{formatCurrency(report.reconciliation.difference)}</strong></div>
          </div>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><CircleDollarSign className="h-4 w-4 text-success" /> Origen de los fondos del período</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Ventas cobradas hacia Caja/Bancos</span><strong>{formatCurrency(report.period.saleCollections)}</strong></div>
            <div className="flex justify-between gap-4"><span>Otros ingresos reales</span><strong>{formatCurrency(report.period.otherIncome)}</strong></div>
            <div className="flex justify-between gap-4"><span>Fondos liberados de separados</span><strong>{formatCurrency(report.period.layawayReleased)}</strong></div>
            <div className="border-t border-border pt-3 flex justify-between gap-4"><strong>Entradas consideradas</strong><strong>{formatCurrency(report.period.entriesConsidered)}</strong></div>
          </div>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><HandCoins className="h-4 w-4 text-warning" /> Salidas de dinero del período</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Compras / pagos a proveedores</span><strong>{formatCurrency(report.period.supplierPayments)}</strong></div>
            <div className="flex justify-between gap-4"><span>Gastos</span><strong>{formatCurrency(report.period.expenses)}</strong></div>
            <div className="flex justify-between gap-4"><span>Retiros del propietario</span><strong>{formatCurrency(report.period.ownerWithdrawals)}</strong></div>
            <div className="flex justify-between gap-4"><span>Otros egresos</span><strong>{formatCurrency(report.period.otherOutflows)}</strong></div>
            <div className="border-t border-border pt-3 flex justify-between gap-4"><strong>TOTAL SALIDAS</strong><strong>{formatCurrency(report.period.totalOutflows)}</strong></div>
          </div>
        </div>
      </section>

      {report.expenseGroups.length > 0 && (
        <section className="rounded-xl border border-border bg-card p-5">
          <h3 className="font-semibold">Comisiones, servicios y gastos según conceptos existentes</h3>
          <p className="mt-1 text-xs text-muted-foreground">No se inventan categorías: se muestran exactamente los conceptos persistidos en los movimientos de gasto.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
            {report.expenseGroups.map(group => (
              <div key={group.label} className="rounded-lg border border-border/70 bg-secondary/20 p-3">
                <p className="text-xs text-muted-foreground">{group.label}</p>
                <p className="mt-1 text-lg font-bold">{formatCurrency(group.total)}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      <section className="grid gap-4 xl:grid-cols-3">
        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><ReceiptText className="h-4 w-4 text-primary" /> Fondos de separados</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Abonos reservados en efectivo</span><strong>{formatCurrency(report.layaways.cashReserved)}</strong></div>
            <div className="flex justify-between gap-4"><span>Abonos reservados en bancos</span><strong>{formatCurrency(report.layaways.bankReserved)}</strong></div>
            <div className="border-t border-border pt-3 flex justify-between gap-4"><strong>Total reservado</strong><strong>{formatCurrency(report.layaways.totalReserved)}</strong></div>
          </div>
          <p className="mt-3 text-xs text-warning">Los abonos de separados no son ventas y no se suman nuevamente al Total Disponible.</p>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><Building2 className="h-4 w-4 text-primary" /> Compras y cuentas por pagar</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Compras registradas</span><strong>{formatCurrency(report.period.purchasesRegistered)}</strong></div>
            <div className="flex justify-between gap-4"><span>Pagos realizados a proveedores</span><strong>{formatCurrency(report.period.supplierPayments)}</strong></div>
            <div className="flex justify-between gap-4"><span>Cuentas por pagar pendientes</span><strong>{formatCurrency(report.period.accountsPayablePending)}</strong></div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Una obligación pendiente no reduce Caja/Bancos hasta que exista un pago real.</p>
        </div>

        <div className="rounded-xl border border-border bg-card p-5">
          <h3 className="flex items-center gap-2 font-semibold"><Landmark className="h-4 w-4 text-primary" /> Bancos</h3>
          <div className="mt-4 space-y-3 text-sm">
            <div className="flex justify-between gap-4"><span>Bancos disponibles</span><strong>{formatCurrency(report.current.banks)}</strong></div>
            <div className="flex justify-between gap-4"><span>Ventas bancarias</span><strong>{formatCurrency(report.bankPeriod.bankSales)}</strong></div>
            <div className="flex justify-between gap-4"><span>Otros ingresos bancarios</span><strong>{formatCurrency(report.bankPeriod.otherIncome)}</strong></div>
            <div className="flex justify-between gap-4"><span>Transferencias</span><strong>{formatCurrency(report.bankPeriod.transfers)}</strong></div>
            <div className="flex justify-between gap-4 text-warning"><span>Fondos provenientes de separados</span><strong>{formatCurrency(report.bankPeriod.layawayFunds)}</strong></div>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Los fondos de separados son informativos y no corresponden a ventas realizadas.</p>
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card p-5">
        <h3 className="flex items-center gap-2 font-semibold"><Banknote className="h-4 w-4 text-primary" /> Cómo se llega al dinero disponible</h3>
        <div className="mt-4 grid gap-x-8 gap-y-2 text-sm md:grid-cols-[minmax(0,1fr)_auto]">
          <span>Saldo disponible al inicio del período</span><strong className="text-right">{formatCurrency(report.reconciliation.openingAvailable)}</strong>
          <span>(+) Ventas cobradas hacia Caja/Bancos</span><strong className="text-right text-success">{formatCurrency(report.period.saleCollections)}</strong>
          <span>(+) Otros ingresos</span><strong className="text-right text-success">{formatCurrency(report.period.otherIncome)}</strong>
          <span>(+) Fondos liberados de separados</span><strong className="text-right text-success">{formatCurrency(report.period.layawayReleased)}</strong>
          <span>(−) Compras / pagos a proveedores</span><strong className="text-right text-destructive">{formatCurrency(report.period.supplierPayments)}</strong>
          <span>(−) Gastos</span><strong className="text-right text-destructive">{formatCurrency(report.period.expenses)}</strong>
          <span>(−) Retiros del propietario</span><strong className="text-right text-destructive">{formatCurrency(report.period.ownerWithdrawals)}</strong>
          <span>(−) Otros egresos</span><strong className="text-right text-destructive">{formatCurrency(report.period.otherOutflows)}</strong>
          <span>(+/-) Anulaciones, aperturas y otros movimientos de conciliación</span><strong className="text-right">{formatCurrency(reconciliationMovementsNet)}</strong>
          <span className="border-t border-border pt-3">Resultado / movimiento neto del período</span><strong className="border-t border-border pt-3 text-right">{formatCurrency(report.reconciliation.periodNetMovement)}</strong>
          <span>Disponible al cierre del período</span><strong className="text-right">{formatCurrency(report.reconciliation.closingAvailable)}</strong>
          {(range.from || range.to) && <><span>(+/-) Movimientos posteriores al período</span><strong className="text-right">{formatCurrency(report.reconciliation.postPeriodMovement)}</strong></>}
          <span className="border-t border-border pt-3 font-bold">Total disponible conciliado actual</span><strong className="border-t border-border pt-3 text-right text-base">{formatCurrency(report.reconciliation.reconciledCurrentAvailable)}</strong>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">El puente utiliza únicamente los movimientos que ya participan en la composición oficial de Total Disponible. Las transferencias internas que no cambian disponibilidad no generan un ingreso o egreso artificial.</p>
      </section>

      <section className="rounded-xl border border-border bg-secondary/20 p-5">
        <h3 className="font-semibold">Ventas del período ≠ dinero disponible</h3>
        <p className="mt-2 text-sm text-muted-foreground">Las ventas válidas miden actividad comercial. El dinero disponible incorpora además saldos iniciales, cobros, pagos a proveedores, gastos, retiros del propietario, movimientos financieros y la separación de fondos reservados. Por eso ambos valores pueden ser distintos sin que exista un error.</p>
        <div className="mt-3 grid gap-3 sm:grid-cols-3">
          <Metric label="Ventas válidas" value={report.period.validSales} />
          <Metric label="Flujo neto del período" value={report.period.netCashFlow} />
          <Metric label="Total disponible actual" value={report.current.totalAvailable} />
        </div>
      </section>

      <section className="space-y-2">
        <h3 className="font-semibold">Detalle desplegable y trazabilidad</h3>
        <DetailSection title="Ventas válidas" total={report.period.validSales} rows={report.details.sales} />
        <DetailSection title="Pagos realizados a proveedores" total={-report.period.supplierPayments} rows={report.details.supplierPayments} />
        <DetailSection title="Gastos" total={-report.period.expenses} rows={report.details.expenses} />
        <DetailSection title="Retiros del propietario" total={-report.period.ownerWithdrawals} rows={report.details.ownerWithdrawals} />
        <DetailSection title="Otros ingresos" total={report.period.otherIncome} rows={report.details.otherIncome} />
        <DetailSection title="Otros egresos" total={-report.period.otherOutflows} rows={report.details.otherOutflows} />
        <DetailSection title="Fondos liberados de separados" total={report.period.layawayReleased} rows={report.details.layawayReleased} />
        <DetailSection title="Movimientos de conciliación / anulaciones" total={reconciliationMovementsNet} rows={report.details.reconciliationMovements} />
      </section>

      {!report.reconciliation.reconciled && (
        <div className="flex gap-3 rounded-xl border border-destructive/40 bg-destructive/5 p-4 text-sm text-destructive">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          El Informe Express detectó una diferencia frente al Total Disponible oficial. La diferencia se muestra explícitamente y no ha sido corregida ni ocultada por el informe.
        </div>
      )}
    </div>
  );
};

export default ExpressFinancialReport;
