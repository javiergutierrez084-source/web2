import { useState, useRef } from 'react';
import { Upload, FileSpreadsheet, Download, CheckCircle2, XCircle, AlertTriangle, Loader2, Tag, FileSearch, ListChecks, Tags, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { useApp } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { logActivity } from '@/lib/auth';
import { parseExcelFile, runBulkImport, downloadImportTemplate, type ImportSummary, type ImportProgress } from '@/lib/bulkImport';

interface BulkImportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

type Stage = 'idle' | 'processing' | 'done' | 'error';

type StepKey = 'reading' | 'validating' | 'categories' | 'inserting';

const STEPS: { key: StepKey; label: string; icon: typeof FileSearch }[] = [
  { key: 'reading', label: 'Leyendo archivo Excel', icon: FileSearch },
  { key: 'validating', label: 'Validando productos', icon: ListChecks },
  { key: 'categories', label: 'Creando categorías y proveedores', icon: Tags },
  { key: 'inserting', label: 'Insertando productos', icon: Database },
];

const STEP_ORDER: Record<StepKey, number> = { reading: 0, validating: 1, categories: 2, inserting: 3 };

const BulkImportDialog = ({ open, onOpenChange }: BulkImportDialogProps) => {
  const { products, refreshProducts } = useApp();
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stage, setStage] = useState<Stage>('idle');
  const [fileName, setFileName] = useState('');
  const [summary, setSummary] = useState<ImportSummary | null>(null);
  const [errorMsg, setErrorMsg] = useState('');
  const [progress, setProgress] = useState<ImportProgress>({ stage: 'reading', progress: 0, message: '' });

  const reset = () => {
    setStage('idle');
    setFileName('');
    setSummary(null);
    setErrorMsg('');
    setProgress({ stage: 'reading', progress: 0, message: '' });
  };

  const handleClose = (isOpen: boolean) => {
    if (!isOpen && stage !== 'processing') reset();
    if (!isOpen && stage === 'processing') return; // bloquear cierre durante proceso
    onOpenChange(isOpen);
  };

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);
    setStage('processing');
    setErrorMsg('');
    setProgress({ stage: 'reading', progress: 5, message: 'Leyendo archivo Excel...' });

    try {
      const rows = await parseExcelFile(file);
      setProgress({ stage: 'reading', progress: 15, message: `Archivo leído: ${rows.length} filas` });

      const existingCodes = new Set(products.map(p => p.code));
      const { summary: result } = await runBulkImport(rows, existingCodes, (p) => {
        setProgress(p);
      });

      // The import already committed through the repository. Refresh React
      // state without issuing a second product write.
      await refreshProducts();

      setSummary(result);
      setStage('done');

      if (user) {
        await logActivity(
          user,
          'PRODUCT_CREATED',
          'product',
          'bulk_import',
          `Importación masiva: ${result.productsCreated} productos, ${result.categoriesCreated.length} categorías nuevas`
        );
      }
    } catch (err: any) {
      setErrorMsg(err.message || 'Error al procesar el archivo');
      setStage('error');
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const currentStepIndex = (() => {
    if (progress.stage === 'done') return STEPS.length;
    return STEP_ORDER[progress.stage as StepKey] ?? 0;
  })();

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-primary" />
            Carga Masiva de Productos
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-2">
          {stage === 'idle' && (
            <>
              <div className="rounded-lg border border-dashed border-border bg-secondary/30 p-8 text-center space-y-3">
                <Upload className="h-8 w-8 mx-auto text-muted-foreground" />
                <div>
                  <p className="text-sm font-medium">Selecciona un archivo Excel (.xlsx)</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Columnas requeridas: Código, Nombre, Categoría
                  </p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx,.xls"
                  onChange={handleFileSelect}
                  className="hidden"
                  id="bulk-import-file"
                />
                <Button
                  onClick={() => fileInputRef.current?.click()}
                  className="gold-gradient text-primary-foreground font-semibold gap-2"
                >
                  <Upload className="h-4 w-4" /> Seleccionar archivo
                </Button>
              </div>

              <button
                onClick={downloadImportTemplate}
                className="w-full flex items-center justify-center gap-2 text-sm text-primary hover:underline"
              >
                <Download className="h-4 w-4" /> Descargar plantilla de ejemplo
              </button>

              <div className="rounded-lg bg-secondary/30 p-4 space-y-1.5">
                <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Cómo funciona la Categoría</p>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Escribe el nombre que quieras (ej: "anillos", "ANILLOS", "  Anillos  ").
                  El sistema las reconoce como la misma categoría automáticamente, ignorando mayúsculas y espacios.
                  Si la categoría no existe, se crea sola — sin pedirte confirmación.
                </p>
              </div>
            </>
          )}

          {stage === 'processing' && (
            <div className="py-4 space-y-5">
              <div className="text-center space-y-1">
                <p className="break-all text-sm font-medium">{fileName}</p>
                <p className="text-xs text-muted-foreground">{progress.message || 'Procesando...'}</p>
              </div>

              <div className="space-y-1.5">
                <Progress value={progress.progress} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>
                    {progress.processed !== undefined && progress.total !== undefined
                      ? `${progress.processed} / ${progress.total} filas`
                      : 'Procesando...'}
                  </span>
                  <span className="font-medium text-primary">{progress.progress}%</span>
                </div>
              </div>

              <div className="space-y-2">
                {STEPS.map((step, i) => {
                  const Icon = step.icon;
                  const isDone = i < currentStepIndex;
                  const isActive = i === currentStepIndex;
                  return (
                    <div
                      key={step.key}
                      className={`flex items-center gap-3 rounded-md px-3 py-2 transition-colors ${
                        isActive ? 'bg-primary/10 border border-primary/30' : 'bg-secondary/30'
                      }`}
                    >
                      <div className="shrink-0">
                        {isDone ? (
                          <CheckCircle2 className="h-4 w-4 text-green-500" />
                        ) : isActive ? (
                          <Loader2 className="h-4 w-4 text-primary animate-spin" />
                        ) : (
                          <Icon className="h-4 w-4 text-muted-foreground" />
                        )}
                      </div>
                      <span
                        className={`text-xs ${
                          isActive
                            ? 'font-medium text-foreground'
                            : isDone
                            ? 'text-muted-foreground line-through'
                            : 'text-muted-foreground'
                        }`}
                      >
                        {step.label}
                      </span>
                    </div>
                  );
                })}
              </div>

              <p className="text-[11px] text-center text-muted-foreground">
                No cierres esta ventana hasta que finalice.
              </p>
            </div>
          )}

          {stage === 'error' && (
            <div className="space-y-4">
              <div className="rounded-lg bg-destructive/10 border border-destructive/20 p-4 flex items-start gap-3">
                <XCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-destructive">No se pudo procesar el archivo</p>
                  <p className="text-xs text-muted-foreground mt-1">{errorMsg}</p>
                </div>
              </div>
              <Button variant="outline" onClick={reset} className="w-full">Intentar de nuevo</Button>
            </div>
          )}

          {stage === 'done' && summary && (
            <div className="space-y-4">
              <div className="rounded-lg bg-green-500/10 border border-green-500/20 p-4 flex items-center gap-3">
                <CheckCircle2 className="h-6 w-6 text-green-500 shrink-0" />
                <div>
                  <p className="font-semibold text-sm">Importación completada</p>
                  <p className="text-xs text-muted-foreground">{fileName}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg border border-border bg-card p-3">
                  <p className="text-2xl font-bold text-green-500">{summary.productsCreated}</p>
                  <p className="text-xs text-muted-foreground">Productos creados</p>
                </div>
                <div className="rounded-lg border border-border bg-card p-3">
                  <p className="text-2xl font-bold text-primary">{summary.categoriesCreated.length}</p>
                  <p className="text-xs text-muted-foreground">Categorías nuevas</p>
                </div>
              </div>

              {summary.categoriesCreated.length > 0 && (
                <div className="rounded-lg bg-primary/5 border border-primary/20 p-4 space-y-2">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <Tag className="h-3.5 w-3.5" /> Categorías creadas automáticamente
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {summary.categoriesCreated.map(cat => (
                      <span key={cat} className="text-xs px-2.5 py-1 rounded-full bg-primary/10 text-primary font-medium">
                        {cat}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {summary.errors.length > 0 && (
                <div className="rounded-lg bg-destructive/5 border border-destructive/20 p-4 space-y-2">
                  <p className="text-xs font-medium uppercase tracking-wider text-destructive flex items-center gap-1.5">
                    <AlertTriangle className="h-3.5 w-3.5" /> Productos con errores ({summary.errors.length})
                  </p>
                  <div className="max-h-40 overflow-y-auto space-y-1">
                    {summary.errors.slice(0, 50).map((err, i) => (
                      <div key={i} className="text-xs flex items-center justify-between gap-2 py-1 border-b border-border/50 last:border-0">
                        <span className="text-muted-foreground">Fila {err.row} · {err.code}</span>
                        <span className="text-destructive text-right">{err.reason}</span>
                      </div>
                    ))}
                    {summary.errors.length > 50 && (
                      <p className="text-xs text-muted-foreground pt-1">
                        + {summary.errors.length - 50} errores más
                      </p>
                    )}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button onClick={reset} variant="outline" className="flex-1">Importar otro archivo</Button>
                <Button onClick={() => handleClose(false)} className="flex-1 gold-gradient text-primary-foreground">Finalizar</Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BulkImportDialog;
