import { useState, useEffect } from 'react';
import { Diamond } from 'lucide-react';
import { APP_VERSION_TEXT } from '@/config/appVersion';

interface SplashScreenProps {
  onFinish?: () => void;
  persistent?: boolean;
}

const SplashScreen = ({ onFinish, persistent = false }: SplashScreenProps) => {
  const [fadeOut, setFadeOut] = useState(false);

  useEffect(() => {
    if (persistent) return undefined;
    const fadeTimer = setTimeout(() => setFadeOut(true), 2500);
    const finishTimer = setTimeout(() => onFinish?.(), 3000);
    return () => { clearTimeout(fadeTimer); clearTimeout(finishTimer); };
  }, [onFinish, persistent]);

  return (
    <div className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-background transition-opacity duration-500 ${!persistent && fadeOut ? 'opacity-0' : 'opacity-100'}`}>
      <div className="flex flex-col items-center gap-6 animate-fade-in">
        <div className="flex h-24 w-24 items-center justify-center rounded-2xl gold-gradient shadow-2xl">
          <Diamond className="h-12 w-12 text-primary-foreground" />
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-bold gold-text tracking-tight">JoyaControl</h1>
          <p className="text-sm text-muted-foreground mt-2">Sistema de Gestión para Joyería</p>
        </div>
        <div className="flex flex-col items-center gap-1 mt-8">
          <p className="text-xs text-muted-foreground font-semibold">{APP_VERSION_TEXT}</p>
          <p className="text-xs text-muted-foreground">100% Local · Sin internet</p>
        </div>
        <div className="mt-4 h-1 w-32 rounded-full bg-secondary overflow-hidden">
          <div className="h-full rounded-full gold-gradient animate-pulse" style={{ width: '100%' }} />
        </div>
      </div>
    </div>
  );
};

export default SplashScreen;
