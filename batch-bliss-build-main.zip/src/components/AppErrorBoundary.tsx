import { Component, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, RefreshCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface AppErrorBoundaryProps {
  children: ReactNode;
}

interface AppErrorBoundaryState {
  hasError: boolean;
}

class AppErrorBoundary extends Component<AppErrorBoundaryProps, AppErrorBoundaryState> {
  state: AppErrorBoundaryState = { hasError: false };

  static getDerivedStateFromError(): AppErrorBoundaryState {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: ErrorInfo): void {
    if (import.meta.env.DEV) {
      console.error('[JoyaControl UI boundary]', error, info.componentStack);
    }
  }

  private reset = (): void => {
    this.setState({ hasError: false });
  };

  private reload = (): void => {
    window.location.reload();
  };

  render(): ReactNode {
    if (!this.state.hasError) return this.props.children;

    return (
      <div className="flex min-h-[60vh] items-center justify-center p-6">
        <div className="w-full max-w-lg rounded-2xl border border-destructive/25 bg-card p-6 text-center shadow-xl">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-destructive/10 text-destructive">
            <AlertTriangle className="h-6 w-6" />
          </div>
          <h1 className="mt-4 text-xl font-bold">No fue posible mostrar esta pantalla</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Tus datos permanecen intactos. Puedes intentar cargar nuevamente el componente o reiniciar la vista.
          </p>
          <div className="mt-5 flex flex-col gap-2 sm:flex-row sm:justify-center">
            <Button type="button" variant="outline" onClick={this.reset}>Intentar nuevamente</Button>
            <Button type="button" className="gap-2" onClick={this.reload}>
              <RefreshCcw className="h-4 w-4" /> Recargar vista
            </Button>
          </div>
        </div>
      </div>
    );
  }
}

export default AppErrorBoundary;
