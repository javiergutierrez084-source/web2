import { useState, useRef, useEffect } from 'react';
import { Printer, Receipt, FileText, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { PrintFormat } from '@/lib/printReport';

interface Props {
  onSelect: (format: PrintFormat) => void;
  label?: string;
  size?: 'sm' | 'default' | 'lg';
  variant?: 'default' | 'outline' | 'ghost';
  icon?: 'printer' | 'download';
  className?: string;
  compact?: boolean; // icon-only trigger (for table rows)
  title?: string;
}

const PrintFormatMenu = ({ onSelect, label = 'Imprimir', size = 'sm', variant = 'outline', icon = 'printer', className = '', compact = false, title }: Props) => {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    if (open) document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const Icon = icon === 'download' ? Download : Printer;
  const pick = (f: PrintFormat) => { setOpen(false); onSelect(f); };

  return (
    <div className={`relative inline-block ${className}`} ref={ref}>
      {compact ? (
        <button
          type="button"
          title={title || label}
          onClick={() => setOpen(o => !o)}
          className="rounded-lg p-1.5 hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
        >
          <Icon className="h-4 w-4" />
        </button>
      ) : (
        <Button type="button" size={size} variant={variant} className="gap-1.5" onClick={() => setOpen(o => !o)}>
          <Icon className="h-3.5 w-3.5" /> {label}
        </Button>
      )}
      {open && (
        <div className="absolute right-0 top-full mt-1 w-48 rounded-lg border border-border bg-popover p-1 shadow-xl z-50">
          <button onClick={() => pick('letter')} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary transition-colors">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <div className="text-left">
              <p className="font-medium">Formato Carta</p>
              <p className="text-[10px] text-muted-foreground">Hoja tamaño normal</p>
            </div>
          </button>
          <button onClick={() => pick('ticket')} className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm hover:bg-secondary transition-colors">
            <Receipt className="h-4 w-4 text-muted-foreground" />
            <div className="text-left">
              <p className="font-medium">Formato Tirilla</p>
              <p className="text-[10px] text-muted-foreground">Ticket térmico 80mm</p>
            </div>
          </button>
        </div>
      )}
    </div>
  );
};

export default PrintFormatMenu;
