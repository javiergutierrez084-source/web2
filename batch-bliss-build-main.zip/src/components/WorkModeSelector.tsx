import { useEffect, useMemo, useState } from 'react';
import { HardDrive, Network, Radar, Server } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useWorkMode } from '@/contexts/WorkModeContext';
import { useLanConnectionState } from '@/contexts/LanConnectionStateContext';
import type { WorkModePreference } from '@/config/workMode';
import { loadLanConfig } from '@/lib/LanCommunicationConfig';
import { cn } from '@/lib/utils';

interface WorkModeSelectorProps {
  variant?: 'login' | 'settings';
}

const MODE_LABELS: Record<WorkModePreference, string> = {
  lan: 'Cliente LAN',
  local: 'Local',
  auto: 'Detectar automáticamente',
};

export default function WorkModeSelector({ variant = 'login' }: WorkModeSelectorProps) {
  const {
    preference,
    effectiveMode,
    serverName,
    serverAddress,
    requestModeChange,
  } = useWorkMode();
  const { connectionState } = useLanConnectionState();
  const [pendingMode, setPendingMode] = useState<WorkModePreference | null>(null);
  const [serverRunning, setServerRunning] = useState(false);

  useEffect(() => {
    let active = true;
    if (effectiveMode !== 'server') {
      setServerRunning(false);
      return () => { active = false; };
    }
    void window.joyaControlLan?.getServerStatus?.().then(status => {
      if (active) setServerRunning(Boolean(status.running));
    });
    return () => { active = false; };
  }, [effectiveMode]);

  const status = useMemo(() => {
    if (effectiveMode === 'server') {
      return {
        label: serverRunning ? 'Servidor activo' : 'Datos locales',
        className: serverRunning
          ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700'
          : 'border-muted bg-muted/40 text-muted-foreground',
      };
    }
    if (effectiveMode === 'lan') {
      if (connectionState === 'connected') {
        return { label: 'Conectado', className: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-700' };
      }
      if (connectionState === 'connecting') {
        return { label: 'Conectando', className: 'border-amber-500/30 bg-amber-500/10 text-amber-700' };
      }
      return { label: 'Desconectado', className: 'border-destructive/30 bg-destructive/10 text-destructive' };
    }
    return { label: 'Datos locales', className: 'border-muted bg-muted/40 text-muted-foreground' };
  }, [connectionState, effectiveMode, serverRunning]);

  const currentModeLabel = effectiveMode === 'server'
    ? 'Servidor Principal'
    : effectiveMode === 'lan'
      ? 'Cliente LAN'
      : 'Local';

  const serverDescription = effectiveMode === 'lan'
    ? [serverName, serverAddress].filter(Boolean).join(' · ') || 'Servidor pendiente de conexión'
    : effectiveMode === 'server'
      ? [serverName || loadLanConfig().deviceName, serverAddress].filter(Boolean).join(' · ')
      : 'No se utiliza un servidor remoto';

  const chooseMode = (value: string) => {
    const nextMode = value as WorkModePreference;
    if (nextMode === preference) return;
    if (variant === 'settings') {
      setPendingMode(nextMode);
      return;
    }
    requestModeChange(nextMode);
  };

  return (
    <>
      <div className={cn(
        'rounded-xl border border-border bg-secondary/20',
        variant === 'settings' ? 'p-5 space-y-4' : 'p-4 space-y-3',
      )}>
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              {effectiveMode === 'lan' ? (
                <Network className="h-4 w-4 text-primary" />
              ) : effectiveMode === 'server' ? (
                <Server className="h-4 w-4 text-primary" />
              ) : (
                <HardDrive className="h-4 w-4 text-primary" />
              )}
              <p className="text-sm font-semibold">Modo de trabajo</p>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">
              El modo solo cambia el origen y transporte de los datos.
            </p>
          </div>
          <Badge variant="outline" className={status.className}>{status.label}</Badge>
        </div>

        <div className={cn('grid gap-3', variant === 'settings' && 'sm:grid-cols-3')}>
          <div className="space-y-1.5">
            <Label className="text-xs text-muted-foreground">Preferencia</Label>
            <Select value={preference} onValueChange={chooseMode}>
              <SelectTrigger className="bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="lan">
                  <span className="inline-flex items-center gap-2"><Network className="h-4 w-4" />Cliente LAN</span>
                </SelectItem>
                <SelectItem value="local">
                  <span className="inline-flex items-center gap-2"><HardDrive className="h-4 w-4" />Local</span>
                </SelectItem>
                <SelectItem value="auto">
                  <span className="inline-flex items-center gap-2"><Radar className="h-4 w-4" />Detectar automáticamente</span>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          {variant === 'settings' && (
            <>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Modo actual</Label>
                <div className="flex min-h-10 items-center rounded-md border border-border bg-background px-3 text-sm font-medium">
                  {currentModeLabel}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">Servidor conectado</Label>
                <div className="flex min-h-10 items-center rounded-md border border-border bg-background px-3 text-xs">
                  <span className="break-words" title={serverDescription}>{serverDescription}</span>
                </div>
              </div>
            </>
          )}
        </div>

        {variant === 'login' && (
          <p className="text-[11px] text-muted-foreground">
            Actual: <strong className="text-foreground">{currentModeLabel}</strong>
            {effectiveMode === 'lan' && serverName ? ` · ${serverName}` : ''}
          </p>
        )}
      </div>

      <AlertDialog open={pendingMode !== null} onOpenChange={open => { if (!open) setPendingMode(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cambiar modo de trabajo</AlertDialogTitle>
            <AlertDialogDescription>
              Se cerrará la sesión actual y JoyaControl se reiniciará usando
              <strong> {pendingMode ? MODE_LABELS[pendingMode] : ''}</strong>. La interfaz y los permisos no cambian; únicamente cambia el origen de datos.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              if (pendingMode) requestModeChange(pendingMode);
            }}>
              Cambiar modo
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
