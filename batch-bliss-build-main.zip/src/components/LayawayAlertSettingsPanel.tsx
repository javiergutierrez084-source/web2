import { useEffect, useState } from 'react';
import { CalendarClock, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { useToast } from '@/hooks/use-toast';
import {
  LAYAWAY_ALERTS_CHANGED_EVENT,
  loadLayawayAlertSettings,
  saveLayawayAlertSettings,
} from '@/lib/LayawayAlertService';

const PRESET_TERMS = [15, 30, 45, 60, 90, 120] as const;

const LayawayAlertSettingsPanel = () => {
  const { toast } = useToast();
  const [selected, setSelected] = useState<string>(() => {
    const days = loadLayawayAlertSettings().defaultTermDays;
    return PRESET_TERMS.includes(days as typeof PRESET_TERMS[number]) ? String(days) : 'custom';
  });
  const [customDays, setCustomDays] = useState(() => String(loadLayawayAlertSettings().defaultTermDays));

  useEffect(() => {
    const handleChange = () => {
      const settings = loadLayawayAlertSettings();
      setCustomDays(String(settings.defaultTermDays));
      setSelected(PRESET_TERMS.includes(settings.defaultTermDays as typeof PRESET_TERMS[number])
        ? String(settings.defaultTermDays)
        : 'custom');
    };
    window.addEventListener(LAYAWAY_ALERTS_CHANGED_EVENT, handleChange);
    return () => window.removeEventListener(LAYAWAY_ALERTS_CHANGED_EVENT, handleChange);
  }, []);

  const save = () => {
    const days = selected === 'custom' ? Number(customDays) : Number(selected);
    if (!Number.isFinite(days) || days < 1 || days > 3650) {
      toast({ title: 'Plazo no válido', description: 'Ingresa un número de días entre 1 y 3650.', variant: 'destructive' });
      return;
    }
    const current = loadLayawayAlertSettings();
    saveLayawayAlertSettings({ ...current, defaultTermDays: Math.round(days) });
    toast({
      title: 'Plazo de separados actualizado',
      description: `Los nuevos separados vencerán ${Math.round(days)} días después de su creación. Los existentes conservan su fecha actual.`,
    });
  };

  return (
    <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex items-start gap-3">
        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <CalendarClock className="h-5 w-5" />
        </div>
        <div>
          <h2 className="text-lg font-semibold">Separados</h2>
          <p className="mt-1 text-sm text-muted-foreground">Tiempo máximo permitido para nuevos separados.</p>
        </div>
      </div>

      <div className="mt-5 rounded-xl border border-border bg-secondary/20 p-4">
        <Label className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Plazo por defecto</Label>
        <RadioGroup value={selected} onValueChange={setSelected} className="mt-3 grid gap-2 sm:grid-cols-2 lg:grid-cols-4">
          {PRESET_TERMS.map(days => (
            <Label key={days} htmlFor={`layaway-term-${days}`} className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-card px-3 py-2.5 text-sm hover:border-primary/30">
              <RadioGroupItem id={`layaway-term-${days}`} value={String(days)} />
              {days} días
            </Label>
          ))}
          <Label htmlFor="layaway-term-custom" className="flex cursor-pointer items-center gap-2 rounded-lg border border-border bg-card px-3 py-2.5 text-sm hover:border-primary/30">
            <RadioGroupItem id="layaway-term-custom" value="custom" />
            Personalizado
          </Label>
        </RadioGroup>

        {selected === 'custom' && (
          <div className="mt-3 max-w-xs space-y-1.5">
            <Label htmlFor="layaway-custom-days" className="text-xs text-muted-foreground">Número de días</Label>
            <Input
              id="layaway-custom-days"
              type="number"
              min={1}
              max={3650}
              value={customDays}
              onChange={event => setCustomDays(event.target.value)}
            />
          </div>
        )}

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <p className="max-w-2xl text-xs leading-relaxed text-muted-foreground">
            El cambio se aplica únicamente a separados nuevos. Las fechas de vencimiento ya asignadas no se recalculan.
          </p>
          <Button onClick={save} className="gap-2 gold-gradient font-semibold text-primary-foreground">
            <Save className="h-4 w-4" /> Guardar plazo
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LayawayAlertSettingsPanel;
