import { useEffect, useMemo, useState } from 'react';
import { Pencil, Plus, Power, PowerOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import {
  createExpenseConcept,
  fetchExpenseConcepts,
  setExpenseConceptActive,
  updateExpenseConcept,
  type ExpenseConcept,
} from '@/lib/ExpenseConceptService';

interface ExpenseConceptCatalogProps {
  concepts: ExpenseConcept[];
  onChange: (concepts: ExpenseConcept[]) => void;
}

const ExpenseConceptCatalog = ({ concepts, onChange }: ExpenseConceptCatalogProps) => {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<ExpenseConcept | null>(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (concepts.length > 0) return;
    void fetchExpenseConcepts().then(onChange);
  }, [concepts.length, onChange]);

  const ordered = useMemo(() => [...concepts].sort((a, b) => Number(b.active) - Number(a.active) || a.name.localeCompare(b.name)), [concepts]);

  const openCreate = () => {
    setEditing(null);
    setName('');
    setDialogOpen(true);
  };

  const openEdit = (concept: ExpenseConcept) => {
    setEditing(concept);
    setName(concept.name);
    setDialogOpen(true);
  };

  const save = async () => {
    if (!name.trim()) return;
    setBusy(true);
    try {
      const saved = editing
        ? await updateExpenseConcept(editing, name)
        : await createExpenseConcept(name);
      onChange(editing
        ? concepts.map(item => item.id === saved.id ? saved : item)
        : [...concepts, saved]);
      setDialogOpen(false);
      toast({ title: editing ? 'Concepto actualizado' : 'Concepto creado' });
    } catch (error) {
      toast({
        title: 'No se pudo guardar el concepto',
        description: error instanceof Error ? error.message : '',
        variant: 'destructive',
      });
    } finally {
      setBusy(false);
    }
  };

  const toggle = async (concept: ExpenseConcept) => {
    setBusy(true);
    try {
      const saved = await setExpenseConceptActive(concept, !concept.active);
      onChange(concepts.map(item => item.id === saved.id ? saved : item));
      toast({ title: saved.active ? 'Concepto activado' : 'Concepto desactivado' });
    } catch (error) {
      toast({ title: 'No se pudo cambiar el estado', description: error instanceof Error ? error.message : '', variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Catálogo de conceptos de gasto</h2>
          <p className="text-sm text-muted-foreground">Los conceptos utilizados no se eliminan; pueden editarse o desactivarse.</p>
        </div>
        <Button onClick={openCreate} className="gap-2"><Plus className="h-4 w-4" />Crear concepto</Button>
      </div>

      <div className="overflow-x-auto rounded-xl border border-border bg-card">
        <table className="w-full min-w-[520px] text-sm">
          <thead className="bg-secondary/50">
            <tr>
              <th className="px-4 py-3 text-left">Concepto</th>
              <th className="px-4 py-3 text-center">Estado</th>
              <th className="px-4 py-3 text-center">Acciones</th>
            </tr>
          </thead>
          <tbody>
            {ordered.map(concept => (
              <tr key={concept.id} className="border-t border-border/60">
                <td className="px-4 py-3">
                  <span className="font-medium">{concept.name}</span>
                  {concept.builtIn && <span className="ml-2 text-xs text-muted-foreground">Inicial</span>}
                </td>
                <td className="px-4 py-3 text-center">
                  <Badge variant={concept.active ? 'default' : 'secondary'}>{concept.active ? 'Activo' : 'Inactivo'}</Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="flex justify-center gap-2">
                    <Button size="sm" variant="outline" onClick={() => openEdit(concept)} disabled={busy} className="gap-1.5">
                      <Pencil className="h-3.5 w-3.5" />Editar
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => void toggle(concept)} disabled={busy} className="gap-1.5">
                      {concept.active ? <PowerOff className="h-3.5 w-3.5" /> : <Power className="h-3.5 w-3.5" />}
                      {concept.active ? 'Desactivar' : 'Activar'}
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? 'Editar concepto' : 'Crear concepto'}</DialogTitle>
            <DialogDescription>El nombre se conservará en los documentos históricos ya registrados.</DialogDescription>
          </DialogHeader>
          <Input value={name} onChange={event => setName(event.target.value)} placeholder="Nombre del concepto" autoFocus />
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button onClick={() => void save()} disabled={busy || !name.trim()}>Guardar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default ExpenseConceptCatalog;
