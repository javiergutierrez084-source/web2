import { useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Landmark,
  Link2,
  Search,
  ShieldAlert,
  Wallet,
} from 'lucide-react';
import type {
  Contact,
  ExpenseInvoice,
  FinancialAccount,
  FinancialMovement,
  FinancialMovementCode,
  FinancialMovementStatus,
  Invoice,
  PurchaseInvoice,
} from '@/data/mockData';
import { formatCurrency } from '@/data/mockData';
import type { CompanyInfo, Layaway } from '@/domain/models';
import {
  auditFinancialLedger,
  buildBankDetails,
  buildFinancialCompositions,
  buildFinancialLedgerRows,
  filterFinancialLedgerRows,
  traceFinancialMovement,
  type FinancialComposition,
  type FinancialLedgerRow,
  type FinancialTraceabilityFilters,
} from '@/lib/FinancialTraceabilityService';
import {
  buildBankMovementComposition,
  calculateActiveLayawayBankFunds,
} from '@/lib/LayawayBankAccountingService';
import { buildTableDocumentData } from '@/lib/pdf';
import PdfDocumentActions from '@/components/PdfDocumentActions';
import ExcelDocumentActions from '@/components/ExcelDocumentActions';
import CsvDocumentActions from '@/components/CsvDocumentActions';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

interface FinancialTraceabilityPanelProps {
  company: CompanyInfo;
  accounts: FinancialAccount[];
  movements: FinancialMovement[];
  contacts: Contact[];
  invoices: Invoice[];
  purchases: PurchaseInvoice[];
  expenses: ExpenseInvoice[];
  layaways: Layaway[];
  dateFrom?: string;
  dateTo?: string;
  rangeLabel?: string;
  initialComposition?: string | null;
}

type TraceView = 'ledger' | 'audit';

const MOVEMENT_CODES: FinancialMovementCode[] = [
  'SALE_PAYMENT', 'SALE_CANCEL', 'LAYAWAY_PAYMENT', 'LAYAWAY_COMPLETED',
  'LAYAWAY_REFUND', 'CUSTOMER_CREDIT', 'CASH_IN', 'CASH_OUT', 'BANK_IN',
  'BANK_OUT', 'BANK_TRANSFER', 'EXPENSE', 'PURCHASE_PAYMENT', 'SUPPLIER_PAYMENT',
  'ADJUSTMENT', 'OPENING_BALANCE', 'REVERSAL',
];

const STATUSES: FinancialMovementStatus[] = ['POSTED', 'COMPLETED', 'REVERSED', 'CANCELLED'];

const formatTimestamp = (value: string | null): string => {
  if (!value) return 'Sin movimientos';
  const parsed = new Date(value);
  if (Number.isNaN(parsed.getTime())) return value;
  return new Intl.DateTimeFormat('es-CO', { dateStyle: 'short', timeStyle: 'medium' }).format(parsed);
};

const selectClassName = 'h-9 rounded-md border border-input bg-background px-3 text-xs text-foreground outline-none focus:ring-2 focus:ring-ring';

const rowToExport = (row: FinancialLedgerRow): Array<string | number> => [
  row.date, row.time, row.type, row.code, row.document, row.client, row.supplier,
  row.concept, row.value, row.income, row.expense, row.cashOrigin, row.cashDestination,
  row.bankOrigin, row.bankDestination, row.user, row.status, row.reference,
  row.movementId, row.relatedMovementId, row.referenceType, row.referenceId,
];

const exportColumns = [
  'Fecha', 'Hora', 'Tipo', 'Código', 'Documento', 'Cliente', 'Proveedor', 'Concepto',
  'Valor', 'Ingreso', 'Egreso', 'Caja origen', 'Caja destino', 'Banco origen',
  'Banco destino', 'Usuario', 'Estado', 'Referencia', 'MovementId',
  'RelatedMovementId', 'ReferenceType', 'ReferenceId',
];

const compositionLabels: Record<string, string> = {
  mainCash: 'Caja Principal',
  layawayReserve: 'Caja Separados',
  banks: 'Bancos',
  totalAvailable: 'Total Disponible',
};

const FinancialTraceabilityPanel = ({
  company,
  accounts,
  movements,
  contacts,
  invoices,
  purchases,
  expenses,
  layaways,
  dateFrom = '',
  dateTo = '',
  rangeLabel = 'Todo el historial',
  initialComposition,
}: FinancialTraceabilityPanelProps) => {
  const [view, setView] = useState<TraceView>('ledger');
  const [filters, setFilters] = useState<FinancialTraceabilityFilters>({});
  const [selectedMovementId, setSelectedMovementId] = useState('');
  const [compositionKey, setCompositionKey] = useState(initialComposition || 'mainCash');

  const completeInput = useMemo(() => ({
    accounts,
    movements,
    contacts,
    invoices,
    purchases,
    expenses,
    layaways,
  }), [accounts, movements, contacts, invoices, purchases, expenses, layaways]);

  // Build the accounting classification with the complete Ledger first, then
  // apply the historical date window. This keeps a sale and its later
  // cancellation in the same neutralization context without changing filters.
  const rows = useMemo(() => buildFinancialLedgerRows(completeInput).filter(row => {
    const date = String(row.date || '').slice(0, 10);
    if (dateFrom && date < dateFrom) return false;
    if (dateTo && date > dateTo) return false;
    return true;
  }), [completeInput, dateFrom, dateTo]);
  const filteredRows = useMemo(
    () => filterFinancialLedgerRows(rows, filters, accounts),
    [rows, filters, accounts],
  );
  // Current Caja/Bancos compositions must always use the complete Ledger.
  // The date selector limits historical rows, never the current account state.
  const compositions = useMemo(() => buildFinancialCompositions(completeInput), [completeInput]);
  const bankDetails = useMemo(() => buildBankDetails(completeInput), [completeInput]);
  const layawayBankFunds = useMemo(
    () => calculateActiveLayawayBankFunds(accounts, layaways),
    [accounts, layaways],
  );
  const bankMovementComposition = useMemo(
    () => buildBankMovementComposition({
      accounts,
      movements,
      layaways,
      dateFrom,
      dateTo,
    }),
    [accounts, movements, layaways, dateFrom, dateTo],
  );
  const audit = useMemo(() => auditFinancialLedger(completeInput), [completeInput]);
  const selectedTrace = useMemo(
    () => selectedMovementId ? traceFinancialMovement(rows, selectedMovementId) : [],
    [rows, selectedMovementId],
  );

  const composition = (
    compositionKey === 'layawayReserve' ? compositions.layawayReserve
      : compositionKey === 'banks' ? compositions.banks
        : compositionKey === 'totalAvailable' ? compositions.totalAvailable
          : compositions.mainCash
  ) as FinancialComposition;

  const ledgerDocument = () => buildTableDocumentData({
    company,
    title: 'Libro Mayor Financiero',
    subtitle: `${rangeLabel} · ${filteredRows.length} movimientos filtrados`,
    filename: 'libro-mayor-financiero',
    columns: exportColumns.map(header => ({ header })),
    rows: filteredRows.map(rowToExport),
    summaryLines: [
      { label: 'Ingresos', value: formatCurrency(filteredRows.reduce((sum, row) => sum + row.income, 0)) },
      { label: 'Egresos', value: formatCurrency(filteredRows.reduce((sum, row) => sum + row.expense, 0)) },
    ],
  });

  const compositionDocument = () => buildTableDocumentData({
    company,
    title: `Composición de ${composition.label}`,
    subtitle: `${rangeLabel} · Última actualización: ${formatTimestamp(composition.lastUpdatedAt)}`,
    filename: `composicion-${composition.key}`,
    columns: [
      { header: 'Fecha' }, { header: 'Código' }, { header: 'Documento' },
      { header: 'Concepto' }, { header: 'Usuario' }, { header: 'Movimiento', align: 'right' },
    ],
    rows: composition.rows.map(row => [
      `${row.date} ${row.time}`, row.code, row.document, row.concept, row.user,
      row.signedAmount >= 0 ? `+${formatCurrency(row.signedAmount)}` : `-${formatCurrency(Math.abs(row.signedAmount))}`,
    ]),
    summaryLines: composition.key === 'banks' ? [
      { label: 'Ventas bancarias', value: formatCurrency(bankMovementComposition.bankSales) },
      { label: 'Otros ingresos', value: formatCurrency(bankMovementComposition.otherIncome) },
      { label: 'Transferencias', value: formatCurrency(bankMovementComposition.transfers) },
      { label: 'Fondos provenientes de separados (no corresponde a ventas realizadas)', value: formatCurrency(layawayBankFunds.total) },
      { label: 'Total movimientos bancarios', value: formatCurrency(bankMovementComposition.totalMovements), bold: true },
      { label: 'Saldo bancario acumulado', value: formatCurrency(composition.total) },
    ] : [{ label: 'TOTAL', value: formatCurrency(composition.total), bold: true }],
  });

  const bankDocument = () => buildTableDocumentData({
    company,
    title: 'Detalle de Bancos',
    subtitle: rangeLabel,
    filename: 'detalle-bancos',
    columns: [
      { header: 'Banco' }, { header: 'Saldo', align: 'right' },
      { header: 'Entradas', align: 'right' }, { header: 'Salidas', align: 'right' },
      { header: 'Transferencias', align: 'right' }, { header: 'Último movimiento' },
    ],
    rows: bankDetails.map(bank => [
      bank.name, formatCurrency(bank.balance), formatCurrency(bank.entries),
      formatCurrency(bank.exits), formatCurrency(bank.transfers), formatTimestamp(bank.lastMovementAt),
    ]),
    summaryLines: [{ label: 'Saldo consolidado', value: formatCurrency(compositions.banks.total), bold: true }],
  });

  const auditDocument = () => buildTableDocumentData({
    company,
    title: 'Auditoría Financiera',
    filename: 'auditoria-financiera',
    columns: [
      { header: 'Severidad' }, { header: 'Tipo' }, { header: 'Descripción' },
      { header: 'MovementId' }, { header: 'Cuenta' }, { header: 'Esperado' }, { header: 'Actual' },
    ],
    rows: audit.issues.map(issue => [
      issue.severity, issue.type, issue.detail, issue.movementId || '', issue.accountId || '',
      issue.expected ?? '', issue.actual ?? '',
    ]),
    summaryLines: [
      { label: 'Hallazgos', value: String(audit.issues.length) },
      { label: 'Conciliación de saldos', value: audit.isBalanced ? 'Correcta' : 'Con diferencias', bold: true },
    ],
  });

  const updateFilter = (key: keyof FinancialTraceabilityFilters, value: string) => {
    setFilters(previous => ({ ...previous, [key]: value }));
  };

  return (
    <div className="space-y-5">
      {!audit.isBalanced && (
        <div className="flex items-start gap-3 rounded-xl border border-destructive/30 bg-destructive/10 p-4 text-sm">
          <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-destructive" />
          <div>
            <p className="font-semibold text-destructive">Advertencia de conciliación</p>
            <p className="text-muted-foreground">
              El saldo reconstruido no coincide con uno o más agregados materializados. No se realizó ninguna corrección automática.
            </p>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Link2 className="h-5 w-5 text-primary" /> Trazabilidad Financiera
          </h2>
          <p className="text-xs text-muted-foreground">Saldos actuales desde el Ledger completo · movimientos visibles: {rangeLabel}.</p>
        </div>
        <div className="flex rounded-lg border border-border bg-secondary/50 p-0.5">
          <button onClick={() => setView('ledger')} className={`rounded-md px-3 py-1.5 text-xs font-medium ${view === 'ledger' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>Libro mayor</button>
          <button onClick={() => setView('audit')} className={`rounded-md px-3 py-1.5 text-xs font-medium ${view === 'audit' ? 'bg-primary text-primary-foreground' : 'text-muted-foreground'}`}>Auditoría financiera</button>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Object.entries(compositions).map(([key, item]) => (
          <Card key={key} className={compositionKey === key ? 'border-primary/40' : ''}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">{item.label}</p>
                  <p className="mt-2 text-2xl font-bold">{formatCurrency(item.total)}</p>
                </div>
                {key === 'banks' ? <Landmark className="h-5 w-5 text-primary" /> : <Wallet className="h-5 w-5 text-primary" />}
              </div>
              <p className="mt-2 text-[10px] text-muted-foreground">{formatTimestamp(item.lastUpdatedAt)}</p>
              <Button variant="ghost" size="sm" className="mt-2 h-7 w-full justify-between px-0 text-xs text-primary" onClick={() => setCompositionKey(key)}>
                Ver composición <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
          <div>
            <CardTitle className="text-base">Composición de {composition.label}</CardTitle>
            <p className="mt-1 text-xs text-muted-foreground">Suma explicable: {formatCurrency(composition.total)}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <PdfDocumentActions document={compositionDocument} label="PDF" />
            <ExcelDocumentActions document={compositionDocument} />
            <CsvDocumentActions document={compositionDocument} />
          </div>
        </CardHeader>
        <CardContent>
          {composition.key === 'banks' && (
            <div className="mb-4 grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
              <div className="rounded-lg border border-border bg-secondary/30 p-3"><p className="text-[10px] uppercase text-muted-foreground">Ventas bancarias</p><p className="mt-1 font-bold">{formatCurrency(bankMovementComposition.bankSales)}</p></div>
              <div className="rounded-lg border border-border bg-secondary/30 p-3"><p className="text-[10px] uppercase text-muted-foreground">Otros ingresos</p><p className="mt-1 font-bold">{formatCurrency(bankMovementComposition.otherIncome)}</p></div>
              {layawayBankFunds.total > 0 && (
                <div className="rounded-lg border border-warning/40 bg-warning/5 p-3"><p className="text-[10px] uppercase text-muted-foreground">Fondos provenientes de separados</p><p className="mt-1 font-bold text-warning">{formatCurrency(layawayBankFunds.total)}</p><p className="mt-1 text-[10px] text-muted-foreground">No corresponde a ventas realizadas.</p></div>
              )}
              <div className="rounded-lg border border-border bg-secondary/30 p-3"><p className="text-[10px] uppercase text-muted-foreground">Transferencias</p><p className="mt-1 font-bold">{formatCurrency(bankMovementComposition.transfers)}</p></div>
              <div className="rounded-lg border border-primary/30 bg-primary/5 p-3"><p className="text-[10px] uppercase text-muted-foreground">Total movimientos bancarios</p><p className="mt-1 font-bold gold-text">{formatCurrency(bankMovementComposition.totalMovements)}</p></div>
            </div>
          )}
          <div className="max-h-72 overflow-auto rounded-lg border border-border">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-secondary"><tr><th className="px-3 py-2 text-left">Documento</th><th className="px-3 py-2 text-left">Código</th><th className="px-3 py-2 text-left">Origen</th><th className="px-3 py-2 text-right">Movimiento</th></tr></thead>
              <tbody>
                {composition.rows.map(row => (
                  <tr key={`${composition.key}-${row.movementId}`} className="border-t border-border/60">
                    <td className="px-3 py-2"><p className="font-medium">{row.document}</p><p className="text-[10px] text-muted-foreground">{row.client || row.supplier || row.concept}</p></td>
                    <td className="px-3 py-2 font-mono">{row.code}</td>
                    <td className="px-3 py-2 text-muted-foreground">{row.cashOrigin || row.bankOrigin || 'Externo'} → {row.cashDestination || row.bankDestination || 'Externo'}</td>
                    <td className={`px-3 py-2 text-right font-semibold ${row.signedAmount >= 0 ? 'text-success' : 'text-destructive'}`}>{row.signedAmount >= 0 ? '+' : '−'}{formatCurrency(Math.abs(row.signedAmount))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {composition.rows.length === 0 && <p className="py-8 text-center text-sm text-muted-foreground">No existen movimientos para esta composición.</p>}
          </div>
        </CardContent>
      </Card>

      {view === 'ledger' ? (
        <>
          <Card>
            <CardHeader className="pb-3"><CardTitle className="flex items-center gap-2 text-base"><Search className="h-4 w-4 text-primary" /> Filtros</CardTitle></CardHeader>
            <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6">
              <Input type="date" value={dateFrom} disabled aria-label="Fecha inicial global" title="Controlado por el selector general de Reportes" />
              <Input type="date" value={dateTo} disabled aria-label="Fecha final global" title="Controlado por el selector general de Reportes" />
              <Input placeholder="Documento" value={filters.document || ''} onChange={event => updateFilter('document', event.target.value)} />
              <Input placeholder="Factura" value={filters.invoice || ''} onChange={event => updateFilter('invoice', event.target.value)} />
              <Input placeholder="Compra" value={filters.purchase || ''} onChange={event => updateFilter('purchase', event.target.value)} />
              <Input placeholder="Gasto" value={filters.expense || ''} onChange={event => updateFilter('expense', event.target.value)} />
              <Input placeholder="Separado" value={filters.layaway || ''} onChange={event => updateFilter('layaway', event.target.value)} />
              <Input placeholder="Proveedor" value={filters.supplier || ''} onChange={event => updateFilter('supplier', event.target.value)} />
              <Input placeholder="Cliente" value={filters.client || ''} onChange={event => updateFilter('client', event.target.value)} />
              <Input placeholder="Usuario" value={filters.user || ''} onChange={event => updateFilter('user', event.target.value)} />
              <select className={selectClassName} value={filters.accountId || ''} onChange={event => updateFilter('accountId', event.target.value)} aria-label="Cuenta">
                <option value="">Caja / Banco</option>
                {accounts.map(account => <option key={account.id} value={account.id}>{account.name}</option>)}
              </select>
              <select className={selectClassName} value={filters.accountKind || ''} onChange={event => updateFilter('accountKind', event.target.value)} aria-label="Tipo de cuenta">
                <option value="">Tipo de cuenta</option><option value="cash">Caja</option><option value="bank">Banco</option>
              </select>
              <select className={selectClassName} value={filters.movementCode || ''} onChange={event => updateFilter('movementCode', event.target.value)} aria-label="Código financiero">
                <option value="">Código financiero</option>{MOVEMENT_CODES.map(code => <option key={code} value={code}>{code}</option>)}
              </select>
              <select className={selectClassName} value={filters.status || ''} onChange={event => updateFilter('status', event.target.value)} aria-label="Estado">
                <option value="">Estado</option>{STATUSES.map(status => <option key={status} value={status}>{status}</option>)}
              </select>
              <select className={selectClassName} value={filters.movementType || ''} onChange={event => updateFilter('movementType', event.target.value)} aria-label="Tipo de movimiento">
                <option value="">Tipo de movimiento</option>{Array.from(new Set(rows.map(row => row.type))).map(type => <option key={type} value={type}>{type}</option>)}
              </select>
              <Button variant="outline" onClick={() => setFilters({})}>Limpiar filtros</Button>
            </CardContent>
          </Card>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm text-muted-foreground">{filteredRows.length} movimientos</p>
            <div className="flex flex-wrap gap-2">
              <PdfDocumentActions document={ledgerDocument} label="Libro mayor PDF" formats={['letter']} />
              <ExcelDocumentActions document={ledgerDocument} label="Libro mayor Excel" />
              <CsvDocumentActions document={ledgerDocument} label="Libro mayor CSV" />
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-border bg-card">
            <table className="min-w-[2400px] w-full text-xs">
              <thead className="bg-secondary/70"><tr>{exportColumns.map(column => <th key={column} className="px-3 py-2 text-left font-medium text-muted-foreground">{column}</th>)}</tr></thead>
              <tbody>
                {filteredRows.map(row => (
                  <tr key={row.movementId} className="cursor-pointer border-t border-border/60 hover:bg-secondary/30" onClick={() => setSelectedMovementId(row.movementId)}>
                    {rowToExport(row).map((value, index) => (
                      <td key={`${row.movementId}-${index}`} className={`max-w-[280px] break-words px-3 py-2 ${index === 9 ? 'text-success' : index === 10 ? 'text-destructive' : ''}`} title={String(value)}>{index >= 8 && index <= 10 ? formatCurrency(Number(value) || 0) : String(value || '—')}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {filteredRows.length === 0 && <p className="py-10 text-center text-sm text-muted-foreground">No existen movimientos con estos filtros.</p>}
          </div>

          {selectedTrace.length > 0 && (
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2 text-base"><Link2 className="h-4 w-4 text-primary" /> Trazabilidad del movimiento</CardTitle></CardHeader>
              <CardContent className="space-y-2">
                {selectedTrace.map(row => (
                  <div key={`trace-${row.movementId}`} className="grid gap-2 rounded-lg border border-border p-3 text-xs md:grid-cols-[1fr_1fr_1fr_auto]">
                    <div><p className="font-semibold">{row.code}</p><p className="text-muted-foreground">{row.movementId}</p></div>
                    <div><p>{row.document}</p><p className="text-muted-foreground">{row.referenceType} · {row.referenceId}</p></div>
                    <div><p>{row.concept}</p><p className="text-muted-foreground">Relacionado: {row.relatedMovementId || '—'}</p></div>
                    <p className={row.expense > 0 ? 'font-bold text-destructive' : 'font-bold text-success'}>{row.expense > 0 ? '−' : '+'}{formatCurrency(row.value)}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader className="flex-row items-center justify-between space-y-0">
              <div><CardTitle className="text-base">Bancos</CardTitle><p className="text-xs text-muted-foreground">Saldo, entradas, salidas, transferencias y último movimiento.</p></div>
              <div className="flex gap-2"><PdfDocumentActions document={bankDocument} label="PDF" /><ExcelDocumentActions document={bankDocument} /><CsvDocumentActions document={bankDocument} /></div>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {bankDetails.map(bank => (
                <div key={bank.accountId} className="rounded-xl border border-border p-4">
                  <div className="flex items-center justify-between"><p className="font-semibold">{bank.name}</p><Landmark className="h-4 w-4 text-primary" /></div>
                  <p className="mt-2 text-2xl font-bold">{formatCurrency(bank.balance)}</p>
                  <div className="mt-3 space-y-1 text-xs"><p className="flex justify-between"><span className="text-muted-foreground">Entradas</span><span className="text-success">{formatCurrency(bank.entries)}</span></p><p className="flex justify-between"><span className="text-muted-foreground">Salidas</span><span className="text-destructive">{formatCurrency(bank.exits)}</span></p><p className="flex justify-between"><span className="text-muted-foreground">Transferencias</span><span>{formatCurrency(bank.transfers)}</span></p><p className="flex justify-between"><span className="text-muted-foreground">Fondos de separados</span><span className="text-warning">{formatCurrency(layawayBankFunds.byAccount.find(item => item.accountId === bank.accountId)?.amount || 0)}</span></p><p className="pt-1 text-muted-foreground">Último: {formatTimestamp(bank.lastMovementAt)}</p></div>
                </div>
              ))}
            </CardContent>
          </Card>
        </>
      ) : (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            <Card><CardContent className="p-4"><p className="text-xs uppercase text-muted-foreground">Hallazgos</p><p className="mt-2 text-2xl font-bold">{audit.issues.length}</p></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs uppercase text-muted-foreground">Críticos</p><p className="mt-2 text-2xl font-bold text-destructive">{audit.issues.filter(issue => issue.severity === 'critical').length}</p></CardContent></Card>
            <Card><CardContent className="p-4"><p className="text-xs uppercase text-muted-foreground">Conciliación</p><div className="mt-2 flex items-center gap-2">{audit.isBalanced ? <CheckCircle2 className="h-5 w-5 text-success" /> : <AlertTriangle className="h-5 w-5 text-destructive" />}<p className="text-lg font-bold">{audit.isBalanced ? 'Correcta' : 'Con diferencias'}</p></div></CardContent></Card>
          </div>
          <div className="flex justify-end gap-2"><PdfDocumentActions document={auditDocument} label="Auditoría PDF" /><ExcelDocumentActions document={auditDocument} label="Auditoría Excel" /><CsvDocumentActions document={auditDocument} label="Auditoría CSV" /></div>
          <div className="space-y-2">
            {audit.issues.map(issue => (
              <div key={issue.id} className={`rounded-xl border p-4 ${issue.severity === 'critical' ? 'border-destructive/30 bg-destructive/5' : 'border-warning/30 bg-warning/5'}`}>
                <div className="flex items-start gap-3">{issue.severity === 'critical' ? <AlertTriangle className="mt-0.5 h-4 w-4 text-destructive" /> : <ShieldAlert className="mt-0.5 h-4 w-4 text-warning" />}<div><p className="text-sm font-semibold">{issue.title}</p><p className="mt-1 text-xs text-muted-foreground">{issue.detail}</p><p className="mt-1 font-mono text-[10px] text-muted-foreground">{issue.movementId || issue.accountId || issue.id}</p></div></div>
              </div>
            ))}
            {audit.issues.length === 0 && <div className="rounded-xl border border-success/30 bg-success/5 p-8 text-center"><CheckCircle2 className="mx-auto h-8 w-8 text-success" /><p className="mt-2 font-semibold">No se detectaron inconsistencias</p></div>}
          </div>
        </>
      )}
    </div>
  );
};

export default FinancialTraceabilityPanel;
