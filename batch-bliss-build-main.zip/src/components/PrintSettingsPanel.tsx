import { useEffect, useMemo, useState } from 'react';
import { Printer, RefreshCw, Save } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { loadLanConfig } from '@/lib/LanCommunicationConfig';
import {
  PRINT_DOCUMENT_TYPES,
  type PrintDocumentType,
  type PrintSettingsMap,
  type PrintSettingsWorkspace,
} from '@/lib/printAgentTypes';
import { PrintRepositoryService } from '@/services/PrintRepositoryService';

const PAPER_OPTIONS = ['Carta', 'A4', 'Térmica 80 mm', 'Térmica 58 mm', 'Etiqueta'];

const PrintSettingsPanel = () => {
  const { toast } = useToast();
  const lanConfig = useMemo(() => loadLanConfig(), []);
  const isLanClient = lanConfig.mode === 'lan' && lanConfig.role === 'client';
  const [workspace, setWorkspace] = useState<PrintSettingsWorkspace | null>(null);
  const [settings, setSettings] = useState<PrintSettingsMap | null>(null);
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState<PrintDocumentType | null>(null);
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    try {
      const next = await PrintRepositoryService.getPrintSettings();
      setWorkspace(next);
      setSettings(next.settings);
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No fue posible cargar la configuración de impresión.');
    }
  };

  useEffect(() => {
    void load();
  }, []);

  if (isLanClient) {
    return (
      <div className="rounded-xl border border-border bg-card p-6">
        <div className="flex items-center gap-3">
          <div className="rounded-lg bg-primary/10 p-2 text-primary"><Printer className="h-5 w-5" /></div>
          <div>
            <h2 className="text-lg font-semibold">Impresión centralizada</h2>
            <p className="text-sm text-muted-foreground">La impresión será realizada por el Servidor Principal.</p>
          </div>
        </div>
      </div>
    );
  }

  const updateSetting = <K extends keyof PrintSettingsMap[PrintDocumentType]>(
    documentType: PrintDocumentType,
    field: K,
    value: PrintSettingsMap[PrintDocumentType][K],
  ) => {
    setSettings(current => current ? {
      ...current,
      [documentType]: { ...current[documentType], [field]: value },
    } : current);
  };

  const handleSave = async () => {
    if (!settings) return;
    setBusy(true);
    setError('');
    try {
      const next = await PrintRepositoryService.savePrintSettings(settings);
      setWorkspace(next);
      setSettings(next.settings);
      toast({ title: 'Configuración de impresión guardada' });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No fue posible guardar la configuración.');
    } finally {
      setBusy(false);
    }
  };

  const handleRefresh = async () => {
    setBusy(true);
    setError('');
    try {
      const next = await PrintRepositoryService.refreshPrinters();
      setWorkspace(next);
      setSettings(next.settings);
      toast({ title: 'Impresoras actualizadas', description: `${next.printers.length} impresora(s) detectada(s).` });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No fue posible actualizar las impresoras.');
    } finally {
      setBusy(false);
    }
  };

  const handleTest = async (documentType: PrintDocumentType) => {
    if (!settings) return;
    setTesting(documentType);
    setError('');
    try {
      const next = await PrintRepositoryService.savePrintSettings(settings);
      setWorkspace(next);
      setSettings(next.settings);
      const result = await PrintRepositoryService.testPrinter({ documentType });
      toast({ title: 'Página de prueba enviada', description: result.printerName });
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : 'No fue posible probar la impresora.');
    } finally {
      setTesting(null);
    }
  };

  return (
    <div className="rounded-xl border border-border bg-card p-6 space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-lg font-semibold">Impresoras del Servidor Principal</h2>
          <p className="mt-1 text-sm text-muted-foreground">Cada tipo de documento se envía automáticamente a la impresora asignada.</p>
        </div>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={() => void handleRefresh()} disabled={busy} className="gap-2">
            <RefreshCw className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} /> Actualizar impresoras
          </Button>
          <Button type="button" onClick={() => void handleSave()} disabled={busy || !settings} className="gap-2">
            <Save className="h-4 w-4" /> Guardar configuración
          </Button>
        </div>
      </div>

      {error && <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</div>}

      {!settings || !workspace ? (
        <p className="text-sm text-muted-foreground">Cargando configuración...</p>
      ) : (
        <div className="space-y-3">
          {PRINT_DOCUMENT_TYPES.map(documentType => {
            const item = settings[documentType];
            return (
              <div key={documentType} className="rounded-lg border border-border p-4">
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold">{documentType}</h3>
                  <Button type="button" size="sm" variant="outline" onClick={() => void handleTest(documentType)} disabled={testing !== null || !item.printerName} className="gap-2">
                    <Printer className="h-3.5 w-3.5" /> {testing === documentType ? 'Imprimiendo...' : 'Probar impresora'}
                  </Button>
                </div>
                <div className="grid gap-3 md:grid-cols-6">
                  <label className="space-y-1 md:col-span-2">
                    <span className="text-xs text-muted-foreground">Impresora</span>
                    <select
                      value={item.printerName}
                      onChange={event => updateSetting(documentType, 'printerName', event.target.value)}
                      className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                    >
                      <option value="">Seleccionar impresora</option>
                      {workspace.printers.map(printer => (
                        <option key={printer.name} value={printer.name}>{printer.displayName || printer.name}</option>
                      ))}
                    </select>
                  </label>
                  <label className="space-y-1">
                    <span className="text-xs text-muted-foreground">Orientación</span>
                    <select
                      value={item.orientation}
                      onChange={event => updateSetting(documentType, 'orientation', event.target.value === 'landscape' ? 'landscape' : 'portrait')}
                      className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                    >
                      <option value="portrait">Vertical</option>
                      <option value="landscape">Horizontal</option>
                    </select>
                  </label>
                  <label className="space-y-1">
                    <span className="text-xs text-muted-foreground">Papel</span>
                    <select
                      value={item.paper}
                      onChange={event => updateSetting(documentType, 'paper', event.target.value)}
                      className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                    >
                      {PAPER_OPTIONS.map(paper => <option key={paper} value={paper}>{paper}</option>)}
                    </select>
                  </label>
                  <label className="space-y-1">
                    <span className="text-xs text-muted-foreground">Copias</span>
                    <Input type="number" min={1} max={99} value={item.copies} onChange={event => updateSetting(documentType, 'copies', Math.max(1, Number(event.target.value) || 1))} />
                  </label>
                  <label className="space-y-1">
                    <span className="text-xs text-muted-foreground">Escala %</span>
                    <Input type="number" min={10} max={200} value={item.scale} onChange={event => updateSetting(documentType, 'scale', Math.max(10, Number(event.target.value) || 100))} />
                  </label>
                </div>
                <label className="mt-3 flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={item.silent} onChange={event => updateSetting(documentType, 'silent', event.target.checked)} />
                  Impresión silenciosa
                </label>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default PrintSettingsPanel;
