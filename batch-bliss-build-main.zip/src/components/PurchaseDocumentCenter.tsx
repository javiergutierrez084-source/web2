import { useMemo, useState } from 'react';
import { Copy, Pencil, Search, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import PdfDocumentActions from '@/components/PdfDocumentActions';
import ExcelExportButton from '@/components/ExcelExportButton';
import { buildTableDocumentData } from '@/lib/pdf';
import { formatCurrency } from '@/data/mockData';
import type { CompanyInfo } from '@/domain/models';
import type { PurchaseDocumentRow, PurchaseDocumentStatus, PurchaseDocumentType } from '@/lib/PurchaseDocumentsService';

interface PurchaseDocumentCenterProps {
  company: CompanyInfo;
  documents: PurchaseDocumentRow[];
  onEdit: (document: PurchaseDocumentRow) => void;
  onDuplicate: (document: PurchaseDocumentRow) => void;
  onDelete: (document: PurchaseDocumentRow) => void;
}

const statusLabel: Record<PurchaseDocumentStatus, string> = {
  pending: 'Pendiente',
  partial: 'Parcial',
  paid: 'Pagada',
  cancelled: 'Anulada',
};

const statusVariant = (status: PurchaseDocumentStatus): 'default' | 'secondary' | 'destructive' | 'outline' => {
  if (status === 'paid') return 'default';
  if (status === 'cancelled') return 'destructive';
  if (status === 'partial') return 'secondary';
  return 'outline';
};

const PurchaseDocumentCenter = ({ company, documents, onEdit, onDuplicate, onDelete }: PurchaseDocumentCenterProps) => {
  const [search, setSearch] = useState('');
  const [type, setType] = useState<'' | PurchaseDocumentType>('');
  const [status, setStatus] = useState<'' | PurchaseDocumentStatus>('');
  const [supplier, setSupplier] = useState('');
  const [concept, setConcept] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const suppliers = useMemo(() => [...new Set(documents.map(item => item.supplierName).filter(Boolean))].sort(), [documents]);
  const concepts = useMemo(() => [...new Set(documents.map(item => item.concept).filter(Boolean))].sort(), [documents]);
  const filtered = useMemo(() => documents.filter(document => {
    const query = search.trim().toLowerCase();
    if (query && !`${document.number} ${document.supplierName} ${document.concept}`.toLowerCase().includes(query)) return false;
    if (type && document.type !== type) return false;
    if (status && document.status !== status) return false;
    if (supplier && document.supplierName !== supplier) return false;
    if (concept && document.concept !== concept) return false;
    if (from && document.date < from) return false;
    if (to && document.date > to) return false;
    return true;
  }), [documents, search, type, status, supplier, concept, from, to]);

  const buildDocument = (document: PurchaseDocumentRow) => buildTableDocumentData({
    company,
    title: `${document.type === 'purchase' ? 'Factura de proveedor' : 'Factura de gasto'} ${document.number}`,
    subtitle: `${document.supplierName} · ${document.date}`,
    filename: `${document.type === 'purchase' ? 'Compra' : 'Gasto'}_${document.number}`,
    columns: [{ header: 'Campo' }, { header: 'Detalle' }],
    rows: [
      ['Tipo', document.type === 'purchase' ? 'Mercancía' : 'Gasto'],
      ['Proveedor', document.supplierName],
      ['Concepto', document.concept],
      ['Fecha', document.date],
      ['Vencimiento', document.dueDate],
      ['Estado', statusLabel[document.status]],
      ['Total', formatCurrency(document.total)],
      ['Pagado', formatCurrency(document.paid)],
      ['Saldo', formatCurrency(document.balance)],
    ],
  });

  return (
    <section className="space-y-4">
      <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-6">
        <div className="relative md:col-span-2 xl:col-span-2"><Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" /><Input className="pl-9" value={search} onChange={event => setSearch(event.target.value)} placeholder="Buscar documento..." /></div>
        <select value={type} onChange={event => setType(event.target.value as '' | PurchaseDocumentType)} className="rounded-lg border border-border bg-card px-3 py-2 text-sm"><option value="">Todos los tipos</option><option value="purchase">Compra de mercancía</option><option value="expense">Factura gasto</option></select>
        <select value={status} onChange={event => setStatus(event.target.value as '' | PurchaseDocumentStatus)} className="rounded-lg border border-border bg-card px-3 py-2 text-sm"><option value="">Todos los estados</option><option value="pending">Pendientes</option><option value="partial">Parciales</option><option value="paid">Pagadas</option><option value="cancelled">Anuladas</option></select>
        <select value={supplier} onChange={event => setSupplier(event.target.value)} className="rounded-lg border border-border bg-card px-3 py-2 text-sm"><option value="">Todos los proveedores</option>{suppliers.map(item => <option key={item}>{item}</option>)}</select>
        <select value={concept} onChange={event => setConcept(event.target.value)} className="rounded-lg border border-border bg-card px-3 py-2 text-sm"><option value="">Todos los conceptos</option>{concepts.map(item => <option key={item}>{item}</option>)}</select>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Input type="date" value={from} onChange={event => setFrom(event.target.value)} className="w-auto" />
        <span className="text-xs text-muted-foreground">hasta</span>
        <Input type="date" value={to} onChange={event => setTo(event.target.value)} className="w-auto" />
        <div className="ml-auto">
          <ExcelExportButton
            filename="Centro_Documentos_Compras"
            sheetName="Documentos"
            rows={filtered}
            columns={[
              { header: 'Tipo', value: row => row.type === 'purchase' ? 'Compra de mercancía' : 'Factura de gasto' },
              { header: 'Número', value: row => row.number },
              { header: 'Proveedor', value: row => row.supplierName },
              { header: 'Concepto', value: row => row.concept },
              { header: 'Fecha', value: row => row.date },
              { header: 'Vencimiento', value: row => row.dueDate },
              { header: 'Estado', value: row => statusLabel[row.status] },
              { header: 'Total', value: row => row.total },
              { header: 'Pagado', value: row => row.paid },
              { header: 'Saldo', value: row => row.balance },
            ]}
            label="Exportar Excel"
          />
        </div>
      </div>

      <div className="overflow-hidden rounded-xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-secondary/50">
              <tr>
                <th className="px-3 py-3 text-left">Documento</th>
                <th className="px-3 py-3 text-left">Proveedor</th>
                <th className="px-3 py-3 text-left">Concepto</th>
                <th className="px-3 py-3 text-left">Fecha</th>
                <th className="px-3 py-3 text-right">Total</th>
                <th className="px-3 py-3 text-right">Saldo</th>
                <th className="px-3 py-3 text-center">Estado</th>
                <th className="px-3 py-3 text-center">Acciones</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(document => {
                const inheritedReadOnly = document.source === 'legacy_expense';
                const editDisabled = inheritedReadOnly || document.status === 'cancelled';
                const deleteDisabled = inheritedReadOnly || document.status === 'paid' || document.status === 'partial';
                const editTitle = inheritedReadOnly
                  ? 'Los gastos heredados son de solo lectura'
                  : document.status === 'cancelled'
                    ? 'Los documentos anulados no se editan'
                    : 'Editar';
                const deleteTitle = inheritedReadOnly
                  ? 'Los gastos heredados se conservan por compatibilidad'
                  : document.status === 'paid' || document.status === 'partial'
                    ? 'Los documentos con pagos no se eliminan'
                    : 'Eliminar';

                return (
                  <tr key={`${document.source}-${document.id}`} className="border-t border-border/60">
                    <td className="px-3 py-3"><div className="font-medium">{document.number}</div><div className="text-xs text-muted-foreground">{document.type === 'purchase' ? 'Compra de mercancía' : 'Factura de gasto'}</div></td>
                    <td className="px-3 py-3">{document.supplierName}</td>
                    <td className="px-3 py-3">{document.concept}</td>
                    <td className="px-3 py-3">{document.date}</td>
                    <td className="px-3 py-3 text-right font-medium">{formatCurrency(document.total)}</td>
                    <td className="px-3 py-3 text-right">{formatCurrency(document.balance)}</td>
                    <td className="px-3 py-3 text-center"><Badge variant={statusVariant(document.status)}>{statusLabel[document.status]}</Badge></td>
                    <td className="px-3 py-3">
                      <div className="flex justify-center gap-1">
                        <Button type="button" size="icon" variant="ghost" onClick={() => onEdit(document)} disabled={editDisabled} title={editTitle} aria-label={`Editar ${document.number}`}><Pencil className="h-4 w-4" /></Button>
                        {document.type === 'expense' && <Button type="button" size="icon" variant="ghost" onClick={() => onDuplicate(document)} title={`Duplicar ${document.number}`} aria-label={`Duplicar ${document.number}`}><Copy className="h-4 w-4" /></Button>}
                        <PdfDocumentActions compact document={() => buildDocument(document)} title={`Imprimir o exportar PDF ${document.number}`} formats={['letter']} />
                        <Button type="button" size="icon" variant="ghost" onClick={() => onDelete(document)} disabled={deleteDisabled} title={deleteTitle} aria-label={`Eliminar ${document.number}`}><Trash2 className="h-4 w-4" /></Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && <div className="p-10 text-center text-sm text-muted-foreground">No hay documentos con los filtros seleccionados.</div>}
      </div>
    </section>
  );
};

export default PurchaseDocumentCenter;
