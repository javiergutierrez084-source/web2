import { useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Loader2,
  Upload,
  X,
} from 'lucide-react';
import type { Contact, Product } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { parseExcelFile } from '@/lib/bulkImport';
import {
  applyProductMassUpdatePlan,
  buildProductMassUpdatePlan,
  DEFAULT_PRODUCT_MASS_UPDATE_FIELDS,
  downloadProductUpdateTemplate,
  exportProductMassUpdateReport,
  PRODUCT_MASS_UPDATE_FIELDS,
  type ProductMassUpdateField,
  type ProductMassUpdatePlan,
} from '@/lib/productMassUpdate';
import { getDataRepository } from '@/repositories/RepositoryRegistry';
import { useToast } from '@/hooks/use-toast';

interface ProductMassUpdateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  products: Product[];
  contacts: Contact[];
  categories: string[];
  onApplied: () => Promise<void>;
}

type RawRow = Record<string, unknown>;

const statusLabel = (status: string): string => {
  switch (status) {
    case 'change': return '✔ Cambiar';
    case 'unchanged': return 'Sin cambios';
    case 'preserved': return 'Se conservará';
    case 'error': return 'Error';
    default: return status;
  }
};

const statusClass = (status: string): string => {
  switch (status) {
    case 'change': return 'text-success';
    case 'error': return 'text-destructive';
    case 'preserved': return 'text-warning';
    default: return 'text-muted-foreground';
  }
};

const ProductMassUpdateDialog = ({
  open,
  onOpenChange,
  products,
  contacts,
  categories,
  onApplied,
}: ProductMassUpdateDialogProps) => {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [safeMode, setSafeMode] = useState(true);
  const [selectedFields, setSelectedFields] = useState<Set<ProductMassUpdateField>>(
    () => new Set(DEFAULT_PRODUCT_MASS_UPDATE_FIELDS),
  );
  const [rows, setRows] = useState<RawRow[]>([]);
  const [fileName, setFileName] = useState('');
  const [reading, setReading] = useState(false);
  const [applying, setApplying] = useState(false);
  const [completedPlan, setCompletedPlan] = useState<ProductMassUpdatePlan | null>(null);

  const plan = useMemo(() => {
    if (rows.length === 0) return null;
    return buildProductMassUpdatePlan(rows, products, contacts, categories, {
      safeMode,
      selectedFields,
    });
  }, [rows, products, contacts, categories, safeMode, selectedFields]);

  const reset = () => {
    setRows([]);
    setFileName('');
    setSafeMode(true);
    setSelectedFields(new Set(DEFAULT_PRODUCT_MASS_UPDATE_FIELDS));
    setCompletedPlan(null);
    setReading(false);
    setApplying(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const close = () => {
    if (reading || applying) return;
    reset();
    onOpenChange(false);
  };

  const toggleField = (field: ProductMassUpdateField) => {
    setCompletedPlan(null);
    setSelectedFields(current => {
      const next = new Set(current);
      if (next.has(field)) next.delete(field);
      else next.add(field);
      return next;
    });
  };

  const handleFile = async (file: File | undefined) => {
    if (!file) return;
    setReading(true);
    setCompletedPlan(null);
    try {
      const parsed = await parseExcelFile(file);
      setRows(parsed);
      setFileName(file.name);
      if (parsed.length === 0) {
        toast({ title: 'Archivo vacío', description: 'El Excel no contiene productos para revisar.', variant: 'destructive' });
      }
    } catch (error) {
      setRows([]);
      setFileName('');
      toast({
        title: 'No se pudo leer el Excel',
        description: error instanceof Error ? error.message : 'Archivo inválido.',
        variant: 'destructive',
      });
    } finally {
      setReading(false);
    }
  };

  const confirmUpdate = async () => {
    if (!plan || plan.upserts.length === 0 || applying) return;
    setApplying(true);
    try {
      // Reconcile with the active Repository immediately before committing. In
      // LAN mode this re-reads the Principal Server, so a product deleted after
      // the preview is reported as missing instead of being recreated by an
      // upsert from stale client state.
      const repository = getDataRepository();
      const [currentProducts, currentContacts, currentCategories] = await Promise.all([
        repository.fetchProducts(),
        repository.fetchContacts(),
        repository.fetchCategories(),
      ]);
      const confirmedPlan = buildProductMassUpdatePlan(
        rows,
        currentProducts,
        currentContacts,
        currentCategories.map(category => category.name),
        { safeMode, selectedFields },
      );

      // This is the only write performed by the entire flow. Parsing, field
      // selection and both previews remain pure dry-run operations.
      await applyProductMassUpdatePlan(confirmedPlan, changes => repository.applyProductChanges(changes));
      await onApplied();
      setCompletedPlan(confirmedPlan);
      toast({
        title: 'Actualización masiva completada',
        description: `${confirmedPlan.summary.productsModified} producto(s) actualizado(s).`,
      });
    } catch (error) {
      toast({
        title: 'No se aplicaron los cambios',
        description: error instanceof Error ? error.message : 'La operación fue rechazada.',
        variant: 'destructive',
      });
    } finally {
      setApplying(false);
    }
  };

  if (!open) return null;

  const visiblePreviewRows = plan?.previewRows.slice(0, 500) || [];
  const finalPlan = completedPlan || plan;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm" onClick={close}>
      <div
        className="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl border border-border bg-card shadow-2xl"
        onClick={event => event.stopPropagation()}
      >
        <div className="flex items-start justify-between border-b border-border p-5">
          <div>
            <h2 className="flex items-center gap-2 text-xl font-bold">
              <FileSpreadsheet className="h-5 w-5 text-primary" /> Actualizar productos masivamente
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Solo actualiza productos existentes. La vista previa es un modo simulación y nunca modifica la base de datos.
            </p>
          </div>
          <button type="button" onClick={close} className="rounded-lg p-2 hover:bg-secondary" disabled={reading || applying}>
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="flex-1 space-y-5 overflow-y-auto p-5">
          {!completedPlan && (
            <>
              <div className="grid gap-4 lg:grid-cols-[1fr_1.4fr]">
                <div className="space-y-3 rounded-xl border border-border bg-secondary/20 p-4">
                  <h3 className="font-semibold">Archivo Excel</h3>
                  <div className="flex flex-wrap gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="gap-2"
                      onClick={() => downloadProductUpdateTemplate(products, contacts)}
                    >
                      <Download className="h-4 w-4" /> Plantilla de actualización
                    </Button>
                    <Button
                      type="button"
                      className="gap-2"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={reading}
                    >
                      {reading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                      Seleccionar Excel
                    </Button>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".xlsx,.xls"
                      className="hidden"
                      onChange={event => void handleFile(event.target.files?.[0])}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {fileName || 'La búsqueda se realiza por ID interno, luego código y finalmente nombre exacto.'}
                  </p>
                </div>

                <div className="space-y-3 rounded-xl border border-border bg-secondary/20 p-4">
                  <h3 className="font-semibold">Campos permitidos</h3>
                  <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
                    {PRODUCT_MASS_UPDATE_FIELDS.map(field => (
                      <label
                        key={field.key}
                        className={`flex items-center gap-2 rounded-lg border px-3 py-2 text-sm ${field.selectable ? 'cursor-pointer border-border bg-card' : 'cursor-not-allowed border-border/60 bg-muted/40 text-muted-foreground'}`}
                        title={field.selectable ? undefined : 'Informativo. El modelo actual no tiene estado independiente de stock.'}
                      >
                        <input
                          type="checkbox"
                          checked={selectedFields.has(field.key)}
                          onChange={() => toggleField(field.key)}
                          disabled={!field.selectable}
                          className="h-4 w-4"
                        />
                        {field.label}
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-3 rounded-xl border border-border p-4">
                <label className="flex cursor-pointer items-start gap-3">
                  <input
                    type="checkbox"
                    checked={safeMode}
                    onChange={event => {
                      setSafeMode(event.target.checked);
                      setCompletedPlan(null);
                    }}
                    className="mt-1 h-4 w-4"
                  />
                  <span>
                    <span className="font-semibold">Actualizar únicamente los campos que contienen información</span>
                    <span className="block text-xs text-muted-foreground">Modo Seguro activado por defecto. Las celdas vacías conservan el valor actual.</span>
                  </span>
                </label>
                {!safeMode && (
                  <div className="flex items-start gap-2 rounded-lg border border-warning/30 bg-warning/10 p-3 text-sm text-warning">
                    <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
                    Esta opción puede borrar información opcional. Los campos obligatorios y valores numéricos inválidos seguirán siendo rechazados.
                  </div>
                )}
              </div>

              {plan && (
                <>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
                    <SummaryCard label="Encontrados" value={plan.summary.productsFound} />
                    <SummaryCard label="Modificar" value={plan.summary.productsModified} emphasis="success" />
                    <SummaryCard label="Sin cambios" value={plan.summary.productsUnchanged} />
                    <SummaryCard label="No encontrados" value={plan.summary.productsNotFound} emphasis="warning" />
                    <SummaryCard label="Con error" value={plan.summary.errors} emphasis="danger" />
                  </div>

                  <div className="overflow-hidden rounded-xl border border-border">
                    <div className="flex items-center justify-between border-b border-border bg-secondary/40 px-4 py-3">
                      <div>
                        <h3 className="font-semibold">Vista previa — Modo Simulación</h3>
                        <p className="text-xs text-muted-foreground">No se ha realizado ninguna escritura.</p>
                      </div>
                      {plan.previewRows.length > visiblePreviewRows.length && (
                        <span className="text-xs text-muted-foreground">Mostrando 500 de {plan.previewRows.length} cambios</span>
                      )}
                    </div>
                    <div className="max-h-[360px] overflow-auto">
                      <table className="w-full min-w-[980px] text-sm">
                        <thead className="sticky top-0 bg-card">
                          <tr className="border-b border-border">
                            <th className="px-3 py-2 text-left">Fila</th>
                            <th className="px-3 py-2 text-left">Producto</th>
                            <th className="px-3 py-2 text-left">Campo</th>
                            <th className="px-3 py-2 text-left">Valor actual</th>
                            <th className="px-3 py-2 text-left">Nuevo valor</th>
                            <th className="px-3 py-2 text-left">Estado</th>
                          </tr>
                        </thead>
                        <tbody>
                          {visiblePreviewRows.map((row, index) => (
                            <tr key={`${row.sourceRow}-${row.field}-${index}`} className="border-b border-border/60 align-top">
                              <td className="px-3 py-2 text-muted-foreground">{row.sourceRow}</td>
                              <td className="px-3 py-2 font-medium">{row.product}</td>
                              <td className="px-3 py-2">{row.field}</td>
                              <td className="px-3 py-2 text-muted-foreground">{row.currentValue}</td>
                              <td className="px-3 py-2">{row.nextValue}</td>
                              <td className={`px-3 py-2 font-medium ${statusClass(row.status)}`} title={row.message}>
                                {statusLabel(row.status)}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </>
              )}
            </>
          )}

          {completedPlan && finalPlan && (
            <div className="space-y-5">
              <div className="flex items-start gap-3 rounded-xl border border-success/30 bg-success/10 p-4">
                <CheckCircle2 className="mt-0.5 h-6 w-6 text-success" />
                <div>
                  <h3 className="font-semibold">Actualización finalizada</h3>
                  <p className="text-sm text-muted-foreground">La operación utilizó un único cambio Repository y no creó productos nuevos.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <SummaryCard label="Actualizados" value={finalPlan.summary.productsModified} emphasis="success" />
                <SummaryCard label="Sin cambios" value={finalPlan.summary.productsUnchanged} />
                <SummaryCard label="No encontrados" value={finalPlan.summary.productsNotFound} emphasis="warning" />
                <SummaryCard label="Errores" value={finalPlan.summary.errors} emphasis="danger" />
              </div>
              <div className="overflow-hidden rounded-xl border border-border">
                <div className="border-b border-border bg-secondary/40 px-4 py-3 font-semibold">Reporte final</div>
                <div className="max-h-[380px] overflow-auto">
                  <table className="w-full min-w-[760px] text-sm">
                    <thead className="sticky top-0 bg-card">
                      <tr className="border-b border-border">
                        <th className="px-3 py-2 text-left">Fila</th>
                        <th className="px-3 py-2 text-left">Producto</th>
                        <th className="px-3 py-2 text-left">Resultado</th>
                        <th className="px-3 py-2 text-left">Motivo</th>
                      </tr>
                    </thead>
                    <tbody>
                      {finalPlan.sourceResults.map(result => (
                        <tr key={`${result.sourceRow}-${result.productId || result.product}`} className="border-b border-border/60">
                          <td className="px-3 py-2 text-muted-foreground">{result.sourceRow}</td>
                          <td className="px-3 py-2 font-medium">{result.product}</td>
                          <td className="px-3 py-2">{
                            result.outcome === 'modified' ? 'Actualizado' :
                            result.outcome === 'unchanged' ? 'Sin cambios' :
                            result.outcome === 'not_found' ? 'No encontrado' : 'Error'
                          }</td>
                          <td className="px-3 py-2 text-muted-foreground">{result.reason}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-end gap-2 border-t border-border p-4">
          {completedPlan && finalPlan ? (
            <>
              <Button variant="outline" className="gap-2" onClick={() => exportProductMassUpdateReport(finalPlan)}>
                <Download className="h-4 w-4" /> Exportar reporte Excel
              </Button>
              <Button onClick={close}>Cerrar</Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={close} disabled={reading || applying}>Cancelar</Button>
              <Button
                onClick={() => void confirmUpdate()}
                disabled={!plan || plan.upserts.length === 0 || applying || selectedFields.size === 0}
                className="gap-2"
              >
                {applying ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
                Confirmar {plan?.upserts.length || 0} actualización(es)
              </Button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

const SummaryCard = ({
  label,
  value,
  emphasis,
}: {
  label: string;
  value: number;
  emphasis?: 'success' | 'warning' | 'danger';
}) => {
  const color = emphasis === 'success'
    ? 'text-success'
    : emphasis === 'warning'
      ? 'text-warning'
      : emphasis === 'danger'
        ? 'text-destructive'
        : 'text-foreground';
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <p className={`text-2xl font-bold ${color}`}>{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
};

export default ProductMassUpdateDialog;
