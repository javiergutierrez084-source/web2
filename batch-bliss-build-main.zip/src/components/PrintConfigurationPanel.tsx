import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock3,
  Printer,
  RefreshCw,
  Save,
  Server,
  TestTube2,
  XCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import {
  createDefaultPrintConfiguration,
  normalizedDocumentSettings,
  PRINT_CONFIGURATION_TARGETS,
} from '@/lib/PrintConfigurationDefaults';
import { PrintRepositoryService } from '@/lib/PrintRepositoryService';
import type {
  PrintConfiguration,
  PrintConfigurationTarget,
  PrintDocumentSettings,
  PrintJobSummary,
  PrintPrinterInfo,
  PrintWorkspace,
} from '@/lib/PrintModels';
import { getActiveRepositoryMode } from '@/repositories/RepositoryRegistry';

const paperLabels: Record<PrintDocumentSettings['paperSize'], string> = {
  letter: 'Carta',
  a4: 'A4',
  ticket80: 'Térmico 80 mm',
  ticket58: 'Térmico 58 mm',
  label: 'Etiqueta 100 × 60 mm',
  barcode: 'Código 100 × 40 mm',
};

const spoolerLabels: Record<string, string> = {
  running: 'En ejecución',
  stopped: 'Detenido',
  error: 'Error',
  unknown: 'Desconocido',
  unsupported: 'No disponible',
};

const normalizeConfiguration = (configuration: PrintConfiguration): PrintConfiguration => ({
  ...createDefaultPrintConfiguration(),
  ...configuration,
  profilePrinters: { ...(configuration.profilePrinters || {}) },
  documentPrinters: { ...(configuration.documentPrinters || {}) },
  documentSettings: normalizedDocumentSettings(configuration.documentSettings),
});

const printerLabel = (printer: PrintPrinterInfo): string => printer.displayName || printer.name;

export default function PrintConfigurationPanel() {
  const { toast } = useToast();
  const [workspace, setWorkspace] = useState<PrintWorkspace | null>(null);
  const [config, setConfig] = useState<PrintConfiguration>(createDefaultPrintConfiguration());
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [testingTarget, setTestingTarget] = useState<PrintConfigurationTarget | null>(null);
  const remoteClient = getActiveRepositoryMode() === 'lan';

  const load = async () => {
    setLoading(true);
    try {
      const next = await PrintRepositoryService.getWorkspace();
      const normalized = normalizeConfiguration(next.configuration);
      setWorkspace({ ...next, configuration: normalized });
      setConfig(normalized);
    } catch (error) {
      toast({
        title: 'No fue posible consultar las impresoras',
        description: error instanceof Error ? error.message : 'PRINT_WORKSPACE_FAILED',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void load(); }, []);

  const printers = useMemo(() => workspace?.printers || [], [workspace]);
  const printerNames = useMemo(() => new Set(printers.flatMap(printer => [printer.name, printer.displayName])), [printers]);
  const systemDefault = printers.find(printer => printer.isDefault) || null;

  const updateSettings = (target: PrintConfigurationTarget, patch: Partial<PrintDocumentSettings>) => {
    setConfig(current => ({
      ...current,
      documentSettings: {
        ...current.documentSettings,
        [target]: { ...current.documentSettings[target], ...patch },
      },
    }));
  };

  const save = async () => {
    if (remoteClient) return;
    setSaving(true);
    try {
      const saved = await PrintRepositoryService.saveConfiguration(config);
      const normalized = normalizeConfiguration(saved);
      setConfig(normalized);
      setWorkspace(current => current ? { ...current, configuration: normalized } : current);
      toast({
        title: 'Configuración de impresión guardada',
        description: 'La configuración quedó almacenada de forma persistente en el Servidor Principal.',
      });
    } catch (error) {
      toast({
        title: 'No fue posible guardar',
        description: error instanceof Error ? error.message : 'PRINT_CONFIGURATION_FAILED',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const printTest = async (target: PrintConfigurationTarget) => {
    if (!workspace) return;
    setTestingTarget(target);
    try {
      const result: PrintJobSummary = await PrintRepositoryService.testPrint({
        target,
        settings: config.documentSettings[target],
        workspace: { ...workspace, configuration: config },
      });
      await load();
      if (result.status === 'completed') {
        toast({ title: 'Correcto', description: `La página de prueba fue entregada a ${result.printerName || 'la impresora seleccionada'}.` });
      } else {
        toast({
          title: 'Error en la prueba de impresión',
          description: result.lastError || `Estado final: ${result.status}`,
          variant: 'destructive',
        });
      }
    } catch (error) {
      toast({
        title: 'Error en la prueba de impresión',
        description: error instanceof Error ? error.message : 'PRINT_TEST_FAILED',
        variant: 'destructive',
      });
    } finally {
      setTestingTarget(null);
    }
  };

  const printerItems = (selectedName: string | null) => {
    const missing = selectedName && !printerNames.has(selectedName);
    return (
      <>
        <SelectItem value="__automatic__">Automática del Servidor Principal</SelectItem>
        {missing && <SelectItem value={selectedName}>{selectedName} — Impresora no disponible</SelectItem>}
        {printers.map(printer => (
          <SelectItem key={printer.name} value={printer.name}>
            {printerLabel(printer)}{printer.available ? '' : ' — No disponible'}
          </SelectItem>
        ))}
      </>
    );
  };

  return (
    <section className="space-y-6 rounded-xl border border-border bg-card p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="flex items-center gap-2 text-lg font-semibold">
            <Printer className="h-5 w-5 text-primary" /> Impresión centralizada
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            El listado y la configuración provienen exclusivamente del Servidor Principal.
          </p>
        </div>
        <Button type="button" variant="outline" size="sm" onClick={() => void load()} disabled={loading} className="gap-2">
          <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Actualizar
        </Button>
      </div>

      {remoteClient && (
        <div className="rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-sm">
          <p className="flex items-center gap-2 font-medium"><Server className="h-4 w-4" /> Configuración administrada por el Servidor Principal</p>
          <p className="mt-1 text-xs text-muted-foreground">Este Cliente LAN puede consultar la configuración y solicitar páginas de prueba, pero no puede modificarla.</p>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-lg border border-border bg-secondary/20 p-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Impresoras detectadas</p>
          <p className="mt-1 text-2xl font-semibold">{printers.length}</p>
        </div>
        <div className="rounded-lg border border-border bg-secondary/20 p-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Predeterminada de Windows</p>
          <p className="mt-1 break-words text-sm font-semibold" title={systemDefault ? printerLabel(systemDefault) : ''}>{systemDefault ? printerLabel(systemDefault) : 'No detectada'}</p>
        </div>
        <div className="rounded-lg border border-border bg-secondary/20 p-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Estado del spooler</p>
          <p className="mt-1 flex items-center gap-2 text-sm font-semibold">
            {workspace?.spooler?.status === 'running' ? <CheckCircle2 className="h-4 w-4 text-success" /> : <XCircle className="h-4 w-4 text-destructive" />}
            {spoolerLabels[workspace?.spooler?.status || 'unknown']}
          </p>
          <p className="mt-1 break-words text-[10px] text-muted-foreground" title={workspace?.spooler?.message}>{workspace?.spooler?.message || 'Sin información'}</p>
        </div>
        <div className="rounded-lg border border-border bg-secondary/20 p-4">
          <p className="text-xs uppercase tracking-wider text-muted-foreground">Última actualización</p>
          <p className="mt-1 flex items-center gap-2 text-sm font-semibold"><Clock3 className="h-4 w-4" /> {workspace?.discoveredAt ? new Date(workspace.discoveredAt).toLocaleString('es-CO') : 'Sin consultar'}</p>
          <p className="mt-1 break-words text-[10px] text-muted-foreground">Servidor: {workspace?.server?.name || 'Servidor Principal'}</p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {printers.map(printer => (
          <div key={printer.name} className="rounded-lg border border-border bg-secondary/20 p-3">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="break-words text-sm font-medium">{printerLabel(printer)}</p>
                <p className="break-words text-[10px] text-muted-foreground">{printer.name}</p>
              </div>
              <span className={`rounded-full px-2 py-0.5 text-[10px] ${printer.available ? 'bg-success/15 text-success' : 'bg-destructive/15 text-destructive'}`}>
                {printer.available ? 'Disponible' : 'No disponible'}
              </span>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">{printer.statusLabel || `Estado ${printer.status}`}</p>
            <div className="mt-2 flex flex-wrap gap-1">
              {printer.isDefault && <span className="rounded bg-primary/10 px-1.5 py-0.5 text-[10px] text-primary">Predeterminada</span>}
              {printer.offline && <span className="rounded bg-destructive/10 px-1.5 py-0.5 text-[10px] text-destructive">Offline</span>}
              {printer.virtual && <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px]">Virtual</span>}
              {printer.pdf && <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px]">PDF</span>}
              {printer.xps && <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px]">XPS</span>}
              {printer.shared && <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px]">Compartida</span>}
              {printer.local && <span className="rounded bg-secondary px-1.5 py-0.5 text-[10px]">Local</span>}
            </div>
          </div>
        ))}
        {!loading && printers.length === 0 && (
          <p className="col-span-full py-6 text-center text-sm text-muted-foreground">No se detectaron impresoras instaladas en el Servidor Principal.</p>
        )}
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Impresora predeterminada de JOYACONTROL</label>
        <Select
          value={config.defaultPrinterName || '__automatic__'}
          onValueChange={value => setConfig(current => ({ ...current, defaultPrinterName: value === '__automatic__' ? null : value }))}
          disabled={remoteClient}
        >
          <SelectTrigger className="max-w-xl"><SelectValue placeholder="Automática del servidor" /></SelectTrigger>
          <SelectContent>{printerItems(config.defaultPrinterName)}</SelectContent>
        </Select>
        {config.defaultPrinterName && !printerNames.has(config.defaultPrinterName) && (
          <p className="flex items-center gap-1 text-xs text-destructive"><AlertTriangle className="h-3.5 w-3.5" /> Impresora no disponible. Seleccione otra para continuar.</p>
        )}
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {PRINT_CONFIGURATION_TARGETS.map(({ key, label, description }) => {
          const settings = config.documentSettings[key];
          const selectedMissing = Boolean(settings.printerName && !printerNames.has(settings.printerName));
          return (
            <article key={key} className="space-y-4 rounded-xl border border-border p-4">
              <div>
                <h3 className="font-semibold">{label}</h3>
                <p className="text-xs text-muted-foreground">{description}</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium">Impresora</label>
                <Select
                  value={settings.printerName || '__automatic__'}
                  onValueChange={value => updateSettings(key, { printerName: value === '__automatic__' ? null : value })}
                  disabled={remoteClient}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{printerItems(settings.printerName)}</SelectContent>
                </Select>
                {selectedMissing && (
                  <p className="flex items-center gap-1 text-xs text-destructive"><AlertTriangle className="h-3.5 w-3.5" /> Impresora no disponible. Puede seleccionar otra sin bloquear la aplicación.</p>
                )}
              </div>

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-medium">Tamaño de papel</label>
                  <Select value={settings.paperSize} onValueChange={value => updateSettings(key, { paperSize: value as PrintDocumentSettings['paperSize'] })} disabled={remoteClient}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{Object.entries(paperLabels).map(([value, text]) => <SelectItem key={value} value={value}>{text}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium">Orientación</label>
                  <Select value={settings.orientation} onValueChange={value => updateSettings(key, { orientation: value as PrintDocumentSettings['orientation'] })} disabled={remoteClient}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="portrait">Vertical</SelectItem><SelectItem value="landscape">Horizontal</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium">Copias</label>
                  <Input type="number" min={1} max={20} value={settings.copies} onChange={event => updateSettings(key, { copies: Number(event.target.value) || 1 })} disabled={remoteClient} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium">Margen</label>
                  <Select value={settings.margin} onValueChange={value => updateSettings(key, { margin: value as PrintDocumentSettings['margin'] })} disabled={remoteClient}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="default">Predeterminado</SelectItem><SelectItem value="none">Sin margen</SelectItem><SelectItem value="printableArea">Área imprimible</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium">Escala (%)</label>
                  <Input type="number" min={10} max={200} value={settings.scale} onChange={event => updateSettings(key, { scale: Number(event.target.value) || 100 })} disabled={remoteClient} />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium">Color</label>
                  <Select value={settings.colorMode} onValueChange={value => updateSettings(key, { colorMode: value as PrintDocumentSettings['colorMode'] })} disabled={remoteClient}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent><SelectItem value="color">Color</SelectItem><SelectItem value="monochrome">Blanco y negro</SelectItem></SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <label className="flex h-10 w-full items-center justify-between rounded-md border border-input px-3 text-xs">
                    Impresión silenciosa
                    <Switch checked={settings.silent} onCheckedChange={checked => updateSettings(key, { silent: checked })} disabled={remoteClient} />
                  </label>
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => void printTest(key)}
                  disabled={!workspace || testingTarget !== null || selectedMissing}
                  className="gap-2"
                >
                  <TestTube2 className={`h-4 w-4 ${testingTarget === key ? 'animate-pulse' : ''}`} />
                  {testingTarget === key ? 'Probando…' : 'Imprimir página de prueba'}
                </Button>
              </div>
            </article>
          );
        })}
      </div>

      {!remoteClient && (
        <div className="flex justify-end">
          <Button onClick={() => void save()} disabled={saving} className="gap-2">
            <Save className="h-4 w-4" /> {saving ? 'Guardando…' : 'Guardar configuración'}
          </Button>
        </div>
      )}
    </section>
  );
}
