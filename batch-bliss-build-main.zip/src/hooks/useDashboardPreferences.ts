import { useCallback, useEffect, useState } from 'react';
import {
  DASHBOARD_PREFERENCES_CHANGED_EVENT,
  loadDashboardPreferences,
  saveDashboardPreferences,
  type DashboardPreferences,
} from '@/lib/DashboardPreferencesService';

export function useDashboardPreferences(userId: string) {
  const [preferences, setPreferences] = useState<DashboardPreferences>(() => loadDashboardPreferences(userId));

  useEffect(() => {
    setPreferences(loadDashboardPreferences(userId));
    const handleChange = (event: Event) => {
      const detail = (event as CustomEvent<{ userId?: string; preferences?: DashboardPreferences }>).detail;
      if (detail?.userId && detail.userId !== userId) return;
      setPreferences(detail?.preferences || loadDashboardPreferences(userId));
    };
    window.addEventListener(DASHBOARD_PREFERENCES_CHANGED_EVENT, handleChange);
    return () => window.removeEventListener(DASHBOARD_PREFERENCES_CHANGED_EVENT, handleChange);
  }, [userId]);

  const updatePreferences = useCallback((next: DashboardPreferences) => {
    setPreferences(saveDashboardPreferences(userId, next));
  }, [userId]);

  return { preferences, updatePreferences };
}
