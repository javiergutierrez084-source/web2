import { useEffect, useState, type Dispatch, type SetStateAction } from 'react';
import type { LanConnectionState } from '@/lib/LanCommunicationConfig';
import {
  LanConnectionManager,
  type LanConnectionEventDetail,
  type LanGlobalConnectionState,
} from '@/lib/LanConnectionManager';

export const toLanConnectionViewState = (
  state: LanGlobalConnectionState,
): LanConnectionState => (
  state === 'ONLINE'
    ? 'connected'
    : state === 'OFFLINE'
      ? 'disconnected'
      : 'connecting'
);

export const reduceLanConnectionViewState = (
  current: LanConnectionState,
  detail: LanConnectionEventDetail,
): LanConnectionState => {
  switch (detail.type) {
    case 'SERVER_ONLINE':
    case 'CLIENT_RECONNECTED':
      return 'connected';
    case 'SERVER_OFFLINE':
      return 'disconnected';
    case 'SERVER_RECONNECTING':
      return 'connecting';
    default:
      return current;
  }
};

/**
 * React representation of the connection state owned by LanConnectionManager.
 * It reads the current snapshot when mounted, so panels do not depend on a
 * transient CustomEvent that may have fired before they existed.
 */
export const useLanConnectionViewState = (): readonly [
  LanConnectionState,
  Dispatch<SetStateAction<LanConnectionState>>,
] => {
  const [state, setState] = useState<LanConnectionState>(() =>
    toLanConnectionViewState(LanConnectionManager.getConnectionState()),
  );

  useEffect(() => {
    // Close the render/effect race with the manager's latest synchronous state.
    setState(toLanConnectionViewState(LanConnectionManager.getConnectionState()));

    return LanConnectionManager.subscribe(detail => {
      setState(current => reduceLanConnectionViewState(current, detail));
    });
  }, []);

  return [state, setState] as const;
};
