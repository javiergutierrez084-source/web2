import { useCallback, useEffect, useMemo, useState } from 'react';
import { useApp } from '@/contexts/AppContext';
import type { InventoryAdjustment } from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import { fetchInventoryAdjustments, fetchSupplierInvoices } from '@/lib/database';
import { buildPurchaseDocumentRows } from '@/lib/PurchaseDocumentsService';
import {
  createSupplierHistoryService,
  type SupplierHistoryService,
} from '@/lib/SupplierHistoryService';

export interface SupplierHistoryServiceState {
  service: SupplierHistoryService;
  loading: boolean;
  error: Error | null;
  refresh: () => Promise<void>;
}

/**
 * Integración de Contactos con la misma fuente documental usada por Compras.
 * PurchaseDocumentsService es la fuente primaria; ajustes y productos se
 * conservan únicamente para compatibilidad histórica y presentación.
 */
export const useSupplierHistoryService = (): SupplierHistoryServiceState => {
  const {
    contacts,
    products,
    purchaseInvoices,
    expenses,
    financialRefreshVersion,
  } = useApp();
  const [supplierInvoices, setSupplierInvoices] = useState<SupplierInvoiceView[]>([]);
  const [inventoryAdjustments, setInventoryAdjustments] = useState<InventoryAdjustment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const [nextSupplierInvoices, nextInventoryAdjustments] = await Promise.all([
        fetchSupplierInvoices(),
        fetchInventoryAdjustments(),
      ]);
      setSupplierInvoices(nextSupplierInvoices);
      setInventoryAdjustments(nextInventoryAdjustments);
      setError(null);
    } catch (reason) {
      const nextError = reason instanceof Error ? reason : new Error(String(reason));
      setError(nextError);
      console.error('Error cargando el historial centralizado de proveedores:', nextError);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh, financialRefreshVersion]);

  const documents = useMemo(() => buildPurchaseDocumentRows({
    purchases: purchaseInvoices,
    payables: supplierInvoices,
    legacyExpenses: expenses,
  }), [purchaseInvoices, supplierInvoices, expenses]);

  const service = useMemo(() => createSupplierHistoryService({
    contacts,
    documents,
    supplierInvoices,
    products,
    inventoryAdjustments,
  }), [contacts, documents, supplierInvoices, products, inventoryAdjustments]);

  return { service, loading, error, refresh };
};
