import { version as packageVersion } from '../../package.json';

const normalizedVersion = String(packageVersion ?? '').trim();

if (!normalizedVersion) {
  throw new Error('PACKAGE_VERSION_NOT_DEFINED');
}

/**
 * Official JoyaControl application version.
 *
 * package.json is the only source of truth. Changing its `version` field and
 * rebuilding updates every consumer of this module automatically.
 */
export const APP_VERSION = normalizedVersion;
export const APP_VERSION_LABEL = `v${APP_VERSION}`;
export const APP_VERSION_TEXT = `Versión ${APP_VERSION}`;
