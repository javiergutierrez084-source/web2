import {
  loadLanConfig,
  saveLanConfig,
  type LanCommunicationConfig,
} from '@/lib/LanCommunicationConfig';
import { LanServerDescriptor } from '@/lib/LanServerDescriptor';

export type WorkModePreference = 'lan' | 'local' | 'auto';
export type EffectiveWorkMode = 'lan' | 'local' | 'server';

const STORAGE_KEY = 'joyacontrol_work_mode_preference';
const WORK_MODE_VALUES: readonly WorkModePreference[] = ['lan', 'local', 'auto'];

function hasBrowserStorage(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function isWorkModePreference(value: unknown): value is WorkModePreference {
  return typeof value === 'string' && WORK_MODE_VALUES.includes(value as WorkModePreference);
}

/**
 * Backward-compatible default for installations created before the work-mode
 * selector existed. An existing LAN client stays LAN; every installation that
 * already owns its data continues using the local Repository.
 */
export function deriveWorkModePreference(config: LanCommunicationConfig = loadLanConfig()): WorkModePreference {
  return config.mode === 'lan' && config.role === 'client' ? 'lan' : 'local';
}

export function loadWorkModePreference(): WorkModePreference {
  if (!hasBrowserStorage()) return deriveWorkModePreference();
  try {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    return isWorkModePreference(stored) ? stored : deriveWorkModePreference();
  } catch {
    return deriveWorkModePreference();
  }
}

export function saveWorkModePreference(mode: WorkModePreference): void {
  if (!hasBrowserStorage()) return;
  window.localStorage.setItem(STORAGE_KEY, mode);
  window.dispatchEvent(new CustomEvent('joyacontrol-work-mode-changed', { detail: { mode } }));
}

export function getEffectiveWorkMode(config: LanCommunicationConfig = loadLanConfig()): EffectiveWorkMode {
  if (config.mode === 'lan' && config.role === 'client') return 'lan';
  if (config.mode === 'lan' && config.role === 'server') return 'server';
  return 'local';
}

/**
 * Activates the local data source without disabling an existing Principal
 * Server. A Principal Server already uses DexieRepository, so its LAN service
 * configuration must remain untouched.
 */
export function activateLocalWorkMode(): EffectiveWorkMode {
  const current = loadLanConfig();
  if (current.role === 'server') return getEffectiveWorkMode(current);

  if (current.mode !== 'local') {
    saveLanConfig({ ...current, mode: 'local' });
  }
  return 'local';
}

/**
 * Activates the existing LAN client transport. The caller must first ensure
 * that LanServerDescriptor contains a valid discovered or remembered server.
 */
export function activateLanClientWorkMode(): EffectiveWorkMode {
  const current = loadLanConfig();
  const descriptor = LanServerDescriptor.load();
  if (!descriptor.ip) throw new Error('LAN_SERVER_NOT_FOUND');

  saveLanConfig({
    ...current,
    mode: 'lan',
    role: 'client',
    serverStarted: false,
  });
  return 'lan';
}

export const WORK_MODE_STORAGE_KEY = STORAGE_KEY;
