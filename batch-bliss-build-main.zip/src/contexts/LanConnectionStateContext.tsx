import {
  createContext,
  useContext,
  useMemo,
  useSyncExternalStore,
  type ReactNode,
} from 'react';
import type { LanConnectionState } from '@/lib/LanCommunicationConfig';
import {
  LanConnectionManager,
  type LanGlobalConnectionState,
} from '@/lib/LanConnectionManager';

interface LanConnectionStateContextValue {
  managerState: LanGlobalConnectionState;
  connectionState: LanConnectionState;
}

const LanConnectionStateContext = createContext<LanConnectionStateContextValue | null>(null);

function subscribeToManager(onStoreChange: () => void): () => void {
  return LanConnectionManager.subscribe(() => onStoreChange());
}

function getManagerSnapshot(): LanGlobalConnectionState {
  return LanConnectionManager.getConnectionState();
}

function toConnectionState(state: LanGlobalConnectionState): LanConnectionState {
  if (state === 'ONLINE') return 'connected';
  if (state === 'OFFLINE') return 'disconnected';
  return 'connecting';
}

export function useLanConnectionState(): LanConnectionStateContextValue {
  const context = useContext(LanConnectionStateContext);
  if (!context) {
    throw new Error('useLanConnectionState must be inside LanConnectionStateProvider');
  }
  return context;
}

export default function LanConnectionStateProvider({ children }: { children: ReactNode }) {
  const managerState = useSyncExternalStore(
    subscribeToManager,
    getManagerSnapshot,
    getManagerSnapshot,
  );

  const value = useMemo<LanConnectionStateContextValue>(() => ({
    managerState,
    connectionState: toConnectionState(managerState),
  }), [managerState]);

  return (
    <LanConnectionStateContext.Provider value={value}>
      {children}
    </LanConnectionStateContext.Provider>
  );
}
