import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import {
  categories as defaultCategories,
  getProductAvailableGrams,
  getProductAveragePurchasePrice,
  isSoldByWeight,
  type Product,
  type Contact,
  type Invoice,
  type PurchaseInvoice,
  type ExpenseInvoice,
  type Quotation,
  type InventoryAdjustment,
  type InventoryAdjustmentInput,
  type FinancialAccount, type FinancialMovement, type PaymentAllocation, type FinancialSummary,
} from '@/data/mockData';
import * as db from '@/lib/database';
import { getAllCategoryNames } from '@/lib/categoryService';
import { BackupManager } from '@/lib/BackupManager';
import { isPermissionDeniedError, requirePermission } from '@/lib/authCore';
import { getActiveRepositoryMode } from '@/repositories/RepositoryRegistry';
import { SalesRepositoryService, type SalesWorkspace } from '@/lib/SalesRepositoryService';
import { isSalesInvoice } from '@/lib/DashboardMetricsService';
import { calculateInvoiceItemSoldGrams } from '@/lib/salesAnalytics';
import type { CompanyInfo, Layaway, CashSession, LayawayCancellationResolution } from '@/domain/models';
export type { CompanyInfo, Layaway, CashSession } from '@/domain/models';

interface SalesByWeightRow {
  productId: string;
  productName: string;
  totalGrams: number;
  totalAmount: number;
  totalQuantity: number;
}

interface AppContextType {
  company: CompanyInfo;
  setCompany: (company: CompanyInfo) => void;
  products: Product[];
  setProducts: (products: Product[]) => void;
  contacts: Contact[];
  setContacts: (contacts: Contact[]) => void;
  invoices: Invoice[];
  salesByWeight: SalesByWeightRow[];
  /** Read-only legacy history used by supplier details and old reports. */
  purchaseInvoices: PurchaseInvoice[];
  /** Compatibility setter retained for legacy callers. */
  setPurchaseInvoices: (purchases: PurchaseInvoice[]) => void;
  createPurchase: (purchase: PurchaseInvoice, accountId?: string) => Promise<void>;
  updatePurchase: (purchase: PurchaseInvoice) => Promise<void>;
  deletePurchase: (id: string) => Promise<void>;
  markPurchasePaid: (id: string, accountId: string) => Promise<void>;
  expenses: ExpenseInvoice[];
  categories: string[];
  setCategories: (categories: string[]) => void;
  layaways: Layaway[];
  quotations: Quotation[];
  createQuotation: (quotation: Omit<Quotation, 'id' | 'number'>) => Promise<Quotation>;
  updateQuotationStatus: (id: string, status: Quotation['status']) => Promise<void>;
  cashSessions: CashSession[];
  setCashSessions: (sessions: CashSession[]) => void;
  applyInventoryAdjustment: (input: InventoryAdjustmentInput) => Promise<{
    adjustment: InventoryAdjustment;
    product: Product;
  }>;
  financialAccounts: FinancialAccount[];
  financialMovements: FinancialMovement[];
  financialSummary: FinancialSummary | null;
  financialRefreshVersion: number;
  createFinancialAccount: (input: { name: string; kind: FinancialAccount['kind']; initialBalance?: number }) => Promise<void>;
  transferFunds: (input: { originAccountId: string; destinationAccountId: string; amount: number; date: string; observation?: string }) => Promise<void>;
  recordInvoice: (
    invoice: Invoice,
    allocations: PaymentAllocation[],
    options?: db.InvoiceFinancialTransactionOptions,
  ) => Promise<void>;
  cancelInvoice: (invoiceId: string, reason: string) => Promise<void>;
  recordExpense: (expense: ExpenseInvoice, accountId: string) => Promise<void>;
  updateExpense: (expense: ExpenseInvoice) => Promise<void>;
  recordLayaway: (layaway: Layaway) => Promise<void>;
  recordLayawayPayment: (layawayId: string, payment: { id: string; amount: number; date: string; method: string; accountId: string }) => Promise<boolean>;
  completeLayaway: (layawayId: string, completedDate: string) => Promise<void>;
  updateLayaway: (layawayId: string, invoice: Invoice) => Promise<void>;
  deleteLayaway: (layawayId: string, resolution?: LayawayCancellationResolution) => Promise<void>;
  refreshFinancialData: () => Promise<void>;
  refreshProducts: () => Promise<void>;
  refreshCategories: () => Promise<void>;
  isLoading: boolean;
  reloadFromDatabase: () => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be inside AppProvider');
  return context;
};

const sameStringArray = (a: string[] = [], b: string[] = []): boolean =>
  a.length === b.length && a.every((value, index) => value === b[index]);

const sameProduct = (a: Product, b: Product): boolean =>
  a.id === b.id &&
  a.code === b.code &&
  a.name === b.name &&
  a.category === b.category &&
  a.purchasePrice === b.purchasePrice &&
  a.salePrice === b.salePrice &&
  a.weightGrams === b.weightGrams &&
  a.margin === b.margin &&
  a.stock === b.stock &&
  a.minStock === b.minStock &&
  (a.description || '') === (b.description || '') &&
  (a.reference || '') === (b.reference || '') &&
  getProductAvailableGrams(a) === getProductAvailableGrams(b) &&
  getProductAveragePurchasePrice(a) === getProductAveragePurchasePrice(b) &&
  (a.lastPurchaseDate || '') === (b.lastPurchaseDate || '') &&
  sameStringArray(a.supplierIds, b.supplierIds);

const reportContextWriteError = (operation: string, error: unknown): void => {
  if (!isPermissionDeniedError(error)) {
    console.error(`No se pudo completar ${operation}.`, error);
  }
};

const readOptionalLanModule = async <T,>(operation: () => Promise<T>, fallback: T): Promise<T> => {
  try {
    return await operation();
  } catch (error) {
    if (error instanceof Error && error.message === 'LAN_PERMISSION_DENIED') return fallback;
    throw error;
  }
};

const normalizeProduct = (product: Product, previous?: Product): Product => {
  let availableGrams = getProductAvailableGrams(product);

  // Existing sales modules commonly update only `stock`. When they preserve an
  // unchanged availableGrams value through object spread, infer the physical
  // gram delta so the new field stays compatible without touching sales code.
  if (previous && product.stock !== previous.stock) {
    const carriedOldGrams = product.availableGrams === previous.availableGrams;
    if (product.availableGrams === undefined || carriedOldGrams) {
      availableGrams = isSoldByWeight(product)
        ? Math.max(0, product.stock)
        : Math.max(
            0,
            getProductAvailableGrams(previous) +
              ((product.stock - previous.stock) * (product.weightGrams || previous.weightGrams || 0)),
          );
    }
  }

  return {
    ...product,
    reference: product.reference || product.code,
    availableGrams,
    // Acquisition costs are immutable through the generic product setter.
    // The atomic adjustment workflow updates state directly after committing.
    purchasePrice: previous ? previous.purchasePrice : product.purchasePrice,
    averagePurchasePrice: previous
      ? getProductAveragePurchasePrice(previous)
      : getProductAveragePurchasePrice(product),
    lastPurchaseDate: previous
      ? (previous.lastPurchaseDate || '')
      : (product.lastPurchaseDate || ''),
  };
};

export const AppProvider = ({ children }: { children: ReactNode }) => {
  const [isLoading, setIsLoading] = useState(true);
  const [company, setCompanyState] = useState<CompanyInfo>({
    name: 'JoyaControl', nit: '', phone: '', city: '', address: '', email: '', logoUrl: '',
  });
  const [products, setProductsState] = useState<Product[]>([]);
  const [contacts, setContactsState] = useState<Contact[]>([]);
  const [invoices, setInvoicesState] = useState<Invoice[]>([]);
  const [purchaseInvoices, setPurchaseInvoicesState] = useState<PurchaseInvoice[]>([]);
  const [expenses, setExpensesState] = useState<ExpenseInvoice[]>([]);
  const [categories, setCategoriesState] = useState<string[]>(defaultCategories);
  const [layaways, setLayawaysState] = useState<Layaway[]>([]);
  const [quotations, setQuotationsState] = useState<Quotation[]>([]);
  const [cashSessions, setCashSessionsState] = useState<CashSession[]>([]);
  const [financialAccounts, setFinancialAccounts] = useState<FinancialAccount[]>([]);
  const [financialMovements, setFinancialMovements] = useState<FinancialMovement[]>([]);
  const [financialSummary, setFinancialSummary] = useState<FinancialSummary | null>(null);
  const [financialRefreshVersion, setFinancialRefreshVersion] = useState(0);
  const financialRefreshRequestRef = useRef(0);

  const applySalesWorkspace = useCallback((workspace: SalesWorkspace) => {
    setCompanyState(workspace.company);
    setContactsState(workspace.contacts);
    setInvoicesState(workspace.invoices);
    setLayawaysState(workspace.layaways);
    setQuotationsState(workspace.quotations);
    setFinancialAccounts(workspace.financialAccounts);
    setFinancialMovements(workspace.financialMovements);
    setFinancialSummary(workspace.financialSummary);
    setFinancialRefreshVersion(previous => previous + 1);
  }, []);

  const salesByWeight = useMemo<SalesByWeightRow[]>(() => {
    const aggregation = new Map<string, SalesByWeightRow>();
    const productById = new Map(products.map(product => [product.id, product]));

    invoices.forEach(invoice => {
      if (!isSalesInvoice(invoice)) return;
      invoice.items.forEach(item => {
        const grams = calculateInvoiceItemSoldGrams(item, productById.get(item.productId));
        const current = aggregation.get(item.productId);
        if (current) {
          current.totalGrams += grams;
          current.totalAmount += item.subtotal;
          current.totalQuantity += item.quantity;
        } else {
          aggregation.set(item.productId, {
            productId: item.productId,
            productName: item.name,
            totalGrams: grams,
            totalAmount: item.subtotal,
            totalQuantity: item.quantity,
          });
        }
      });
    });

    return Array.from(aggregation.values());
  }, [invoices, products]);

  const refreshFinancialData = useCallback(async () => {
    const requestId = ++financialRefreshRequestRef.current;

    if (getActiveRepositoryMode() === 'lan') {
      const workspace = await SalesRepositoryService.getSalesWorkspace();
      if (requestId !== financialRefreshRequestRef.current) return;
      applySalesWorkspace(workspace);
      return;
    }

    await db.ensureDefaultFinancialAccounts();
    const [accounts, movements, summary] = await Promise.all([
      db.fetchFinancialAccounts(), db.fetchFinancialMovements(), db.fetchFinancialSummary(),
    ]);

    // A slower, older refresh must never overwrite a newer financial snapshot.
    if (requestId !== financialRefreshRequestRef.current) return;

    setFinancialAccounts(accounts);
    setFinancialMovements(movements);
    setFinancialSummary(summary);
    setFinancialRefreshVersion(previous => previous + 1);
  }, [applySalesWorkspace]);


  const refreshProducts = useCallback(async () => {
    const persistedProducts = await db.fetchProducts();
    setProductsState(persistedProducts.map(product => normalizeProduct(product)));
  }, []);

  const refreshCategories = useCallback(async () => {
    const persistedCategories = await getAllCategoryNames();
    setCategoriesState(
      Array.from(new Set([...defaultCategories, ...persistedCategories]))
        .sort((a, b) => a.localeCompare(b, 'es')),
    );
  }, []);

  const reloadFromDatabase = useCallback(async () => {
    const maxWaitMs = 5000;
    const pollIntervalMs = 50;
    let waited = 0;

    while (BackupManager.isBusy() && waited < maxWaitMs) {
      await new Promise(resolve => setTimeout(resolve, pollIntervalMs));
      waited += pollIntervalMs;
    }
    if (BackupManager.isBusy()) {
      console.warn('reloadFromDatabase(): BackupManager continúa ocupado tras 5 segundos.');
    }

    try {
      if (getActiveRepositoryMode() === 'lan') {
        const [
          productsData,
          persistedCategories,
          salesWorkspace,
          historicalPurchases,
          expensesData,
          cashData,
        ] = await Promise.all([
          db.fetchProducts(),
          getAllCategoryNames(),
          SalesRepositoryService.getSalesWorkspace(),
          readOptionalLanModule(() => db.fetchPurchaseInvoices(), []),
          readOptionalLanModule(() => db.fetchExpenses(), []),
          readOptionalLanModule(() => db.fetchCashSessions(), []),
        ]);
        setProductsState(productsData.map(product => normalizeProduct(product)));
        setCategoriesState(
          Array.from(new Set([...defaultCategories, ...persistedCategories]))
            .sort((a, b) => a.localeCompare(b, 'es')),
        );
        applySalesWorkspace(salesWorkspace);
        setPurchaseInvoicesState(historicalPurchases);
        setExpensesState(expensesData);
        setCashSessionsState(cashData);
        return;
      }

      const [
        companyData,
        productsData,
        contactsData,
        invoicesData,
        historicalPurchases,
        expensesData,
        quotationsData,
        cashData,
      ] = await Promise.all([
        db.fetchCompany(),
        db.fetchProducts(),
        db.fetchContacts(),
        db.fetchInvoices(),
        db.fetchPurchaseInvoices(),
        db.fetchExpenses(),
        db.fetchQuotations(),
        db.fetchCashSessions(),
      ]);

      setCompanyState(companyData);
      setProductsState(productsData.map(product => normalizeProduct(product)));
      setContactsState(contactsData);
      setInvoicesState(invoicesData);
      // Legacy history remains available to supplier details. It no longer
      // controls stock or purchase prices and has no active creation route.
      setPurchaseInvoicesState(historicalPurchases);
      setExpensesState(expensesData);
      setQuotationsState(quotationsData);
      setCashSessionsState(cashData);

      const layawaysData = await db.fetchLayaways();
      setLayawaysState(layawaysData);

      const persistedCategories = await getAllCategoryNames();
      setCategoriesState(
        Array.from(new Set([...defaultCategories, ...persistedCategories]))
          .sort((a, b) => a.localeCompare(b, 'es')),
      );
      await refreshFinancialData();
    } catch (error) {
      console.error('Error loading data from database:', error);
      setProductsState([]);
      setContactsState([]);
      setInvoicesState([]);
      setPurchaseInvoicesState([]);
      setExpensesState([]);
    } finally {
      setIsLoading(false);
    }
  }, [applySalesWorkspace, refreshFinancialData]);

  useEffect(() => {
    reloadFromDatabase();
  }, [reloadFromDatabase]);

  useEffect(() => {
    if (getActiveRepositoryMode() !== 'lan') return undefined;
    const handleRepositorySynchronized = () => {
      SalesRepositoryService.invalidate();
      void reloadFromDatabase().catch(error => {
        console.error('No se pudo sincronizar el Repository LAN.', error);
      });
    };
    window.addEventListener('joyacontrol:lan-repository-synchronized', handleRepositorySynchronized);
    return () => window.removeEventListener('joyacontrol:lan-repository-synchronized', handleRepositorySynchronized);
  }, [reloadFromDatabase]);

  const setCompany = useCallback((next: CompanyInfo) => {
    void (async () => {
      try {
        if (getActiveRepositoryMode() !== 'lan') await requirePermission('manage_settings');
        await db.saveCompany(next);
        setCompanyState(next);
      } catch (error) {
        reportContextWriteError('la configuración de empresa', error);
      }
    })();
  }, []);

  const setProducts = useCallback((nextProducts: Product[]) => {
    void (async () => {
      try {
        if (getActiveRepositoryMode() !== 'lan') await requirePermission('manage_products');
        const previousProducts = products;
        const previousById = new Map(previousProducts.map(product => [product.id, product]));
        const normalized = nextProducts.map(product =>
          normalizeProduct(product, previousById.get(product.id)),
        );
        const nextIds = new Set(normalized.map(product => product.id));
        const upserts = normalized.filter(product => {
          const previous = previousById.get(product.id);
          return !previous || !sameProduct(previous, product);
        });
        const deleteIds = previousProducts
          .filter(product => !nextIds.has(product.id))
          .map(product => product.id);

        await db.applyProductChanges({ upserts, deleteIds });
        setProductsState(normalized);
      } catch (error) {
        reportContextWriteError('la actualización de productos', error);
      }
    })();
  }, [products]);

  const setContacts = useCallback((nextContacts: Contact[]) => {
    const previousContacts = contacts;
    setContactsState(nextContacts);

    void (async () => {
      try {
        if (getActiveRepositoryMode() !== 'lan') await requirePermission('manage_contacts');
        const previousById = new Map(previousContacts.map(contact => [contact.id, contact]));
        const nextIds = new Set(nextContacts.map(contact => contact.id));
        const upserts = nextContacts.filter(contact => {
          const previous = previousById.get(contact.id);
          return !previous || JSON.stringify(previous) !== JSON.stringify(contact);
        });
        const deleteIds = previousContacts
          .filter(contact => !nextIds.has(contact.id))
          .map(contact => contact.id);

        const clientOnlyChanges = upserts.every(contact => contact.type === 'client')
          && deleteIds.every(id => previousById.get(id)?.type === 'client');

        if (getActiveRepositoryMode() === 'lan' && clientOnlyChanges) {
          for (const contact of upserts) {
            if (previousById.has(contact.id)) await SalesRepositoryService.updateClient(contact);
            else await SalesRepositoryService.createClient(contact);
          }
          for (const id of deleteIds) await SalesRepositoryService.deleteClient(id);
        } else {
          await SalesRepositoryService.applyContactChanges({ upserts, deleteIds });
        }
      } catch (error) {
        setContactsState(previousContacts);
        reportContextWriteError('la actualización de contactos', error);
      }
    })();
  }, [contacts]);


  const setPurchaseInvoices = useCallback((nextPurchases: PurchaseInvoice[]) => {
    setPurchaseInvoicesState(nextPurchases);
  }, []);

  const createPurchase = useCallback(async (purchase: PurchaseInvoice, accountId?: string) => {
    await db.createPurchaseWithInventory(purchase, accountId);
    setPurchaseInvoicesState(previous => [purchase, ...previous.filter(item => item.id !== purchase.id)]);
    setProductsState(await db.fetchProducts());
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const updatePurchase = useCallback(async (purchase: PurchaseInvoice) => {
    await db.updatePurchaseWithInventory(purchase);
    setPurchaseInvoicesState(previous => previous.map(item => item.id === purchase.id ? purchase : item));
    setProductsState(await db.fetchProducts());
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const deletePurchase = useCallback(async (id: string) => {
    await db.deletePurchaseWithInventory(id);
    setPurchaseInvoicesState(previous => previous.filter(item => item.id !== id));
    setProductsState(await db.fetchProducts());
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const markPurchasePaid = useCallback(async (id: string, accountId: string) => {
    await db.markPurchaseAsPaid(id, accountId);
    setPurchaseInvoicesState(previous => previous.map(item => item.id === id ? { ...item, status: 'paid' as const } : item));
    await refreshFinancialData();
  }, [refreshFinancialData]);



  const createQuotation = useCallback(async (
    input: Omit<Quotation, 'id' | 'number'>,
  ): Promise<Quotation> => {
    const quotation = await SalesRepositoryService.createQuotation(input);
    setQuotationsState(previous => [
      quotation,
      ...previous.filter(existing => existing.id !== quotation.id),
    ]);
    return quotation;
  }, []);

  const updateQuotationStatus = useCallback(async (
    id: string,
    status: Quotation['status'],
  ): Promise<void> => {
    await SalesRepositoryService.updateQuotationStatus(id, status);
    setQuotationsState(previous => previous.map(quotation => (
      quotation.id === id ? { ...quotation, status } : quotation
    )));
  }, []);

  const setCashSessions = useCallback((nextSessions: CashSession[]) => {
    void (async () => {
      try {
        if (getActiveRepositoryMode() !== 'lan') await requirePermission('manage_cash');
        const previousById = new Map(cashSessions.map(session => [session.id, session]));
        for (const session of nextSessions) {
          const previous = previousById.get(session.id);
          if (!previous) {
            await db.insertCashSession(session);
          } else if (!previous.closedAt && session.closedAt) {
            await db.closeCashSession(
              session.id,
              session.closedAt,
              session.closedBy || '',
              session.observations || '',
            );
          }
        }
        setCashSessionsState(nextSessions);
      } catch (error) {
        reportContextWriteError('la actualización de caja', error);
      }
    })();
  }, [cashSessions]);

  const applyInventoryAdjustment = useCallback(async (input: InventoryAdjustmentInput) => {
    const result = await db.applyInventoryAdjustment(input);
    setProductsState(previousProducts => {
      const index = previousProducts.findIndex(product => product.id === result.product.id);
      if (index < 0) return [result.product, ...previousProducts];
      const nextProducts = previousProducts.slice();
      nextProducts[index] = result.product;
      return nextProducts;
    });
    return result;
  }, []);

  const createFinancialAccount = useCallback(async (input: { name: string; kind: FinancialAccount['kind']; initialBalance?: number }) => {
    await db.createFinancialAccount(input);
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const transferFunds = useCallback(async (input: { originAccountId: string; destinationAccountId: string; amount: number; date: string; observation?: string }) => {
    await db.transferBetweenAccounts(input);
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const recordInvoice = useCallback(async (
    invoice: Invoice,
    allocations: PaymentAllocation[],
    options: db.InvoiceFinancialTransactionOptions = {},
  ) => {
    const updatedProducts = await SalesRepositoryService.createSale(invoice, allocations, options);
    const updatedById = new Map(updatedProducts.map(product => [product.id, product]));
    setProductsState(previous => previous.map(product => updatedById.get(product.id) || product));
    setInvoicesState(previous => [invoice, ...previous.filter(item => item.id !== invoice.id)]);
    if (options.quotationId) {
      setQuotationsState(previous => previous.map(quotation => (
        quotation.id === options.quotationId
          ? { ...quotation, status: 'accepted' }
          : quotation
      )));
    }
    // The sale is already committed atomically at this point. A transient read
    // failure while refreshing React state must not be reported as if Dexie had
    // rolled the sale back; the next reload will reconstruct the same data.
    try {
      await refreshFinancialData();
    } catch (error) {
      console.error('La venta fue guardada, pero no se pudo refrescar el resumen financiero.', error);
    }
  }, [refreshFinancialData]);

  const cancelInvoice = useCallback(async (invoiceId: string, reason: string) => {
    const result = await SalesRepositoryService.cancelSale(invoiceId, reason);
    setInvoicesState(previous => previous.map(invoice => invoice.id === invoiceId
      ? {
          ...invoice,
          status: 'cancelled' as const,
          cancellationReason: reason.trim(),
          cancelledAt: result.cancelledAt,
          cancelledBy: result.cancelledBy,
          paymentAllocations: [],
        }
      : invoice));

    if (result.restoredProducts.length > 0) {
      const restoredById = new Map(result.restoredProducts.map(product => [product.id, product]));
      setProductsState(previous => previous.map(product => restoredById.get(product.id) || product));
    }
    if (result.removedLayawayId) {
      setLayawaysState(previous => previous.filter(layaway => layaway.id !== result.removedLayawayId));
    }
    if (result.reopenedQuotationId) {
      setQuotationsState(previous => previous.map(quotation => quotation.id === result.reopenedQuotationId
        ? { ...quotation, status: 'active' as const }
        : quotation));
    }

    await refreshFinancialData();
  }, [refreshFinancialData]);

  const recordExpense = useCallback(async (expense: ExpenseInvoice, accountId: string) => {
    await db.insertExpenseWithFinancials(expense, accountId);
    setExpensesState(previous => [expense, ...previous.filter(item => item.id !== expense.id)]);
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const updateExpense = useCallback(async (expense: ExpenseInvoice) => {
    await db.updateExpenseWithFinancialAdjustment(expense);
    setExpensesState(previous => previous.map(item => item.id === expense.id ? expense : item));
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const recordLayaway = useCallback(async (layaway: Layaway) => {
    const persisted = await SalesRepositoryService.createLayaway(layaway);
    setLayawaysState(previous => [persisted, ...previous.filter(item => item.id !== persisted.id)]);
    setInvoicesState(previous => [persisted.invoice, ...previous.filter(item => item.id !== persisted.invoice.id)]);
    setProductsState(await db.fetchProducts());
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const recordLayawayPayment = useCallback(async (layawayId: string, payment: { id: string; amount: number; date: string; method: string; accountId: string }) => {
    const result = await SalesRepositoryService.addLayawayPayment(layawayId, payment);
    setLayawaysState(previous => previous.map(layaway => layaway.id === layawayId
      ? {
          ...layaway,
          payments: layaway.payments.some(existing => existing.id === result.payment.id)
            ? layaway.payments
            : [...layaway.payments, result.payment],
          completed: result.completed || layaway.completed,
          completedDate: result.completedDate || layaway.completedDate,
        }
      : layaway));
    if (result.completed) {
      setInvoicesState(previous => previous.map(invoice => invoice.id === result.invoiceId
        ? { ...invoice, status: 'paid' as const, date: result.completedDate || invoice.date }
        : invoice));
    }
    await refreshFinancialData();
    return result.completed;
  }, [refreshFinancialData]);

  const completeLayaway = useCallback(async (layawayId: string, completedDate: string) => {
    const invoiceId = await SalesRepositoryService.completeLayaway(layawayId, completedDate);
    setLayawaysState(previous => previous.map(item => item.id === layawayId
      ? { ...item, completed: true, completedDate }
      : item));
    setInvoicesState(previous => previous.map(invoice => invoice.id === invoiceId
      ? { ...invoice, status: 'paid' as const, date: completedDate }
      : invoice));
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const updateLayaway = useCallback(async (layawayId: string, invoice: Invoice) => {
    const result = await SalesRepositoryService.updateLayaway(layawayId, invoice);
    setLayawaysState(previous => previous.map(item => item.id === layawayId ? result.layaway : item));
    setInvoicesState(previous => previous.map(item => item.id === invoice.id ? result.layaway.invoice : item));
    if (result.updatedProducts.length > 0) {
      const updatedById = new Map(result.updatedProducts.map(product => [product.id, product]));
      setProductsState(previous => previous.map(product => updatedById.get(product.id) || product));
    }
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const deleteLayaway = useCallback(async (
    layawayId: string,
    resolution: LayawayCancellationResolution = 'refund',
  ) => {
    const result = await SalesRepositoryService.deleteLayaway(layawayId, resolution);
    setLayawaysState(previous => previous.filter(item => item.id !== layawayId));
    setInvoicesState(previous => previous.filter(invoice => invoice.id !== result.invoiceId));
    if (result.restoredProducts.length > 0) {
      const restoredById = new Map(result.restoredProducts.map(product => [product.id, product]));
      setProductsState(previous => previous.map(product => restoredById.get(product.id) || product));
    }
    await refreshFinancialData();
  }, [refreshFinancialData]);

  const setCategories = useCallback((nextCategories: string[]) => {
    void (async () => {
      try {
        if (getActiveRepositoryMode() !== 'lan') await requirePermission('manage_products');
        setCategoriesState(nextCategories);
      } catch (error) {
        reportContextWriteError('la actualización de categorías', error);
      }
    })();
  }, []);

  const value = useMemo<AppContextType>(() => ({
    company,
    setCompany,
    products,
    setProducts,
    contacts,
    setContacts,
    invoices,
    salesByWeight,
    purchaseInvoices,
    setPurchaseInvoices, createPurchase, updatePurchase, deletePurchase, markPurchasePaid,
    expenses,
    categories,
    setCategories,
    layaways,
    quotations,
    createQuotation,
    updateQuotationStatus,
    cashSessions,
    setCashSessions,
    applyInventoryAdjustment,
    financialAccounts, financialMovements, financialSummary, financialRefreshVersion,
    createFinancialAccount, transferFunds, recordInvoice, cancelInvoice, recordExpense, updateExpense, recordLayaway, recordLayawayPayment, completeLayaway, updateLayaway, deleteLayaway, refreshFinancialData, refreshProducts, refreshCategories,
    isLoading,
    reloadFromDatabase,
  }), [
    company,
    setCompany,
    products,
    setProducts,
    contacts,
    setContacts,
    invoices,
    salesByWeight,
    purchaseInvoices,
    setPurchaseInvoices, createPurchase, updatePurchase, deletePurchase, markPurchasePaid,
    expenses,
    categories,
    setCategories,
    layaways,
    quotations,
    createQuotation,
    updateQuotationStatus,
    cashSessions,
    setCashSessions,
    applyInventoryAdjustment,
    financialAccounts, financialMovements, financialSummary, financialRefreshVersion,
    createFinancialAccount, transferFunds, recordInvoice, cancelInvoice, recordExpense, updateExpense, recordLayaway, recordLayawayPayment, completeLayaway, updateLayaway, deleteLayaway, refreshFinancialData, refreshProducts, refreshCategories,
    isLoading,
    reloadFromDatabase,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};
