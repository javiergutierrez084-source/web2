import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import {
  activateLanClientWorkMode,
  activateLocalWorkMode,
  getEffectiveWorkMode,
  loadWorkModePreference,
  saveWorkModePreference,
  type EffectiveWorkMode,
  type WorkModePreference,
} from '@/config/workMode';
import { clearSession } from '@/lib/authCore';
import {
  discoverLanServers,
  loadLanConfig,
  saveLanConfig,
  type LanDiscoveredServer,
} from '@/lib/LanCommunicationConfig';
import { LanServerDescriptor } from '@/lib/LanServerDescriptor';
import { resetDataRepository } from '@/repositories/RepositoryRegistry';

export type WorkModeResolutionPhase =
  | 'resolving'
  | 'detecting'
  | 'awaiting-confirmation'
  | 'ready'
  | 'error';

interface WorkModeContextValue {
  preference: WorkModePreference;
  effectiveMode: EffectiveWorkMode;
  phase: WorkModeResolutionPhase;
  detectedServer: LanDiscoveredServer | null;
  error: string | null;
  serverName: string | null;
  serverAddress: string | null;
  requestModeChange: (mode: WorkModePreference) => void;
  confirmAutomaticServer: (connect: boolean) => Promise<void>;
  retryResolution: () => void;
  useLocalFallback: () => void;
}

const WorkModeContext = createContext<WorkModeContextValue | null>(null);

function selectDetectedServer(servers: LanDiscoveredServer[], ignoreTrust = false): LanDiscoveredServer | null {
  if (servers.length === 0) return null;
  const descriptor = LanServerDescriptor.load();
  if (ignoreTrust) return [...servers].sort((left, right) => left.latencyMs - right.latencyMs)[0] ?? null;
  const trusted = servers.find(server =>
    (!descriptor.serverId || server.serverId === descriptor.serverId)
    && (!descriptor.companyId || server.companyId === descriptor.companyId)
  );
  if (descriptor.serverId || descriptor.companyId) return trusted ?? null;
  return [...servers].sort((left, right) => left.latencyMs - right.latencyMs)[0] ?? null;
}

async function discoverPreferredServer(excludedServerId?: string, ignoreTrust = false): Promise<LanDiscoveredServer | null> {
  if (!window.joyaControlLan?.discoverServers) return null;
  const current = loadLanConfig();
  const servers = await discoverLanServers({
    ...current,
    mode: 'lan',
    role: 'client',
    autoReconnect: true,
  });
  return selectDetectedServer(
    excludedServerId ? servers.filter(server => server.serverId !== excludedServerId) : servers,
    ignoreTrust,
  );
}

async function rememberDetectedServer(server: LanDiscoveredServer): Promise<void> {
  await LanServerDescriptor.rememberServer({
    serverId: server.serverId,
    companyId: server.companyId,
    serverName: server.serverName,
    ip: server.ip,
    port: server.port,
    protocolVersion: server.protocolVersion,
  });
}

export function useWorkMode(): WorkModeContextValue {
  const context = useContext(WorkModeContext);
  if (!context) throw new Error('useWorkMode must be inside WorkModeProvider');
  return context;
}

export function WorkModeProvider({ children }: { children: ReactNode }) {
  const [preference, setPreference] = useState<WorkModePreference>(() => loadWorkModePreference());
  const [effectiveMode, setEffectiveMode] = useState<EffectiveWorkMode>(() => getEffectiveWorkMode());
  const [phase, setPhase] = useState<WorkModeResolutionPhase>('resolving');
  const [detectedServer, setDetectedServer] = useState<LanDiscoveredServer | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [descriptorSnapshot, setDescriptorSnapshot] = useState(() => LanServerDescriptor.toJSON());

  const resolveLocal = useCallback(() => {
    setDetectedServer(null);
    setError(null);
    setEffectiveMode(activateLocalWorkMode());
    resetDataRepository();
    setDescriptorSnapshot(LanServerDescriptor.toJSON());
    setPhase('ready');
  }, []);

  const resolveLan = useCallback(async (server?: LanDiscoveredServer | null) => {
    const current = loadLanConfig();
    if (current.role === 'server') {
      const status = await window.joyaControlLan?.getServerStatus?.();
      if (status?.running) await window.joyaControlLan?.stopServer?.();
      if (server) await LanServerDescriptor.reset();
    }
    if (server) await rememberDetectedServer(server);
    setDetectedServer(server ?? null);
    setError(null);
    setEffectiveMode(activateLanClientWorkMode());
    resetDataRepository();
    setDescriptorSnapshot(LanServerDescriptor.toJSON());
    setPhase('ready');
  }, []);

  useEffect(() => {
    let cancelled = false;

    const resolve = async () => {
      setError(null);
      setDetectedServer(null);
      const current = loadLanConfig();

      // A Principal Server owns the data locally. Automatic mode must never
      // make it connect to another server merely because discovery is enabled.
      if (current.mode === 'lan' && current.role === 'server' && preference !== 'lan') {
        if (!cancelled) {
          setEffectiveMode('server');
          setDescriptorSnapshot(LanServerDescriptor.toJSON());
          setPhase('ready');
        }
        return;
      }

      if (preference === 'local') {
        if (!cancelled) resolveLocal();
        return;
      }

      if (preference === 'lan') {
        try {
          setPhase('detecting');
          let server: LanDiscoveredServer | null = null;
          const ownServerId = current.role === 'server' ? LanServerDescriptor.getServerId() : undefined;
          if (current.role === 'server' || !LanServerDescriptor.hasAddress()) {
            server = await discoverPreferredServer(ownServerId || undefined, current.role === 'server');
          }
          if (cancelled) return;
          if ((current.role === 'server' || !LanServerDescriptor.hasAddress()) && !server) {
            throw new Error('No se encontró un Servidor Principal disponible en la red.');
          }
          await resolveLan(server);
        } catch (resolutionError) {
          if (cancelled) return;
          setError(resolutionError instanceof Error ? resolutionError.message : 'No fue posible preparar el Cliente LAN.');
          setPhase('error');
        }
        return;
      }

      // Automatic mode never blocks access when no Principal Server exists.
      setPhase('detecting');
      try {
        const server = await discoverPreferredServer();
        if (cancelled) return;
        if (!server) {
          resolveLocal();
          return;
        }
        setDetectedServer(server);
        setDescriptorSnapshot(LanServerDescriptor.toJSON());
        setPhase('awaiting-confirmation');
      } catch {
        if (!cancelled) resolveLocal();
      }
    };

    void resolve();
    return () => { cancelled = true; };
  }, [attempt, preference, resolveLan, resolveLocal]);

  useEffect(() => {
    const refreshDescriptor = () => setDescriptorSnapshot(LanServerDescriptor.toJSON());
    const refreshLanConfiguration = () => {
      refreshDescriptor();
      const current = loadLanConfig();
      if (current.mode === 'lan' && current.role === 'server') {
        saveWorkModePreference('local');
        setPreference('local');
        setEffectiveMode('server');
        setPhase('ready');
        resetDataRepository();
      }
    };
    window.addEventListener(LanServerDescriptor.changedEvent, refreshDescriptor);
    window.addEventListener('joyacontrol-lan-config-changed', refreshLanConfiguration);
    return () => {
      window.removeEventListener(LanServerDescriptor.changedEvent, refreshDescriptor);
      window.removeEventListener('joyacontrol-lan-config-changed', refreshLanConfiguration);
    };
  }, []);

  const requestModeChange = useCallback((mode: WorkModePreference) => {
    const applyAndReload = async () => {
      const current = loadLanConfig();
      if (mode === 'lan' && current.role === 'server') {
        const status = await window.joyaControlLan?.getServerStatus?.();
        if (status?.running) await window.joyaControlLan?.stopServer?.();
        saveLanConfig({ ...current, mode: 'local', role: 'client', serverStarted: false });
      }
      saveWorkModePreference(mode);
      setPreference(mode);
      clearSession();
      resetDataRepository();
      window.location.reload();
    };
    void applyAndReload();
  }, []);

  const confirmAutomaticServer = useCallback(async (connect: boolean) => {
    try {
      if (connect && detectedServer) {
        await resolveLan(detectedServer);
        return;
      }
      resolveLocal();
    } catch (confirmationError) {
      setError(confirmationError instanceof Error ? confirmationError.message : 'No fue posible cambiar el modo de trabajo.');
      setPhase('error');
    }
  }, [detectedServer, resolveLan, resolveLocal]);

  const retryResolution = useCallback(() => {
    setPhase('resolving');
    setAttempt(current => current + 1);
  }, []);

  const useLocalFallback = useCallback(() => {
    saveWorkModePreference('local');
    resolveLocal();
  }, [resolveLocal]);

  const value = useMemo<WorkModeContextValue>(() => ({
    preference,
    effectiveMode,
    phase,
    detectedServer,
    error,
    serverName: detectedServer?.serverName || descriptorSnapshot.serverName || null,
    serverAddress: detectedServer
      ? `http://${detectedServer.ip}:${detectedServer.port}`
      : descriptorSnapshot.baseUrl || null,
    requestModeChange,
    confirmAutomaticServer,
    retryResolution,
    useLocalFallback,
  }), [
    preference,
    effectiveMode,
    phase,
    detectedServer,
    error,
    descriptorSnapshot,
    requestModeChange,
    confirmAutomaticServer,
    retryResolution,
    useLocalFallback,
  ]);

  return <WorkModeContext.Provider value={value}>{children}</WorkModeContext.Provider>;
}
