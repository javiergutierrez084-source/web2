import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getSession, clearSession, logoutUser, type SessionUser } from '@/lib/auth';
import { getMasterExists } from '@/lib/auth';
import { LAN_AUTH_SESSION_EXPIRED_EVENT } from '@/lib/LanCommunicationConfig';

type AuthState = 'loading' | 'setup' | 'login' | 'authenticated';

interface AuthContextType {
  state: AuthState;
  user: SessionUser | null;
  login: (user: SessionUser) => void;
  logout: () => Promise<void>;
  refreshState: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be inside AuthProvider');
  return ctx;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [state, setState] = useState<AuthState>('loading');
  const [user, setUser] = useState<SessionUser | null>(null);

  const refreshState = async () => {
    const session = getSession();
    if (session) {
      setUser(session);
      setState('authenticated');
      return;
    }
    const masterExists = await getMasterExists();
    setState(masterExists ? 'login' : 'setup');
  };

  useEffect(() => { refreshState(); }, []);

  useEffect(() => {
    const handleConfirmedLanExpiration = () => {
      clearSession();
      setUser(null);
      setState('login');
    };
    window.addEventListener(LAN_AUTH_SESSION_EXPIRED_EVENT, handleConfirmedLanExpiration);
    return () => window.removeEventListener(LAN_AUTH_SESSION_EXPIRED_EVENT, handleConfirmedLanExpiration);
  }, []);

  const login = (u: SessionUser) => {
    setUser(u);
    setState('authenticated');
  };

  const logout = async () => {
    await logoutUser();
    clearSession();
    setUser(null);
    setState('login');
  };

  return (
    <AuthContext.Provider value={{ state, user, login, logout, refreshState }}>
      {children}
    </AuthContext.Provider>
  );
};
