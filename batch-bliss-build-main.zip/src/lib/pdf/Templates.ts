export type PdfDocumentFormat = 'letter' | 'ticket80' | 'ticket50';

export interface PdfTemplateDefinition {
  format: PdfDocumentFormat;
  label: string;
  description: string;
  width: number;
  minimumHeight: number;
  margin: number;
}

export const PDF_TEMPLATES: Record<PdfDocumentFormat, PdfTemplateDefinition> = {
  letter: {
    format: 'letter',
    label: 'Carta',
    description: 'Documento tamaño carta',
    width: 612,
    minimumHeight: 792,
    margin: 42,
  },
  ticket80: {
    format: 'ticket80',
    label: 'Tirilla 80 mm',
    description: 'Impresora térmica estándar',
    width: 226.77,
    minimumHeight: 420,
    margin: 10,
  },
  ticket50: {
    format: 'ticket50',
    label: 'Tirilla 50 mm',
    description: 'Impresora térmica compacta',
    width: 141.73,
    minimumHeight: 360,
    margin: 6,
  },
};

export const DEFAULT_DOCUMENT_FORMATS: PdfDocumentFormat[] = ['letter', 'ticket80', 'ticket50'];
