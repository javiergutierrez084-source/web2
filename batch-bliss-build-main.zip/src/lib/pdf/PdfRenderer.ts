import {
  generateInvoicePdf,
  generateTablePdf,
  type PdfDocumentData,
} from './DocumentRenderer';
import type { PdfDocumentFormat } from './Templates';

/**
 * Single rendering entry point used by preview, direct download and printing.
 * Every action receives the same immutable document model and the same PDF blob.
 */
export const renderPdfDocument = async (
  document: PdfDocumentData,
  format: PdfDocumentFormat,
): Promise<Blob> => document.kind === 'invoice'
  ? generateInvoicePdf(document, format)
  : generateTablePdf(document, format);
