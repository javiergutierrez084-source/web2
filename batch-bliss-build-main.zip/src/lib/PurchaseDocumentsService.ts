import type { ExpenseInvoice, PurchaseInvoice } from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';

export type PurchaseDocumentType = 'purchase' | 'expense';
export type PurchaseDocumentStatus = 'pending' | 'partial' | 'paid' | 'cancelled';

export interface ExpenseDocumentMetadata {
  version: 1;
  kind: 'expense';
  conceptId: string;
  conceptName: string;
  description: string;
}

export interface PurchaseDocumentRow {
  id: string;
  type: PurchaseDocumentType;
  number: string;
  supplierId: string;
  supplierName: string;
  concept: string;
  date: string;
  dueDate: string;
  total: number;
  paid: number;
  balance: number;
  status: PurchaseDocumentStatus;
  source: 'purchase' | 'supplier_invoice' | 'legacy_expense';
  purchase?: PurchaseInvoice;
  payable?: SupplierInvoiceView;
  legacyExpense?: ExpenseInvoice;
}

export interface PurchaseDashboardMetrics {
  purchasesToday: number;
  expensesToday: number;
  purchasesMonth: number;
  expensesMonth: number;
  pendingInvoices: number;
  overdueInvoices: number;
  topExpenseConcepts: Array<{ name: string; total: number }>;
  topSuppliers: Array<{ name: string; total: number }>;
}

const EXPENSE_METADATA_PREFIX = 'JOYACONTROL_EXPENSE_V1:';

const asDateKey = (value: string): string => String(value || '').slice(0, 10);
const asMonthKey = (value: string): string => asDateKey(value).slice(0, 7);

export function encodeExpenseDocumentNotes(input: {
  conceptId: string;
  conceptName: string;
  description?: string;
}): string {
  const metadata: ExpenseDocumentMetadata = {
    version: 1,
    kind: 'expense',
    conceptId: input.conceptId,
    conceptName: input.conceptName.trim(),
    description: String(input.description || '').trim(),
  };
  return `${EXPENSE_METADATA_PREFIX}${JSON.stringify(metadata)}`;
}

export function parseExpenseDocumentNotes(notes?: string): ExpenseDocumentMetadata | null {
  const value = String(notes || '');
  if (!value.startsWith(EXPENSE_METADATA_PREFIX)) return null;
  try {
    const parsed = JSON.parse(value.slice(EXPENSE_METADATA_PREFIX.length)) as Partial<ExpenseDocumentMetadata>;
    if (parsed.kind !== 'expense' || !parsed.conceptId || !parsed.conceptName) return null;
    return {
      version: 1,
      kind: 'expense',
      conceptId: String(parsed.conceptId),
      conceptName: String(parsed.conceptName),
      description: String(parsed.description || ''),
    };
  } catch {
    return null;
  }
}

export function isExpensePayable(invoice: SupplierInvoiceView): boolean {
  return Boolean(parseExpenseDocumentNotes(invoice.notes));
}

const normalizePayableStatus = (status: string): PurchaseDocumentStatus => {
  if (status === 'paid') return 'paid';
  if (status === 'partial') return 'partial';
  if (status === 'cancelled') return 'cancelled';
  return 'pending';
};

export function buildPurchaseDocumentRows(input: {
  purchases: PurchaseInvoice[];
  payables: SupplierInvoiceView[];
  legacyExpenses?: ExpenseInvoice[];
}): PurchaseDocumentRow[] {
  const payableByPurchaseId = new Map(
    input.payables
      .filter(item => item.sourceType === 'purchase_invoice' && item.sourceId)
      .map(item => [item.sourceId, item]),
  );

  const purchases: PurchaseDocumentRow[] = input.purchases.map(purchase => {
    const payable = payableByPurchaseId.get(purchase.id);
    const paid = payable
      ? payable.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0)
      : purchase.status === 'paid' ? purchase.total : 0;
    const balance = payable ? Math.max(0, payable.pendingBalance) : Math.max(0, purchase.total - paid);
    return {
      id: purchase.id,
      type: 'purchase',
      number: purchase.number,
      supplierId: purchase.supplierId,
      supplierName: purchase.supplierName,
      concept: purchase.description || 'Mercancía',
      date: purchase.date,
      dueDate: payable?.dueDate || purchase.date,
      total: purchase.total,
      paid,
      balance,
      status: purchase.status === 'cancelled'
        ? 'cancelled'
        : payable ? normalizePayableStatus(payable.status) : purchase.status === 'paid' ? 'paid' : 'pending',
      source: 'purchase',
      purchase,
      payable,
    };
  });

  const expensePayables: PurchaseDocumentRow[] = input.payables
    .filter(isExpensePayable)
    .map(payable => {
      const metadata = parseExpenseDocumentNotes(payable.notes)!;
      const paid = payable.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
      return {
        id: payable.id,
        type: 'expense',
        number: payable.invoiceNumber,
        supplierId: payable.supplierId,
        supplierName: payable.supplierName,
        concept: metadata.conceptName,
        date: payable.issueDate,
        dueDate: payable.dueDate,
        total: payable.total,
        paid,
        balance: Math.max(0, payable.pendingBalance),
        status: normalizePayableStatus(payable.status),
        source: 'supplier_invoice',
        payable,
      };
    });

  const representedExpenseNumbers = new Set(expensePayables.map(item => item.number));
  const legacyExpenses: PurchaseDocumentRow[] = (input.legacyExpenses || [])
    .filter(expense => !representedExpenseNumbers.has(expense.number))
    .map(expense => ({
      id: expense.id,
      type: 'expense',
      number: expense.number,
      supplierId: expense.supplierId,
      supplierName: expense.supplierName,
      concept: expense.description,
      date: expense.date,
      dueDate: expense.date,
      total: expense.total,
      paid: expense.status === 'paid' ? expense.total : 0,
      balance: expense.status === 'paid' ? 0 : expense.total,
      status: expense.status === 'paid' ? 'paid' : 'pending',
      source: 'legacy_expense',
      legacyExpense: expense,
    }));

  return [...purchases, ...expensePayables, ...legacyExpenses]
    .sort((a, b) => `${b.date}-${b.number}`.localeCompare(`${a.date}-${a.number}`));
}

export function calculatePurchaseDashboardMetrics(
  documents: PurchaseDocumentRow[],
  now = new Date(),
): PurchaseDashboardMetrics {
  const today = now.toISOString().slice(0, 10);
  const month = today.slice(0, 7);
  const active = documents.filter(item => item.status !== 'cancelled');
  const sum = (rows: PurchaseDocumentRow[]) => rows.reduce((total, item) => total + item.total, 0);

  const conceptTotals = new Map<string, number>();
  const supplierTotals = new Map<string, number>();
  for (const document of active) {
    supplierTotals.set(document.supplierName || 'Sin proveedor', (supplierTotals.get(document.supplierName || 'Sin proveedor') || 0) + document.total);
    if (document.type === 'expense') {
      conceptTotals.set(document.concept || 'Otros', (conceptTotals.get(document.concept || 'Otros') || 0) + document.total);
    }
  }

  const top = (values: Map<string, number>) => [...values.entries()]
    .map(([name, total]) => ({ name, total }))
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  return {
    purchasesToday: sum(active.filter(item => item.type === 'purchase' && asDateKey(item.date) === today)),
    expensesToday: sum(active.filter(item => item.type === 'expense' && asDateKey(item.date) === today)),
    purchasesMonth: sum(active.filter(item => item.type === 'purchase' && asMonthKey(item.date) === month)),
    expensesMonth: sum(active.filter(item => item.type === 'expense' && asMonthKey(item.date) === month)),
    pendingInvoices: active.filter(item => item.balance > 0.01).length,
    overdueInvoices: active.filter(item => item.balance > 0.01 && asDateKey(item.dueDate) < today).length,
    topExpenseConcepts: top(conceptTotals),
    topSuppliers: top(supplierTotals),
  };
}

export function duplicateExpenseNumber(number: string): string {
  const clean = String(number || 'GAS').replace(/-COPIA(?:-\d+)?$/i, '');
  return `${clean}-COPIA`;
}
