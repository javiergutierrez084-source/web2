export type ReportRangePreset =
  | 'today'
  | 'yesterday'
  | 'last7'
  | 'last30'
  | 'currentMonth'
  | 'previousMonth'
  | 'last3Months'
  | 'currentYear'
  | 'previousYear'
  | 'all'
  | 'custom';

export interface ReportDateRange {
  from: string;
  to: string;
  preset: ReportRangePreset;
}

const pad = (value: number): string => String(value).padStart(2, '0');

export const localDateKey = (date: Date): string =>
  `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;

const startOfMonth = (date: Date): Date => new Date(date.getFullYear(), date.getMonth(), 1);
const endOfMonth = (date: Date): Date => new Date(date.getFullYear(), date.getMonth() + 1, 0);

const addDays = (date: Date, days: number): Date => {
  const next = new Date(date);
  next.setDate(next.getDate() + days);
  return next;
};

export function buildReportDateRange(
  preset: Exclude<ReportRangePreset, 'custom'>,
  now = new Date(),
): ReportDateRange {
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  switch (preset) {
    case 'today':
      return { from: localDateKey(today), to: localDateKey(today), preset };
    case 'yesterday': {
      const yesterday = addDays(today, -1);
      return { from: localDateKey(yesterday), to: localDateKey(yesterday), preset };
    }
    case 'last7':
      return { from: localDateKey(addDays(today, -6)), to: localDateKey(today), preset };
    case 'last30':
      return { from: localDateKey(addDays(today, -29)), to: localDateKey(today), preset };
    case 'currentMonth':
      return { from: localDateKey(startOfMonth(today)), to: localDateKey(today), preset };
    case 'previousMonth': {
      const previous = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      return { from: localDateKey(startOfMonth(previous)), to: localDateKey(endOfMonth(previous)), preset };
    }
    case 'last3Months': {
      const start = new Date(today.getFullYear(), today.getMonth() - 2, 1);
      return { from: localDateKey(start), to: localDateKey(today), preset };
    }
    case 'currentYear':
      return { from: `${today.getFullYear()}-01-01`, to: localDateKey(today), preset };
    case 'previousYear': {
      const year = today.getFullYear() - 1;
      return { from: `${year}-01-01`, to: `${year}-12-31`, preset };
    }
    case 'all':
      return { from: '', to: '', preset };
  }
}

export function dateMatchesReportRange(value: string | null | undefined, range: Pick<ReportDateRange, 'from' | 'to'>): boolean {
  const date = String(value || '').slice(0, 10);
  if (!date) return false;
  if (range.from && date < range.from) return false;
  if (range.to && date > range.to) return false;
  return true;
}

export function isValidReportDateRange(range: Pick<ReportDateRange, 'from' | 'to'>): boolean {
  return !range.from || !range.to || range.from <= range.to;
}

export function describeReportDateRange(range: Pick<ReportDateRange, 'from' | 'to'>): string {
  if (!range.from && !range.to) return 'Todo el historial';
  if (range.from && range.to && range.from === range.to) return range.from;
  if (range.from && range.to) return `${range.from} a ${range.to}`;
  if (range.from) return `Desde ${range.from}`;
  return `Hasta ${range.to}`;
}
