import type { Contact, Product } from '@/data/mockData';
import { exportRowsToExcel, type ExcelColumn } from '@/lib/excelExport';

export type ProductMassUpdateField =
  | 'code'
  | 'name'
  | 'category'
  | 'supplierIds'
  | 'weightGrams'
  | 'purchasePrice'
  | 'salePrice'
  | 'reference'
  | 'description'
  | 'status';

export type ProductMassUpdatePreviewStatus =
  | 'change'
  | 'unchanged'
  | 'preserved'
  | 'error';

export interface ProductMassUpdateFieldDefinition {
  key: ProductMassUpdateField;
  label: string;
  header: string;
  aliases: string[];
  selectable: boolean;
  defaultSelected: boolean;
}

export interface ProductMassUpdateOptions {
  safeMode: boolean;
  selectedFields: ReadonlySet<ProductMassUpdateField>;
}

export interface ProductMassUpdatePreviewRow {
  sourceRow: number;
  productId?: string;
  product: string;
  field: string;
  currentValue: string;
  importedValue: string;
  nextValue: string;
  status: ProductMassUpdatePreviewStatus;
  message: string;
}

export interface ProductMassUpdateSourceResult {
  sourceRow: number;
  productId?: string;
  product: string;
  outcome: 'modified' | 'unchanged' | 'not_found' | 'error';
  reason: string;
}

export interface ProductMassUpdateSummary {
  productsFound: number;
  productsModified: number;
  productsUnchanged: number;
  productsNotFound: number;
  errors: number;
}

export interface ProductMassUpdatePlan {
  previewRows: ProductMassUpdatePreviewRow[];
  upserts: Product[];
  sourceResults: ProductMassUpdateSourceResult[];
  summary: ProductMassUpdateSummary;
}

export interface ProductUpdateTemplateRow {
  internalId: string;
  code: string;
  name: string;
  category: string;
  supplier: string;
  weightGrams: number;
  purchasePrice: number;
  salePrice: number;
  barcode: string;
  status: string;
  observations: string;
}

type RawRow = Record<string, unknown>;

export const PRODUCT_MASS_UPDATE_FIELDS: ProductMassUpdateFieldDefinition[] = [
  { key: 'code', label: 'Código', header: 'Código', aliases: ['codigo', 'código', 'code'], selectable: true, defaultSelected: true },
  { key: 'name', label: 'Nombre', header: 'Nombre', aliases: ['nombre', 'name', 'producto'], selectable: true, defaultSelected: true },
  { key: 'category', label: 'Categoría', header: 'Categoría', aliases: ['categoria', 'categoría', 'category'], selectable: true, defaultSelected: true },
  { key: 'supplierIds', label: 'Proveedor', header: 'Proveedor', aliases: ['proveedor', 'proveedores', 'supplier'], selectable: true, defaultSelected: true },
  { key: 'weightGrams', label: 'Peso', header: 'Peso', aliases: ['peso', 'peso gramos', 'gramos', 'weight'], selectable: true, defaultSelected: true },
  { key: 'purchasePrice', label: 'Precio compra', header: 'Precio compra', aliases: ['precio compra', 'precio de compra', 'purchase price'], selectable: true, defaultSelected: true },
  { key: 'salePrice', label: 'Precio venta', header: 'Precio venta', aliases: ['precio venta', 'precio de venta', 'sale price'], selectable: true, defaultSelected: true },
  { key: 'reference', label: 'Código de barras', header: 'Código de barras', aliases: ['codigo de barras', 'código de barras', 'barcode', 'referencia'], selectable: true, defaultSelected: true },
  { key: 'description', label: 'Observaciones', header: 'Observaciones', aliases: ['observaciones', 'observacion', 'observación', 'descripcion', 'descripción', 'description'], selectable: true, defaultSelected: true },
  {
    key: 'status',
    label: 'Estado',
    header: 'Estado',
    aliases: ['estado', 'status'],
    selectable: false,
    defaultSelected: false,
  },
];

const ID_ALIASES = ['id interno', 'id', 'product id', 'producto id'];

export const DEFAULT_PRODUCT_MASS_UPDATE_FIELDS = new Set<ProductMassUpdateField>(
  PRODUCT_MASS_UPDATE_FIELDS.filter(field => field.defaultSelected).map(field => field.key),
);

const stripAccents = (value: string): string => value
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '');

const normalizeHeader = (value: string): string => stripAccents(value.trim().toLowerCase());
const normalizeLookup = (value: unknown): string => stripAccents(String(value ?? '').trim().toLowerCase());
const isBlankCell = (value: unknown): boolean => value === undefined || value === null || String(value).trim() === '';

const findHeader = (headers: string[], aliases: string[]): string | undefined => {
  const accepted = new Set(aliases.map(normalizeHeader));
  return headers.find(header => accepted.has(normalizeHeader(header)));
};

const displayValue = (value: unknown): string => {
  if (Array.isArray(value)) return value.join(', ');
  if (value === undefined || value === null || value === '') return '(vacío)';
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : '(inválido)';
  return String(value);
};

const parseNumberCell = (value: unknown): number | null => {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  const source = String(value ?? '').trim().replace(/[$\s]/g, '');
  if (!source) return 0;

  let normalized = source;
  if (/^-?\d{1,3}(\.\d{3})+$/.test(source)) normalized = source.replace(/\./g, '');
  else if (/^-?\d{1,3}(,\d{3})+$/.test(source)) normalized = source.replace(/,/g, '');
  else if (source.includes(',') && source.includes('.')) {
    const decimalSeparator = source.lastIndexOf(',') > source.lastIndexOf('.') ? ',' : '.';
    const thousandsSeparator = decimalSeparator === ',' ? '.' : ',';
    normalized = source.replace(new RegExp(`\\${thousandsSeparator}`, 'g'), '').replace(decimalSeparator, '.');
  } else if (source.includes(',')) normalized = source.replace(',', '.');

  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
};

const sameStringArray = (left: string[] = [], right: string[] = []): boolean =>
  left.length === right.length && left.every((value, index) => value === right[index]);

const sameProduct = (left: Product, right: Product): boolean =>
  left.id === right.id &&
  left.code === right.code &&
  left.name === right.name &&
  left.category === right.category &&
  left.purchasePrice === right.purchasePrice &&
  left.salePrice === right.salePrice &&
  left.weightGrams === right.weightGrams &&
  left.margin === right.margin &&
  left.stock === right.stock &&
  left.minStock === right.minStock &&
  (left.description || '') === (right.description || '') &&
  (left.reference || left.code) === (right.reference || right.code) &&
  sameStringArray(left.supplierIds, right.supplierIds);

const productStatus = (product: Product): string =>
  product.stock <= 0 && product.minStock <= 0 ? 'Desactivado' : 'Activo';

const supplierNames = (product: Product, contactsById: Map<string, Contact>): string =>
  (product.supplierIds || [])
    .map(id => contactsById.get(id)?.name)
    .filter((name): name is string => Boolean(name))
    .join(', ');

const currentFieldValue = (
  product: Product,
  field: ProductMassUpdateField,
  contactsById: Map<string, Contact>,
): unknown => {
  switch (field) {
    case 'supplierIds': return supplierNames(product, contactsById);
    case 'reference': return product.reference || product.code;
    case 'description': return product.description || '';
    case 'status': return productStatus(product);
    default: return product[field];
  }
};

const appendPreview = (
  rows: ProductMassUpdatePreviewRow[],
  sourceRow: number,
  product: Product | undefined,
  field: string,
  currentValue: unknown,
  importedValue: unknown,
  nextValue: unknown,
  status: ProductMassUpdatePreviewStatus,
  message: string,
): void => {
  rows.push({
    sourceRow,
    productId: product?.id,
    product: product ? `${product.code} · ${product.name}` : '(producto no encontrado)',
    field,
    currentValue: displayValue(currentValue),
    importedValue: displayValue(importedValue),
    nextValue: displayValue(nextValue),
    status,
    message,
  });
};

const parseSupplierIds = (
  value: unknown,
  suppliersByName: Map<string, Contact[]>,
): { supplierIds?: string[]; error?: string } => {
  const names = String(value ?? '')
    .split(/[,;|]/)
    .map(name => name.trim())
    .filter(Boolean);
  if (names.length === 0) return { supplierIds: [] };

  const ids: string[] = [];
  for (const name of names) {
    const matches = suppliersByName.get(normalizeLookup(name)) || [];
    if (matches.length === 0) return { error: `El proveedor "${name}" no existe.` };
    if (matches.length > 1) return { error: `El proveedor "${name}" está duplicado y no puede resolverse de forma segura.` };
    if (!ids.includes(matches[0].id)) ids.push(matches[0].id);
  }
  return { supplierIds: ids };
};

const resolveProduct = (
  row: RawRow,
  idHeader: string | undefined,
  codeHeader: string | undefined,
  nameHeader: string | undefined,
  byId: Map<string, Product>,
  byCode: Map<string, Product[]>,
  byName: Map<string, Product[]>,
): { product?: Product; reason?: string } => {
  const attempts: string[] = [];
  const internalId = idHeader ? String(row[idHeader] ?? '').trim() : '';
  if (internalId) {
    const product = byId.get(internalId);
    if (product) return { product };
    attempts.push(`ID interno ${internalId}`);
  }

  const code = codeHeader ? String(row[codeHeader] ?? '').trim() : '';
  if (code) {
    const matches = byCode.get(normalizeLookup(code)) || [];
    if (matches.length === 1) return { product: matches[0] };
    if (matches.length > 1) return { reason: `El código ${code} identifica varios productos.` };
    attempts.push(`código ${code}`);
  }

  const name = nameHeader ? String(row[nameHeader] ?? '').trim() : '';
  if (name) {
    const matches = byName.get(normalizeLookup(name)) || [];
    if (matches.length === 1) return { product: matches[0] };
    if (matches.length > 1) return { reason: `El nombre exacto "${name}" identifica varios productos.` };
    attempts.push(`nombre exacto "${name}"`);
  }

  return {
    reason: attempts.length > 0
      ? `No se encontró el producto por ${attempts.join(', ')}.`
      : 'No se encontró el producto por ID interno, código ni nombre exacto.',
  };
};

const buildLookup = (products: Product[], selector: (product: Product) => string): Map<string, Product[]> => {
  const result = new Map<string, Product[]>();
  products.forEach(product => {
    const key = normalizeLookup(selector(product));
    if (!key) return;
    const bucket = result.get(key);
    if (bucket) bucket.push(product);
    else result.set(key, [product]);
  });
  return result;
};

const calculateMargin = (purchasePrice: number, salePrice: number): number =>
  purchasePrice > 0 ? ((salePrice - purchasePrice) / purchasePrice) * 100 : 0;

export function buildProductMassUpdatePlan(
  rows: RawRow[],
  products: Product[],
  contacts: Contact[],
  categories: string[],
  options: ProductMassUpdateOptions,
): ProductMassUpdatePlan {
  const previewRows: ProductMassUpdatePreviewRow[] = [];
  const upserts: Product[] = [];
  const sourceResults: ProductMassUpdateSourceResult[] = [];
  const byId = new Map(products.map(product => [product.id, product]));
  const byCode = buildLookup(products, product => product.code);
  const byName = buildLookup(products, product => product.name);
  const contactsById = new Map(contacts.map(contact => [contact.id, contact]));
  const suppliersByName = new Map<string, Contact[]>();
  contacts.filter(contact => contact.type === 'supplier').forEach(contact => {
    const key = normalizeLookup(contact.name);
    const bucket = suppliersByName.get(key);
    if (bucket) bucket.push(contact);
    else suppliersByName.set(key, [contact]);
  });
  const categoryLookup = new Map(categories.map(category => [normalizeLookup(category), category]));
  const headers = rows[0] ? Object.keys(rows[0]) : [];
  const idHeader = findHeader(headers, ID_ALIASES);
  const codeHeader = findHeader(headers, PRODUCT_MASS_UPDATE_FIELDS.find(field => field.key === 'code')!.aliases);
  const nameHeader = findHeader(headers, PRODUCT_MASS_UPDATE_FIELDS.find(field => field.key === 'name')!.aliases);
  const headersByField = new Map<ProductMassUpdateField, string | undefined>(
    PRODUCT_MASS_UPDATE_FIELDS.map(field => [field.key, findHeader(headers, field.aliases)]),
  );
  const seenProducts = new Set<string>();

  rows.forEach((row, index) => {
    const sourceRow = index + 2;
    const resolved = resolveProduct(row, idHeader, codeHeader, nameHeader, byId, byCode, byName);
    if (!resolved.product) {
      appendPreview(previewRows, sourceRow, undefined, 'Producto', '', '', '', 'error', resolved.reason || 'Producto no encontrado.');
      sourceResults.push({ sourceRow, product: '(producto no encontrado)', outcome: 'not_found', reason: resolved.reason || 'Producto no encontrado.' });
      return;
    }

    const product = resolved.product;
    const productLabel = `${product.code} · ${product.name}`;
    if (seenProducts.has(product.id)) {
      const reason = 'El producto aparece más de una vez en el archivo. Solo se admite una fila por producto.';
      appendPreview(previewRows, sourceRow, product, 'Producto', productLabel, productLabel, productLabel, 'error', reason);
      sourceResults.push({ sourceRow, productId: product.id, product: productLabel, outcome: 'error', reason });
      return;
    }
    seenProducts.add(product.id);

    let next: Product = { ...product, supplierIds: [...(product.supplierIds || [])] };
    let rowHasError = false;
    let selectedColumnFound = false;

    PRODUCT_MASS_UPDATE_FIELDS.forEach(definition => {
      if (!options.selectedFields.has(definition.key)) return;
      const header = headersByField.get(definition.key);
      if (!header) return;
      selectedColumnFound = true;
      const rawValue = row[header];
      const current = currentFieldValue(product, definition.key, contactsById);
      const blank = isBlankCell(rawValue);

      if (blank && options.safeMode) {
        appendPreview(previewRows, sourceRow, product, definition.label, current, rawValue, current, 'preserved', 'Se conservará el valor actual.');
        return;
      }

      if (definition.key === 'status') {
        const importedStatus = String(rawValue ?? '').trim();
        if (!importedStatus || normalizeLookup(importedStatus) === normalizeLookup(String(current))) {
          appendPreview(previewRows, sourceRow, product, definition.label, current, rawValue, current, 'unchanged', 'Sin cambios.');
        } else {
          rowHasError = true;
          appendPreview(
            previewRows,
            sourceRow,
            product,
            definition.label,
            current,
            rawValue,
            current,
            'error',
            'El modelo actual no tiene un campo de estado independiente. Use el flujo existente de activación/desactivación para no modificar stock.',
          );
        }
        return;
      }

      let nextValue: unknown;
      let error: string | undefined;

      switch (definition.key) {
        case 'code': {
          const value = String(rawValue ?? '').trim();
          if (!value) error = 'El código no puede quedar vacío.';
          else {
            const duplicates = byCode.get(normalizeLookup(value)) || [];
            if (duplicates.some(candidate => candidate.id !== product.id)) error = `El código ${value} ya pertenece a otro producto.`;
            nextValue = value;
          }
          break;
        }
        case 'name': {
          const value = String(rawValue ?? '').trim();
          if (!value) error = 'El nombre no puede quedar vacío.';
          else nextValue = value;
          break;
        }
        case 'category': {
          const value = String(rawValue ?? '').trim();
          if (!value) error = 'La categoría no puede quedar vacía.';
          else {
            const existingCategory = categoryLookup.get(normalizeLookup(value));
            if (!existingCategory) error = `La categoría "${value}" no existe.`;
            else nextValue = existingCategory;
          }
          break;
        }
        case 'supplierIds': {
          const parsed = parseSupplierIds(rawValue, suppliersByName);
          error = parsed.error;
          nextValue = parsed.supplierIds;
          break;
        }
        case 'weightGrams':
        case 'purchasePrice':
        case 'salePrice': {
          const parsed = parseNumberCell(rawValue);
          if (parsed === null || parsed < 0) error = 'Debe contener un número válido mayor o igual a cero.';
          else if (definition.key === 'salePrice' && parsed <= 0) error = 'El precio de venta debe ser mayor a cero.';
          else nextValue = parsed;
          break;
        }
        case 'reference': {
          const value = String(rawValue ?? '').trim();
          nextValue = value || product.code;
          break;
        }
        case 'description':
          nextValue = String(rawValue ?? '').trim();
          break;
      }

      if (error) {
        rowHasError = true;
        appendPreview(previewRows, sourceRow, product, definition.label, current, rawValue, current, 'error', error);
        return;
      }

      const comparableCurrent = definition.key === 'supplierIds'
        ? product.supplierIds || []
        : definition.key === 'reference'
          ? product.reference || product.code
          : definition.key === 'description'
            ? product.description || ''
            : product[definition.key];
      const unchanged = Array.isArray(nextValue)
        ? sameStringArray(comparableCurrent as string[], nextValue as string[])
        : comparableCurrent === nextValue;

      if (unchanged) {
        appendPreview(previewRows, sourceRow, product, definition.label, current, rawValue, current, 'unchanged', 'Sin cambios.');
        return;
      }

      switch (definition.key) {
        case 'code': next.code = nextValue as string; break;
        case 'name': next.name = nextValue as string; break;
        case 'category': next.category = nextValue as string; break;
        case 'supplierIds': next.supplierIds = nextValue as string[]; break;
        case 'weightGrams': next.weightGrams = nextValue as number; break;
        case 'purchasePrice': next.purchasePrice = nextValue as number; break;
        case 'salePrice': next.salePrice = nextValue as number; break;
        case 'reference': next.reference = nextValue as string; break;
        case 'description': next.description = nextValue as string; break;
      }
      appendPreview(previewRows, sourceRow, product, definition.label, current, rawValue, nextValue, 'change', 'Cambiar.');
    });

    if (!selectedColumnFound) {
      const reason = 'Ninguno de los campos seleccionados está presente en el archivo.';
      appendPreview(previewRows, sourceRow, product, 'Producto', productLabel, productLabel, productLabel, 'error', reason);
      sourceResults.push({ sourceRow, productId: product.id, product: productLabel, outcome: 'error', reason });
      return;
    }

    next = {
      ...next,
      stock: product.stock,
      minStock: product.minStock,
      availableGrams: product.availableGrams,
      averagePurchasePrice: product.averagePurchasePrice,
      lastPurchaseDate: product.lastPurchaseDate,
      margin: calculateMargin(next.purchasePrice, next.salePrice),
    };

    if (rowHasError) {
      sourceResults.push({ sourceRow, productId: product.id, product: productLabel, outcome: 'error', reason: 'La fila contiene uno o más campos inválidos. No se aplicará ningún cambio de esta fila.' });
      return;
    }

    if (sameProduct(product, next)) {
      sourceResults.push({ sourceRow, productId: product.id, product: productLabel, outcome: 'unchanged', reason: 'No contiene cambios aplicables.' });
      return;
    }

    upserts.push(next);
    sourceResults.push({ sourceRow, productId: product.id, product: productLabel, outcome: 'modified', reason: 'Listo para actualizar.' });
  });

  const productsFound = sourceResults.filter(result => result.outcome !== 'not_found').length;
  const productsModified = sourceResults.filter(result => result.outcome === 'modified').length;
  const productsUnchanged = sourceResults.filter(result => result.outcome === 'unchanged').length;
  const productsNotFound = sourceResults.filter(result => result.outcome === 'not_found').length;
  const errors = sourceResults.filter(result => result.outcome === 'error').length;

  return {
    previewRows,
    upserts,
    sourceResults,
    summary: { productsFound, productsModified, productsUnchanged, productsNotFound, errors },
  };
}


export async function applyProductMassUpdatePlan(
  plan: ProductMassUpdatePlan,
  applyChanges: (changes: { upserts: Product[]; deleteIds: string[] }) => Promise<void>,
): Promise<void> {
  if (plan.upserts.length === 0) return;
  await applyChanges({ upserts: plan.upserts, deleteIds: [] });
}

export function buildProductUpdateTemplateRows(products: Product[], contacts: Contact[]): ProductUpdateTemplateRow[] {
  const contactsById = new Map(contacts.map(contact => [contact.id, contact]));
  return products.map(product => ({
    internalId: product.id,
    code: product.code,
    name: product.name,
    category: product.category,
    supplier: supplierNames(product, contactsById),
    weightGrams: product.weightGrams,
    purchasePrice: product.purchasePrice,
    salePrice: product.salePrice,
    barcode: product.reference || product.code,
    status: productStatus(product),
    observations: product.description || '',
  }));
}

const templateColumns: ExcelColumn<ProductUpdateTemplateRow>[] = [
  { header: 'ID interno', value: row => row.internalId, width: 38 },
  { header: 'Código', value: row => row.code, width: 16 },
  { header: 'Nombre', value: row => row.name, width: 32 },
  { header: 'Categoría', value: row => row.category, width: 22 },
  { header: 'Proveedor', value: row => row.supplier, width: 30 },
  { header: 'Peso', value: row => row.weightGrams, width: 14 },
  { header: 'Precio compra', value: row => row.purchasePrice, width: 18 },
  { header: 'Precio venta', value: row => row.salePrice, width: 18 },
  { header: 'Código de barras', value: row => row.barcode, width: 22 },
  { header: 'Estado', value: row => row.status, width: 14 },
  { header: 'Observaciones', value: row => row.observations, width: 36 },
];

export function downloadProductUpdateTemplate(products: Product[], contacts: Contact[]): void {
  exportRowsToExcel({
    filename: 'Plantilla_Actualizacion_Productos',
    sheetName: 'Actualizar productos',
    columns: templateColumns,
    rows: buildProductUpdateTemplateRows(products, contacts),
  });
}

const reportColumns: ExcelColumn<ProductMassUpdateSourceResult>[] = [
  { header: 'Fila Excel', value: row => row.sourceRow, width: 12 },
  { header: 'ID interno', value: row => row.productId || '', width: 38 },
  { header: 'Producto', value: row => row.product, width: 36 },
  { header: 'Resultado', value: row => {
    switch (row.outcome) {
      case 'modified': return 'Actualizado';
      case 'unchanged': return 'Sin cambios';
      case 'not_found': return 'No encontrado';
      case 'error': return 'Error';
    }
  }, width: 18 },
  { header: 'Motivo', value: row => row.reason, width: 58 },
];

export function exportProductMassUpdateReport(plan: ProductMassUpdatePlan): void {
  exportRowsToExcel({
    filename: 'Reporte_Actualizacion_Masiva_Productos',
    sheetName: 'Resultado',
    columns: reportColumns,
    rows: plan.sourceResults,
  });
}
