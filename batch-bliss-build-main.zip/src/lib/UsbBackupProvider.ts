import type { IBackupProvider } from './IBackupProvider';
import { readFromFolder, writeBackupDataToFolder, isFileSystemAccessSupported } from './backup';
import {
  BackupDestination,
  type BackupInfo,
  type BackupEnvelope,
  normalizeBackupSource,
} from '@/types/backup';

export class UsbBackupProvider implements IBackupProvider {
  readonly destination = BackupDestination.USB;

  async save(envelope: BackupEnvelope): Promise<void> {
    if (!isFileSystemAccessSupported()) {
      throw new Error('Tu navegador no soporta elegir carpeta (PC o USB). Usa "Descargar archivo" en su lugar.');
    }
    await writeBackupDataToFolder(envelope);
  }

  async load(): Promise<BackupEnvelope | null> {
    if (!isFileSystemAccessSupported()) {
      throw new Error('Tu navegador no soporta elegir carpeta (PC o USB).');
    }
    return normalizeBackupSource(await readFromFolder());
  }

  async list(): Promise<BackupInfo[]> {
    return [];
  }

  async delete(): Promise<void> {
    // No persistent directory handle is retained.
  }

  async exists(): Promise<boolean> {
    return false;
  }
}
