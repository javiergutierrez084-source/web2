import { isSoldByWeight, type Invoice, type InvoiceItem, type Product } from '@/data/mockData';
import { isSalesInvoice } from '@/lib/DashboardMetricsService';

export interface ProductSalesSummary {
  productId: string;
  code: string;
  name: string;
  quantitySold: number;
  gramsSold: number;
  totalSold: number;
}

/**
 * Resolves the physical grams represented by one immutable invoice line.
 * Weight-based lines already store the total grams in weightGrams, while unit
 * products store the weight of one unit and therefore multiply by quantity.
 */
export function calculateInvoiceItemSoldGrams(
  item: InvoiceItem,
  product?: Product,
): number {
  if (typeof item.totalGramsSold === 'number' && Number.isFinite(item.totalGramsSold)) {
    return Math.max(0, item.totalGramsSold);
  }
  const byWeight = item.isByWeight === true || Boolean(product && isSoldByWeight(product));
  const weight = Number(item.weightGrams) || 0;
  return Math.max(0, byWeight ? weight : weight * (Number(item.quantity) || 0));
}

export function calculateProductSales(
  invoices: readonly Invoice[],
  products: readonly Product[] = [],
): ProductSalesSummary[] {
  const result = new Map<string, ProductSalesSummary>();
  const productById = new Map(products.map(product => [product.id, product]));

  invoices.filter(isSalesInvoice).forEach(invoice => {
    invoice.items.forEach(item => {
      const current = result.get(item.productId) ?? {
        productId: item.productId,
        code: item.code,
        name: item.name,
        quantitySold: 0,
        gramsSold: 0,
        totalSold: 0,
      };
      current.quantitySold += Number(item.quantity) || 0;
      current.gramsSold += calculateInvoiceItemSoldGrams(item, productById.get(item.productId));
      current.totalSold += Number(item.subtotal) || 0;
      result.set(item.productId, current);
    });
  });

  return [...result.values()].sort((left, right) => right.totalSold - left.totalSold);
}
