import type { Contact } from '@/data/mockData';
import type { IDataRepository } from '@/repositories/IDataRepository';
import { getDataRepository } from '@/repositories/RepositoryRegistry';

export type SupplierResolverRepository = Pick<
  IDataRepository,
  'fetchContacts' | 'applyContactChanges'
>;

export interface SupplierResolution {
  supplierId: string | null;
  supplierName: string;
  isNew: boolean;
  isReused: boolean;
}

export function normalizeSupplierName(value: unknown): string {
  return String(value ?? '').replace(/\s+/g, ' ').trim();
}

export function normalizeSupplierKey(value: unknown): string {
  return normalizeSupplierName(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLocaleLowerCase('es');
}

/**
 * Resolves every supplier used by a single bulk-import in memory.
 * Existing contacts are loaded once and newly-created suppliers are committed
 * in one repository write, so repeated names never trigger repeated queries or
 * duplicate inserts during the same import.
 */
export class SupplierImportResolver {
  private readonly byKey = new Map<string, Contact>();
  private readonly createdThisRun: Contact[] = [];
  private readonly createdIds = new Set<string>();
  private readonly reusedExistingIds = new Set<string>();
  private loaded = false;

  constructor(
    private readonly repository: SupplierResolverRepository = getDataRepository(),
    private readonly idFactory: () => string = () => crypto.randomUUID(),
  ) {}

  async load(): Promise<void> {
    if (this.loaded) return;
    const contacts = await this.repository.fetchContacts();
    for (const contact of contacts) {
      if (contact.type !== 'supplier') continue;
      const key = normalizeSupplierKey(contact.name);
      if (key && !this.byKey.has(key)) this.byKey.set(key, contact);
    }
    this.loaded = true;
  }

  resolve(rawName: unknown): SupplierResolution {
    if (!this.loaded) throw new Error('SUPPLIER_RESOLVER_NOT_LOADED');

    const supplierName = normalizeSupplierName(rawName);
    if (!supplierName) {
      return { supplierId: null, supplierName: '', isNew: false, isReused: false };
    }

    const key = normalizeSupplierKey(supplierName);
    const existing = this.byKey.get(key);
    if (existing) {
      const isCreatedThisRun = this.createdIds.has(existing.id);
      if (!isCreatedThisRun) this.reusedExistingIds.add(existing.id);
      return {
        supplierId: existing.id,
        supplierName: existing.name,
        isNew: false,
        isReused: true,
      };
    }

    const supplier: Contact = {
      id: this.idFactory(),
      type: 'supplier',
      name: supplierName,
      document: '',
      phone: '',
      email: '',
      address: '',
      notes: 'Creado automáticamente por carga masiva de productos',
    };
    this.byKey.set(key, supplier);
    this.createdThisRun.push(supplier);
    this.createdIds.add(supplier.id);

    return {
      supplierId: supplier.id,
      supplierName: supplier.name,
      isNew: true,
      isReused: false,
    };
  }

  async commit(): Promise<Contact[]> {
    if (this.createdThisRun.length === 0) return [];
    const created = [...this.createdThisRun];
    await this.repository.applyContactChanges({ upserts: created, deleteIds: [] });
    this.createdThisRun.length = 0;
    return created;
  }

  getReusedExistingCount(): number {
    return this.reusedExistingIds.size;
  }
}
