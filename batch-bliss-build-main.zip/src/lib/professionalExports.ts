import type { Contact, FinancialMovement, Invoice, Product } from '@/data/mockData';
import {
  formatCurrency,
  getProductAvailableGrams,
  getProductAveragePurchasePrice,
  isSoldByWeight,
} from '@/data/mockData';
import type { CompanyInfo } from '@/domain/models';
import { buildInvoiceDocumentData, buildTableDocumentData, type InvoiceDocumentData, type TableDocumentData } from '@/lib/pdf';
import type { ExcelColumn } from '@/lib/excelExport';
import { isSalesInvoice } from '@/lib/DashboardMetricsService';
import { calculateInvoiceItemSoldGrams } from '@/lib/salesAnalytics';

export interface SalesExportFilters {
  search: string;
  status: string;
  dateFrom: string;
  dateTo: string;
  user: string;
  sortOrder: 'asc' | 'desc';
}

export interface SalesExportContext {
  company: CompanyInfo;
  invoices: Invoice[];
  contacts: Contact[];
  products: Product[];
  financialMovements: FinancialMovement[];
  currentUserName: string;
  filters: SalesExportFilters;
}

export interface InvoiceExportRow {
  invoiceNumber: string;
  date: string;
  client: string;
  document: string;
  product: string;
  quantity: number;
  grams: number;
  price: number;
  subtotal: number;
  total: number;
  paymentMethod: string;
  user: string;
  status: string;
  observations: string;
}

export interface SalesSummaryRow {
  invoiceNumber: string;
  date: string;
  client: string;
  document: string;
  products: string;
  totalQuantity: number;
  grams: number;
  cost: number;
  sale: number;
  profit: number;
  paymentMethod: string;
  user: string;
  status: string;
  observations: string;
}

const finite = (value: unknown): number => Number.isFinite(Number(value)) ? Number(value) : 0;

export const getInvoiceUserName = (invoice: Invoice, movements: FinancialMovement[]): string =>
  movements.find(movement => movement.documentType === 'invoice' && movement.documentId === invoice.id)?.userName || 'No registrado';

export const invoiceCost = (invoice: Invoice): number => invoice.items.reduce((sum, item) =>
  sum + (finite(item.costPrice) * finite(item.quantity)), 0);

export const invoiceProductCount = (invoice: Invoice): number =>
  invoice.items.reduce((sum, item) => sum + finite(item.quantity), 0);

export const invoiceGrams = (invoice: Invoice, products: Product[] = []): number => {
  const productById = new Map(products.map(product => [product.id, product]));
  return invoice.items.reduce((sum, item) =>
    sum + calculateInvoiceItemSoldGrams(item, productById.get(item.productId)), 0);
};

export const buildInvoiceExcelRows = (
  invoice: Invoice,
  contact: Contact | undefined,
  movements: FinancialMovement[],
  products: Product[] = [],
): InvoiceExportRow[] => {
  const user = getInvoiceUserName(invoice, movements);
  const productById = new Map(products.map(product => [product.id, product]));
  return invoice.items.map(item => ({
    invoiceNumber: invoice.number,
    date: invoice.date,
    client: invoice.clientName,
    document: contact?.document || '',
    product: item.name,
    quantity: finite(item.quantity),
    grams: calculateInvoiceItemSoldGrams(item, productById.get(item.productId)),
    price: finite(item.unitPrice),
    subtotal: finite(item.subtotal),
    total: finite(invoice.total),
    paymentMethod: invoice.paymentMethod || '—',
    user,
    status: invoice.status,
    observations: invoice.clientNotes || '',
  }));
};

export const invoiceExcelColumns: ExcelColumn<InvoiceExportRow>[] = [
  { header: 'Número factura', value: row => row.invoiceNumber, width: 18 },
  { header: 'Fecha', value: row => row.date, width: 13 },
  { header: 'Cliente', value: row => row.client, width: 28 },
  { header: 'Documento', value: row => row.document, width: 18 },
  { header: 'Producto', value: row => row.product, width: 30 },
  { header: 'Cantidad', value: row => row.quantity, width: 12 },
  { header: 'Gramos', value: row => row.grams, width: 12 },
  { header: 'Precio', value: row => row.price, width: 16 },
  { header: 'Subtotal', value: row => row.subtotal, width: 16 },
  { header: 'Total', value: row => row.total, width: 16 },
  { header: 'Método de pago', value: row => row.paymentMethod, width: 20 },
  { header: 'Usuario', value: row => row.user, width: 22 },
  { header: 'Estado', value: row => row.status, width: 14 },
  { header: 'Observaciones', value: row => row.observations, width: 36 },
];

export const buildSalesSummaryRows = (context: SalesExportContext): SalesSummaryRow[] => {
  const contactById = new Map(context.contacts.map(contact => [contact.id, contact]));
  return context.invoices.filter(isSalesInvoice).map(invoice => {
    const cost = invoiceCost(invoice);
    return {
      invoiceNumber: invoice.number,
      date: invoice.date,
      client: invoice.clientName,
      document: contactById.get(invoice.clientId)?.document || '',
      products: invoice.items.map(item => item.name).join(', '),
      totalQuantity: invoiceProductCount(invoice),
      grams: invoiceGrams(invoice, context.products),
      cost,
      sale: finite(invoice.total),
      profit: finite(invoice.total) - cost,
      paymentMethod: invoice.paymentMethod || '—',
      user: getInvoiceUserName(invoice, context.financialMovements),
      status: invoice.status,
      observations: invoice.clientNotes || '',
    };
  });
};

export const salesSummaryExcelColumns: ExcelColumn<SalesSummaryRow>[] = [
  { header: 'No Factura', value: row => row.invoiceNumber, width: 18 },
  { header: 'Fecha', value: row => row.date, width: 13 },
  { header: 'Cliente', value: row => row.client, width: 26 },
  { header: 'Documento', value: row => row.document, width: 18 },
  { header: 'Productos', value: row => row.products, width: 42 },
  { header: 'Cantidad total', value: row => row.totalQuantity, width: 15 },
  { header: 'Gramos', value: row => row.grams, width: 14 },
  { header: 'Costo', value: row => row.cost, width: 16 },
  { header: 'Venta', value: row => row.sale, width: 16 },
  { header: 'Utilidad', value: row => row.profit, width: 16 },
  { header: 'Método pago', value: row => row.paymentMethod, width: 20 },
  { header: 'Usuario', value: row => row.user, width: 22 },
  { header: 'Estado', value: row => row.status, width: 14 },
  { header: 'Observaciones', value: row => row.observations, width: 36 },
];

export const buildSalesFiltersDescription = (filters: SalesExportFilters): string => {
  const parts = [
    filters.dateFrom ? `Desde ${filters.dateFrom}` : '',
    filters.dateTo ? `Hasta ${filters.dateTo}` : '',
    filters.status ? `Estado: ${filters.status}` : '',
    filters.user ? `Usuario: ${filters.user}` : '',
    filters.search.trim() ? `Búsqueda: ${filters.search.trim()}` : '',
    `Orden: ${filters.sortOrder === 'desc' ? 'mayor a menor' : 'menor a mayor'}`,
  ].filter(Boolean);
  return parts.length ? parts.join(' · ') : 'Sin filtros';
};

export const buildSalesPdfDocument = (context: SalesExportContext): TableDocumentData => {
  const rows = buildSalesSummaryRows(context);
  const totalSales = rows.reduce((sum, row) => sum + row.sale, 0);
  const totalCost = rows.reduce((sum, row) => sum + row.cost, 0);
  const totalProducts = rows.reduce((sum, row) => sum + row.totalQuantity, 0);
  return buildTableDocumentData({
    company: context.company,
    title: 'Informe de Facturas',
    subtitle: `Generado por ${context.currentUserName} · ${buildSalesFiltersDescription(context.filters)}`,
    filename: 'Facturas_Filtradas',
    columns: [
      { header: 'Factura' }, { header: 'Cliente' }, { header: 'Fecha' },
      { header: 'Valor', align: 'right' }, { header: 'Estado', align: 'center' }, { header: 'Usuario' },
    ],
    rows: rows.map(row => [row.invoiceNumber, row.client, row.date, formatCurrency(row.sale), row.status, row.user]),
    summaryLines: [
      { label: 'Total ventas', value: formatCurrency(totalSales) },
      { label: 'Total costo', value: formatCurrency(totalCost) },
      { label: 'Utilidad', value: formatCurrency(totalSales - totalCost), bold: true },
      { label: 'Cantidad facturas', value: String(rows.length) },
      { label: 'Cantidad productos', value: String(totalProducts) },
    ],
  });
};

export interface InventoryExportContext {
  company: CompanyInfo;
  products: Product[];
  contacts: Contact[];
  currentUserName: string;
  filtersDescription: string;
}

export interface InventoryExportRow {
  code: string;
  product: string;
  category: string;
  supplier: string;
  quantity: number;
  grams: number;
  cost: number;
  salePrice: number;
  profit: number;
  minStock: number;
  status: string;
  location: string;
  inventoryValue: number;
}

export const buildInventoryRows = (context: InventoryExportContext): InventoryExportRow[] => {
  const contactById = new Map(context.contacts.map(contact => [contact.id, contact.name]));
  return context.products.map(product => {
    const cost = getProductAveragePurchasePrice(product);
    const inventoryValue = cost * product.stock;
    return {
      code: product.code,
      product: product.name,
      category: product.category,
      supplier: (product.supplierIds || []).map(id => contactById.get(id) || id).join(', ') || '—',
      quantity: isSoldByWeight(product) ? 0 : product.stock,
      grams: getProductAvailableGrams(product),
      cost,
      salePrice: product.salePrice,
      profit: (product.salePrice - cost) * product.stock,
      minStock: product.minStock,
      status: product.stock <= product.minStock ? 'Bajo Stock' : 'Stock OK',
      location: (product as Product & { location?: string }).location || '—',
      inventoryValue,
    };
  });
};

export const inventoryProfessionalExcelColumns: ExcelColumn<InventoryExportRow>[] = [
  { header: 'Código', value: row => row.code, width: 16 },
  { header: 'Producto', value: row => row.product, width: 30 },
  { header: 'Categoría', value: row => row.category, width: 20 },
  { header: 'Proveedor', value: row => row.supplier, width: 28 },
  { header: 'Cantidad', value: row => row.quantity, width: 12 },
  { header: 'Gramos', value: row => row.grams, width: 14 },
  { header: 'Costo', value: row => row.cost, width: 16 },
  { header: 'Precio venta', value: row => row.salePrice, width: 16 },
  { header: 'Utilidad', value: row => row.profit, width: 16 },
  { header: 'Stock mínimo', value: row => row.minStock, width: 14 },
  { header: 'Estado', value: row => row.status, width: 14 },
  { header: 'Ubicación', value: row => row.location, width: 18 },
  { header: 'Valor inventario', value: row => row.inventoryValue, width: 18 },
];

export const buildInventoryPdfDocument = (context: InventoryExportContext): TableDocumentData => {
  const rows = buildInventoryRows(context);
  const totalGrams = rows.reduce((sum, row) => sum + row.grams, 0);
  const totalCost = rows.reduce((sum, row) => sum + row.inventoryValue, 0);
  const totalSale = context.products.reduce((sum, product) => sum + (product.salePrice * product.stock), 0);
  return buildTableDocumentData({
    company: context.company,
    title: 'Inventario',
    subtitle: `Generado por ${context.currentUserName} · ${context.filtersDescription}`,
    filename: 'Inventario_Filtrado',
    columns: [
      { header: 'Código' }, { header: 'Producto' }, { header: 'Categoría' }, { header: 'Proveedor' },
      { header: 'Cant.', align: 'right' }, { header: 'Gramos', align: 'right' },
      { header: 'Costo', align: 'right' }, { header: 'Venta', align: 'right' }, { header: 'Estado' },
    ],
    rows: rows.map(row => [row.code, row.product, row.category, row.supplier, row.quantity, row.grams, formatCurrency(row.cost), formatCurrency(row.salePrice), row.status]),
    summaryLines: [
      { label: 'Cantidad productos', value: String(rows.length) },
      { label: 'Gramos totales', value: String(totalGrams) },
      { label: 'Costo total', value: formatCurrency(totalCost) },
      { label: 'Valor venta', value: formatCurrency(totalSale) },
      { label: 'Utilidad potencial', value: formatCurrency(totalSale - totalCost), bold: true },
    ],
  });
};

export const buildIndividualInvoicePdf = (
  invoice: Invoice,
  company: CompanyInfo,
  contact: Contact | undefined,
  products: Product[],
): InvoiceDocumentData => buildInvoiceDocumentData({ invoice, type: 'sale', company, contact, products });
