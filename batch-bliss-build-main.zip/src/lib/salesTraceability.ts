import {
  isSoldByWeight,
  type Invoice,
  type Product,
} from '@/data/mockData';
import { isSalesInvoice } from '@/lib/DashboardMetricsService';
import { calculateInvoiceItemSoldGrams } from '@/lib/salesAnalytics';
import type { FinancialLedgerRow } from '@/lib/FinancialTraceabilityService';

export interface InvoiceTraceSearchIndex {
  searchableByInvoiceId: Map<string, string>;
  exactInvoiceIdsByTerm: Map<string, Set<string>>;
}

export interface ProductSaleHistoryEntry {
  invoiceId: string;
  invoiceNumber: string;
  date: string;
  clientName: string;
  quantity: number;
  unitPrice: number;
  subtotal: number;
  isByWeight: boolean;
}

export interface ProductSalesInfo {
  totalTransactions: number;
  totalGrams: number;
  totalAmount: number;
  history: ProductSaleHistoryEntry[];
}


const COMMERCIAL_SALE_LEDGER_CODES = new Set(['SALE_PAYMENT', 'CUSTOMER_CREDIT_USED', 'LAYAWAY_COMPLETED', 'SALE_CANCEL', 'REVERSAL']);

/**
 * Keeps non-sale ledger history untouched while excluding every financial row
 * whose source invoice is not a valid commercial sale. Raw Libro Mayor views
 * may still display the immutable original/reversal pair; commercial reports
 * call this helper so all periods use the official invoice-validity rule.
 */
export function filterCommercialSaleLedgerRows(
  rows: readonly FinancialLedgerRow[],
  invoices: readonly Invoice[],
): FinancialLedgerRow[] {
  const invoiceById = new Map(invoices.map(invoice => [invoice.id, invoice]));
  return rows.filter(row => {
    if (!COMMERCIAL_SALE_LEDGER_CODES.has(row.code)) return true;
    if (row.code === 'REVERSAL' && row.referenceType !== 'SALE') return true;

    const directInvoice = invoiceById.get(row.referenceId || row.movement.documentId);
    const searchableDocument = `${row.document} ${row.reference} ${row.movement.reference || ''}`
      .toLocaleLowerCase('es');
    // Historical LAYAWAY_COMPLETED rows used the layaway id as reference. Once
    // a completed layaway is cancelled and removed, the persisted invoice
    // number is the remaining stable bridge back to the commercial document.
    const invoice = directInvoice || (row.code === 'LAYAWAY_COMPLETED'
      ? invoices.find(candidate => searchableDocument.includes(candidate.number.toLocaleLowerCase('es')))
      : undefined);
    return !invoice || isSalesInvoice(invoice);
  });
}

export const EMPTY_PRODUCT_SALES_INFO: ProductSalesInfo = Object.freeze({
  totalTransactions: 0,
  totalGrams: 0,
  totalAmount: 0,
  history: [],
});

export function normalizeSalesTraceSearch(value: unknown): string {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLocaleLowerCase('es');
}

function addExactTerm(index: Map<string, Set<string>>, value: unknown, invoiceId: string): void {
  const term = normalizeSalesTraceSearch(value);
  if (!term) return;
  const current = index.get(term) ?? new Set<string>();
  current.add(invoiceId);
  index.set(term, current);
}

/**
 * Builds a read-only search index from the invoices and products already
 * supplied by AppContext. It does not write to Repository or IndexedDB.
 */
export function buildInvoiceTraceSearchIndex(
  invoices: readonly Invoice[],
  products: readonly Product[],
): InvoiceTraceSearchIndex {
  const productById = new Map(products.map(product => [product.id, product]));
  const searchableByInvoiceId = new Map<string, string>();
  const exactInvoiceIdsByTerm = new Map<string, Set<string>>();

  invoices.forEach(invoice => {
    const searchableTerms: unknown[] = [invoice.number, invoice.clientName];
    addExactTerm(exactInvoiceIdsByTerm, invoice.number, invoice.id);

    invoice.items.forEach(item => {
      const product = productById.get(item.productId);
      const productTerms = [
        item.code,
        item.name,
        product?.code,
        product?.name,
        product?.reference,
      ];
      searchableTerms.push(...productTerms);
      productTerms.forEach(term => addExactTerm(exactInvoiceIdsByTerm, term, invoice.id));
    });

    searchableByInvoiceId.set(
      invoice.id,
      normalizeSalesTraceSearch(searchableTerms.filter(Boolean).join(' ')),
    );
  });

  return { searchableByInvoiceId, exactInvoiceIdsByTerm };
}

export function invoiceMatchesTraceSearch(
  invoiceId: string,
  query: string,
  index: InvoiceTraceSearchIndex,
): boolean {
  const tokens = normalizeSalesTraceSearch(query).split(/\s+/).filter(Boolean);
  if (tokens.length === 0) return true;
  const searchable = index.searchableByInvoiceId.get(invoiceId) || '';
  return tokens.every(token => searchable.includes(token));
}

export function exactInvoiceIdsForTraceSearch(
  query: string,
  index: InvoiceTraceSearchIndex,
): string[] {
  const normalized = normalizeSalesTraceSearch(query);
  if (!normalized) return [];
  return [...(index.exactInvoiceIdsByTerm.get(normalized) ?? [])];
}

/**
 * Builds the complete product-to-invoice history in one pass. The returned
 * Map makes each product-detail lookup O(1), even with thousands of invoices.
 */
export function buildProductSalesHistoryIndex(
  invoices: readonly Invoice[],
  products: readonly Product[],
  layaways: readonly { invoiceId: string; completed: boolean }[],
): Map<string, ProductSalesInfo> {
  const productById = new Map(products.map(product => [product.id, product]));
  const activeLayawayInvoiceIds = new Set(
    layaways.filter(layaway => !layaway.completed).map(layaway => layaway.invoiceId),
  );
  const result = new Map<string, ProductSalesInfo>();

  invoices.forEach(invoice => {
    if (!isSalesInvoice(invoice) || activeLayawayInvoiceIds.has(invoice.id)) return;

    const countedProductIds = new Set<string>();
    invoice.items.forEach(item => {
      const product = productById.get(item.productId);
      if (!product) return;

      const previous = result.get(item.productId) ?? {
        totalTransactions: 0,
        totalGrams: 0,
        totalAmount: 0,
        history: [],
      };
      const byWeight = isSoldByWeight(product);
      const grams = calculateInvoiceItemSoldGrams(item, product);
      const firstItemForInvoice = !countedProductIds.has(item.productId);
      countedProductIds.add(item.productId);

      result.set(item.productId, {
        totalTransactions: previous.totalTransactions + (firstItemForInvoice ? 1 : 0),
        totalGrams: previous.totalGrams + grams,
        totalAmount: previous.totalAmount + item.subtotal,
        history: [
          ...previous.history,
          {
            invoiceId: invoice.id,
            invoiceNumber: invoice.number,
            date: invoice.date,
            clientName: invoice.clientName || 'Consumidor final',
            quantity: item.quantity,
            unitPrice: item.unitPrice,
            subtotal: item.subtotal,
            isByWeight: byWeight,
          },
        ],
      });
    });
  });

  result.forEach(info => {
    info.history.sort((left, right) => {
      const byDate = right.date.localeCompare(left.date);
      return byDate !== 0 ? byDate : right.invoiceNumber.localeCompare(left.invoiceNumber, 'es');
    });
  });

  return result;
}
