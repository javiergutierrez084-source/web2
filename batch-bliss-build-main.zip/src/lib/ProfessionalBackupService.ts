import { BackupManager, type BackupEnvelope } from '@/lib/BackupManager';
import { getEffectiveWorkMode } from '@/config/workMode';
import { getSession, logActivity } from '@/lib/auth';
import {
  BackupDestination,
  BackupType,
  type BackupHistory,
  type BackupSettings,
} from '@/types/backup';

export const PROFESSIONAL_BACKUP_STATUS_EVENT = 'joyacontrol:backup-status-changed';
export const PROFESSIONAL_BACKUP_INTERVAL_MS = 15 * 60 * 1000;

const DATABASE_VERSION_STORAGE_KEY = 'joyacontrol_backup_database_version';

type ExternalBackupCategory = 'AUTO' | 'MANUAL' | 'RESTORE_POINTS';
export type ProfessionalBackupTrigger =
  | 'interval'
  | 'startup'
  | 'app-close'
  | 'cash-close'
  | 'manual'
  | 'restore-point'
  | 'database-update';

export interface ExternalBackupRuntimeStatus {
  status: 'not-configured' | 'ready' | 'success' | 'error';
  lastSuccessAt: string | null;
  lastAttemptAt: string | null;
  lastErrorAt: string | null;
  lastError: string | null;
  lastFilePath: string | null;
  lastChecksum: string | null;
  lastSize: number;
}

export interface ProfessionalBackupStatus {
  serverMode: boolean;
  running: boolean;
  queued: number;
  internal: {
    status: 'active' | 'success' | 'error' | 'unavailable';
    lastBackupAt: string | null;
    lastError: string | null;
  };
  external: ExternalBackupRuntimeStatus & {
    configuredFolder: string;
    rootPath: string;
  };
}

export interface ProfessionalBackupResult {
  skipped: boolean;
  trigger: ProfessionalBackupTrigger;
  envelope: BackupEnvelope | null;
  internalCompleted: boolean;
  externalCompleted: boolean;
  externalError: string | null;
}

interface ExternalBridgeStatus {
  configuredFolder?: string;
  rootPath?: string;
  external?: Partial<ExternalBackupRuntimeStatus>;
}

const defaultExternalStatus: ExternalBackupRuntimeStatus = {
  status: 'not-configured',
  lastSuccessAt: null,
  lastAttemptAt: null,
  lastErrorAt: null,
  lastError: null,
  lastFilePath: null,
  lastChecksum: null,
  lastSize: 0,
};

function isServerMode(): boolean {
  return getEffectiveWorkMode() === 'server';
}

async function sha256Text(value: string): Promise<string> {
  const bytes = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}

function safeError(error: unknown): string {
  return error instanceof Error ? error.message : String(error || 'Error desconocido');
}

function dispatchBackupStatusChanged(): void {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(PROFESSIONAL_BACKUP_STATUS_EVENT));
  }
}

function isBackupCreation(entry: BackupHistory): boolean {
  return entry.type === BackupType.AUTOMATIC
    || entry.type === BackupType.MANUAL
    || entry.type === BackupType.PRE_RESTORE;
}

class ProfessionalBackupServiceImpl {
  private queue: Promise<unknown> = Promise.resolve();
  private queued = 0;
  private running = false;

  private enqueue<T>(operation: () => Promise<T>): Promise<T> {
    this.queued += 1;
    dispatchBackupStatusChanged();
    const scheduled = this.queue.then(async () => {
      this.queued = Math.max(0, this.queued - 1);
      this.running = true;
      dispatchBackupStatusChanged();
      try {
        return await operation();
      } finally {
        this.running = false;
        dispatchBackupStatusChanged();
      }
    }, async () => {
      this.queued = Math.max(0, this.queued - 1);
      this.running = true;
      dispatchBackupStatusChanged();
      try {
        return await operation();
      } finally {
        this.running = false;
        dispatchBackupStatusChanged();
      }
    });
    this.queue = scheduled.then(() => undefined, () => undefined);
    return scheduled;
  }

  private async audit(action: string, detail: Record<string, unknown>): Promise<void> {
    const session = getSession();
    if (!session || !isServerMode()) return;
    try {
      await logActivity(
        session,
        action,
        'BACKUP',
        String(detail.backupId || detail.filePath || crypto.randomUUID()),
        JSON.stringify(detail),
      );
    } catch (error) {
      console.warn('[Backup] No fue posible registrar Activity Log:', error);
    }
  }

  async ensureProfessionalSettings(): Promise<BackupSettings> {
    const current = await BackupManager.loadSettings();
    const next: BackupSettings = {
      ...current,
      // Preserve the persisted user switch. Legacy rows without the field
      // remain enabled, while an explicit false survives restarts.
      backupEnabled: current.backupEnabled !== false,
      backupInterval: '15m',
      maxBackups: 100,
      deleteOldBackups: true,
      verifyChecksum: true,
      backupBeforeRestore: true,
      backupOnExit: true,
      defaultDestination: BackupDestination.LOCAL,
    };
    if (JSON.stringify(current) !== JSON.stringify(next)) {
      await BackupManager.saveSettings(next);
    }
    if (next.backupFolder && window.joyaControlBackup?.setFolder) {
      await window.joyaControlBackup.setFolder(next.backupFolder).catch(() => undefined);
    }
    return next;
  }

  private async writeExternalBackup(
    envelope: BackupEnvelope,
    category: ExternalBackupCategory,
    trigger: ProfessionalBackupTrigger,
  ): Promise<{ completed: boolean; error: string | null }> {
    const settings = await BackupManager.loadSettings();
    const baseFolder = settings.backupFolder.trim();
    const bridge = window.joyaControlBackup;
    if (!baseFolder || !bridge?.writeBackup) {
      return { completed: false, error: baseFolder ? 'El host Electron no permite escribir copias externas.' : null };
    }

    const content = JSON.stringify(envelope, null, 2);
    const expectedSha256 = await sha256Text(content);
    try {
      const written = await bridge.writeBackup({
        baseFolder,
        category,
        createdAt: envelope.createdAt,
        content,
        expectedSha256,
      });
      await this.audit('BACKUP_EXTERNAL_COMPLETED', {
        message: 'Backup externo completado.',
        trigger,
        backupId: envelope.checksum,
        filePath: written.filePath,
        checksum: written.checksum,
        size: written.size,
      });
      return { completed: true, error: null };
    } catch (error) {
      const message = safeError(error);
      await this.audit('BACKUP_EXTERNAL_FAILED', {
        message: 'Backup externo fallido.',
        trigger,
        backupId: envelope.checksum,
        folder: baseFolder,
        error: message,
      });
      return { completed: false, error: message };
    }
  }

  private async createBackupNow(
    trigger: ProfessionalBackupTrigger,
    type: BackupType,
    category: ExternalBackupCategory,
    allowLocalManual = false,
  ): Promise<ProfessionalBackupResult> {
    const mode = getEffectiveWorkMode();
    if (mode !== 'server' && !(allowLocalManual && mode === 'local')) {
      return {
        skipped: true,
        trigger,
        envelope: null,
        internalCompleted: false,
        externalCompleted: false,
        externalError: null,
      };
    }

    const envelope = await BackupManager.createBackup(type, BackupDestination.LOCAL);
    await this.audit('BACKUP_INTERNAL_COMPLETED', {
      message: 'Backup interno completado.',
      trigger,
      backupId: envelope.checksum,
      type,
      date: envelope.createdAt,
      records: envelope.metadata.recordCount,
    });

    const external = mode === 'server'
      ? await this.writeExternalBackup(envelope, category, trigger)
      : { completed: false, error: null };
    dispatchBackupStatusChanged();
    return {
      skipped: false,
      trigger,
      envelope,
      internalCompleted: true,
      externalCompleted: external.completed,
      externalError: external.error,
    };
  }

  createAutomaticBackup(trigger: Exclude<ProfessionalBackupTrigger, 'manual' | 'restore-point'> = 'interval') {
    return this.enqueue(() => this.createBackupNow(trigger, BackupType.AUTOMATIC, 'AUTO'));
  }

  createManualBackup() {
    return this.enqueue(() => this.createBackupNow('manual', BackupType.MANUAL, 'MANUAL', true));
  }

  createRestorePoint() {
    return this.enqueue(() => this.createBackupNow('restore-point', BackupType.PRE_RESTORE, 'RESTORE_POINTS', true));
  }

  restoreBackup(source: BackupEnvelope | unknown): Promise<void> {
    return this.enqueue(async () => {
      if (getEffectiveWorkMode() === 'lan') throw new Error('Los Clientes LAN no pueden restaurar la base del Servidor Principal.');
      const safety = await this.createBackupNow('restore-point', BackupType.PRE_RESTORE, 'RESTORE_POINTS', true);
      await BackupManager.restoreBackup(source, { skipPreRestore: true });
      await this.audit('BACKUP_RESTORE_COMPLETED', {
        message: 'Restauración realizada.',
        backupId: safety.envelope?.checksum || crypto.randomUUID(),
        restoredAt: new Date().toISOString(),
      });
      dispatchBackupStatusChanged();
    });
  }

  async selectExternalFolder(): Promise<string | null> {
    if (!isServerMode()) throw new Error('Solo el Servidor Principal puede configurar copias automáticas.');
    const bridge = window.joyaControlBackup;
    if (!bridge?.selectFolder || !bridge.setFolder) {
      throw new Error('La selección de carpeta requiere la aplicación Electron.');
    }

    const selected = await bridge.selectFolder();
    const nextPath = String(selected.folderPath || '').trim();
    if (selected.canceled || !nextPath) return null;

    const validation = await bridge.validateFolder?.(nextPath);
    if (validation && !validation.ok) throw new Error(validation.message);

    const currentSettings = await BackupManager.loadSettings();
    const previousPath = String(currentSettings.backupFolder || '').trim();
    if (previousPath === nextPath) {
      await bridge.setFolder(nextPath);
      dispatchBackupStatusChanged();
      return nextPath;
    }

    const nextSettings: BackupSettings = {
      ...currentSettings,
      backupFolder: nextPath,
    };

    await BackupManager.saveSettings(nextSettings);
    try {
      await bridge.setFolder(nextPath);
    } catch (error) {
      await BackupManager.saveSettings(currentSettings).catch(() => undefined);
      throw error;
    }

    const changedAt = new Date().toISOString();
    await this.audit('BACKUP_PATH_CHANGED', {
      message: 'Ruta de backup externo modificada.',
      filePath: nextPath,
      previousPath: previousPath || null,
      newPath: nextPath,
      changedAt,
    });
    dispatchBackupStatusChanged();
    return nextPath;
  }

  async openExternalFolder(): Promise<void> {
    const settings = await BackupManager.loadSettings();
    if (!settings.backupFolder) throw new Error('Seleccione una carpeta para las copias externas.');
    if (!window.joyaControlBackup?.openFolder) throw new Error('Abrir carpeta requiere la aplicación Electron.');
    await window.joyaControlBackup.openFolder(settings.backupFolder);
  }

  async runDatabaseUpdateBackupIfNeeded(): Promise<void> {
    if (!isServerMode()) return;
    const currentVersion = String(await BackupManager.getDatabaseVersion());
    let previousVersion = '';
    try { previousVersion = localStorage.getItem(DATABASE_VERSION_STORAGE_KEY) || ''; } catch { /* ignored */ }
    if (!previousVersion) {
      const initialResult = await this.createAutomaticBackup('database-update');
      if (!initialResult.skipped && initialResult.internalCompleted) {
        try { localStorage.setItem(DATABASE_VERSION_STORAGE_KEY, currentVersion); } catch { /* ignored */ }
      }
      return;
    }
    if (previousVersion === currentVersion) return;
    const result = await this.createAutomaticBackup('database-update');
    if (!result.skipped && result.internalCompleted) {
      try { localStorage.setItem(DATABASE_VERSION_STORAGE_KEY, currentVersion); } catch { /* ignored */ }
    }
  }

  async getStatus(): Promise<ProfessionalBackupStatus> {
    const [history, settings, externalState] = await Promise.all([
      BackupManager.listHistory(100).catch(() => []),
      BackupManager.loadSettings().catch(() => null),
      window.joyaControlBackup?.getStatus?.().catch(() => null) ?? Promise.resolve(null),
    ]);
    const latestCreation = history.find(isBackupCreation) ?? null;
    const external = (externalState as ExternalBridgeStatus | null)?.external ?? {};
    const configuredFolder = settings?.backupFolder
      || (externalState as ExternalBridgeStatus | null)?.configuredFolder
      || '';

    return {
      serverMode: isServerMode(),
      running: this.running,
      queued: this.queued,
      internal: {
        status: latestCreation
          ? latestCreation.status === 'success' ? 'success' : 'error'
          : BackupManager.isOPFSSupported() ? 'active' : 'unavailable',
        lastBackupAt: latestCreation?.date ?? null,
        lastError: latestCreation?.status === 'failed' ? latestCreation.notes || 'Error durante el respaldo interno.' : null,
      },
      external: {
        ...defaultExternalStatus,
        ...external,
        configuredFolder,
        rootPath: (externalState as ExternalBridgeStatus | null)?.rootPath || '',
      },
    };
  }
}

export const ProfessionalBackupService = new ProfessionalBackupServiceImpl();
