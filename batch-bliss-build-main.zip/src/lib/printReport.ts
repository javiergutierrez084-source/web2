import type { CompanyInfo } from '@/contexts/AppContext';

export type PrintFormat = 'letter' | 'ticket';

interface PrintColumn {
  header: string;
  align?: 'left' | 'center' | 'right';
}

interface PrintReportOptions {
  company: CompanyInfo;
  title: string;
  subtitle?: string;
  columns: PrintColumn[];
  rows: string[][];
  summaryLines?: { label: string; value: string; bold?: boolean }[];
  date?: string;
  format?: PrintFormat;
}

function buildLetterHtml(opts: PrintReportOptions): string {
  const { company, title, subtitle, columns, rows, summaryLines, date } = opts;
  const today = date || new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });

  const logoHtml = company.logoUrl
    ? `<img src="${company.logoUrl}" style="height:50px;width:50px;object-fit:contain;border-radius:6px;" />`
    : `<div style="height:50px;width:50px;background:#f0f0f0;border-radius:6px;display:flex;align-items:center;justify-content:center;font-size:20px;">💎</div>`;

  const companyBlock = `
    <div style="display:flex;align-items:flex-start;gap:12px;margin-bottom:6px;">
      ${logoHtml}
      <div>
        <div style="font-size:16px;font-weight:700;">${company.name}</div>
        ${company.nit ? `<div style="font-size:11px;color:#666;">NIT: ${company.nit}</div>` : ''}
        ${company.city ? `<div style="font-size:11px;color:#666;">${company.city}${company.address ? ` - ${company.address}` : ''}</div>` : ''}
        ${company.phone ? `<div style="font-size:11px;color:#666;">Tel: ${company.phone}</div>` : ''}
        ${company.email ? `<div style="font-size:11px;color:#666;">${company.email}</div>` : ''}
      </div>
    </div>`;

  const headerRow = columns.map(c => `<th style="text-align:${c.align || 'left'};padding:8px 10px;background:#f5f5f5;font-size:11px;font-weight:600;text-transform:uppercase;color:#555;border-bottom:2px solid #ddd;">${c.header}</th>`).join('');

  const bodyRows = rows.map(row =>
    `<tr>${row.map((cell, i) => `<td style="text-align:${columns[i]?.align || 'left'};padding:7px 10px;border-bottom:1px solid #eee;font-size:12px;">${cell}</td>`).join('')}</tr>`
  ).join('');

  const summaryHtml = summaryLines?.length ? `
    <div style="margin-top:20px;border-top:2px solid #333;padding-top:12px;max-width:350px;margin-left:auto;">
      ${summaryLines.map(s => `<div style="display:flex;justify-content:space-between;padding:3px 0;font-size:${s.bold ? '14px' : '12px'};font-weight:${s.bold ? '700' : '400'};${s.bold ? 'border-top:1px solid #ccc;padding-top:8px;margin-top:4px;' : ''}"><span>${s.label}</span><span>${s.value}</span></div>`).join('')}
    </div>` : '';

  return `<!DOCTYPE html><html><head><title>${title} - ${company.name}</title>
    <style>
      @media print { body { margin: 0; } @page { size: letter; margin: 15mm; } }
      body { font-family: 'Segoe UI', Arial, sans-serif; color: #222; padding: 30px; max-width: 900px; margin: 0 auto; }
      table { width: 100%; border-collapse: collapse; }
      .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #333; padding-bottom: 12px; margin-bottom: 16px; }
      .report-title { font-size: 18px; font-weight: 700; margin: 0; }
      .report-subtitle { font-size: 12px; color: #666; margin-top: 2px; }
      .report-date { font-size: 11px; color: #888; text-align: right; }
      .footer { margin-top: 30px; border-top: 1px solid #ddd; padding-top: 10px; font-size: 10px; color: #999; text-align: center; }
    </style>
  </head><body>
    <div class="header">
      <div>
        ${companyBlock}
        <h1 class="report-title">${title}</h1>
        ${subtitle ? `<p class="report-subtitle">${subtitle}</p>` : ''}
      </div>
      <div class="report-date">Fecha: ${today}</div>
    </div>
    <table>
      <thead><tr>${headerRow}</tr></thead>
      <tbody>${bodyRows}</tbody>
    </table>
    ${summaryHtml}
    <div class="footer">Generado por ${company.name} · JoyaControl</div>
  </body></html>`;
}

function buildTicketHtml(opts: PrintReportOptions): string {
  const { company, title, subtitle, columns, rows, summaryLines, date } = opts;
  const today = date || new Date().toLocaleDateString('es-CO', { year: 'numeric', month: 'long', day: 'numeric' });

  // For ticket, use compact rows: label(s) + right-aligned value
  const rightIdx = columns.findIndex(c => c.align === 'right');
  const bodyRows = rows.map(row => {
    if (rightIdx > 0) {
      const left = row.filter((_, i) => i !== rightIdx).filter(Boolean).join(' · ');
      const right = row[rightIdx] || '';
      return `<div class="row"><span class="l">${left}</span><span class="r">${right}</span></div>`;
    }
    return `<div class="row block">${row.filter(Boolean).join(' · ')}</div>`;
  }).join('');

  const summaryHtml = summaryLines?.length ? `
    <hr class="sep"/>
    ${summaryLines.map(s => `<div class="row ${s.bold ? 'grand' : ''}"><span>${s.label}</span><span>${s.value}</span></div>`).join('')}
  ` : '';

  return `<!DOCTYPE html><html><head><title>${title}</title>
    <style>
      @media print { @page { size: 80mm auto; margin: 3mm; } body { margin: 0; } }
      body { font-family: 'Courier New', monospace; color: #000; width: 74mm; margin: 0 auto; padding: 4mm 2mm; font-size: 11px; line-height: 1.35; }
      .center { text-align: center; }
      .company { font-weight: 700; font-size: 13px; }
      .muted { color: #333; font-size: 10px; }
      .sep { border: none; border-top: 1px dashed #000; margin: 6px 0; }
      .title { font-weight: 700; text-align: center; font-size: 12px; margin: 4px 0; text-transform: uppercase; }
      .subtitle { text-align: center; font-size: 10px; color: #333; margin-bottom: 4px; }
      .row { display: flex; justify-content: space-between; gap: 6px; padding: 1px 0; font-size: 11px; }
      .row.block { display: block; }
      .row .l { flex: 1; word-break: break-word; }
      .row .r { white-space: nowrap; font-weight: 600; }
      .row.grand { font-weight: 700; font-size: 12px; border-top: 1px solid #000; padding-top: 4px; margin-top: 3px; }
      .foot { text-align: center; font-size: 9px; margin-top: 8px; color: #555; }
    </style>
  </head><body>
    <div class="center">
      <div class="company">${company.name}</div>
      ${company.nit ? `<div class="muted">NIT: ${company.nit}</div>` : ''}
      ${company.city ? `<div class="muted">${company.city}${company.address ? ` - ${company.address}` : ''}</div>` : ''}
      ${company.phone ? `<div class="muted">Tel: ${company.phone}</div>` : ''}
    </div>
    <hr class="sep"/>
    <div class="title">${title}</div>
    ${subtitle ? `<div class="subtitle">${subtitle}</div>` : ''}
    <div class="muted center">${today}</div>
    <hr class="sep"/>
    ${bodyRows}
    ${summaryHtml}
    <hr class="sep"/>
    <div class="foot">${company.name} · JoyaControl</div>
  </body></html>`;
}

export function openPrintReport(opts: PrintReportOptions) {
  const html = (opts.format || 'letter') === 'ticket' ? buildTicketHtml(opts) : buildLetterHtml(opts);
  const win = window.open('', '_blank');
  if (!win) return;
  win.document.write(html);
  win.document.close();
  win.print();
}
