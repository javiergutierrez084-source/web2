import type {
  Contact,
  InventoryAdjustment,
  InvoiceItem,
  Product,
  PurchaseInvoice,
} from '@/data/mockData';

export type SupplierResolutionSource =
  | 'purchase-id'
  | 'purchase-name'
  | 'adjustment-id'
  | 'adjustment-name'
  | 'product-supplier-ids';

export interface SupplierResolution {
  supplierId: string;
  supplier: Contact;
  source: SupplierResolutionSource;
}

const normalizeSupplierName = (value: unknown): string => String(value ?? '')
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLocaleLowerCase('es')
  .replace(/[^a-z0-9]+/g, ' ')
  .trim()
  .replace(/\s+/g, ' ');

const unique = <T,>(values: Iterable<T>): T[] => [...new Set(values)];

const missingSupplierLabels = new Set([
  '',
  'sin proveedor',
  'proveedor no disponible',
  'no disponible',
  'n a',
  'na',
]);

const hasMeaningfulSupplierName = (value: unknown): boolean =>
  !missingSupplierLabels.has(normalizeSupplierName(value));

const addIndexedProduct = (
  index: Map<string, Product[]>,
  key: unknown,
  product: Product,
): void => {
  const normalized = normalizeSupplierName(key);
  if (!normalized) return;
  const values = index.get(normalized) ?? [];
  values.push(product);
  index.set(normalized, values);
};

/**
 * Resolves historical supplier relations without changing persisted data.
 *
 * Resolution priority is intentionally stable:
 * 1. Explicit purchase supplierId.
 * 2. Purchase supplierName matched to one current supplier contact.
 * 3. Explicit inventory-adjustment supplierId.
 * 4. Inventory-adjustment supplierName matched to one current supplier contact.
 * 5. Product.supplierIds, only when the historical record has no supplier data.
 */
export class SupplierRelationResolver {
  private readonly suppliersById: Map<string, Contact>;
  private readonly suppliersByNormalizedName: Map<string, Contact[]>;
  private readonly productsById: Map<string, Product>;
  private readonly productsByCode: Map<string, Product[]>;
  private readonly productsByReference: Map<string, Product[]>;
  private readonly productsByName: Map<string, Product[]>;

  constructor(contacts: readonly Contact[], products: readonly Product[]) {
    const suppliers = contacts.filter(contact => contact.type === 'supplier');
    this.suppliersById = new Map(suppliers.map(contact => [contact.id, contact]));
    this.productsById = new Map(products.map(product => [product.id, product]));
    this.suppliersByNormalizedName = new Map();
    this.productsByCode = new Map();
    this.productsByReference = new Map();
    this.productsByName = new Map();

    suppliers.forEach(supplier => {
      const key = normalizeSupplierName(supplier.name);
      if (!key) return;
      const matches = this.suppliersByNormalizedName.get(key) ?? [];
      matches.push(supplier);
      this.suppliersByNormalizedName.set(key, matches);
    });

    products.forEach(product => {
      addIndexedProduct(this.productsByCode, product.code, product);
      addIndexedProduct(this.productsByReference, product.reference, product);
      addIndexedProduct(this.productsByName, product.name, product);
    });
  }

  getSupplier(supplierId: string): Contact | null {
    return this.suppliersById.get(String(supplierId || '').trim()) ?? null;
  }

  resolveName(name: unknown): Contact | null {
    const key = normalizeSupplierName(name);
    if (!key) return null;
    const matches = this.suppliersByNormalizedName.get(key) ?? [];
    return matches.length === 1 ? matches[0] : null;
  }

  getValidSupplierIdsForProduct(product: Product): string[] {
    return unique(
      (Array.isArray(product.supplierIds) ? product.supplierIds : [])
        .map(id => String(id || '').trim())
        .filter(id => this.suppliersById.has(id)),
    );
  }

  getProductsForSupplier(supplierId: string): Product[] {
    return [...this.productsById.values()]
      .filter(product => this.isProductRelatedToSupplier(product, supplierId));
  }

  isProductRelatedToSupplier(product: Product, supplierId: string): boolean {
    return this.getValidSupplierIdsForProduct(product).includes(supplierId);
  }

  hasPurchaseSupplierReference(purchase: PurchaseInvoice): boolean {
    return Boolean(String(purchase.supplierId || '').trim())
      || hasMeaningfulSupplierName(purchase.supplierName);
  }

  resolvePurchaseDirect(purchase: PurchaseInvoice): SupplierResolution | null {
    const explicit = this.getSupplier(purchase.supplierId);
    if (explicit) {
      return { supplierId: explicit.id, supplier: explicit, source: 'purchase-id' };
    }

    const byName = this.resolveName(purchase.supplierName);
    if (byName) {
      return { supplierId: byName.id, supplier: byName, source: 'purchase-name' };
    }

    return null;
  }

  resolvePurchase(purchase: PurchaseInvoice): SupplierResolution | null {
    const direct = this.resolvePurchaseDirect(purchase);
    if (direct) return direct;

    // A historical document with supplier data must never be reassigned by its
    // products. Product inference is reserved for records that truly have no
    // supplier relation stored.
    if (this.hasPurchaseSupplierReference(purchase)) return null;

    const inferred = this.resolveUniqueSupplierFromProductIds(
      this.getProductsForPurchase(purchase).map(product => product.id),
    );
    return inferred
      ? { supplierId: inferred.id, supplier: inferred, source: 'product-supplier-ids' }
      : null;
  }

  purchaseContainsSupplierProduct(purchase: PurchaseInvoice, supplierId: string): boolean {
    return this.getProductsForPurchase(purchase)
      .some(product => this.isProductRelatedToSupplier(product, supplierId));
  }

  getProductsForPurchase(purchase: PurchaseInvoice): Product[] {
    const resolved = (Array.isArray(purchase.items) ? purchase.items : [])
      .map(item => this.resolveInvoiceItemProduct(item))
      .filter((product): product is Product => Boolean(product));
    return unique(resolved);
  }

  resolveAdjustment(adjustment: InventoryAdjustment): SupplierResolution | null {
    const explicit = this.getSupplier(adjustment.supplierId || '');
    if (explicit) {
      return { supplierId: explicit.id, supplier: explicit, source: 'adjustment-id' };
    }

    const byName = this.resolveName(adjustment.supplierName);
    if (byName) {
      return { supplierId: byName.id, supplier: byName, source: 'adjustment-name' };
    }

    const inferred = this.resolveUniqueSupplierFromProductIds([adjustment.productId]);
    return inferred
      ? { supplierId: inferred.id, supplier: inferred, source: 'product-supplier-ids' }
      : null;
  }

  resolveInvoiceItemProduct(item: InvoiceItem): Product | null {
    const byId = this.productsById.get(String(item.productId || '').trim());
    if (byId) return byId;

    const uniqueMatch = (index: Map<string, Product[]>, value: unknown): Product | null => {
      const matches = index.get(normalizeSupplierName(value)) ?? [];
      return matches.length === 1 ? matches[0] : null;
    };

    return uniqueMatch(this.productsByCode, item.code)
      ?? uniqueMatch(this.productsByReference, item.code)
      ?? uniqueMatch(this.productsByName, item.name);
  }

  private resolveUniqueSupplierFromProductIds(productIds: readonly string[]): Contact | null {
    const supplierSets = unique(productIds.map(id => String(id || '').trim()).filter(Boolean))
      .map(productId => this.productsById.get(productId))
      .filter((product): product is Product => Boolean(product))
      .map(product => new Set(this.getValidSupplierIdsForProduct(product)))
      .filter(set => set.size > 0);

    if (supplierSets.length === 0) return null;

    const intersection = new Set(supplierSets[0]);
    supplierSets.slice(1).forEach(set => {
      [...intersection].forEach(candidate => {
        if (!set.has(candidate)) intersection.delete(candidate);
      });
    });

    if (intersection.size !== 1) return null;
    return this.getSupplier([...intersection][0]);
  }
}

export { hasMeaningfulSupplierName, normalizeSupplierName };
