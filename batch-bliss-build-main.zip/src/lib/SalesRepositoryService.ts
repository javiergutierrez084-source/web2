import type {
  Contact,
  FinancialAccount,
  FinancialMovement,
  FinancialSummary,
  Invoice,
  PaymentAllocation,
  Product,
  Quotation,
} from '@/data/mockData';
import type {
  CompanyInfo,
  ContactChangeSet,
  InvoiceCancellationResult,
  InvoiceFinancialTransactionOptions,
  Layaway,
  LayawayCancellationResolution,
  LayawayDeleteResult,
  LayawayPaymentResult,
  LayawayUpdateResult,
} from '@/domain/models';
import type { IDataRepository } from '@/repositories/IDataRepository';
import { getActiveRepositoryMode, getDataRepository } from '@/repositories/RepositoryRegistry';

export interface SalesWorkspace {
  company: CompanyInfo;
  contacts: Contact[];
  invoices: Invoice[];
  layaways: Layaway[];
  quotations: Quotation[];
  financialAccounts: FinancialAccount[];
  financialMovements: FinancialMovement[];
  financialSummary: FinancialSummary | null;
}

export interface SalesQuery {
  text?: string;
  clientId?: string;
  number?: string;
  status?: Invoice['status'];
  dateFrom?: string;
  dateTo?: string;
  period?: 'today' | 'month';
  limit?: number;
}

export interface SalesRemoteRepository {
  getSalesWorkspace(): Promise<SalesWorkspace>;
  getSalesClients(): Promise<Contact[]>;
  searchSalesClients(text: string): Promise<Contact[]>;
  getSalesClientById(id: string): Promise<Contact | null>;
  createSalesClient(client: Contact): Promise<Contact>;
  updateSalesClient(client: Contact): Promise<Contact>;
  deleteSalesClient(id: string): Promise<void>;
  querySales(query: SalesQuery): Promise<Invoice[]>;
  getSaleById(id: string): Promise<Invoice | null>;
  createSale(
    invoice: Invoice,
    allocations: PaymentAllocation[],
    options?: InvoiceFinancialTransactionOptions,
  ): Promise<Product[]>;
  updateSaleStatus(id: string, status: string): Promise<void>;
  cancelSale(id: string, reason: string): Promise<InvoiceCancellationResult>;
  applySalesContactChanges(changes: ContactChangeSet<Contact>): Promise<void>;
  createSalesQuotation(input: Omit<Quotation, 'id' | 'number'>): Promise<Quotation>;
  updateSalesQuotationStatus(id: string, status: Quotation['status']): Promise<void>;
  createSalesLayaway(layaway: Layaway): Promise<Layaway>;
  updateSalesLayaway(layawayId: string, invoice: Invoice): Promise<LayawayUpdateResult>;
  deleteSalesLayaway(
    layawayId: string,
    resolution?: LayawayCancellationResolution,
  ): Promise<LayawayDeleteResult>;
  addSalesLayawayPayment(
    layawayId: string,
    payment: { amount: number; date: string; method: string; accountId?: string },
  ): Promise<LayawayPaymentResult>;
  completeSalesLayaway(layawayId: string, completedDate: string): Promise<string>;
  invalidateSales?: () => void;
}

const repository = (): IDataRepository & SalesRemoteRepository =>
  getDataRepository() as IDataRepository & SalesRemoteRepository;

const isLanClient = (): boolean => getActiveRepositoryMode() === 'lan';

const monthPrefix = (date = new Date()): string =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;

const todayKey = (date = new Date()): string => date.toISOString().slice(0, 10);

const normalizeContactSearch = (value: string): string =>
  value
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim()
    .toLocaleLowerCase('es');

const salesClientsOnly = (contacts: Contact[]): Contact[] =>
  contacts.filter(contact => contact.type === 'client');

const mergeWorkspaceClients = (workspace: SalesWorkspace, clients: Contact[]): SalesWorkspace => ({
  ...workspace,
  contacts: [
    ...clients,
    ...workspace.contacts.filter(contact => contact.type !== 'client'),
  ],
});

const assertSalesClient = (client: Contact): Contact => {
  if (client.type !== 'client') throw new Error('SALES_CLIENT_REQUIRED');
  return client;
};

export function filterSalesClients(contacts: Contact[], text: string): Contact[] {
  const clients = salesClientsOnly(contacts);
  const normalized = normalizeContactSearch(text);
  if (!normalized) return clients;

  const terms = normalized.split(/\s+/).filter(Boolean);
  return clients.filter(client => {
    const searchable = normalizeContactSearch([
      client.name,
      client.document,
      client.phone,
      client.email,
    ].filter(Boolean).join(' '));
    return terms.every(term => searchable.includes(term));
  });
}

export function filterSales(invoices: Invoice[], query: SalesQuery): Invoice[] {
  const normalizedText = String(query.text || '').trim().toLocaleLowerCase('es');
  const numberText = String(query.number || '').trim().toLocaleLowerCase('es');
  const today = todayKey();
  const month = monthPrefix();

  const filtered = invoices.filter(invoice => {
    if (query.clientId && invoice.clientId !== query.clientId) return false;
    if (query.status && invoice.status !== query.status) return false;
    if (query.dateFrom && invoice.date < query.dateFrom) return false;
    if (query.dateTo && invoice.date > query.dateTo) return false;
    if (query.period === 'today' && invoice.date !== today) return false;
    if (query.period === 'month' && !invoice.date.startsWith(month)) return false;
    if (numberText && !invoice.number.toLocaleLowerCase('es').includes(numberText)) return false;
    if (
      normalizedText &&
      ![invoice.number, invoice.clientName]
        .join(' ')
        .toLocaleLowerCase('es')
        .includes(normalizedText)
    ) return false;
    return true;
  });

  const sorted = filtered.sort((left, right) => {
    const byDate = right.date.localeCompare(left.date);
    return byDate !== 0 ? byDate : right.number.localeCompare(left.number, 'es');
  });

  return Number.isFinite(query.limit) && Number(query.limit) > 0
    ? sorted.slice(0, Number(query.limit))
    : sorted;
}

async function buildLocalWorkspace(activeRepository: IDataRepository): Promise<SalesWorkspace> {
  await activeRepository.ensureDefaultFinancialAccounts();
  const [
    company,
    contacts,
    invoices,
    layaways,
    quotations,
    financialAccounts,
    financialMovements,
    financialSummary,
  ] = await Promise.all([
    activeRepository.fetchCompany(),
    activeRepository.fetchContacts(),
    activeRepository.fetchInvoices(),
    activeRepository.fetchLayaways(),
    activeRepository.fetchQuotations(),
    activeRepository.fetchFinancialAccounts(),
    activeRepository.fetchFinancialMovements(),
    activeRepository.fetchFinancialSummary(),
  ]);

  return {
    company,
    contacts,
    invoices,
    layaways,
    quotations,
    financialAccounts,
    financialMovements,
    financialSummary,
  };
}

/**
 * Repository-backed application service for the complete Sales workspace.
 *
 * Desktop and Principal Server modes use IDataRepository directly. LAN clients
 * delegate the same commands to ApiRepository, which transports them through
 * the existing POST /repository/call channel.
 */
export const SalesRepositoryService = {
  async getSalesWorkspace(): Promise<SalesWorkspace> {
    const activeRepository = repository();
    if (!isLanClient()) return buildLocalWorkspace(activeRepository);

    const [workspace, clients] = await Promise.all([
      activeRepository.getSalesWorkspace(),
      activeRepository.getSalesClients(),
    ]);
    return mergeWorkspaceClients(workspace, clients);
  },

  async getClients(): Promise<Contact[]> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.getSalesClients()
      : salesClientsOnly(await activeRepository.fetchContacts());
  },

  async searchClients(text: string): Promise<Contact[]> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.searchSalesClients(text)
      : filterSalesClients(await activeRepository.fetchContacts(), text);
  },

  async getClientById(id: string): Promise<Contact | null> {
    const activeRepository = repository();
    if (isLanClient()) return activeRepository.getSalesClientById(id);
    const client = (await activeRepository.fetchContacts()).find(contact => contact.id === id);
    return client?.type === 'client' ? client : null;
  },

  async createClient(client: Contact): Promise<Contact> {
    const activeRepository = repository();
    const validated = assertSalesClient(client);
    if (isLanClient()) return activeRepository.createSalesClient(validated);
    await activeRepository.upsertContact(validated);
    return validated;
  },

  async updateClient(client: Contact): Promise<Contact> {
    const activeRepository = repository();
    const validated = assertSalesClient(client);
    if (isLanClient()) return activeRepository.updateSalesClient(validated);
    await activeRepository.upsertContact(validated);
    return validated;
  },

  async deleteClient(id: string): Promise<void> {
    const activeRepository = repository();
    if (isLanClient()) {
      await activeRepository.deleteSalesClient(id);
      return;
    }
    await activeRepository.deleteContact(id);
  },

  async querySales(query: SalesQuery): Promise<Invoice[]> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.querySales(query)
      : filterSales(await activeRepository.fetchInvoices(), query);
  },

  async getSaleById(id: string): Promise<Invoice | null> {
    const activeRepository = repository();
    if (isLanClient()) return activeRepository.getSaleById(id);
    const invoices = await activeRepository.fetchInvoices();
    return invoices.find(invoice => invoice.id === id) || null;
  },

  async createSale(
    invoice: Invoice,
    allocations: PaymentAllocation[],
    options: InvoiceFinancialTransactionOptions = {},
  ): Promise<Product[]> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.createSale(invoice, allocations, options)
      : activeRepository.insertInvoiceWithFinancials(invoice, allocations, options);
  },

  async updateSaleStatus(id: string, status: string): Promise<void> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.updateSaleStatus(id, status)
      : activeRepository.updateInvoiceStatus(id, status);
  },

  async cancelSale(id: string, reason: string): Promise<InvoiceCancellationResult> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.cancelSale(id, reason)
      : activeRepository.cancelInvoice(id, reason);
  },

  async applyContactChanges(changes: ContactChangeSet<Contact>): Promise<void> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.applySalesContactChanges(changes)
      : activeRepository.applyContactChanges(changes);
  },

  async createQuotation(input: Omit<Quotation, 'id' | 'number'>): Promise<Quotation> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.createSalesQuotation(input)
      : activeRepository.createQuotation(input);
  },

  async updateQuotationStatus(id: string, status: Quotation['status']): Promise<void> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.updateSalesQuotationStatus(id, status)
      : activeRepository.updateQuotationStatus(id, status);
  },

  async createLayaway(layaway: Layaway): Promise<Layaway> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.createSalesLayaway(layaway)
      : activeRepository.insertLayaway(layaway);
  },

  async updateLayaway(layawayId: string, invoice: Invoice): Promise<LayawayUpdateResult> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.updateSalesLayaway(layawayId, invoice)
      : activeRepository.updateLayaway(layawayId, invoice);
  },

  async deleteLayaway(
    layawayId: string,
    resolution: LayawayCancellationResolution = 'refund',
  ): Promise<LayawayDeleteResult> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.deleteSalesLayaway(layawayId, resolution)
      : (activeRepository.deleteLayaway as (
          id: string,
          nextResolution?: LayawayCancellationResolution,
        ) => Promise<LayawayDeleteResult>)(layawayId, resolution);
  },

  async addLayawayPayment(
    layawayId: string,
    payment: { amount: number; date: string; method: string; accountId?: string },
  ): Promise<LayawayPaymentResult> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.addSalesLayawayPayment(layawayId, payment)
      : activeRepository.addLayawayPayment(layawayId, payment);
  },

  async completeLayaway(layawayId: string, completedDate: string): Promise<string> {
    const activeRepository = repository();
    return isLanClient()
      ? activeRepository.completeSalesLayaway(layawayId, completedDate)
      : activeRepository.completeLayawayDb(layawayId, completedDate);
  },

  invalidate(): void {
    repository().invalidateSales?.();
  },
};
