import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}


export function formatWeight(value: number): string {
  const numericValue = Number(value);
  if (!Number.isFinite(numericValue)) return '0';

  const roundedValue = Number(numericValue.toFixed(3));
  const safeValue = Object.is(roundedValue, -0) ? 0 : roundedValue;

  return safeValue.toLocaleString('es-CO', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 3,
  });
}

export function formatShortDate(value: string | number | Date): string {
  if (value === '') return '—';

  const normalizedValue =
    typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value.trim())
      ? `${value.trim()}T00:00:00`
      : value;
  const date = value instanceof Date ? value : new Date(normalizedValue);

  if (Number.isNaN(date.getTime())) return '—';

  return new Intl.DateTimeFormat('es-CO', {
    day: '2-digit',
    month: '2-digit',
    year: '2-digit',
  }).format(date);
}
