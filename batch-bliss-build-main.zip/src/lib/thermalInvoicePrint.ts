import { formatCurrency } from '@/data/mockData';
import { buildCode39Bars, createQrMatrix, type InvoiceDocumentData } from '@/lib/pdf';
import thermal80Css from '@/styles/thermal80.css?raw';

const escapeHtml = (value: unknown): string => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#039;');

const qrSvg = (value: string): string => {
  if (!value) return '';
  const matrix = createQrMatrix(value);
  const quietZone = 2;
  const size = matrix.length + (quietZone * 2);
  const modules: string[] = [];
  matrix.forEach((row, y) => row.forEach((dark, x) => {
    if (dark) modules.push(`<rect x="${x + quietZone}" y="${y + quietZone}" width="1" height="1"/>`);
  }));
  return `<svg class="thermal-qr" viewBox="0 0 ${size} ${size}" role="img" aria-label="Código QR" shape-rendering="crispEdges"><rect width="${size}" height="${size}" fill="#fff"/><g fill="#000">${modules.join('')}</g></svg>`;
};

const barcodeSvg = (value: string): string => {
  if (!value) return '';
  const bars = buildCode39Bars(value);
  const totalWidth = Math.max(1, bars.reduce((sum, bar) => sum + bar.width, 0));
  let x = 0;
  const shapes = bars.map(bar => {
    const shape = bar.dark ? `<rect x="${x}" y="0" width="${bar.width}" height="34"/>` : '';
    x += bar.width;
    return shape;
  }).join('');
  return `<svg class="thermal-barcode" viewBox="0 0 ${totalWidth} 34" role="img" aria-label="Código de barras" preserveAspectRatio="none" shape-rendering="crispEdges"><rect width="${totalWidth}" height="34" fill="#fff"/><g fill="#000">${shapes}</g></svg>`;
};

export const buildThermalInvoice80Html = (data: InvoiceDocumentData): string => {
  const items = data.items.map(item => `
    <tr>
      <td class="description"><span class="thermal-item-name">${escapeHtml(item.name)}</span>${item.code ? `<span class="thermal-item-code">${escapeHtml(item.code)}</span>` : ''}</td>
      <td class="quantity">${escapeHtml(item.quantityLabel)}</td>
      <td class="price">${escapeHtml(formatCurrency(item.unitPrice))}</td>
      <td class="subtotal">${escapeHtml(formatCurrency(item.subtotal))}</td>
    </tr>`).join('');

  const companyLocation = [data.company.city, data.company.address].filter(Boolean).join(' - ');
  const logo = data.company.logoUrl
    ? `<img class="thermal-logo" src="${escapeHtml(data.company.logoUrl)}" alt="Logo de ${escapeHtml(data.company.name)}"/>`
    : '';

  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=302, initial-scale=1"/>
  <title>${escapeHtml(data.number)}</title>
  <style>${thermal80Css}</style>
</head>
<body>
  <main class="thermal-receipt">
    <header class="thermal-header thermal-center">
      ${logo}
      <h1 class="thermal-company">${escapeHtml(data.company.name || 'JoyaControl')}</h1>
      ${data.company.nit ? `<p class="thermal-small">NIT: ${escapeHtml(data.company.nit)}</p>` : ''}
      ${companyLocation ? `<p class="thermal-small">${escapeHtml(companyLocation)}</p>` : ''}
      ${data.company.phone ? `<p class="thermal-small">Tel: ${escapeHtml(data.company.phone)}</p>` : ''}
      ${data.company.email ? `<p class="thermal-small">${escapeHtml(data.company.email)}</p>` : ''}
    </header>
    <hr class="thermal-separator"/>
    <section class="thermal-party">
      <h2 class="thermal-title">${escapeHtml(data.title)}</h2>
      <p class="thermal-meta thermal-center"><strong>${escapeHtml(data.number)}</strong> · ${escapeHtml(data.date)}</p>
      <p><strong>${escapeHtml(data.entity.label)}:</strong> ${escapeHtml(data.entity.name || '—')}</p>
      ${data.entity.document ? `<p><strong>Documento:</strong> ${escapeHtml(data.entity.document)}</p>` : ''}
      ${data.entity.phone ? `<p><strong>Teléfono:</strong> ${escapeHtml(data.entity.phone)}</p>` : ''}
    </section>
    <hr class="thermal-separator"/>
    <table class="thermal-items">
      <thead><tr><th class="description">Producto</th><th class="quantity">Cant.</th><th class="price">Precio</th><th class="subtotal">Total</th></tr></thead>
      <tbody>${items}</tbody>
    </table>
    <hr class="thermal-separator"/>
    <section class="thermal-totals">
      <div class="thermal-total-line"><span>Subtotal</span><span>${escapeHtml(formatCurrency(data.subtotal))}</span></div>
      ${data.discount > 0 ? `<div class="thermal-total-line"><span>Descuento</span><span>-${escapeHtml(formatCurrency(data.discount))}</span></div>` : ''}
      ${data.tax > 0 ? `<div class="thermal-total-line"><span>Impuestos</span><span>${escapeHtml(formatCurrency(data.tax))}</span></div>` : ''}
      <div class="thermal-total-line grand"><span>TOTAL</span><span>${escapeHtml(formatCurrency(data.total))}</span></div>
      <p class="thermal-payment"><strong>Método de pago:</strong> ${escapeHtml(data.paymentMethod || 'No especificado')}</p>
    </section>
    ${data.notes ? `<section class="thermal-notes"><strong>Observaciones:</strong><p>${escapeHtml(data.notes)}</p></section>` : ''}
    ${(data.qrValue || data.number) ? `<section class="thermal-codes">${qrSvg(data.qrValue)}${barcodeSvg(data.number)}<p class="thermal-barcode-label">${escapeHtml(data.number)}</p></section>` : ''}
    <hr class="thermal-separator"/>
    <footer class="thermal-footer"><strong>Gracias por su compra</strong><br/>${escapeHtml(data.company.name || 'JoyaControl')} · JoyaControl</footer>
  </main>
</body>
</html>`;
};

export const printThermalInvoice80 = (data: InvoiceDocumentData): void => {
  const iframe = document.createElement('iframe');
  iframe.setAttribute('title', `Impresión térmica ${data.number}`);
  iframe.setAttribute('aria-hidden', 'true');
  Object.assign(iframe.style, {
    position: 'fixed',
    right: '0',
    bottom: '0',
    width: '80mm',
    height: '1px',
    border: '0',
    opacity: '0',
    pointerEvents: 'none',
  });
  document.body.appendChild(iframe);

  const cleanup = () => window.setTimeout(() => iframe.remove(), 500);
  iframe.onload = () => {
    const frameWindow = iframe.contentWindow;
    if (!frameWindow) {
      cleanup();
      throw new Error('No se pudo preparar la impresión térmica.');
    }
    window.setTimeout(() => {
      frameWindow.focus();
      frameWindow.print();
      cleanup();
    }, 80);
  };
  iframe.srcdoc = buildThermalInvoice80Html(data);
};
