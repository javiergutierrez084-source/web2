import type {
  PrintConfiguration,
  PrintConfigurationTarget,
  PrintDocumentSettings,
  PrintPaperSize,
} from '@/lib/PrintModels';

export const PRINT_CONFIGURATION_TARGETS: Array<{
  key: PrintConfigurationTarget;
  label: string;
  description: string;
}> = [
  { key: 'invoiceLetter', label: 'Factura Carta', description: 'Facturas en hoja tamaño carta.' },
  { key: 'invoiceTicket80', label: 'Factura Térmica 80 mm', description: 'Tirillas para impresora térmica de 80 mm.' },
  { key: 'invoiceTicket58', label: 'Factura Térmica 58 mm', description: 'Tirillas para impresora térmica de 58 mm.' },
  { key: 'quotation', label: 'Cotización', description: 'Cotizaciones impresas desde el sistema.' },
  { key: 'report', label: 'Reporte', description: 'Reportes administrativos y operativos.' },
  { key: 'label', label: 'Etiqueta', description: 'Etiquetas de productos y joyas.' },
  { key: 'barcode', label: 'Código de barras', description: 'Códigos de barras para inventario.' },
  { key: 'pdf', label: 'PDF', description: 'Documentos PDF sin clasificación específica.' },
];

const setting = (paperSize: PrintPaperSize, colorMode: PrintDocumentSettings['colorMode'] = 'color'): PrintDocumentSettings => ({
  printerName: null,
  paperSize,
  orientation: 'portrait',
  copies: 1,
  silent: true,
  margin: paperSize === 'letter' || paperSize === 'a4' ? 'default' : 'none',
  scale: 100,
  colorMode,
});

export const createDefaultDocumentSettings = (): Record<PrintConfigurationTarget, PrintDocumentSettings> => ({
  invoiceLetter: setting('letter'),
  invoiceTicket80: setting('ticket80', 'monochrome'),
  invoiceTicket58: setting('ticket58', 'monochrome'),
  quotation: setting('letter'),
  report: setting('letter'),
  label: setting('label', 'monochrome'),
  barcode: setting('barcode', 'monochrome'),
  pdf: setting('letter'),
});

export const createDefaultPrintConfiguration = (): PrintConfiguration => ({
  defaultPrinterName: null,
  profilePrinters: {},
  documentPrinters: {},
  documentSettings: createDefaultDocumentSettings(),
  automaticRetry: true,
  retryDelayMs: 30_000,
  updatedAt: new Date(0).toISOString(),
});

export const normalizedDocumentSettings = (
  value: Partial<Record<PrintConfigurationTarget, Partial<PrintDocumentSettings>>> | undefined,
): Record<PrintConfigurationTarget, PrintDocumentSettings> => {
  const defaults = createDefaultDocumentSettings();
  return Object.fromEntries(
    PRINT_CONFIGURATION_TARGETS.map(({ key }) => {
      const candidate = value?.[key] || {};
      const copies = Number(candidate.copies);
      const scale = Number(candidate.scale);
      return [key, {
        ...defaults[key],
        ...candidate,
        printerName: candidate.printerName ? String(candidate.printerName) : null,
        copies: Number.isFinite(copies) ? Math.max(1, Math.min(20, Math.round(copies))) : defaults[key].copies,
        scale: Number.isFinite(scale) ? Math.max(10, Math.min(200, Math.round(scale))) : defaults[key].scale,
      }];
    }),
  ) as Record<PrintConfigurationTarget, PrintDocumentSettings>;
};
