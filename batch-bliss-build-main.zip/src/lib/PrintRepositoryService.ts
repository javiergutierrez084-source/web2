import { getSession } from '@/lib/authCore';
import { loadLanConfig } from '@/lib/LanCommunicationConfig';
import type { PdfDocumentData, PdfDocumentFormat } from '@/lib/pdf';
import type {
  PrintConfiguration,
  PrintConfigurationTarget,
  PrintDocumentFormat,
  PrintDocumentSettings,
  PrintDocumentType,
  PrintJobRequest,
  PrintJobSummary,
  PrintRequester,
  PrintWorkspace,
} from '@/lib/PrintModels';
import { getActiveRepositoryMode, getDataRepository } from '@/repositories/RepositoryRegistry';
import { ApiRepository } from '@/repositories/ApiRepository';

interface LocalPrintBridge {
  command(payload: Record<string, unknown>): Promise<unknown>;
  getWorkspace(): Promise<PrintWorkspace>;
}

const localBridge = (): LocalPrintBridge => {
  if (!window.joyaControlPrint) throw new Error('PRINT_SERVICE_NOT_AVAILABLE');
  return window.joyaControlPrint;
};

const apiRepository = (): ApiRepository => {
  const repository = getDataRepository();
  if (!(repository instanceof ApiRepository)) throw new Error('PRINT_REMOTE_REPOSITORY_NOT_AVAILABLE');
  return repository;
};

const bytesToBase64 = (bytes: Uint8Array): string => {
  let binary = '';
  const chunk = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunk) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + chunk)));
  }
  return btoa(binary);
};

const blobToBase64 = async (blob: Blob): Promise<string> => bytesToBase64(new Uint8Array(await blob.arrayBuffer()));


const escapeHtml = (value: unknown): string => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#039;');

const testFormatForPaper = (paperSize: PrintDocumentSettings['paperSize']): PrintDocumentFormat => {
  if (paperSize === 'ticket80') return 'ticket80';
  if (paperSize === 'ticket58') return 'ticket50';
  if (paperSize === 'a4') return 'a4';
  if (paperSize === 'label') return 'label';
  if (paperSize === 'barcode') return 'barcode';
  return 'letter';
};

const wait = (milliseconds: number): Promise<void> => new Promise(resolve => setTimeout(resolve, milliseconds));

const normalizedText = (value: string): string => value
  .normalize('NFD')
  .replace(/[\u0300-\u036f]/g, '')
  .toLowerCase();

export const inferPrintDocumentType = (document: PdfDocumentData): PrintDocumentType => {
  if (document.kind === 'invoice') {
    if (document.type === 'quotation') return 'quotation';
    if (document.type === 'purchase') return 'purchase';
    return 'invoice';
  }
  const source = normalizedText(`${document.title} ${document.subtitle || ''} ${document.filename}`);
  if (source.includes('separado')) return 'layaway';
  if (source.includes('abono')) return 'payment';
  if (source.includes('recibo')) return 'receipt';
  if (source.includes('gasto')) return 'expense';
  if (source.includes('compra')) return 'purchase';
  if (source.includes('cierre') || source.includes('caja')) return 'cash_close';
  if (source.includes('etiqueta')) return 'label';
  if (source.includes('codigo de barras') || source.includes('barcode')) return 'barcode';
  return 'report';
};

export const mapPdfFormatToPrintFormat = (format: PdfDocumentFormat): PrintDocumentFormat => format;

const requester = (): PrintRequester => {
  const session = getSession();
  const lan = loadLanConfig();
  return {
    userId: session?.id || '',
    username: session?.username || '',
    displayName: session?.displayName || session?.username || 'Usuario local',
    clientId: lan.clientId || 'desktop-local',
    deviceName: lan.deviceName || (typeof navigator !== 'undefined' ? navigator.platform || 'Equipo local' : 'Equipo local'),
  };
};

const invoke = async <T>(localPayload: Record<string, unknown>, remote: () => Promise<T>): Promise<T> => {
  if (getActiveRepositoryMode() === 'lan') return remote();
  return localBridge().command(localPayload) as Promise<T>;
};

export class PrintRepositoryService {
  static async getWorkspace(): Promise<PrintWorkspace> {
    if (getActiveRepositoryMode() === 'lan') return apiRepository().getPrintWorkspace();
    return localBridge().getWorkspace();
  }

  static async saveConfiguration(configuration: PrintConfiguration): Promise<PrintConfiguration> {
    if (getActiveRepositoryMode() === 'lan') throw new Error('PRINT_CONFIGURATION_SERVER_ONLY');
    return localBridge().command({ action: 'saveConfiguration', configuration }) as Promise<PrintConfiguration>;
  }

  static async submitPdf(input: {
    blob: Blob;
    document: PdfDocumentData;
    format: PdfDocumentFormat;
    copies?: number;
  }): Promise<PrintJobSummary> {
    const documentType = inferPrintDocumentType(input.document);
    const documentId = input.document.kind === 'invoice' ? input.document.invoiceId : input.document.id;
    const documentNumber = input.document.kind === 'invoice' ? input.document.number : input.document.title;
    const request: PrintJobRequest = {
      requestId: crypto.randomUUID(),
      documentType,
      documentId,
      documentNumber,
      title: input.document.title,
      format: mapPdfFormatToPrintFormat(input.format),
      contentType: 'application/pdf',
      contentBase64: await blobToBase64(input.blob),
      copies: input.copies || 1,
      requester: requester(),
      requestedAt: new Date().toISOString(),
    };
    return this.submit(request);
  }

  static async submitHtml(input: {
    html: string;
    documentType: PrintDocumentType;
    documentId: string;
    documentNumber: string;
    title: string;
    format: PrintDocumentFormat;
    copies?: number;
  }): Promise<PrintJobSummary> {
    const request: PrintJobRequest = {
      requestId: crypto.randomUUID(),
      documentType: input.documentType,
      documentId: input.documentId,
      documentNumber: input.documentNumber,
      title: input.title,
      format: input.format,
      contentType: 'text/html',
      contentBase64: bytesToBase64(new TextEncoder().encode(input.html)),
      copies: input.copies || 1,
      requester: requester(),
      requestedAt: new Date().toISOString(),
    };
    return this.submit(request);
  }


  static async testPrint(input: {
    target: PrintConfigurationTarget;
    settings: PrintDocumentSettings;
    workspace: PrintWorkspace;
    waitForResult?: boolean;
    timeoutMs?: number;
  }): Promise<PrintJobSummary> {
    const currentRequester = requester();
    const requestedAt = new Date();
    const configuredPrinter = input.settings.printerName
      || input.workspace.configuration.defaultPrinterName
      || input.workspace.printers.find(printer => printer.isDefault)?.name
      || input.workspace.printers.find(printer => printer.available)?.name
      || null;
    const printer = input.workspace.printers.find(item => item.name === configuredPrinter || item.displayName === configuredPrinter);
    const printerLabel = printer?.displayName || configuredPrinter || 'Automática del servidor';
    const serverName = input.workspace.server?.name || 'Servidor Principal';
    const date = requestedAt.toLocaleDateString('es-CO');
    const time = requestedAt.toLocaleTimeString('es-CO');
    const html = `<!doctype html>
<html lang="es"><head><meta charset="utf-8"><title>Prueba de impresión JOYACONTROL</title>
<style>
  *{box-sizing:border-box} body{margin:0;padding:24px;font-family:Arial,sans-serif;color:#111;background:#fff}
  .page{border:2px solid #111;padding:22px;max-width:720px;margin:0 auto}
  h1{margin:0 0 8px;font-size:30px;letter-spacing:1px} h2{margin:0 0 22px;font-size:20px;font-weight:600}
  table{width:100%;border-collapse:collapse;font-size:14px} td{border-top:1px solid #bbb;padding:8px 0;vertical-align:top}
  td:first-child{width:42%;font-weight:700}.result{margin-top:22px;padding-top:14px;border-top:2px solid #111;font-size:12px}
</style></head><body><main class="page">
<h1>JOYACONTROL</h1><h2>Prueba de impresión</h2>
<table>
<tr><td>Fecha</td><td>${escapeHtml(date)}</td></tr>
<tr><td>Hora</td><td>${escapeHtml(time)}</td></tr>
<tr><td>Nombre impresora</td><td>${escapeHtml(printerLabel)}</td></tr>
<tr><td>Servidor</td><td>${escapeHtml(serverName)}</td></tr>
<tr><td>Cliente solicitante</td><td>${escapeHtml(currentRequester.deviceName)}</td></tr>
<tr><td>Usuario</td><td>${escapeHtml(currentRequester.displayName)}</td></tr>
</table><p class="result">Si esta página salió correctamente, JOYACONTROL pudo entregar la prueba al sistema de impresión del Servidor Principal.</p>
</main></body></html>`;
    const { printerName: _printerName, ...printOptions } = input.settings;
    const request: PrintJobRequest = {
      requestId: crypto.randomUUID(),
      documentType: 'other',
      documentId: `print-test-${input.target}`,
      documentNumber: `TEST-${requestedAt.getTime()}`,
      title: 'Prueba de impresión JOYACONTROL',
      format: testFormatForPaper(input.settings.paperSize),
      contentType: 'text/html',
      contentBase64: bytesToBase64(new TextEncoder().encode(html)),
      copies: input.settings.copies,
      requester: currentRequester,
      requestedAt: requestedAt.toISOString(),
      configurationTarget: input.target,
      requestedPrinterName: configuredPrinter,
      printOptions,
      isTestPrint: true,
    };
    const submitted = await this.submit(request);
    if (input.waitForResult === false) return submitted;
    return this.waitForResult(submitted.id, input.timeoutMs);
  }

  static async waitForResult(jobId: string, timeoutMs = 60_000): Promise<PrintJobSummary> {
    const startedAt = Date.now();
    while (Date.now() - startedAt < timeoutMs) {
      const workspace = await this.getWorkspace();
      const job = workspace.jobs.find(item => item.id === jobId);
      if (job && ['completed', 'error', 'cancelled'].includes(job.status)) return job;
      await wait(400);
    }
    const workspace = await this.getWorkspace();
    const current = workspace.jobs.find(item => item.id === jobId);
    if (current) return current;
    throw new Error('PRINT_TEST_RESULT_NOT_FOUND');
  }

  static async submit(request: PrintJobRequest): Promise<PrintJobSummary> {
    return invoke(
      { action: 'submit', request },
      () => apiRepository().submitPrintJob(request),
    );
  }

  static async retry(jobId: string): Promise<PrintJobSummary> {
    return invoke({ action: 'retry', jobId }, () => apiRepository().retryPrintJob(jobId));
  }

  static async cancel(jobId: string): Promise<PrintJobSummary> {
    return invoke({ action: 'cancel', jobId }, () => apiRepository().cancelPrintJob(jobId));
  }

  static async reprint(jobId: string, suppliedRequester?: PrintRequester): Promise<PrintJobSummary> {
    const requestId = crypto.randomUUID();
    const currentRequester = suppliedRequester || requester();
    return invoke(
      { action: 'reprint', jobId, requestId, requester: currentRequester },
      () => apiRepository().reprintPrintJob(jobId, requestId, currentRequester),
    );
  }
}
