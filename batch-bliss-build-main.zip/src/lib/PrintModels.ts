export type PrintDocumentType =
  | 'invoice'
  | 'quotation'
  | 'layaway'
  | 'receipt'
  | 'payment'
  | 'expense'
  | 'purchase'
  | 'cash_close'
  | 'report'
  | 'label'
  | 'barcode'
  | 'other';

export type PrintDocumentFormat = 'letter' | 'a4' | 'ticket80' | 'ticket50' | 'label' | 'barcode';
export type PrintRoutingProfile = 'invoice' | 'ticket' | 'letter' | 'a4' | 'label' | 'barcode';
export type PrintJobStatus = 'pending' | 'printing' | 'completed' | 'error' | 'cancelled';

export type PrintConfigurationTarget =
  | 'invoiceLetter'
  | 'invoiceTicket80'
  | 'invoiceTicket58'
  | 'quotation'
  | 'report'
  | 'label'
  | 'barcode'
  | 'pdf';

export type PrintPaperSize = 'letter' | 'a4' | 'ticket80' | 'ticket58' | 'label' | 'barcode';
export type PrintOrientation = 'portrait' | 'landscape';
export type PrintMargin = 'default' | 'none' | 'printableArea';
export type PrintColorMode = 'color' | 'monochrome';

export interface PrintDocumentSettings {
  printerName: string | null;
  paperSize: PrintPaperSize;
  orientation: PrintOrientation;
  copies: number;
  silent: boolean;
  margin: PrintMargin;
  scale: number;
  colorMode: PrintColorMode;
}

export interface PrintPrinterInfo {
  name: string;
  displayName: string;
  description: string;
  status: number;
  statusLabel?: string;
  isDefault: boolean;
  available: boolean;
  offline?: boolean;
  virtual?: boolean;
  pdf?: boolean;
  xps?: boolean;
  shared?: boolean;
  local?: boolean;
  type: 'local' | 'network' | 'virtual' | 'unknown';
}

export interface PrintSpoolerInfo {
  status: 'running' | 'stopped' | 'error' | 'unknown' | 'unsupported';
  checkedAt: string;
  message: string;
}

export interface PrintServerInfo {
  name: string;
  platform: string;
}

export interface PrintConfiguration {
  defaultPrinterName: string | null;
  profilePrinters: Partial<Record<PrintRoutingProfile, string>>;
  documentPrinters: Partial<Record<PrintDocumentType, string>>;
  documentSettings: Record<PrintConfigurationTarget, PrintDocumentSettings>;
  automaticRetry: boolean;
  retryDelayMs: number;
  updatedAt: string;
}

export interface PrintRequester {
  userId: string;
  username: string;
  displayName: string;
  clientId: string;
  deviceName: string;
}

export interface PrintJobRequest {
  requestId: string;
  documentType: PrintDocumentType;
  documentId: string;
  documentNumber: string;
  title: string;
  format: PrintDocumentFormat;
  contentType: 'application/pdf' | 'text/html';
  contentBase64: string;
  copies?: number;
  requester: PrintRequester;
  requestedAt: string;
  configurationTarget?: PrintConfigurationTarget;
  requestedPrinterName?: string | null;
  printOptions?: Partial<Omit<PrintDocumentSettings, 'printerName'>>;
  isTestPrint?: boolean;
}

export interface PrintJobSummary {
  id: string;
  requestId: string;
  originalJobId: string | null;
  documentType: PrintDocumentType;
  documentId: string;
  documentNumber: string;
  title: string;
  format: PrintDocumentFormat;
  printerName: string | null;
  status: PrintJobStatus;
  attempts: number;
  requestedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  updatedAt: string;
  nextRetryAt: string | null;
  lastError: string | null;
  durationMs: number | null;
  requester: PrintRequester;
  configurationTarget?: PrintConfigurationTarget;
  isTestPrint?: boolean;
}

export interface PrintWorkspace {
  printers: PrintPrinterInfo[];
  configuration: PrintConfiguration;
  jobs: PrintJobSummary[];
  spooler?: PrintSpoolerInfo;
  server?: PrintServerInfo;
  discoveredAt?: string;
}
