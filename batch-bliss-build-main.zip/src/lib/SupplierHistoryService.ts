import type {
  Contact,
  InventoryAdjustment,
  InvoiceItem,
  Product,
  PurchaseInvoice,
} from '@/data/mockData';
import type { SupplierInvoiceView } from '@/domain/models';
import type { PurchaseDocumentRow } from '@/lib/PurchaseDocumentsService';
import {
  SupplierRelationResolver,
  hasMeaningfulSupplierName,
  normalizeSupplierName,
} from '@/lib/SupplierRelationResolver';

export type SupplierHistorySource =
  | 'purchase_document'
  | 'supplier_invoice'
  | 'inventory_adjustment';

export interface SupplierCommercialEntry {
  id: string;
  source: SupplierHistorySource;
  sourceId: string;
  documentNumber: string;
  date: string;
  total: number;
  grams: number;
  supplierId: string;
  supplierName: string;
  productIds: string[];
  productLabels: string[];
  notes: string;
}

export interface SupplierHistoryTraceability {
  productosAsociados: number;
  documentosPorSupplierId: number;
  documentosPorSupplierName: number;
  documentosPorProductos: number;
  documentosDuplicadosDescartados: number;
}

export interface SupplierHistory {
  totalInvertido: number;
  totalGramos: number;
  numeroEntradas: number;
  ultimaCompra: string;
  compras: SupplierCommercialEntry[];
  productos: Product[];
  ajustes: InventoryAdjustment[];
  facturas: PurchaseInvoice[];
  documentos: PurchaseDocumentRow[];
  cuentasPorPagar: SupplierInvoiceView[];
  trazabilidad: SupplierHistoryTraceability;
}

export interface SupplierHistoryData {
  contacts: readonly Contact[];
  /**
   * Fuente comercial primaria. Debe construirse con buildPurchaseDocumentRows,
   * igual que Compras y el Centro de documentos.
   */
  documents: readonly PurchaseDocumentRow[];
  /** Fuente complementaria usada por Cuentas por pagar. */
  supplierInvoices: readonly SupplierInvoiceView[];
  /** Respaldo histórico y catálogo; nunca son la fuente primaria de totales. */
  products: readonly Product[];
  inventoryAdjustments: readonly InventoryAdjustment[];
}

const finitePositive = (value: unknown): number => {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : 0;
};

const normalizedDate = (value: unknown): string => String(value ?? '').trim();

const dateTimestamp = (value: unknown): number => {
  const date = normalizedDate(value);
  if (!date) return Number.NEGATIVE_INFINITY;
  const parsed = new Date(/^\d{4}-\d{2}-\d{2}$/.test(date) ? `${date}T00:00:00` : date).getTime();
  return Number.isFinite(parsed) ? parsed : Number.NEGATIVE_INFINITY;
};

const normalizedToken = (value: unknown): string => normalizeSupplierName(value);
const numericToken = (value: unknown): string => finitePositive(value).toFixed(6);

const cancelledStatus = (status: unknown): boolean => [
  'cancelled', 'canceled', 'anulada', 'anulado', 'cancelada', 'cancelado',
].includes(normalizedToken(status));

const adjustmentWasReverted = (adjustment: InventoryAdjustment): boolean => {
  const historical = adjustment as InventoryAdjustment & Record<string, unknown>;
  const status = normalizedToken(historical.status ?? historical.state);
  const terminalStatuses = new Set([
    'cancelled', 'canceled', 'anulada', 'anulado', 'cancelada', 'cancelado',
    'reverted', 'reversed', 'revertida', 'revertido', 'reversada', 'reversado',
  ]);

  return terminalStatuses.has(status)
    || historical.reverted === true
    || historical.reversed === true
    || historical.cancelled === true
    || historical.isReverted === true
    || historical.isReversed === true
    || Boolean(historical.revertedAt)
    || Boolean(historical.reversedAt)
    || Boolean(historical.cancelledAt);
};

const itemTotalGrams = (item: InvoiceItem): number =>
  finitePositive(item.weightGrams) * finitePositive(item.quantity);

const itemTotalValue = (item: InvoiceItem): number =>
  finitePositive(item.subtotal)
  || (finitePositive(item.unitPrice) * finitePositive(item.quantity));

const purchaseTotalValue = (purchase: PurchaseInvoice): number => {
  const documentedTotal = finitePositive(purchase.total);
  if (documentedTotal > 0) return documentedTotal;

  const calculatedHeader = finitePositive(purchase.subtotal)
    + finitePositive(purchase.tax)
    - finitePositive(purchase.discount);
  if (calculatedHeader > 0) return calculatedHeader;

  return (Array.isArray(purchase.items) ? purchase.items : [])
    .reduce((sum, item) => sum + itemTotalValue(item), 0);
};

const adjustmentTotalGrams = (
  adjustment: InventoryAdjustment,
  product?: Product,
): number => finitePositive(adjustment.grams)
  || (finitePositive(adjustment.quantity) * finitePositive(product?.weightGrams));

const adjustmentTotalValue = (
  adjustment: InventoryAdjustment,
  grams: number,
): number => finitePositive(adjustment.totalCost)
  || (finitePositive(adjustment.unitCost) * finitePositive(adjustment.quantity))
  || (finitePositive(adjustment.valuePerGram) * grams)
  || (finitePositive(adjustment.purchasePrice) * finitePositive(adjustment.quantity));

const productReference = (item: Pick<InvoiceItem, 'productId' | 'code' | 'name'>): string =>
  normalizedToken(item.productId) || normalizedToken(item.code) || normalizedToken(item.name);

const adjustmentProductReference = (adjustment: InventoryAdjustment): string =>
  normalizedToken(adjustment.productId)
  || normalizedToken(adjustment.productCode)
  || normalizedToken(adjustment.productName);

const documentTotalGrams = (document: PurchaseDocumentRow): number =>
  (Array.isArray(document.purchase?.items) ? document.purchase.items : [])
    .reduce((sum, item) => sum + itemTotalGrams(item), 0);

const documentProductIds = (document: PurchaseDocumentRow): string[] => [...new Set(
  (Array.isArray(document.purchase?.items) ? document.purchase.items : [])
    .map(item => String(item.productId || '').trim())
    .filter(Boolean),
)];

const documentProductLabels = (document: PurchaseDocumentRow): string[] => [...new Set(
  (Array.isArray(document.purchase?.items) ? document.purchase.items : [])
    .map(item => `${item.code || ''} ${item.name || ''}`.trim())
    .filter(Boolean),
)];

const documentIdentity = (document: PurchaseDocumentRow, supplierId: string): string => [
  supplierId,
  normalizedToken(document.number),
  normalizedDate(document.date),
  numericToken(document.total),
].join('|');

const documentCanonicalKey = (document: PurchaseDocumentRow, supplierId: string): string => {
  const purchaseId = String(document.purchase?.id || '').trim();
  if (purchaseId) return `purchase:${purchaseId}`;

  const payableId = String(document.payable?.id || '').trim();
  if (payableId) return `supplier_invoice:${payableId}`;

  const legacyExpenseId = String(document.legacyExpense?.id || '').trim();
  if (legacyExpenseId) return `legacy_expense:${legacyExpenseId}`;

  const documentId = String(document.id || '').trim();
  return documentId
    ? `${document.source}:${documentId}`
    : `identity:${documentIdentity(document, supplierId)}`;
};

const payableIdentity = (payable: SupplierInvoiceView, supplierId: string): string => [
  supplierId,
  normalizedToken(payable.invoiceNumber),
  normalizedDate(payable.issueDate),
  numericToken(payable.total),
].join('|');

const invoiceLineToken = (
  supplierId: string,
  date: string,
  item: InvoiceItem,
): string => [
  supplierId,
  normalizedDate(date),
  productReference(item),
  numericToken(item.quantity),
  numericToken(itemTotalGrams(item)),
  numericToken(itemTotalValue(item)),
].join('|');

const adjustmentLineToken = (
  supplierId: string,
  adjustment: InventoryAdjustment,
  grams: number,
  total: number,
): string => [
  supplierId,
  normalizedDate(adjustment.date || adjustment.createdAt),
  adjustmentProductReference(adjustment),
  numericToken(adjustment.quantity),
  numericToken(grams),
  numericToken(total),
].join('|');

const adjustmentIdentity = (
  adjustment: InventoryAdjustment,
  supplierId: string,
  grams: number,
  total: number,
): string => [
  supplierId,
  normalizedDate(adjustment.date || adjustment.createdAt),
  adjustmentProductReference(adjustment),
  numericToken(adjustment.quantity),
  numericToken(grams),
  numericToken(total),
].join('|');

const headerValueToken = (supplierId: string, date: string, total: number): string => [
  supplierId,
  normalizedDate(date),
  numericToken(total),
].join('|');

const sortByMostRecent = <T,>(rows: T[], getDate: (row: T) => string): T[] => rows.sort((left, right) => {
  const timestampDifference = dateTimestamp(getDate(right)) - dateTimestamp(getDate(left));
  return timestampDifference || getDate(right).localeCompare(getDate(left));
});

const validCommercialDocument = (document: PurchaseDocumentRow): boolean =>
  !cancelledStatus(document.status)
  && dateTimestamp(document.date) !== Number.NEGATIVE_INFINITY
  && finitePositive(document.total) > 0;

const validSupplierInvoice = (invoice: SupplierInvoiceView): boolean =>
  !cancelledStatus(invoice.status)
  && dateTimestamp(invoice.issueDate) !== Number.NEGATIVE_INFINITY
  && finitePositive(invoice.total) > 0;

const validHistoricalAdjustment = (
  adjustment: InventoryAdjustment,
  product?: Product,
): boolean => {
  const grams = adjustmentTotalGrams(adjustment, product);
  return adjustment.type === 'increase'
    && !adjustmentWasReverted(adjustment)
    && dateTimestamp(adjustment.date || adjustment.createdAt) !== Number.NEGATIVE_INFINITY
    && grams > 0
    && adjustmentTotalValue(adjustment, grams) > 0
    && Boolean(adjustmentProductReference(adjustment));
};

/**
 * Historial comercial central de proveedores.
 *
 * La fuente primaria es exactamente la vista documental usada por Compras:
 * PurchaseDocumentsService. Las cuentas por pagar no representadas en esa
 * vista se incorporan desde supplierInvoices. Productos y ajustes se conservan
 * únicamente como respaldo histórico cuando no existe un documento comercial.
 */
export class SupplierHistoryService {
  private readonly resolver: SupplierRelationResolver;
  private readonly productsById: Map<string, Product>;

  constructor(private readonly data: SupplierHistoryData) {
    this.resolver = new SupplierRelationResolver(data.contacts, data.products);
    this.productsById = new Map(data.products.map(product => [product.id, product]));
  }

  getSupplierHistory(supplierId: string): SupplierHistory {
    const supplier = this.resolver.getSupplier(supplierId);
    if (!supplier) return this.emptyHistory();

    const productosAsociados = this.resolver.getProductsForSupplier(supplierId);
    const trazabilidad: SupplierHistoryTraceability = {
      productosAsociados: productosAsociados.length,
      documentosPorSupplierId: 0,
      documentosPorSupplierName: 0,
      documentosPorProductos: 0,
      documentosDuplicadosDescartados: 0,
    };

    const documentos: PurchaseDocumentRow[] = [];
    const seenDocumentKeys = new Set<string>();
    const seenDocumentIdentities = new Set<string>();

    this.data.documents.forEach(document => {
      if (!validCommercialDocument(document)) return;

      const direct = this.resolveDocumentSupplierDirect(document);
      const productMatch = Boolean(
        document.purchase
        && this.resolver.purchaseContainsSupplierProduct(document.purchase, supplierId),
      );

      let relation: 'supplier-id' | 'supplier-name' | 'products' | null = null;
      if (direct) {
        if (direct.supplier.id !== supplierId) return;
        relation = direct.source;

        // La misma factura puede coincidir también por sus productos. La
        // relación directa es autoritativa y la segunda ruta se descarta.
        if (productMatch) trazabilidad.documentosDuplicadosDescartados += 1;
      } else if (this.documentHasSupplierReference(document)) {
        // Si el documento conserva proveedor, aunque ya no pueda resolverse,
        // no debe reasignarse silenciosamente a otro proveedor por producto.
        return;
      } else if (productMatch) {
        relation = 'products';
      } else {
        return;
      }

      const key = documentCanonicalKey(document, supplierId);
      const identity = documentIdentity(document, supplierId);
      if (seenDocumentKeys.has(key) || seenDocumentIdentities.has(identity)) {
        trazabilidad.documentosDuplicadosDescartados += 1;
        return;
      }

      seenDocumentKeys.add(key);
      seenDocumentIdentities.add(identity);
      documentos.push(document);

      if (relation === 'supplier-id') trazabilidad.documentosPorSupplierId += 1;
      if (relation === 'supplier-name') trazabilidad.documentosPorSupplierName += 1;
      if (relation === 'products') trazabilidad.documentosPorProductos += 1;
    });

    const representedPayableIds = new Set(
      documentos.map(document => document.payable?.id).filter((id): id is string => Boolean(id)),
    );
    const representedPayableSourceIds = new Set(
      documentos
        .flatMap(document => [document.id, document.purchase?.id, document.payable?.sourceId])
        .filter((id): id is string => Boolean(id)),
    );

    const cuentasPorPagar: SupplierInvoiceView[] = [];
    const payableFallbacks: SupplierInvoiceView[] = [];
    const seenPayableIds = new Set<string>();
    const seenPayableIdentities = new Set<string>();

    this.data.supplierInvoices.forEach(payable => {
      const resolution = this.resolveSupplier(payable.supplierId, payable.supplierName);
      if (!resolution || resolution.id !== supplierId || !validSupplierInvoice(payable)) return;

      if (!seenPayableIds.has(payable.id)) {
        seenPayableIds.add(payable.id);
        cuentasPorPagar.push(payable);
      }

      const represented = representedPayableIds.has(payable.id)
        || Boolean(payable.sourceId && representedPayableSourceIds.has(payable.sourceId));
      const identity = payableIdentity(payable, supplierId);
      if (represented || seenDocumentIdentities.has(identity) || seenPayableIdentities.has(identity)) {
        trazabilidad.documentosDuplicadosDescartados += 1;
        return;
      }

      seenPayableIdentities.add(identity);
      payableFallbacks.push(payable);
    });

    const invoiceLineCounts = new Map<string, number>();
    documentos.forEach(document => {
      if (!document.purchase) return;
      document.purchase.items.forEach(item => {
        const token = invoiceLineToken(supplierId, document.date, item);
        invoiceLineCounts.set(token, (invoiceLineCounts.get(token) ?? 0) + 1);
      });
    });

    const documentHeaderCounts = new Map<string, number>();
    documentos.forEach(document => {
      const token = headerValueToken(supplierId, document.date, document.total);
      documentHeaderCounts.set(token, (documentHeaderCounts.get(token) ?? 0) + 1);
    });
    payableFallbacks.forEach(payable => {
      const token = headerValueToken(supplierId, payable.issueDate, payable.total);
      documentHeaderCounts.set(token, (documentHeaderCounts.get(token) ?? 0) + 1);
    });

    const adjustmentCandidates: Array<{
      adjustment: InventoryAdjustment;
      grams: number;
      total: number;
    }> = [];
    const seenAdjustmentIds = new Set<string>();
    const seenAdjustmentIdentities = new Set<string>();

    this.data.inventoryAdjustments.forEach(adjustment => {
      const resolution = this.resolver.resolveAdjustment(adjustment);
      const product = this.productsById.get(adjustment.productId);
      if (!resolution || resolution.supplierId !== supplierId || !validHistoricalAdjustment(adjustment, product)) return;

      const grams = adjustmentTotalGrams(adjustment, product);
      const total = adjustmentTotalValue(adjustment, grams);
      const id = String(adjustment.id || '').trim();
      const identity = adjustmentIdentity(adjustment, supplierId, grams, total);
      if ((id && seenAdjustmentIds.has(id)) || seenAdjustmentIdentities.has(identity)) return;

      const lineToken = adjustmentLineToken(supplierId, adjustment, grams, total);
      const duplicateLineCount = invoiceLineCounts.get(lineToken) ?? 0;
      if (duplicateLineCount > 0) {
        invoiceLineCounts.set(lineToken, duplicateLineCount - 1);
        return;
      }

      if (id) seenAdjustmentIds.add(id);
      seenAdjustmentIdentities.add(identity);
      adjustmentCandidates.push({ adjustment, grams, total });
    });

    // Cuando varios ajustes históricos representan las líneas de un documento
    // comercial, su suma por fecha/valor se descarta como respaldo duplicado.
    const candidatesByDate = new Map<string, typeof adjustmentCandidates>();
    adjustmentCandidates.forEach(candidate => {
      const date = normalizedDate(candidate.adjustment.date || candidate.adjustment.createdAt);
      const rows = candidatesByDate.get(date) ?? [];
      rows.push(candidate);
      candidatesByDate.set(date, rows);
    });

    const ajustes: InventoryAdjustment[] = [];
    const retainedAdjustments: typeof adjustmentCandidates = [];
    candidatesByDate.forEach((candidates, date) => {
      const total = candidates.reduce((sum, candidate) => sum + candidate.total, 0);
      const headerToken = headerValueToken(supplierId, date, total);
      const duplicateHeaderCount = documentHeaderCounts.get(headerToken) ?? 0;
      if (duplicateHeaderCount > 0) {
        documentHeaderCounts.set(headerToken, duplicateHeaderCount - 1);
        return;
      }
      candidates.forEach(candidate => {
        ajustes.push(candidate.adjustment);
        retainedAdjustments.push(candidate);
      });
    });

    const compras: SupplierCommercialEntry[] = [
      ...documentos.map(document => this.documentEntry(document, supplierId, supplier.name)),
      ...payableFallbacks.map(payable => this.payableEntry(payable, supplierId, supplier.name)),
      ...retainedAdjustments.map(({ adjustment, grams, total }) => this.adjustmentEntry(
        adjustment,
        supplierId,
        supplier.name,
        grams,
        total,
      )),
    ];

    sortByMostRecent(compras, entry => entry.date);
    sortByMostRecent(documentos, document => document.date);
    sortByMostRecent(cuentasPorPagar, payable => payable.issueDate);
    sortByMostRecent(ajustes, adjustment => adjustment.date || adjustment.createdAt);

    const facturas = documentos
      .map(document => document.purchase)
      .filter((purchase): purchase is PurchaseInvoice => Boolean(purchase));

    const productIds = new Set<string>();
    this.data.products.forEach(product => {
      if (this.resolver.isProductRelatedToSupplier(product, supplierId)) productIds.add(product.id);
    });
    compras.forEach(entry => entry.productIds.forEach(productId => productIds.add(productId)));

    const productos = [...productIds]
      .map(productId => this.productsById.get(productId))
      .filter((product): product is Product => Boolean(product))
      .sort((left, right) => left.name.localeCompare(right.name, 'es'));

    return {
      totalInvertido: compras.reduce((sum, entry) => sum + entry.total, 0),
      totalGramos: compras.reduce((sum, entry) => sum + entry.grams, 0),
      numeroEntradas: compras.length,
      ultimaCompra: compras[0]?.date ?? '',
      compras,
      productos,
      ajustes,
      facturas,
      documentos,
      cuentasPorPagar,
      trazabilidad,
    };
  }

  hasCommercialHistory(supplierId: string): boolean {
    return this.getSupplierHistory(supplierId).compras.length > 0;
  }

  private resolveSupplier(supplierId: unknown, supplierName: unknown): Contact | null {
    return this.resolver.getSupplier(String(supplierId || '').trim())
      ?? this.resolver.resolveName(supplierName);
  }

  private resolveDocumentSupplierDirect(document: PurchaseDocumentRow): {
    supplier: Contact;
    source: 'supplier-id' | 'supplier-name';
  } | null {
    const explicitId = String(document.supplierId || document.purchase?.supplierId || '').trim();
    const explicit = this.resolver.getSupplier(explicitId);
    if (explicit) return { supplier: explicit, source: 'supplier-id' };

    const supplierName = document.supplierName || document.purchase?.supplierName || '';
    const byName = this.resolver.resolveName(supplierName);
    return byName ? { supplier: byName, source: 'supplier-name' } : null;
  }

  private documentHasSupplierReference(document: PurchaseDocumentRow): boolean {
    if (document.purchase) return this.resolver.hasPurchaseSupplierReference(document.purchase);
    return Boolean(String(document.supplierId || '').trim())
      || hasMeaningfulSupplierName(document.supplierName);
  }

  private documentEntry(
    document: PurchaseDocumentRow,
    supplierId: string,
    fallbackSupplierName: string,
  ): SupplierCommercialEntry {
    return {
      id: `purchase_document:${document.source}:${document.id || documentIdentity(document, supplierId)}`,
      source: 'purchase_document',
      sourceId: document.id,
      documentNumber: document.number || 'Documento',
      date: document.date,
      total: finitePositive(document.total),
      grams: this.getDocumentTotalGrams(document),
      supplierId,
      supplierName: hasMeaningfulSupplierName(document.supplierName)
        ? document.supplierName
        : fallbackSupplierName,
      productIds: documentProductIds(document),
      productLabels: documentProductLabels(document),
      notes: document.purchase?.description || document.concept || '',
    };
  }

  private getDocumentTotalGrams(document: PurchaseDocumentRow): number {
    return (Array.isArray(document.purchase?.items) ? document.purchase.items : [])
      .reduce((sum, item) => {
        const product = this.resolver.resolveInvoiceItemProduct(item);
        const unitWeight = finitePositive(item.weightGrams)
          || finitePositive(product?.weightGrams);
        return sum + (unitWeight * finitePositive(item.quantity));
      }, 0);
  }

  private payableEntry(
    payable: SupplierInvoiceView,
    supplierId: string,
    fallbackSupplierName: string,
  ): SupplierCommercialEntry {
    return {
      id: `supplier_invoice:${payable.id || payableIdentity(payable, supplierId)}`,
      source: 'supplier_invoice',
      sourceId: payable.id,
      documentNumber: payable.invoiceNumber || 'Cuenta por pagar',
      date: payable.issueDate,
      total: finitePositive(payable.total),
      grams: 0,
      supplierId,
      supplierName: payable.supplierName || fallbackSupplierName,
      productIds: [],
      productLabels: [],
      notes: payable.notes || '',
    };
  }

  private adjustmentEntry(
    adjustment: InventoryAdjustment,
    supplierId: string,
    fallbackSupplierName: string,
    grams: number,
    total: number,
  ): SupplierCommercialEntry {
    return {
      id: `inventory_adjustment:${adjustment.id || adjustmentIdentity(adjustment, supplierId, grams, total)}`,
      source: 'inventory_adjustment',
      sourceId: adjustment.id,
      documentNumber: adjustment.productCode
        ? `Entrada ${adjustment.productCode}`
        : 'Entrada de inventario',
      date: adjustment.date || adjustment.createdAt,
      total,
      grams,
      supplierId,
      supplierName: adjustment.supplierName || fallbackSupplierName,
      productIds: adjustment.productId ? [adjustment.productId] : [],
      productLabels: [
        `${adjustment.productCode || ''} ${adjustment.productName || ''}`.trim(),
      ].filter(Boolean),
      notes: adjustment.notes || '',
    };
  }

  private emptyHistory(): SupplierHistory {
    return {
      totalInvertido: 0,
      totalGramos: 0,
      numeroEntradas: 0,
      ultimaCompra: '',
      compras: [],
      productos: [],
      ajustes: [],
      facturas: [],
      documentos: [],
      cuentasPorPagar: [],
      trazabilidad: {
        productosAsociados: 0,
        documentosPorSupplierId: 0,
        documentosPorSupplierName: 0,
        documentosPorProductos: 0,
        documentosDuplicadosDescartados: 0,
      },
    };
  }
}

export const createSupplierHistoryService = (data: SupplierHistoryData): SupplierHistoryService =>
  new SupplierHistoryService(data);

export {
  adjustmentWasReverted,
  adjustmentTotalGrams,
  adjustmentTotalValue,
  documentTotalGrams,
  itemTotalGrams,
  purchaseTotalValue,
  validCommercialDocument,
  validHistoricalAdjustment,
  validSupplierInvoice,
};
