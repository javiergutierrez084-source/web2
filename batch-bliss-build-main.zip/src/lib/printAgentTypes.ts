export type PrintOrientation = 'portrait' | 'landscape';
export type PrintContentKind = 'html' | 'pdf';

export const PRINT_DOCUMENT_TYPES = [
  'Facturas Carta',
  'Factura Térmica 80',
  'Factura Térmica 58',
  'Cotización',
  'Reporte',
  'Etiqueta',
  'Código de barras',
  'PDF',
] as const;

export type PrintDocumentType = (typeof PRINT_DOCUMENT_TYPES)[number];

export interface PrintDocumentContent {
  kind: PrintContentKind;
  data: string;
}

export interface PrintDocumentRequest {
  documentType: PrintDocumentType;
  content: PrintDocumentContent;
  clientId?: string;
  userId?: string;
}

export interface PrintExecutionResult {
  success: true;
  documentType: PrintDocumentType;
  printerName: string;
  clientId: string;
  userId: string;
  printedAt: string;
}

export interface PrintTypeSettings {
  printerName: string;
  orientation: PrintOrientation;
  copies: number;
  paper: string;
  scale: number;
  silent: boolean;
}

export type PrintSettingsMap = Record<PrintDocumentType, PrintTypeSettings>;

export interface PrintAgentPrinter {
  name: string;
  displayName?: string;
  description?: string;
  status?: number;
  isDefault?: boolean;
}

export interface PrintSettingsWorkspace {
  documentTypes: PrintDocumentType[];
  settings: PrintSettingsMap;
  printers: PrintAgentPrinter[];
}

export interface PrintTestRequest {
  documentType: PrintDocumentType;
}

export interface PrintTestResult {
  success: true;
  documentType: PrintDocumentType;
  printerName: string;
}
